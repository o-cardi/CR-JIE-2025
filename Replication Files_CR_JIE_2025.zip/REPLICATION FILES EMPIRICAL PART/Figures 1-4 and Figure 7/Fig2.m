fileinput   = fullfile(pathin,'empirical results.xlsx');
dataLP      = readmatrix(fileinput,'Sheet','Fig2','Range','B02:F89');
namevars    = char('ZA','ZHZN','CA','TOT','L','LN','LHL','PNPH');
nameshock   = char('AGG'); 
maxvalue    = [ 1.50  2.25  0.03  0.50  0.25  0.25  0.10  2.75];
minvalue    = [-0.50 -0.50 -0.07 -2.75 -0.70 -0.50 -0.15 -0.50];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=01:08
k0          = (i-1)*11+1; 
k1          = k0+10;
data        = dataLP(k0:k1,01:05);
[obs,nbvar] = size(data); 
irf         = data(1:obs,2);       % IRF 
lowerb90    = data(1:obs,1);       % lower bound of IRF (confidence level: 90%) 
upperb90    = data(1:obs,3);       % upper bound of IRF (confidence level: 90%) 
lowerb68    = data(1:obs,4);       % lower bound of IRF (confidence level: 68%) 
upperb68    = data(1:obs,5);       % upper bound of IRF (confidence level: 68%) 
time        = 0:obs-1; 
line_x      = zeros(1,obs);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
hold on;   
area90   = [lowerb90(1:obs)',fliplr(upperb90(1:obs)')];
area68   = [lowerb68(1:obs)',fliplr(upperb68(1:obs)')];
xpoints  = [time(1:obs),fliplr(time(1:obs))];
p1       = patch(xpoints,area90,[1 1 1]*0.90,'LineStyle','non');   
p2       = patch(xpoints,area68,[1 1 1]*0.80,'LineStyle','non');
p3       = plot(time(1:obs),irf(1:obs),'blue','LineWidth',3);
p4       = plot(time(1:obs),line_x(1:obs),'LineWidth',0.1,'Color',[0.45 0.45 0.45]);
axis([-.05 obs-0.95 minvalue(i) maxvalue(i)]);
set(gca,'FontSize',12)
box on;
filename = ['Figure2_' deblank(namevars(i,:)) '.eps']; saveas(gcf,fullfile(pathout,filename),'epsc');
end
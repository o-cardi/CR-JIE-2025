fileinput   = fullfile(pathin,'empirical results.xlsx');
data        = readmatrix(fileinput,'Sheet','Fig4','Range','B02:F134'); 
namevars    = char('L','PN','LN','TOT','LH');
maxvalue    = [ 0.10  2.00  0.05  0.10  0.075];
minvalue    = [-0.50 -0.10 -0.25 -2.25 -0.175];
norm        = [ 1.00  1.00 0.634  1.00  0.366];
normZA      = data(01:19,02);
dataLP      = data(20:114,:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=01:05
k0          = (i-1)*19+1; 
k1          = k0+18;
datavar     = dataLP(k0:k1,01:05);
[obs,nbvar] = size(datavar); 
irf         = (datavar(1:obs,2)./normZA(1:obs))*norm(i);  % IRF at time t = 0 
lowerb90    = (datavar(1:obs,1)./normZA(1:obs))*norm(i);  % lower bound of IRF (confidence level: 90%) 
upperb90    = (datavar(1:obs,3)./normZA(1:obs))*norm(i);  % upper bound of IRF (confidence level: 90%) 
lowerb68    = (datavar(1:obs,4)./normZA(1:obs))*norm(i);  % lower bound of IRF (confidence level: 68%) 
upperb68    = (datavar(1:obs,5)./normZA(1:obs))*norm(i);  % upper bound of IRF (confidence level: 68%) 
time        = 1999:2017; 
line_x      = zeros(1,obs);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
hold on;   
area90   = [lowerb90(1:obs)',fliplr(upperb90(1:obs)')];
area68   = [lowerb68(1:obs)',fliplr(upperb68(1:obs)')];
xpoints  = [time(1:obs),fliplr(time(1:obs))];
p1       = patch(xpoints,area90,[1 1 1]*0.90,'LineStyle','non');   
p2       = patch(xpoints,area68,[1 1 1]*0.80,'LineStyle','non');
p3       = plot(time(1:obs)',irf(1:obs),'blue','LineWidth',3);
p4       = plot(time(1:obs)',line_x(1:obs),'LineWidth',0.1,'Color',[0.45 0.45 0.45]);
hold off;
axis([time(1)-.15 time(obs)+0.15 minvalue(i) maxvalue(i)]);
set(gca,'FontSize',12)
box on;
filename = ['Figure4_' deblank(namevars(i,:)) '.eps']; saveas(gcf,fullfile(pathout,filename),'epsc');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dataFEVD      = data(115:133,2);
figure
hold on;   
p5       = plot(time(1:obs)',dataFEVD(1:obs),'blue','LineWidth',3);
p6       = plot(time(1:obs)',line_x(1:obs),'LineWidth',0.1,'Color',[0.45 0.45 0.45]);
hold off;
axis([time(1)-.15 time(obs)+0.15 0.00 0.40]);
set(gca,'FontSize',12)
box on;
filename = 'Figure4_FEVD.eps'; saveas(gcf,fullfile(pathout,filename),'epsc');
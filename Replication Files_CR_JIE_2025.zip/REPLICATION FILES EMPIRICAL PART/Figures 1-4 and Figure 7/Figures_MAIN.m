clear global; clc; close all; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathin  = fullfile('C:\Users\restout5\Desktop\replication files JIE2025\Empirical results',filesep);
pathout = fullfile('C:\Users\restout5\Desktop\replication files JIE2025\Figures\Files_eps',filesep);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fig1;
% Fig2;
% Fig3;
  Fig4;
% Fig7;
fileinput   = fullfile(pathin,'empirical results.xlsx');
dataLP1     = readmatrix(fileinput,'Sheet','Fig3','Range','B02:F89'); % Asymmetric TFP shocks
dataLP2     = readmatrix(fileinput,'Sheet','Fig3','Range','L02:P89'); % Symmetric TFP shocks
namevars    = char('ZA','ZHZN','PN','TOT','L','LN','LHL','FBTCH');
nameshock   = char('AGG'); 
maxvalue    = [ 2.00  4.50  1.75  0.50  0.75  0.70  0.25  7.00];
minvalue    = [-0.10 -0.75 -1.00 -4.25 -1.00 -0.70 -0.25 -6.00];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=01:08
k0          = (i-1)*11+1; 
k1          = k0+10;
data1       = dataLP1(k0:k1,01:05);
data2       = dataLP2(k0:k1,01:05);
[obs,nbvar] = size(data1); 
irf1        = data1(1:obs,2);       % IRF - Asymmetric TFP shocks
lowerb901   = data1(1:obs,1);       % lower bound of IRF (confidence level: 90%) - Asymmetric TFP shocks
upperb901   = data1(1:obs,3);       % upper bound of IRF (confidence level: 90%) - Asymmetric TFP shocks
lowerb681   = data1(1:obs,4);       % lower bound of IRF (confidence level: 68%) - Asymmetric TFP shocks 
upperb681   = data1(1:obs,5);       % upper bound of IRF (confidence level: 68%) - Asymmetric TFP shocks 
irf2        = data2(1:obs,2);       % IRF - Symmetric TFP shocks
lowerb902   = data2(1:obs,1);       % lower bound of IRF (confidence level: 90%) - Symmetric TFP shocks
upperb902   = data2(1:obs,3);       % upper bound of IRF (confidence level: 90%) - Symmetric TFP shocks
lowerb682   = data2(1:obs,4);       % lower bound of IRF (confidence level: 68%) - Symmetric TFP shocks 
upperb682   = data2(1:obs,5);       % upper bound of IRF (confidence level: 68%) - Symmetric TFP shocks 
time        = 0:obs-1; 
line_x      = zeros(1,obs);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
hold on;   
area901     = [upperb901(1:obs)',fliplr(lowerb901(1:obs)')];
area681     = [upperb681(1:obs)',fliplr(lowerb681(1:obs)')];
area902     = [upperb902(1:obs)',fliplr(lowerb902(1:obs)')];
area682     = [upperb682(1:obs)',fliplr(lowerb682(1:obs)')];
xpoints     = [time(1:nptsvar),fliplr(time(1:nptsvar))];
p1          =  patch(xpoints,area902,c2,'LineStyle','non','FaceAlpha',0.3); 
p2          =  patch(xpoints,area682,c2,'LineStyle','non','FaceAlpha',0.5); 
p3          =  patch(xpoints,area901,c1,'LineStyle','non','FaceAlpha',0.3); 
p4          =  patch(xpoints,area681,c1,'LineStyle','non','FaceAlpha',0.5);
p5          =  plot(time(1:obs),irf1(1:obs),'red','LineWidth',2,'LineStyle',"--");
p6          =  plot(time(1:obs),irf2(1:obs),'blue','LineWidth',2);
p7          =  plot(time(1:obs),line_x(1:obs),'LineWidth',0.1,'Color',[0.45 0.45 0.45]);
legend([p5 p6],{'ASYM','SYM'},'Location','best','interpreter','latex','FontSize',12);
axis([-.05 obs-0.95 minvalue(i) maxvalue(i)]);
set(gca,'FontSize',12)
box on;
filename = ['Figure3_' deblank(namevars(i,:)) '.eps']; saveas(gcf,fullfile(pathout,filename),'epsc');
end
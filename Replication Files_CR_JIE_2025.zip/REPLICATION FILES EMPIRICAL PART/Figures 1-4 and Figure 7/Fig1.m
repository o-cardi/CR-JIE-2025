fileinput   = fullfile(pathin,'empirical results.xlsx');
dataLP1     = readmatrix(fileinput,'Sheet','Fig1','Range','C03:G13'); % 1970 - 1992
dataLP2     = readmatrix(fileinput,'Sheet','Fig1','Range','I03:M13'); % 1993 - 2017
[obs,nbvar] = size(dataLP1);
time        = 0:obs-1; 
line_x      = zeros(1,obs);
c1          = [0.93 0.75 0.75]; % pink
c2          = [0.39 0.68 0.93]; % blue
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
irf1        = dataLP1(1:obs,2);  % IRF   
lowerb901   = dataLP1(1:obs,1);  % lower bound of IRF (confidence level: 90%)
upperb901   = dataLP1(1:obs,3);  % upper bound of IRF (confidence level: 90%) 
lowerb681   = dataLP1(1:obs,4);  % lower bound of IRF (confidence level: 68%)
upperb681   = dataLP1(1:obs,5);  % upper bound of IRF (confidence level: 68%) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
irf2        = dataLP2(1:obs,2);  % IRF 
lowerb902   = dataLP2(1:obs,1);  % lower bound of IRF (confidence level: 90%)
upperb902   = dataLP2(1:obs,3);  % upper bound of IRF (confidence level: 90%)
lowerb682   = dataLP2(1:obs,4);  % lower bound of IRF (confidence level: 68%)
upperb682   = dataLP2(1:obs,5);  % upper bound of IRF (confidence level: 68%)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
hold on;   
area901     = [upperb901(1:obs)',fliplr(lowerb901(1:obs)')];
area681     = [upperb681(1:obs)',fliplr(lowerb681(1:obs)')];
area902     = [upperb902(1:obs)',fliplr(lowerb902(1:obs)')];
area682     = [upperb682(1:obs)',fliplr(lowerb682(1:obs)')];
xpoints     = [time(1:nptsvar),fliplr(time(1:nptsvar))];
p1          =  patch(xpoints,area902,c2,'LineStyle','non','FaceAlpha',0.3); 
p2          =  patch(xpoints,area682,c2,'LineStyle','non','FaceAlpha',0.5); 
p3          =  patch(xpoints,area901,c1,'LineStyle','non','FaceAlpha',0.3); 
p4          =  patch(xpoints,area681,c1,'LineStyle','non','FaceAlpha',0.5); 
p5          =  plot(time(1:obs),irf1(1:obs),'red','LineWidth',2,'LineStyle',"--");
p6          =  plot(time(1:obs),irf2(1:obs),'blue','LineWidth',2);
p7          =  plot(time(1:obs),line_x(1:obs),'LineWidth',0.1,'Color',[0.45 0.45 0.45]);
legend([p5 p6],{'$1970 - 1992$','$1993 - 2017$'},'Location','southwest','interpreter','latex','FontSize',12);
axis([-.05 obs-0.95  -1 0.6]);
box on;   
set(gca,'FontSize',12);
filename = 'Figure1.eps'; saveas(gcf,fullfile(pathout,filename),'epsc');
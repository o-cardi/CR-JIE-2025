Data and Replication Codes for 'Why Hours Worked Decline Less After Technology Shocks?' 
by Olivier Cardi and Romain Restout, April 2025.

The software for Figures 1, 2, 3, 4 and 7 is RATS Pro 10.0. All figures are computed with in Matlab R2020a. Figures are generated in EPS format.
Figures files are automatically saved in the subfolder Files_eps.

Sample: 17 OECD countries, 1970-2017, annual data.

Step 1 (Folder: Empirical results):
- run SVAR_identification.rpf: estimate panel SVAR models to identify shocks to utilization-adjusted 1) aggregate TFP, 2) asymmetric TFP and 3) symmetric TFP.
It generates an Excel file (database_epsilonZ.xlsx) which contains time series for the three above structural shocks.
- run IRF_LP_Fig1.rpf: estimate the IRF of hours to an utilization-adjusted aggregate TFP for the 2 subperiods (1970-1992 and 1993-2017).
- run IRF_LP_Fig2.rpf: estimate the IRFs of main variables (1970-2017) to an utilization-adjusted aggregate TFP shock.
- run IRF_LP_Fig3.rpf: estimate the IRFs of main variables (1970-2017) to asymmetric and symmetric utilization-adjusted TFP shocks.
- run IRF_LP_Fig4.rpf: estimate the IRFs of main variables (rolling windows) to an utilization-adjusted aggregate TFP shock.
- run FEVD_Fig4.rpf: estimate the Forecast Error Variance Decomposition (rolling windows) in the baseline SVAR model.
- run IRF_LP_Fig7.rpf: estimate the IRFs of additional variables (rolling windows) to an utilization-adjusted aggregate TFP shock.

All empirical results are stored in the Excel file empirical results.xlsx.

Step 2 (Folder: Figures): 
- run Figures_MAIN.m : generate Figure 1, Figure 2 (a) to (h), Figure 3 (a) to (h), Figure 4 (a) to (f) and Figure 7 (a) to (e)




 
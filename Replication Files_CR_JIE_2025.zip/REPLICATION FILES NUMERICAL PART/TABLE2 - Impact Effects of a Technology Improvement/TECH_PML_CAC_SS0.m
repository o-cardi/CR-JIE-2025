function g = TECH_PML_CAC_SS0(x)

global sigma phi varphi 
global gammaL sigmaL phiI varphiI
global r deltaK omegaG omegaGN
global ZT ZN thetaT thetaN kappa
global B0 K0  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    VARAIABLES of the MODEL                      %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kT      = x(3)  ; % Capital-labor ratio in sector T
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LT      = x(6) ; % Labor in sector T
LN      = x(7) ; % Labor in sector N 
P       = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
B       = x(10) ; % Stock of Traded Bonds
CN      = x(11) ; % Consumption in non tradables 
CT      = x(12) ; % Consumption in tradables 
PC      = x(13) ; % Consumption price index
alphaC  = x(14) ; % Tradable share of consumption - alphaC
IN      = x(15) ; % Non tradable investment
IT      = x(16) ; % Tradable investment 
PI      = x(17) ; % Investment price index
alphaI  = x(18) ; % Tradable share of investment 
GT      = x(19) ; % Government spending in tradables
GN      = x(20) ; % Government spending in non tradables 
YT      = x(21) ; % Output in sector T 
YN      = x(22) ; % Output in sector N 
VL      = x(23) ; % Labor disutility
lambda  = x(24) ; % Intertemporal Solvency Condition   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    STEADY STATE of the MODEL                    %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
% Aggregate Consumption -  C
g(1)= (C^(-sigma))*(VL^sigma) - (PC*lambda);

% Aggregate labor supply - L
g(2)= (C^(1-sigma))*sigma*gammaL*(L^(1/sigmaL))*(VL^(sigma-1)) - (lambda*W);

% equality of marginal product of capital across the two sectors  - kT and
% kN
g(3)= ZT*(1-thetaT)*(kT^(-thetaT)) -  P*ZN*(1-thetaN)*(kN^(-thetaN));

% Wage rate in sector T  - kT and kN
g(4)= ZT*thetaT*(kT^(1-thetaT)) - P*ZN*thetaN*(kN^(1-thetaN));

% Aggregate wage index  - W
g(5)= W - ZT*thetaT*(kT^(1-thetaT));

% sectoral labor allocation  - LT and LN 
g(6)= (LT+LN) - L;

% sectoral capital allocation  -  LT and LN - 
g(7)= (LT*kT) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate  
g(8)= P*ZN*(1-thetaN)*(kN^(-thetaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - GN - IN;

% Traded good market clearing condition - B
g(10)= (r*B) + YT - CT - GT - IT;

% Consumption in non tradables - CN
g(11)= CN - C*(1-varphi)*(P/PC)^(-phi);

% Consumption in tradables - CT 
g(12)= CT - C*varphi*(1/PC)^(-phi);

% Consumption price index - PC
g(13)= PC - (varphi+(1-varphi)*P^(1-phi))^(1/(1-phi));

% Tradable share of consumption - alphaC
g(14)= alphaC - (varphi*(1/PC)^(1-phi));

% Non tradable Investment - IN
g(15)= IN - (deltaK*K)*(1-varphiI)*((P/PI)^(-phiI));

% Tradable Investment - IT 
g(16)= IT - (deltaK*K)*varphiI*((1/PI)^(-phiI));

% Investment price index - PI
g(17)= PI - (varphiI+(1-varphiI)*P^(1-phiI))^(1/(1-phiI));

% Tradable share of investment - alphaI
g(18)= alphaI - (varphiI*(1/PI)^(1-phiI));

% Total government spending - GT
g(19)= (GT+(P*GN)) - omegaG*(YT + (P*YN)); 

% Non tradable share of government spending 
g(20)= (P*GN) - omegaGN*(GT+(P*GN)); 

% Output per worker in the traded sector - YT
g(21)= YT - ZT*LT*(kT^(1-thetaT)); 

% Output per worker in the non traded sector - YN
g(22)= YN - ZN*LN*(kN^(1-thetaN));

% Desutility from labor
g(23)= VL - ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) ); % Desutility labor

% Non Sep preferences Shimer (2009)
%VL        = ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );
V_L       = (sigma-1)*gammaL*L^(1/sigmaL);
V_LL      = (sigma-1)*(gammaL/sigmaL)*(L^((1/sigmaL)-1)); 
U_C       =  (C^(-sigma))*(VL^sigma); 
U_CC      = -sigma*(C^(-sigma-1))*(VL^sigma); 
U_L       = ( (C^(1-sigma))*sigma*V_L*(VL^(sigma-1)) )/(1-sigma); 
U_LL      = U_L*( (V_LL/V_L) + (sigma-1)*V_L*(VL^(-1)) ); 
U_CL      = (C^(-sigma))*sigma*V_L*(VL^(sigma-1));
U_LC      = U_CL; 

% Solutions C=C(lambda,PN,PH,W); L=L(lambda,PN,PH,W)                      
a11 = (U_CC/U_C);                                                         
a12 = (U_CL/U_C);                                                         
a21 = (U_LC/U_L);                                                         
a22 = (U_LL/U_L);                                                         
                                                                          
% PN, PH, W, lambda                                                            
b11 = (1-alphaC)/P;                                                                                                        
b12 = 0; 
b13 = (1/lambda); 
                                                                          
b21 = 0;                                                                                                                                   
b22 = (1/W);   
b23 = (1/lambda); 
                                                                          
A1 = [a11 a12; a21 a22];                                                  
B1 = [b11 b12 b13; b21 b22 b23];                                          
JST1 = inv(A1);                                                           
MST1 = JST1*B1;                                                           
C_1P = MST1(1,1); C_W = MST1(1,2); C_1lambda = MST1(1,3);                  
L_1P = MST1(2,1); L_W = MST1(2,2); L_1lambda = MST1(2,3);

% Intermediate solution for CN, CT - Cj=Cj(lambda,P,W)                      
CN_1P = -(CN/P)*(alphaC*phi) + (CN/C)*C_1P;                                                                              
CN_W  = (CN/C)*C_W;                                                                                                                              
                                                                                        
CT_1P = (CT/P)*phi*(1-alphaC) + (CT/C)*C_1P;                                                  
CT_W  = (CT/C)*C_W;                                                
 
% Solutions for kj=kj(P,Zj)
d11 = -(thetaT/kT); 
d12 = (thetaN/kN);
d21 = (1-thetaT)/kT; 
d22 = -(1-thetaN)/kN;  

e11 = (1/P); 
e21 = (1/P); 

M2 = [d11 d12; d21 d22];
X2 = [e11; e21];
JST2 = inv(M2);
MST2 = JST2*X2;
kT_P = MST2(1,1); 
kN_P = MST2(2,1); 

% Solution for W=W(P,ZT,ZN), L=L(lambda,P,ZT,ZN)
W_P  = (1-thetaT)*(W/kT)*kT_P;   
L_P   = L_1P + (L_W*W_P);

% Solution for Cj(lambda,P,ZT,ZN)
CN_P     = CN_1P + (CN_W*W_P);
CT_P     = CT_1P + (CT_W*W_P);     
           
% Solutions for Lj=Lj(K,P)
Psi_P  = ( (LT*kT_P) + (LN*kN_P) ); 

f11 = 1; 
f12 = 1;  
f21 = kT; 
f22 = kN;

g11 = 0; 
g12 = L_P;
g21 = 1; 
g22 = -Psi_P; 

M3 = [f11 f12; f21 f22];
X3 = [g11 g12; g21 g22];
JST3 = inv(M3);
MST3 = JST3*X3;
LT_1K = MST3(1,1); LT_P = MST3(1,2);    
LN_1K = MST3(2,1); LN_P = MST3(2,2); 

% Solutions for sectoral sectoral output Yj=Yj(K,P,ZT,ZN)
YT_P = YT*( (LT_P/LT) + (1-thetaT)*(kT_P/kT) ); 
YT_1K = YT*(LT_1K/LT); 

YN_P = YN*( (LN_P/LN) + (1-thetaN)*(kN_P/kN) ); 
YN_1K = YN*(LN_1K/LN); 

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution                            
v_1Q = 1/(kappa*PI);                                                                                  
v_P  = - (1-alphaI)/(kappa*P);                                                                        
                                                                                                      
% Solution for J = J(K,Q,PN,PH)   
J_P  = K*v_P; 
J_1K = deltaK;                                                                                         
J_1Q = K*v_1Q;                                                                                                                                                                                  
                                                                                                      
% Solution for JN, JT - Jj=Jj(P,K,Q)                                                                  
I     = deltaK*K;                                                                                     
JN_P = -(IN/P)*(phiI*alphaI) + (IN/I)*J_P;                                                            
JN_1K = (IN/I)*J_1K;                                                                                   
JN_1Q = (IN/I)*J_1Q;                                                                                   
                                                                                                      
JT_P  =  (IT/P)*phiI*(1-alphaI) + (IT/I)*J_P;                                                         
JT_1K  = (IT/I)*J_1K;                                                                                  
JT_1Q  = (IT/I)*J_1Q;                                                                                  

% Solution for R as function R=R(K,P,ZT,ZN) 
RK  = PI*(r+deltaK); 
R_P = -(RK/kT)*thetaT*kT_P; 

% Solving for the relative price P=P(lambda,K,Q,GN)         
DeltaP  = (YN_P-CN_P-JN_P);                                  
P_K     = -(1/DeltaP)*(YN_1K - JN_1K);              
P_Q     = (JN_1Q/DeltaP);    

% Final solutions X=X(K,Q,ZT,ZN)
LT_K  = LT_1K + (LT_P*P_K);
LT_Q  = (LT_P*P_Q);

LN_K  = LN_1K + (LN_P*P_K);
LN_Q  = (LN_P*P_Q);

YT_K  = YT_1K + (YT_P*P_K);
YT_Q  = (YT_P*P_Q);

YN_K  = YN_1K + (YN_P*P_K);
YN_Q  = (YN_P*P_Q);

CT_K  = CT_P*P_K;
CT_Q  = CT_P*P_Q;

CN_K  = CN_P*P_K;
CN_Q  = CN_P*P_Q;

JT_K  = JT_1K + (JT_P*P_K);
JT_Q  = JT_1Q + (JT_P*P_Q);

JN_K  = JN_1K + (JN_P*P_K);
JN_Q  = JN_1Q + (JN_P*P_Q);

v_K  = (v_P*P_K);        
v_Q  = v_1Q + (v_P*P_Q); 

R_K  = (R_P*P_K);                
R_Q  = (R_P*P_Q);  

% Elements of the Jacobian Matrix 
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + alphaI*phiI*I*(P_K/P);                                                                        
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + alphaI*phiI*I*(P_Q/P); 
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) ); 
 
x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    
                                                                                   
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
 
% Intertemporal solvency condition - lambda 
B_K   = (YT_K - CT_K - JT_K);                                                                              
B_Q   = (YT_Q - CT_Q - JT_Q); 
N1    = (B_K + (B_Q*omega_21));
H1    = N1/(nu_1-r); 
g(24) = (B - B0) - H1*(K-K0);



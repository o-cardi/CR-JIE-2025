clc
clear

% Maxim duration for graphics
Tg = 100;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

IML_IMK_CAC_TOT_CES_NS_NORMALIZED_SYMvsASYM; 
IML_IMK_CAC_TOT_CES_NS_NORMALIZED_SYM; 
IML_IMK_CAC_TOT_CES_NS_NORMALIZED_ASYM; 
IML_IMK_CAC_TOT_CES_NS_HNTC_NORMALIZED_SYMvsASYM; 
IML_IMK_CAC_TOT_CES_NS_HNTC_NORMALIZED_SYM; 
IML_IMK_CAC_TOT_CES_NS_HNTC_NORMALIZED_ASYM; 

IML_IMK_CAC_SYMvsASYM; 
IML_IMK_CAC_SYM; 
IML_IMK_CAC_ASYM; 
PML_CAC_SYMvsASYM; 
PML_CAC_SYM;
PML_CAC_ASYM;

%%%%%%%%%%% Table of Results %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

disp('Adjusted TFP - Impact Effects');
disp(sprintf('Variables |(1)| |(2)| |(3)| |(4)| |(5)| |(6)| |(7)| |(8)| |(9)| |(10)| |(11)| |(12)|'));
disp(sprintf('dZtime0     |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dZAtime0_bias,dZAtime0_biassym,dZAtime0_biasasym,dZAtime0_hntc,dZAtime0_hntcsym,dZAtime0_hntcasym,dZAtime0_imlimk,dZAtime0_imlimksym,dZAtime0_imlimkasym,dZAtime0_pmlcac,dZAtime0_pmlcacsym,dZAtime0_pmlcacasym));
disp(sprintf('dZTtime0    |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dZHtime0_bias,dZHtime0_biassym,dZHtime0_biasasym,dZHtime0_hntc,dZHtime0_hntcsym,dZHtime0_hntcasym,dZTtime0_imlimk,dZTtime0_imlimksym,dZTtime0_imlimkasym,dZTtime0_pmlcac,dZTtime0_pmlcacsym,dZTtime0_pmlcacasym));
disp(sprintf('dZNtime0    |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dZNtime0_bias,dZNtime0_biassym,dZNtime0_biasasym,dZNtime0_hntc,dZNtime0_hntcsym,dZNtime0_hntcasym,dZNtime0_imlimk,dZNtime0_imlimksym,dZNtime0_imlimkasym,dZNtime0_pmlcac,dZNtime0_pmlcacsym,dZNtime0_pmlcacasym));

disp('Hours - Impact Effects');
disp(sprintf('dLtime0     |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dLtime0_bias,dLtime0_biassym,dLtime0_biasasym,dLtime0_hntc,dLtime0_hntcsym,dLtime0_hntcasym,dLtime0_imlimk,dLtime0_imlimksym,dLtime0_imlimkasym,dLtime0_pmlcac,dLtime0_pmlcacsym,dLtime0_pmlcacasym));
disp(sprintf('dLTtime0    |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dLHtime0_bias,dLHtime0_biassym,dLHtime0_biasasym,dLHtime0_hntc,dLHtime0_hntcsym,dLHtime0_hntcasym,dLTtime0_imlimk,dLTtime0_imlimksym,dLTtime0_imlimkasym,dLTtime0_pmlcac,dLTtime0_pmlcacsym,dLTtime0_pmlcacasym));
disp(sprintf('dLNtime0    |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dLNtime0_bias,dLNtime0_biassym,dLNtime0_biasasym,dLNtime0_hntc,dLNtime0_hntcsym,dLNtime0_hntcasym,dLNtime0_imlimk,dLNtime0_imlimksym,dLNtime0_imlimkasym,dLNtime0_pmlcac,dLNtime0_pmlcacsym,dLNtime0_pmlcacasym));
disp(sprintf('dLTStime0   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dLHStime0_bias,dLHStime0_biassym,dLHStime0_biasasym,dLHStime0_hntc,dLHStime0_hntcsym,dLHStime0_hntcasym,dLTStime0_imlimk,dLTStime0_imlimksym,dLTStime0_imlimkasym,dLTStime0_pmlcac,dLTStime0_pmlcacsym,dLTStime0_pmlcacasym));

disp('Transmission - Impact Effects');
disp(sprintf('dCAYtime0   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',CAYtime0_bias,CAYtime0_biassym,CAYtime0_biasasym,CAYtime0_hntc,CAYtime0_hntcsym,CAYtime0_hntcasym,CAYtime0_imlimk,CAYtime0_imlimksym,CAYtime0_imlimkasym,CAYtime0_pmlcac,CAYtime0_pmlcacsym,CAYtime0_pmlcacasym));
disp(sprintf('dPHtime0    |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dPHtime0_bias,dPHtime0_biassym,dPHtime0_biasasym,dPHtime0_hntc,dPHtime0_hntcsym,dPHtime0_hntcasym,dPTtime0_imlimk,dPTtime0_imlimksym,dPTtime0_imlimkasym,dPTtime0_pmlcac,dPTtime0_pmlcacsym,dPTtime0_pmlcacasym));
disp(sprintf('dPtime0     |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dPtime0_bias,dPtime0_biassym,dPtime0_biasasym,dPtime0_hntc,dPtime0_hntcsym,dPtime0_hntcasym,dPtime0_imlimk,dPtime0_imlimksym,dPtime0_imlimkasym,dPtime0_pmlcac,dPtime0_pmlcacsym,dPtime0_pmlcacasym));
disp(sprintf('duKHtime0   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',duKHtime0_bias,duKHtime0_biassym,duKHtime0_biasasym,duKHtime0_hntc,duKHtime0_hntcsym,duKHtime0_hntcasym,duKTtime0_imlimk,duKTtime0_imlimksym,duKTtime0_imlimkasym,duKTtime0_pmlcac,duKTtime0_pmlcacsym,duKTtime0_pmlcacasym));
disp(sprintf('duKNtime0   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',duKNtime0_bias,duKNtime0_biassym,duKNtime0_biasasym,duKNtime0_hntc,duKNtime0_hntcsym,duKNtime0_hntcasym,duKNtime0_imlimk,duKNtime0_imlimksym,duKNtime0_imlimkasym,duKNtime0_pmlcac,duKNtime0_pmlcacsym,duKNtime0_pmlcacasym));
disp(sprintf('dLISHtime0  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dLISHtime0_bias,dLISHtime0_biassym,dLISHtime0_biasasym,dLISHtime0_hntc,dLISHtime0_hntcsym,dLISHtime0_hntcasym,dLISTtime0_imlimk,dLISTtime0_imlimksym,dLISTtime0_imlimkasym,dLISTtime0_pmlcac,dLISTtime0_pmlcacsym,dLISTtime0_pmlcacasym));
disp(sprintf('dLISNtime0  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dLISNtime0_bias,dLISNtime0_biassym,dLISNtime0_biasasym,dLISNtime0_hntc,dLISNtime0_hntcsym,dLISNtime0_hntcasym,dLISNtime0_imlimk,dLISNtime0_imlimksym,dLISNtime0_imlimkasym,dLISNtime0_pmlcac,dLISNtime0_pmlcacsym,dLISNtime0_pmlcacasym));

disp('Value Added - Impact Effects');
disp(sprintf('dYRtime0        |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dYRtime0_bias,dYRtime0_biassym,dYRtime0_biasasym,dYRtime0_hntc,dYRtime0_hntcsym,dYRtime0_hntcasym,dYRtime0_imlimk,dYRtime0_imlimksym,dYRtime0_imlimkasym,dYRtime0_pmlcac,dYRtime0_pmlcacsym,dYRtime0_pmlcacasym));
disp(sprintf('dYTtime0        |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dYHtime0_bias,dYHtime0_biassym,dYHtime0_biasasym,dYHtime0_hntc,dYHtime0_hntcsym,dYHtime0_hntcasym,dYTtime0_imlimk,dYTtime0_imlimksym,dYTtime0_imlimkasym,dYTtime0_pmlcac,dYTtime0_pmlcacsym,dYTtime0_pmlcacasym));
disp(sprintf('dYNtime0        |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dYNtime0_bias,dYNtime0_biassym,dYNtime0_biasasym,dYNtime0_hntc,dYNtime0_hntcsym,dYNtime0_hntcasym,dYNtime0_imlimk,dYNtime0_imlimksym,dYNtime0_imlimkasym,dYNtime0_pmlcac,dYNtime0_pmlcacsym,dYNtime0_pmlcacasym));
disp(sprintf('dYTStime0       |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',dYHStime0_bias,dYHStime0_biassym,dYHStime0_biasasym,dYHStime0_hntc,dYHStime0_hntcsym,dYHStime0_hntcasym,dYTStime0_imlimk,dYTStime0_imlimksym,dYTStime0_imlimkasym,dYTStime0_pmlcac,dYTStime0_pmlcacsym,dYTStime0_pmlcacasym));
disp(sprintf('domegaYNtime0   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f |%10.2f |%10.2f  |%10.2f  |%10.2f  |%10.2f |',domegaYNtime0_bias,domegaYNtime0_biassym,domegaYNtime0_biasasym,domegaYNtime0_hntc,domegaYNtime0_hntcsym,domegaYNtime0_hntcasym,domegaYNtime0_imlimk,domegaYNtime0_imlimksym,domegaYNtime0_imlimkasym,domegaYNtime0_pmlcac,domegaYNtime0_pmlcacsym,domegaYNtime0_pmlcacasym));

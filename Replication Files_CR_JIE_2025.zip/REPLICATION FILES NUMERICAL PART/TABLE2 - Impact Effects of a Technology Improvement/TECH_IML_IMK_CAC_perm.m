function g = TECH_IML_IMK_CAC_perm(x)

global sigma phi varphi 
global gammaL sigmaL phiI varphiI
global epsilon vartheta 
global epsilonK varthetaK 
global r deltaK 
global ZT_0 ZN_0 ZT ZN thetaT thetaN kappa 
global B0 K0 GT GN 
global xiZT chiZT xiZN chiZN barzT barzN 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption                                 
L       = x(2)  ; % Labor supply                                
RT      = x(3)  ; % Return on traded capital                    
RN      = x(4)  ; % Return on non-traded capital                
WT      = x(5)  ; % Wage rate in sector H                       
WN      = x(6)  ; % Wage rate in sector N                       
W       = x(7)  ; % Aggregate wage index                        
RK      = x(8)  ; % Aggregate capital rental rate               
P       = x(9)  ; % Relative price of non tradables             
K       = x(10)  ; % Stock of capital                           
B       = x(11) ; % Stock of Traded Bonds                       
alphaL  = x(12) ; % Labor compensation share of tradables       
alphaK  = x(13) ; % Capital compensation share of tradables     
CN      = x(14) ; % Consumption in non tradables                
CT      = x(15) ; % Consumption in tradables                    
PC      = x(16) ; % Consumption price index                     
IN      = x(17) ; % Non tradable investment                     
IT      = x(18) ; % Tradable investment                         
PI      = x(19) ; % Investment price index                      
LT      = x(20) ; % Labor in sector T                           
LN      = x(21) ; % Labor in sector N                           
KT      = x(22) ; % Capital in sector T                         
KN      = x(23) ; % Capital in sector N                         
YT      = x(24) ; % Output in sector T                          
YN      = x(25) ; % Output in sector N                          
VL      = x(26) ; % Labor disutility                            
lambda  = x(27) ; % Intertemporal Solvency Condition            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Aggregate Consumption -  C
g(1)= (C^(-sigma))*(VL^sigma) - (PC*lambda);

% Aggregate labor supply - L
g(2)= (C^(1-sigma))*sigma*gammaL*(L^(1/sigmaL))*(VL^(sigma-1)) - (lambda*W);

% MRPKT = RT - RT -
g(3)= ZT*(1-thetaT)*(LT^thetaT)*(KT^(-thetaT)) - RT;

% MRPKN = RN - RN
g(4)= P*ZN*(1-thetaN)*(LN^thetaN)*(KN^(-thetaN)) - RN;

% MRPLH = WT - WT
g(5)= ZT*thetaT*(LT^(thetaT-1))*(KT^(1-thetaT)) - WT;

% MRPLN = WN - WN
g(6)= P*ZN*thetaN*(LN^(thetaN-1))*(KN^(1-thetaN)) - WN;

% Aggregate wage index - W
g(7)= W - ((vartheta*(WT)^(epsilon+1)) + ((1-vartheta)*(WN)^(epsilon+1)))^(1/(epsilon+1));

% Aggregate capital rental rate index - RK
g(8)= RK - ((varthetaK*(RT)^(epsilonK+1)) + ((1-varthetaK)*(RN)^(epsilonK+1)))^(1/(epsilonK+1));

% Return on capital is equal to capital cost dotQ=0 - PN
g(9)= RK - (deltaK + r)*PI;

% Non traded market good market clearing condition - K
g(10)= YN - CN - GN - IN;

% Traded good market clearing condition - B
g(11)= (r*B) + YT - CT - GT - IT;

% Tradable share of labor income - alphaL
g(12)= alphaL - (vartheta*(WT)^(epsilon+1))/( vartheta*(WT)^(epsilon+1) + (1-vartheta)*(WN)^(epsilon+1) );

% Capital compensation share of tradables RH*KH/RK*K- alphaK
g(13)= alphaK - (varthetaK*(RT)^(epsilonK+1))/( varthetaK*(RT)^(epsilonK+1) + (1-varthetaK)*(RN)^(epsilonK+1) );

% Consumption in non tradables - CN
g(14)= CN - C*(1-varphi)*(P/PC)^(-phi);

% Consumption in tradables - CT
g(15)= CT - C*varphi*(1/PC)^(-phi);

% Consumption price index - PC
g(16)= PC - (varphi+(1-varphi)*P^(1-phi))^(1/(1-phi));

% Non tradable Investment - IN
g(17)= IN - (deltaK*K)*(1-varphiI)*((P/PI)^(-phiI));

% Tradable Investment - IT
g(18)= IT - (deltaK*K)*varphiI*((1/PI)^(-phiI));

% Investment price index - PI
g(19)= PI - (varphiI+(1-varphiI)*P^(1-phiI))^(1/(1-phiI));

% Employment in the traded sector - LT
g(29)= LT - L*(vartheta*(WT/W)^epsilon);

% Employment in the non traded sector - LN
g(21)= LN - L*((1-vartheta)*(WN/W)^epsilon);

% Capital stock in the traded sector - KT
g(22)= KT - K*varthetaK*(RT/RK)^epsilonK;

% Capital stock in the non traded sector - KN
g(23)= KN - K*(1-varthetaK)*(RN/RK)^epsilonK;

% Output per worker in the traded sector - YT
g(24)= YT - ZT*(LT^thetaT)*(KT^(1-thetaT));

% Output per worker in the non traded sector - YN
g(25)= YN - ZN*(LN^thetaN)*(KN^(1-thetaN));

% Desutility from labor
g(26)= VL - ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) ); % Desutility labor

% Non tradable shares of consumption, investment, labor compensation
alphaC = (varphi*(1/PC)^(1-phi));
alphaI = (varphiI*(1/PI)^(1-phiI));

% Non Sep preferences Shimer (2009)
%VL        = ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );
V_L       = (sigma-1)*gammaL*L^(1/sigmaL);
V_LL      = (sigma-1)*(gammaL/sigmaL)*(L^((1/sigmaL)-1));
U_C       =  (C^(-sigma))*(VL^sigma);
U_CC      = -sigma*(C^(-sigma-1))*(VL^sigma);
U_L       = ( (C^(1-sigma))*sigma*V_L*(VL^(sigma-1)) )/(1-sigma);
U_LL      = U_L*( (V_LL/V_L) + (sigma-1)*V_L*(VL^(-1)) );
U_CL      = (C^(-sigma))*sigma*V_L*(VL^(sigma-1));
U_LC      = U_CL;

% Solutions C=C(lambda,P,W); L=L(lambda,P,W)
a11 = (U_CC/U_C);
a12 = (U_CL/U_C);
a21 = (U_LC/U_L);
a22 = (U_LL/U_L);

% P, W, lambda
b11 = (1-alphaC)/P;
b12 = 0;
b13 = (1/lambda);

b21 = 0;
b22 = (1/W);
b23 = (1/lambda);

A1 = [a11 a12; a21 a22];
B1 = [b11 b12 b13; b21 b22 b23];
JST1 = inv(A1);
MST1 = JST1*B1;
C_1P = MST1(1,1); C_W = MST1(1,2);
L_1P = MST1(2,1); L_W = MST1(2,2);

% Partial derivatives of W=W(WN,WH)
W_WT   = (W/WT)*alphaL;
W_WN   = (W/WN)*(1-alphaL);
L_WT   = L_W*W_WT;
L_WN   = L_W*W_WN;

% Intermediate solution for CN, CT - Cj=Cj(lambda,P,W)
CN_1P = -(CN/P)*(alphaC*phi) + (CN/C)*C_1P;
CN_WN = (CN/C)*C_W*W_WN;
CN_WT = (CN/C)*C_W*W_WT;

CT_1P = (CT/P)*phi*(1-alphaC) + (CT/C)*C_1P;
CT_WN = (CT/C)*C_W*W_WN;
CT_WT = (CT/C)*C_W*W_WT;

% Solutions LT=LT(lambda,WT,WN,P), LN=LN(lambda,WT,WN,P)
LT_WT  = (LT/WT)*epsilon*(1-alphaL) + (LT/L)*L_WT;
LT_WN  = -(LT/WN)*epsilon*(1-alphaL) + (LT/L)*L_WN;
LT_1P  = (LT/L)*L_1P;

LN_WT  = -(LN/WT)*epsilon*alphaL + (LN/L)*L_WT;
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN;
LN_1P  = (LN/L)*L_1P;

% Solutions Kj=Kj(RH,RN,K), j=H,N
KT_RT = (KT/RT)*epsilonK*(1-alphaK);
KT_RN = -(KT/RN)*epsilonK*(1-alphaK);
KT_1K  = (KT/K);

KN_RT = -(KN/RT)*epsilonK*alphaK;
KN_RN = (KN/RN)*epsilonK*alphaK;
KN_1K  = (KN/K);

% Solving for WT,WN,RT,RN(P,K,ZT,ZN,lambda)
d11 = - ( (1-thetaT)*(LT_WT/LT) + (1/WT) ); % WT
d12 = - (1-thetaT)*(LT_WN/LT);  % WN
d13 = (1-thetaT)*(KT_RT/KT);  % RT
d14 = (1-thetaT)*(KT_RN/KT); % RN

d21 = - (1-thetaN)*(LN_WT/LN);  % WT
d22 = - ( (1-thetaN)*(LN_WN/LN) + (1/WN) ); % WN
d23 = (1-thetaN)*(KN_RT/KN);  % RT
d24 = (1-thetaN)*(KN_RN/KN); % RN

d31 = thetaT*(LT_WT/LT); % WT
d32 = thetaT*(LT_WN/LT); % WN
d33 = - ( thetaT*(KT_RT/KT) + (1/RT) ); % RT
d34 = - thetaT*(KT_RN/KT); % RN

d41 = thetaN*(LN_WT/LN); % WT
d42 = thetaN*(LN_WN/LN); % WN
d43 = - thetaN*(KN_RT/KN); % RT
d44 = - ( thetaN*(KN_RN/KN) + (1/RN) ); % RN

% P,K,ZT,ZN,lambda
e11  = (1-thetaT)*(LT_1P/LT);    % P
e12  = - (1-thetaT)*(KT_1K/KT);  % K
e13  = - (1/ZT);                 % ZT
e14  = 0;                        % ZN

e21  = (1-thetaN)*(LN_1P/LN) - (1/P); % P
e22  = - (1-thetaN)*(KN_1K/KN);       % K
e23  = 0;                             % ZT
e24  = - (1/ZN);                      % ZN

e31  = - thetaT*(LT_1P/LT);    % P
e32  = thetaT*(KT_1K/KT);      % K
e33  = - (1/ZT);               % ZT
e34  = 0;                      % ZN

e41  = - ( thetaN*(LN_1P/LN) + (1/P) );    % P
e42  = thetaN*(KN_1K/KN);                   % K
e43  = 0;                                   % ZT
e44  = - (1/ZN);                            % ZN

M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X2 = [e11 e12 e13 e14; e21 e22 e23 e24; e31 e32 e33 e34; e41 e42 e43 e44];
JST2 = inv(M2);
MST2 = JST2*X2;
WT_1P = MST2(1,1); WT_1K = MST2(1,2); WT_1ZT = MST2(1,3); WT_1ZN = MST2(1,4);
WN_1P = MST2(2,1); WN_1K = MST2(2,2); WN_1ZT = MST2(2,3); WN_1ZN = MST2(2,4);
RT_1P = MST2(3,1); RT_1K = MST2(3,2); RT_1ZT = MST2(3,3); RT_1ZN = MST2(3,4);
RN_1P = MST2(4,1); RN_1K = MST2(4,2); RN_1ZT = MST2(4,3); RN_1ZN = MST2(4,4);

% Solving for sectoral labor and sectoral output - Lj,Kj,Yj,(P,K,ZT,ZN,lambda)
LT_P   = LT_1P + (LT_WT*WT_1P) + (LT_WN*WN_1P);
LT_1K  = (LT_WT*WT_1K)  + (LT_WN*WN_1K);
LT_1ZT = (LT_WT*WT_1ZT) + (LT_WN*WN_1ZT);
LT_1ZN = (LT_WT*WT_1ZN) + (LT_WN*WN_1ZN);

LN_P   = LN_1P + (LN_WT*WT_1P) + (LN_WN*WN_1P);
LN_1K  = (LN_WT*WT_1K)  + (LN_WN*WN_1K);
LN_1ZT = (LN_WT*WT_1ZT) + (LN_WN*WN_1ZT);
LN_1ZN = (LN_WT*WT_1ZN) + (LN_WN*WN_1ZN);

KT_P   = (KT_RT*RT_1P) + (KT_RN*RN_1P);
KT_2K  = KT_1K  +(KT_RT*RT_1K)  + (KT_RN*RN_1K);
KT_1ZT = (KT_RT*RT_1ZT) + (KT_RN*RN_1ZT);
KT_1ZN = (KT_RT*RT_1ZN) + (KT_RN*RN_1ZN);

KN_P   = (KN_RT*RT_1P) + (KN_RN*RN_1P);
KN_2K  = KN_1K + (KN_RT*RT_1K)  + (KN_RN*RN_1K);
KN_1ZT = (KN_RT*RT_1ZT) + (KN_RN*RN_1ZT);
KN_1ZN = (KN_RT*RT_1ZN) + (KN_RN*RN_1ZN);

YT_P   = thetaT*YT*(LT_P/LT) + (1-thetaT)*YT*(KT_P/KT);                    
YT_1K  = thetaT*YT*(LT_1K/LT) + (1-thetaT)*YT*(KT_2K/KT);                  
YT_1ZT = thetaT*YT*(LT_1ZT/LT) + (1-thetaT)*YT*(KT_1ZT/KT) + (YT/ZT);      
YT_1ZN = thetaT*YT*(LT_1ZN/LT) + (1-thetaT)*YT*(KT_1ZN/KT);       

YN_P   = thetaN*YN*(LN_P/LN) + (1-thetaN)*YN*(KN_P/KN);                
YN_1K  = thetaN*YN*(LN_1K/LN) + (1-thetaN)*YN*(KN_2K/KN);              
YN_1ZT = thetaN*YN*(LN_1ZT/LN) + (1-thetaN)*YN*(KN_1ZT/KN);            
YN_1ZN = thetaN*YN*(LN_1ZN/LN) + (1-thetaN)*YN*(KN_1ZN/KN) + (YN/ZN);  

% Intermediate solution for CN, CT- Cj=Cj(P,K,ZT,ZN,lambda)
CN_P       = CN_1P + (CN_WT*WT_1P) + (CN_WN*WN_1P);
CN_1K      = (CN_WT*WT_1K) + (CN_WN*WN_1K);
CN_1ZT     = (CN_WT*WT_1ZT) + (CN_WN*WN_1ZT);
CN_1ZN     = (CN_WT*WT_1ZN) + (CN_WN*WN_1ZN);

CT_P       = CT_1P + (CT_WT*WT_1P) + (CT_WN*WN_1P);
CT_1K      = (CT_WT*WT_1K) + (CT_WN*WN_1K);
CT_1ZT     = (CT_WT*WT_1ZT) + (CT_WN*WN_1ZT);
CT_1ZN     = (CT_WT*WT_1ZN) + (CT_WN*WN_1ZN);

% Investment function I/K = v(Q/PI(P))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI);
v_P  = - (1-alphaI)/(kappa*P);

% Solution for J = J(K,Q,P)
J_1K = deltaK;
J_1Q = K*v_1Q;
J_P  = K*v_P;

% Solution for JN, JT - Jj=Jj(P,K,Q)
I     = deltaK*K;
JN_P  = -(IN/P)*(phiI*alphaI) + (IN/I)*J_P;
JN_1K = (IN/I)*J_1K;
JN_1Q = (IN/I)*J_1Q;

JT_P  =  (IT/P)*phiI*(1-alphaI) + (IT/I)*J_P;
JT_1K = (IT/I)*J_1K;
JT_1Q = (IT/I)*J_1Q;

% Solving for the relative price P=P(lambda,K,Q,ZT,ZN)
DeltaP  = (YN_P-CN_P-JN_P);
P_K     = -(1/DeltaP)*(YN_1K - CN_1K - JN_1K);
P_Q     = (JN_1Q/DeltaP);
P_ZT    = -(1/DeltaP)*(YN_1ZT - CN_1ZT);
P_ZN    = -(1/DeltaP)*(YN_1ZN - CN_1ZN);

% Final solutions X=X(K,Q,ZT,ZN)
LT_K  = LT_1K + (LT_P*P_K);
LT_Q  = (LT_P*P_Q);
LT_ZT = LT_1ZT + (LT_P*P_ZT);
LT_ZN = LT_1ZN + (LT_P*P_ZN);

LN_K  = LN_1K + (LN_P*P_K);
LN_Q  = (LN_P*P_Q);
LN_ZT = LN_1ZT + (LN_P*P_ZT);
LN_ZN = LN_1ZN + (LN_P*P_ZN);

KT_K  = KT_2K + (KT_P*P_K);
KT_Q  = (KT_P*P_Q);
KT_ZT = KT_1ZT + (KT_P*P_ZT);
KT_ZN = KT_1ZN + (KT_P*P_ZN);

KN_K  = KN_2K + (KN_P*P_K);
KN_Q  = (KN_P*P_Q);
KN_ZT = KN_1ZT + (KN_P*P_ZT);
KN_ZN = KN_1ZN + (KN_P*P_ZN);

YT_K  = YT_1K + (YT_P*P_K);
YT_Q  = (YT_P*P_Q);
YT_ZT = YT_1ZT + (YT_P*P_ZT);
YT_ZN = YT_1ZN + (YT_P*P_ZN);

YN_K  = YN_1K + (YN_P*P_K);
YN_Q  = (YN_P*P_Q);
YN_ZT = YN_1ZT + (YN_P*P_ZT);
YN_ZN = YN_1ZN + (YN_P*P_ZN);

CT_K  = CT_1K + (CT_P*P_K);
CT_Q  = CT_P*P_Q;
CT_ZT = CT_1ZT + (CT_P*P_ZT);
CT_ZN = CT_1ZN + (CT_P*P_ZN);

CN_K  = CN_1K + (CN_P*P_K);
CN_Q  = CN_P*P_Q;
CN_ZT = CN_1ZT + (CN_P*P_ZT);
CN_ZN = CN_1ZN + (CN_P*P_ZN);

JT_K  = JT_1K + (JT_P*P_K);
JT_Q  = JT_1Q + (JT_P*P_Q);
JT_ZT = (JT_P*P_ZT);
JT_ZN = (JT_P*P_ZN);

JN_K  = JN_1K + (JN_P*P_K);
JN_Q  = JN_1Q + (JN_P*P_Q);
JN_ZT = (JN_P*P_ZT);
JN_ZN = (JN_P*P_ZN);

v_K  = (v_P*P_K);
v_Q  = v_1Q + (v_P*P_Q);
v_ZT = (v_P*P_ZT);
v_ZN = (v_P*P_ZN);

% Solving for sectoral capital rental rats - Rj(K,Q,ZT,ZN)
RT_K = RT_1K + (RT_1P*P_K);
RT_Q = (RT_1P*P_Q);
RT_ZT = RT_1ZT + (RT_1P*P_ZT);
RT_ZN = RT_1ZN + (RT_1P*P_ZN);

RN_K = RN_1K + (RN_1P*P_K);
RN_Q = (RN_1P*P_Q);
RN_ZT = RN_1ZT + (RN_1P*P_ZT);
RN_ZN = RN_1ZN + (RN_1P*P_ZN);

R_RT = alphaK*(RK/RT); 
R_RN = (1-alphaK)*(RK/RN);
R_K  = (R_RT*RT_K) + (R_RN*RN_K);
R_Q  = (R_RT*RT_Q) + (R_RN*RN_Q);
R_ZT = (R_RT*RT_ZT) + (R_RN*RN_ZT);
R_ZN = (R_RT*RT_ZN) + (R_RN*RN_ZN);

% Elements of the Jacobian Matrix                                      
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + alphaI*phiI*I*(P_K/P);      
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + alphaI*phiI*I*(P_Q/P);               
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) );                         
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) );             
                                                                       
x11 = Upsilon_K;                                                       
x12 = Upsilon_Q;                                                       
x21 = Sigma_K;                                                         
x22 = Sigma_Q;                                                         
                                                                       
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
omega_12 = V_sorted(1,2)/V_sorted(1,2); 
omega_22 = V_sorted(2,2)/V_sorted(1,2); 

% Solutions                                                      
Upsilon_ZT = (I/IN)*(YN_ZT-CN_ZT) + (alphaI*phiI*I)*(P_ZT/P);    
Upsilon_ZN = (I/IN)*(YN_ZN-CN_ZN) + (alphaI*phiI*I)*(P_ZN/P);    
                                                                 
Sigma_ZT   = -( R_ZT + (PI*kappa*v_ZT*deltaK) );                 
Sigma_ZN   = -( R_ZN + (PI*kappa*v_ZN*deltaK) );                 

%%%%%%%%%%%%%%%%%% Solutions for Permanent Shocks %%%%%%%%%%%%%%%%%%%%                                                       
Vnorm = [omega_11 omega_12; omega_21 omega_22];                                                                              
Vinv   = inv(Vnorm);                                                                                                         
u11    = Vinv(1,1);                                                                                                          
u12    = Vinv(1,2);                                                                                                          
u21    = Vinv(2,1);                                                                                                          
u22    = Vinv(2,2);                                                                                                          
                                                                                                                             
s11   = (u11*Upsilon_ZT) + (u12*Sigma_ZT);                                                                                   
s12   = (u11*Upsilon_ZN) + (u12*Sigma_ZN);                                                                                   
                                                                                                                             
s21   = (u21*Upsilon_ZT) + (u22*Sigma_ZT);                                                                                   
s22   = (u21*Upsilon_ZN) + (u22*Sigma_ZN);                                                                                   
                                                                                                                             
DeltaZT_1   = - s11*ZT_0*(1/(nu_1+xiZT));                                                                                    
DeltaZN_1   = - s12*ZN_0*(1/(nu_1+xiZN));                                                                                    
                                                                                                                             
DeltaZT_2   = s21*ZT_0*(1/(nu_2+xiZT));                                                                                      
DeltaZN_2   = s22*ZN_0*(1/(nu_2+xiZN));                                                                                      
                                                                                                                             
ThetaZT_1   = (1-barzT)*((nu_1+xiZT)/(nu_1+chiZT));                                                                          
ThetaZT_2   = (1-barzT)*((nu_2+xiZT)/(nu_2+chiZT));                                                                          
ThetaZN_1   = (1-barzN)*((nu_1+xiZN)/(nu_1+chiZN));                                                                          
ThetaZN_2   = (1-barzN)*((nu_2+xiZN)/(nu_2+chiZN));                                                                          
                                                                                                                             
X20 = - DeltaZT_2*(1-ThetaZT_2) - DeltaZN_2*(1-ThetaZN_2);                                                                   
X10 = (K0-K) - X20;                                                                                                          
X11 = X10 - DeltaZT_1*(1-ThetaZT_1) - DeltaZN_1*(1-ThetaZN_1);                                                               
                                                                                                                             
% Intertemporal solvency condition - lambda                                                                
B_K    = (YT_K - CT_K - JT_K);                                                                              
B_Q    = (YT_Q - CT_Q - JT_Q);                                                                             
B_ZT   = (YT_ZT - CT_ZT - JT_ZT);                                                                           
B_ZN   = (YT_ZN - CT_ZN - JT_ZN);                                                                          
N1     = (B_K + (B_Q*omega_21));                                                                     
N2     = (B_K + (B_Q*omega_22));                                                                     
ThetaZT_prime  = (1-barzT)*((xiZT+r)/(chiZT+r));                                                           
ThetaZT_1prime = ThetaZT_1*((xiZT+r)/(chiZT+r));                                                           
ThetaZT_2prime = ThetaZT_2*((xiZT+r)/(chiZT+r));                                                           
ThetaZN_prime  = (1-barzN)*((xiZN+r)/(chiZN+r));                                                           
ThetaZN_1prime = ThetaZN_1*((xiZN+r)/(chiZN+r));                                                           
ThetaZN_2prime = ThetaZN_2*((xiZN+r)/(chiZN+r));                                                           
                                                                                                           
wB1   = (N1*X11);                                                                                            
wBZT2 = B_ZT*ZT_0*(1-ThetaZT_prime) + N1*DeltaZT_1*(1-ThetaZT_1prime) - N2*DeltaZT_2*(1-ThetaZT_2prime);
wBZN2 = B_ZN*ZN_0*(1-ThetaZN_prime) + N1*DeltaZN_1*(1-ThetaZN_1prime) - N2*DeltaZN_2*(1-ThetaZN_2prime);   
                                                                                                                             
g(27) = (B-B0)-( (wB1/(r-nu_1)) + (wBZT2/(xiZT+r)) + (wBZN2/(xiZN+r)) );                                                     



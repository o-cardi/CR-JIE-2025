function g = TECH_PML_CAC_perm(x)

global sigma phi varphi 
global gammaL sigmaL phiI varphiI
global r deltaK 
global ZT_0 ZN_0 ZT ZN thetaT thetaN kappa 
global B0 K0 GT GN 
global xiZT chiZT xiZN chiZN barzT barzN 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kT      = x(3)  ; % Capital-labor ratio in sector T
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LT      = x(6) ; % Labor in sector T
LN      = x(7) ; % Labor in sector N 
P       = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
B       = x(10) ; % Stock of Traded Bonds
CN      = x(11) ; % Consumption in non tradables 
CT      = x(12) ; % Consumption in tradables 
PC      = x(13) ; % Consumption price index
IN      = x(14) ; % Non tradable investment
IT      = x(15) ; % Tradable investment 
PI      = x(16) ; % Investment price index
YT      = x(17) ; % Labor in sector T
YN      = x(18) ; % Labor in sector N  
VL      = x(19) ; % Labor disutility
lambda  = x(20) ; % Marginal utility of wealth lambda
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Aggregate Consumption -  C
g(1)= (C^(-sigma))*(VL^sigma) - (PC*lambda);

% Aggregate labor supply - L
g(2)= (C^(1-sigma))*sigma*gammaL*(L^(1/sigmaL))*(VL^(sigma-1)) - (lambda*W);

% equality of marginal product of capital across the two sectors  - kT and
% kN
g(3)= ZT*(1-thetaT)*(kT^(-thetaT)) -  P*ZN*(1-thetaN)*(kN^(-thetaN));

% Wage rate in sector T  - kT and kN
g(4)= ZT*thetaT*(kT^(1-thetaT)) - P*ZN*thetaN*(kN^(1-thetaN));

% Aggregate wage index  - W
g(5)= W - ZT*thetaT*(kT^(1-thetaT));

% sectoral labor allocation  - LT and LN 
g(6)= (LT+LN) - L;

% sectoral capital allocation  -  LT and LN - 
g(7)= (LT*kT) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate  
g(8)= P*ZN*(1-thetaN)*(kN^(-thetaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - GN - IN;

% Traded good market clearing condition - B
g(10)= (r*B) + YT - CT - GT - IT;

% Consumption in non tradables - CN
g(11)= CN - C*(1-varphi)*(P/PC)^(-phi);

% Consumption in tradables - CT 
g(12)= CT - C*varphi*(1/PC)^(-phi);

% Consumption price index - PC
g(13)= PC - ((varphi+(1-varphi)*P^(1-phi))^(1/(1-phi)));

% Non tradable Investment - IN
g(14)= IN - (deltaK*K)*(1-varphiI)*((P/PI)^(-phiI));

% Tradable Investment - IT 
g(15)= IT - (deltaK*K)*varphiI*((1/PI)^(-phiI));

% Investment price index - PI
g(16)= PI - (varphiI+(1-varphiI)*P^(1-phiI))^(1/(1-phiI));

% Output per worker in the traded sector - YT
g(17)= YT - ZT*LT*(kT^(1-thetaT)); 

% Output per worker in the non traded sector - YN
g(18)= YN - ZN*LN*(kN^(1-thetaN));

% Desutility from labor
g(19)= VL - ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) ); % Desutility labor

% Non tradable shares of consumption, investment, labor compensation
alphaC = (varphi*(1/PC)^(1-phi));
alphaI = (varphiI*(1/PI)^(1-phiI));

% Non Sep preferences Shimer (2009)
%VL        = ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );
V_L       = (sigma-1)*gammaL*L^(1/sigmaL);
V_LL      = (sigma-1)*(gammaL/sigmaL)*(L^((1/sigmaL)-1));
U_C       =  (C^(-sigma))*(VL^sigma);
U_CC      = -sigma*(C^(-sigma-1))*(VL^sigma);
U_L       = ( (C^(1-sigma))*sigma*V_L*(VL^(sigma-1)) )/(1-sigma);
U_LL      = U_L*( (V_LL/V_L) + (sigma-1)*V_L*(VL^(-1)) );
U_CL      = (C^(-sigma))*sigma*V_L*(VL^(sigma-1));
U_LC      = U_CL;

% Solutions C=C(lambda,PN,PH,W); L=L(lambda,PN,PH,W)
a11 = (U_CC/U_C);
a12 = (U_CL/U_C);
a21 = (U_LC/U_L);
a22 = (U_LL/U_L);

% PN, PH, W, lambda
b11 = (1-alphaC)/P;
b12 = 0;

b21 = 0;
b22 = (1/W);

A1 = [a11 a12; a21 a22];
B1 = [b11 b12; b21 b22];
JST1 = inv(A1);
MST1 = JST1*B1;
C_1P = MST1(1,1); C_W = MST1(1,2); 
L_1P = MST1(2,1); L_W = MST1(2,2); 

% Intermediate solution for CN, CT - Cj=Cj(lambda,P,W)                      
CN_1P = -(CN/P)*(alphaC*phi) + (CN/C)*C_1P;                                                                              
CN_W  = (CN/C)*C_W; 
                                                                                        
CT_1P = (CT/P)*phi*(1-alphaC) + (CT/C)*C_1P;                                                  
CT_W  = (CT/C)*C_W;  

% Solutions for kj=kj(P,ZT,ZN)
d11 = -(thetaT/kT);
d12 =  (thetaN/kN);
d21 =  (1-thetaT)/kT;
d22 = -(1-thetaN)/kN;

e11 =  (1/P);
e12 = -(1/ZT);
e13 =  (1/ZN);
e21 =  (1/P);
e22 = -(1/ZT);
e23 =  (1/ZN);

M2 = [d11 d12; d21 d22];
X2 = [e11 e12 e13; e21 e22 e23];
JST2 = inv(M2);
MST2 = JST2*X2;
kT_P = MST2(1,1); kT_1ZT = MST2(1,2); kT_1ZN = MST2(1,3);
kN_P = MST2(2,1); kN_1ZT = MST2(2,2); kN_1ZN = MST2(2,3);

% Solutions for W=W(P,ZT,ZN)
W_P       = (1-thetaT)*(W/kT)*kT_P;
W_1ZT     = (W/ZT) + (1-thetaT)*(W/kT)*kT_1ZT;
W_1ZN     = (1-thetaT)*(W/kT)*kT_1ZN;

% Solution for L as function L=L(lambda,P,ZT,ZN)
L_P      = L_1P + (L_W*W_P);
L_1ZT    = L_W*W_1ZT;
L_1ZN    = L_W*W_1ZN;

% Solution for Cj(lambda,P,ZT,ZN)
CN_P     = CN_1P + (CN_W*W_P);
CN_1ZT   = CN_W*W_1ZT;
CN_1ZN   = CN_W*W_1ZN;

CT_P     = CT_1P + (CT_W*W_P);     
CT_1ZT   = CT_W*W_1ZT;             
CT_1ZN   = CT_W*W_1ZN;             

% Solutions for Lj=Lj(K,P)                                                                        
Psi_P  = ( (LT*kT_P) + (LN*kN_P) );                                                               
Psi_ZT = ( (LT*kT_1ZT) + (LN*kN_1ZT) );                                                           
Psi_ZN = ( (LT*kT_1ZN) + (LN*kN_1ZN) );                                                           
                                                                                                  
f11 = 1;                                                                                          
f12 = 1;                                                                                          
f21 = kT;                                                                                         
f22 = kN;                                                                                         
                                                                                                  
g11 = 0;                                                                                          
g12 = L_P;                                                                                        
g13 = L_1ZT;                                                                                       
g14 = L_1ZN;                                                                                                                                                                        
                                                                                                  
g21 = 1;                                                                                          
g22 = -Psi_P;                                                                                     
g23 = -Psi_ZT;                                                                                    
g24 = -Psi_ZN;                                                                                                                                                                            
                                                                                                  
M3 = [f11 f12; f21 f22];                                                                          
X3 = [g11 g12 g13 g14; g21 g22 g23 g24];                                                  
JST3 = inv(M3);                                                                                   
MST3 = JST3*X3;                                                                                   
LT_1K = MST3(1,1); LT_P = MST3(1,2); LT_1ZT = MST3(1,3); LT_1ZN = MST3(1,4);
LN_1K = MST3(2,1); LN_P = MST3(2,2); LN_1ZT = MST3(2,3); LN_1ZN = MST3(2,4);   
 
% Solutions for sectoral labor and sectoral output                 
YT_P = YT*( (LT_P/LT) + (1-thetaT)*(kT_P/kT) );                    
YT_1K = YT*(LT_1K/LT);                                             
YT_1ZT = YT*( (1/ZT) + (LT_1ZT/LT) + (1-thetaT)*(kT_1ZT/kT) );     
YT_1ZN = YT*( (LT_1ZN/LT) + (1-thetaT)*(kT_1ZN/kT) );              
                                                                   
YN_P = YN*( (LN_P/LN) + (1-thetaN)*(kN_P/kN) );                    
YN_1K = YN*(LN_1K/LN);                                             
YN_1ZT = YN*( (LN_1ZT/LN) + (1-thetaN)*(kN_1ZT/kN) );              
YN_1ZN = YN*( (1/ZN) + (LN_1ZN/LN) + (1-thetaN)*(kN_1ZN/kN) );     

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution                            
v_1Q = 1/(kappa*PI);                                                                                  
v_P  = - (1-alphaI)/(kappa*P);                                                                        
                                                                                                      
% Solution for J = J(K,Q,PN,PH)      
J_P  = K*v_P;   
J_1K = deltaK;                                                                                         
J_1Q = K*v_1Q;                                                                                                                                                                                
                                                                                                      
% Solution for JN, JT - Jj=Jj(P,K,Q)                                                                  
I     = deltaK*K;                                                                                     
JN_P  = -(IN/P)*(phiI*alphaI) + (IN/I)*J_P;                                                            
JN_1K = (IN/I)*J_1K;                                                                                   
JN_1Q = (IN/I)*J_1Q;                                                                                   
                                                                                                      
JT_P  =  (IT/P)*phiI*(1-alphaI) + (IT/I)*J_P;                                                         
JT_1K = (IT/I)*J_1K;                                                                                  
JT_1Q = (IT/I)*J_1Q;                                                                                  

% Solution for R as function R=R(K,P,lambda,ZT,ZN) 
RK   = PI*(r+deltaK); 
R_P  = -RK*thetaT*(kT_P/kT); 
R_1ZT = (RK/ZT) - RK*thetaT*(kT_1ZT/kT); 
R_1ZN = -RK*thetaT*(kT_1ZN/kT); 

% Solving for the relative price P=P(lambda,K,Q,GN)         
DeltaP  = (YN_P-CN_P-JN_P);                                  
P_K     = -(1/DeltaP)*(YN_1K - JN_1K);              
P_Q     = (JN_1Q/DeltaP);                                    
P_ZT    = -(1/DeltaP)*(YN_1ZT - CN_1ZT);                    
P_ZN    = -(1/DeltaP)*(YN_1ZN - CN_1ZN); 

% Final solutions X=X(K,Q,ZT,ZN)         
LT_K  = LT_1K + (LT_P*P_K);              
LT_Q  = (LT_P*P_Q);                      
LT_ZT = LT_1ZT + (LT_P*P_ZT);            
LT_ZN = LT_1ZN + (LT_P*P_ZN);            
                                         
LN_K  = LN_1K + (LN_P*P_K);              
LN_Q  = (LN_P*P_Q);                      
LN_ZT = LN_1ZT + (LN_P*P_ZT);            
LN_ZN = LN_1ZN + (LN_P*P_ZN);            
                                         
YT_K  = YT_1K + (YT_P*P_K);              
YT_Q  = (YT_P*P_Q);                      
YT_ZT = YT_1ZT + (YT_P*P_ZT);            
YT_ZN = YT_1ZN + (YT_P*P_ZN);            
                                         
YN_K  = YN_1K + (YN_P*P_K);              
YN_Q  = (YN_P*P_Q);                      
YN_ZT = YN_1ZT + (YN_P*P_ZT);            
YN_ZN = YN_1ZN + (YN_P*P_ZN);            
                                         
CT_K  = CT_P*P_K;                        
CT_Q  = CT_P*P_Q;                        
CT_ZT = CT_1ZT + (CT_P*P_ZT);            
CT_ZN = CT_1ZN + (CT_P*P_ZN);            
                                         
CN_K  = CN_P*P_K;                        
CN_Q  = CN_P*P_Q;                        
CN_ZT = CN_1ZT + (CN_P*P_ZT);            
CN_ZN = CN_1ZN + (CN_P*P_ZN);            
                                         
JT_K  = JT_1K + (JT_P*P_K);              
JT_Q  = JT_1Q + (JT_P*P_Q);              
JT_ZT = (JT_P*P_ZT);                     
JT_ZN = (JT_P*P_ZN);                     
                                         
JN_K  = JN_1K + (JN_P*P_K);              
JN_Q  = JN_1Q + (JN_P*P_Q);              
JN_ZT = (JN_P*P_ZT);                     
JN_ZN = (JN_P*P_ZN);                     
                                         
v_K  = (v_P*P_K);                
v_Q  = v_1Q + (v_P*P_Q);         
v_ZT = (v_P*P_ZT);               
v_ZN = (v_P*P_ZN);               
                                 
R_K  = (R_P*P_K);                
R_Q  = (R_P*P_Q);                
R_ZT = R_1ZT + (R_P*P_ZT);       
R_ZN = R_1ZN + (R_P*P_ZN);                          

% Elements of the Jacobian Matrix                                      
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + alphaI*phiI*I*(P_K/P);      
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + alphaI*phiI*I*(P_Q/P);               
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) );                         
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) );             
                                                                       
x11 = Upsilon_K;                                                       
x12 = Upsilon_Q;                                                       
x21 = Sigma_K;                                                         
x22 = Sigma_Q;                                                         
                                                                       
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
omega_12 = V_sorted(1,2)/V_sorted(1,2); 
omega_22 = V_sorted(2,2)/V_sorted(1,2); 

% Solutions                                                      
Upsilon_ZT = (I/IN)*(YN_ZT-CN_ZT) + (alphaI*phiI*I)*(P_ZT/P);    
Upsilon_ZN = (I/IN)*(YN_ZN-CN_ZN) + (alphaI*phiI*I)*(P_ZN/P);    
                                                                 
Sigma_ZT   = -( R_ZT + (PI*kappa*v_ZT*deltaK) );                 
Sigma_ZN   = -( R_ZN + (PI*kappa*v_ZN*deltaK) );                 

%%%%%%%%%%%%%%%%%% Solutions for Permanent Shocks %%%%%%%%%%%%%%%%%%%%                                                       
Vnorm = [omega_11 omega_12; omega_21 omega_22];                                                                              
Vinv   = inv(Vnorm);                                                                                                         
u11    = Vinv(1,1);                                                                                                          
u12    = Vinv(1,2);                                                                                                          
u21    = Vinv(2,1);                                                                                                          
u22    = Vinv(2,2);                                                                                                          
                                                                                                                             
s11   = (u11*Upsilon_ZT) + (u12*Sigma_ZT);                                                                                   
s12   = (u11*Upsilon_ZN) + (u12*Sigma_ZN);                                                                                   
                                                                                                                             
s21   = (u21*Upsilon_ZT) + (u22*Sigma_ZT);                                                                                   
s22   = (u21*Upsilon_ZN) + (u22*Sigma_ZN);                                                                                   
                                                                                                                             
DeltaZT_1   = - s11*ZT_0*(1/(nu_1+xiZT));                                                                                    
DeltaZN_1   = - s12*ZN_0*(1/(nu_1+xiZN));                                                                                    
                                                                                                                             
DeltaZT_2   = s21*ZT_0*(1/(nu_2+xiZT));                                                                                      
DeltaZN_2   = s22*ZN_0*(1/(nu_2+xiZN));                                                                                      
                                                                                                                             
ThetaZT_1   = (1-barzT)*((nu_1+xiZT)/(nu_1+chiZT));                                                                          
ThetaZT_2   = (1-barzT)*((nu_2+xiZT)/(nu_2+chiZT));                                                                          
ThetaZN_1   = (1-barzN)*((nu_1+xiZN)/(nu_1+chiZN));                                                                          
ThetaZN_2   = (1-barzN)*((nu_2+xiZN)/(nu_2+chiZN));                                                                          
                                                                                                                             
X20 = - DeltaZT_2*(1-ThetaZT_2) - DeltaZN_2*(1-ThetaZN_2);                                                                   
X10 = (K0-K) - X20;                                                                                                          
X11 = X10 - DeltaZT_1*(1-ThetaZT_1) - DeltaZN_1*(1-ThetaZN_1);                                                               
                                                                                                                             
% Intertemporal solvency condition - lambda                                                                
B_K    = (YT_K - CT_K - JT_K);                                                                              
B_Q    = (YT_Q - CT_Q - JT_Q);                                                                             
B_ZT   = (YT_ZT - CT_ZT - JT_ZT);                                                                           
B_ZN   = (YT_ZN - CT_ZN - JT_ZN);                                                                          
N1     = (B_K + (B_Q*omega_21));                                                                     
N2     = (B_K + (B_Q*omega_22));                                                                     
ThetaZT_prime  = (1-barzT)*((xiZT+r)/(chiZT+r));                                                           
ThetaZT_1prime = ThetaZT_1*((xiZT+r)/(chiZT+r));                                                           
ThetaZT_2prime = ThetaZT_2*((xiZT+r)/(chiZT+r));                                                           
ThetaZN_prime  = (1-barzN)*((xiZN+r)/(chiZN+r));                                                           
ThetaZN_1prime = ThetaZN_1*((xiZN+r)/(chiZN+r));                                                           
ThetaZN_2prime = ThetaZN_2*((xiZN+r)/(chiZN+r));                                                           
                                                                                                           
wB1   = (N1*X11);                                                                                            
wBZT2 = B_ZT*ZT_0*(1-ThetaZT_prime) + N1*DeltaZT_1*(1-ThetaZT_1prime) - N2*DeltaZT_2*(1-ThetaZT_2prime);
wBZN2 = B_ZN*ZN_0*(1-ThetaZN_prime) + N1*DeltaZN_1*(1-ThetaZN_1prime) - N2*DeltaZN_2*(1-ThetaZN_2prime);   
                                                                                                                             
g(20) = (B-B0)-( (wB1/(r-nu_1)) + (wBZT2/(xiZT+r)) + (wBZN2/(xiZN+r)) );                                                     



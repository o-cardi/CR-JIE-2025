%clc
%clear

global sigma phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global epsilonK varthetaK 
global gammaL sigmaL
global r deltaK kappa
global omegaG omegaGN omegaGH GH GN GF 
global BH BN AH AN gammaH gammaN sigmaH sigmaN ZH ZN
global xi1H xi1N  xi2H xi2N
global B0 K0 Y_0 omegaG_0 AH_0 BH_0 AN_0 BN_0 ZH_0 ZN_0 
global barg baraH barbH baraN barbN xi chi xiAH chiAH xiBH chiBH xiAN chiAN xiBN chiBN
global gAH gBH gAN gBN gG

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

CD_IMK_NS_initial_SYM; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% CES and FBTC - TECH EXO   %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigmaH_0     = 0.808;                                                                                                       
sigmaN_0     = 0.865;
gammaH_0     = sLH_0CD*( sLH_0CD + (1-sLH_0CD)*(kH_0CD^((1-sigmaH_0)/sigmaH_0)) )^(-1);                           
gammaN_0     = sLN_0CD*( sLN_0CD + (1-sLN_0CD)*(kN_0CD^((1-sigmaN_0)/sigmaN_0)) )^(-1);                              
ZH_0         = (YH_0CD/LH_0CD)*( gammaH_0 + (1-gammaH_0)*(kH_0CD^((sigmaH_0 - 1)/sigmaH_0)) )^(sigmaH_0/(1-sigmaH_0));      
ZN_0         = (YN_0CD/LN_0CD)*( gammaN_0 + (1-gammaN_0)*(kN_0CD^((sigmaN_0 - 1)/sigmaN_0)) )^(sigmaN_0/(1-sigmaN_0));      
AH_0         = ZH_0;                                                                                                        
AN_0         = ZN_0;                                                                                                        
BH_0         = ZH_0;                                                                                                        
BN_0         = ZN_0; 

omegaG       = 0.198; 
omegaGN      = 0.838; 
omegaGH      = 0.65;
sigmaL_0     = 3;
gammaL       = 1; 
sigma        = 2;  
phi_0        = 0.35; 
varphi_0     = alphaC_0CD*( alphaC_0CD + (1-alphaC_0CD)*((PN_0CD/PT_0CD)^(phi_0 -1)) )^(-1); 
rho_0        = 1.3;  
varphiH_0    = alphaH_0CD*( alphaH_0CD + (1-alphaH_0CD)*((PH_0CD)^(1-rho_0)) )^(-1); 
epsilon_0    = 0.80;  
vartheta_0   = alphaL_0CD*( alphaL_0CD + (1-alphaL_0CD)*((WH_0CD/WN_0CD)^(1+epsilon_0)) )^(-1); 
epsilonK_0   = 0.15;  
varthetaK_0  = alphaK_0CD*( alphaK_0CD + (1-alphaK_0CD)*((RH_0CD/RN_0CD)^(1+epsilonK_0)) )^(-1); 
phiI_0       = 1.000001;                    
iota_0       = 0.319;  
rhoI_0       = 1.3;  
iotaH_0      = alphaIH_0CD*( alphaIH_0CD + (1-alphaIH_0CD)*((PH_0CD)^(1-rhoI_0)) )^(-1);
kappa        = 17; 
nuX          = 1.3;
ex           = omegaXHY_0CD*Y_0CD*(PH_0CD)^(nuX-1);

r            = 0.027; 
beta         = r; 
deltaK       = (omegaI_0CD/PI_0CD)*(Y_0CD/K_0CD); 

B0           = Y_0CD*(omegaC_0CD+omegaI_0CD+omegaG-1)/r;                                                               
K0           = K_0CD + ((B0 - B_0CD)/H1_0CD); 
 
AH           = AH_0;       
AN           = AN_0;  
BH           = BH_0;       
BN           = BN_0;
gammaH       = gammaH_0;   
gammaN       = gammaN_0;  
sigmaH       = sigmaH_0;   
sigmaN       = sigmaN_0;       
sigmaL       = sigmaL_0;   
phi          = phi_0;     
varphi       = varphi_0;  
rho          = rho_0;     
varphiH      = varphiH_0;
phiI         = phiI_0;    
iota         = iota_0; 
rhoI         = rhoI_0;    
iotaH        = iotaH_0;
epsilon      = epsilon_0;  
vartheta     = vartheta_0; 
epsilonK     = epsilonK_0;  
varthetaK    = varthetaK_0;
                                                                                                                                                                                                                                                                                                                                                                     
xi2H     = 0.5; %0.1; % capital utilization adustment costs in the traded sector                                                                                                                              
xi2N     = 0.6;  % capital utilization adustment costs in the non-traded sector 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.270  ; % Consumption
L_ini        = 0.905  ; % Total hours worked
RH_ini       = 0.220  ; % Capital rental rate in sector H
RN_ini       = 0.220  ; % Capital rental rate in sector N
WH_ini       = 3.763  ; % Wage rate in sector H
WN_ini       = 4.244  ; % Wage rate in sector N
W_ini        = 4.065  ; % Aggregate wage index
RK_ini       = 0.220  ; % Aggregate capital rental rate
PN_ini       = 3.104  ; % Non-traded good prices
K_ini        = 8.447  ; % Stock of capital
PH_ini       = 2.540  ; % Terms of trade
B_ini        = 0.63   ; % Stock of traded Bonds
alphaL_ini   = 0.333  ; % Labor compensation share of tradables
alphaK_ini   = 0.389  ; % Capital compensation share of tradables
PC_ini       = 2.491  ; % Aggregate consumption price index
PT_ini       = 1.898  ; % Consumption price index for tradables
CN_ini       = 0.576  ; % Consumption in non-traded goods
CH_ini       = 0.356  ; % Consumption in home-produced traded goods
CF_ini       = 0.472  ; % Consumption in foreign goods
alphaC_ini   = 0.434  ; % Tradable content of consumption expenditure
alphaH_ini   = 0.657  ; % Home goods content of consumption expenditure on traded goods
PI_ini       = 2.477  ; % Aggregate investment price index
PIT_ini      = 1.531  ; % Investment price index for traded goods
IN_ini       = 0.285  ; % Non traded investment
IH_ini       = 0.069  ; % Home goods investment
IF_ini       = 0.239  ; % Foreign goods investment
alphaI_ini   = 0.319  ; % Tradable content of investment expenditure
alphaIH_ini  = 0.422  ; % Home goods content of investment expenditure on traded goods
LH_ini       = 0.326  ; % Labor in sector H
LN_ini       = 0.578  ; % Labor in sector N
KH_ini       = 3.282  ; % Capital stock in sector H
KN_ini       = 5.165  ; % Capital stock in sector N
GF_ini       = 0.03   ; % Government spending in foreign goods
GH_ini       = 0.05   ; % Government spending in home goods
GN_ini       = 0.30   ; % Government spending in non tradables
YH_ini       = 0.768  ; % Traded value added
YN_ini       = 1.158  ; % Non traded value added
XH_ini       = 0.298  ; % Exports of home traded goods
MF_ini       = 0.773  ; % Imports of foreign goods
xi1H_ini     = 0.09   ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N_ini     = 0.07   ; % Parameter of non-traded capital utilization cost function
VL_ini       = 1.41   ; % Desutility labor
lambda_ini   = 0.494  ; % Intertemporal Solvency Condition

x0 =[C_ini L_ini RH_ini RN_ini WH_ini WN_ini W_ini RK_ini PN_ini K_ini PH_ini B_ini alphaL_ini alphaK_ini PC_ini PT_ini CN_ini CH_ini CF_ini alphaC_ini alphaH_ini PI_ini PIT_ini IN_ini IH_ini IF_ini alphaI_ini alphaIH_ini LH_ini LN_ini KH_ini KN_ini GF_ini GN_ini GH_ini YH_ini YN_ini XH_ini MF_ini xi1H_ini xi1N_ini VL_ini lambda_ini];
[x,~,exitflag]=fsolve('IML_IMK_CAC_TOT_CES_NS_SS0_SYM',x0,optimset('display','off','TolFun',1e-011));

C        = x(1)  ; % Consumption
L        = x(2)  ; % Labor supply
RH       = x(3)  ; % Return on traded capital
RN       = x(4)  ; % Return on non-traded capital
WH       = x(5)  ; % Wage rate in sector H
WN       = x(6)  ; % Wage rate in sector N
W        = x(7)  ; % Aggregate wage index
RK       = x(8)  ; % Aggregate capital rental rate
PN       = x(9)  ; % Relative price of non tradables
K        = x(10)  ; % Stock of capital
PH       = x(11) ; % Terms of trade : PH/PF with PF = numeraire
B        = x(12) ; % Stock of Traded Bonds
alphaL   = x(13) ; % Labor compensation share of tradables
alphaK   = x(14) ; % Capital compensation share of tradables
PC       = x(15) ; % Aggregate consumption price index
PT       = x(16) ; % Consumption price index for tradables
CN       = x(17) ; % Consumption in non tradables
CH       = x(18) ; % Consumption in tradables
CF       = x(19) ; % Consumption goods imports
alphaC   = x(20) ; % Tradable content of consumption expenditure
alphaH   = x(21) ; % Home goods content of consumption expenditure on traded goods
PI       = x(22) ; % Aggregate investment price index
PIT      = x(23) ; % Investment price index for tradables
IN       = x(24) ; % Non tradable investment
IH       = x(25) ; % Investment in home goods
IF       = x(26) ; % Investment in foreign goods
alphaI   = x(27) ; % Tradable content of investment expenditure
alphaIH  = x(28) ; % Home goods content of investment expenditure
LH       = x(29) ; % Labor in sector H
LN       = x(30) ; % Labor in sector N
KH       = x(31) ; % Capital stock in sector H
KN       = x(32) ; % Capital stock in sector N
GF       = x(33) ; % Government spending in foreign goods
GN       = x(34) ; % Government spending in non tradables
GH       = x(35) ; % Government spending in home traded goods
YH       = x(36) ; % Traded value added
YN       = x(37) ; % Non-traded value added
XH       = x(38) ; % Exports of home traded goods
MF       = x(39) ; % Imports of foreign goods
xi1H     = x(40) ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N     = x(41) ; % Parameter of non-traded capital utilization cost function
VL       = x(42) ; % Desutility labor
lambda   = x(43) ; % Marginal Utility of Wealth - Intertemporal Solvency Condition                                                 

% Sectoral outputs and sectoral profits    
PiH = (PH*YH) - (RH*KH) - (WH*LH);  
PiN = (PN*YN) - (RN*KN) - (WN*LN);

% Value added and labor share
Y   = (PH*YH) +(PN*YN);
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L; 

% Labor income share in the home traded good and non traded good sector
kH  = KH/LH; 
kN  = KN/LN; 
yH  = YH/LH; 
yN  = YN/LN; 
sLH = WH*LH/(PH*YH);
sLN = WN*LN/(PN*YN);
sL  = W*L/Y; 
k   = K/L; 
P   = PN/PH; 
KHK = KH/K; 

% Unit cost for producting
MN = ((gammaN^sigmaN)*((WN/AN)^(1-sigmaN)) + ((1-gammaN)^sigmaN)*((RN/BN)^(1-sigmaN)))^(1/(1-sigmaN));   
MH = ((gammaH^sigmaH)*((WH/AH)^(1-sigmaH)) + ((1-gammaH)^sigmaH)*((RH/BH)^(1-sigmaH)))^(1/(1-sigmaH));   

% Technology
ZH = ((AH)^(sLH))*((BH)^(1-sLH)); 
ZN = ((AN)^(sLN))*((BN)^(1-sLN)); 
Z  = (ZH^omegaYH)*(ZN^(1-omegaYH));
TFPH = YH/(gammaH*(LH^((sigmaH-1)/sigmaH)) + (1-gammaH)*(KH^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1)); 
TFPN = YN/(gammaN*(LN^((sigmaN-1)/sigmaN)) + (1-gammaN)*(KN^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1)); 
TFP  = (TFPH^omegaYH)*(TFPN^(1-omegaYH));

% Non Sep preferences Shimer (2009)
%VL        = ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );
V_L       = (sigma-1)*gammaL*L^(1/sigmaL);
V_LL      = (sigma-1)*(gammaL/sigmaL)*(L^((1/sigmaL)-1)); 
U_C       =  (C^(-sigma))*(VL^sigma); 
U_CC      = -sigma*(C^(-sigma-1))*(VL^sigma); 
U_L       = ( (C^(1-sigma))*sigma*V_L*(VL^(sigma-1)) )/(1-sigma);
U_LL      = U_L*( (V_LL/V_L) + (sigma-1)*V_L*(VL^(-1)) ); 
U_CL      = (C^(-sigma))*sigma*V_L*(VL^(sigma-1));
U_LC      = U_CL; 

% Solutions C=C(lambda,PN,PH,W); L=L(lambda,PN,PH,W)                      
a11 = (U_CC/U_C);                                                         
a12 = (U_CL/U_C);                                                         
a21 = (U_LC/U_L);                                                         
a22 = (U_LL/U_L);                                                         
                                                                          
% PN, PH, W, lambda                                                            
b11 = (1-alphaC)/PN;                                                      
b12 = alphaC*alphaH/PH;                                                   
b13 = 0; 
b14 = (1/lambda); 
                                                                          
b21 = 0;                                                                  
b22 = 0;                                                                  
b23 = (1/W);   
b24 = (1/lambda); 
                                                                          
A1 = [a11 a12; a21 a22];                                                  
B1 = [b11 b12 b13 b14; b21 b22 b23 b24];                                          
JST1 = inv(A1);                                                           
MST1 = JST1*B1;                                                           
C_1PN = MST1(1,1); C_1PH = MST1(1,2); C_W = MST1(1,3); C_1lambda = MST1(1,4);                  
L_1PN = MST1(2,1); L_1PH = MST1(2,2); L_W = MST1(2,3); L_1lambda = MST1(2,4);

% Partial derivatives of W=W(WN,WH)           
W_WH     = (W/WH)*alphaL; 
W_WN     = (W/WN)*(1-alphaL);                                                                                                                         
L_WH     = L_W*W_WH;                                                                    
L_WN     = L_W*W_WN;                                                                    
                                                                                        
% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH,WN,WH)                      
CN_1PN = - (CN/PN)*(alphaC*phi) + (CN/C)*C_1PN;                                         
CN_1PH = (CN/PH)*alphaC*alphaH*phi + (CN/C)*C_1PH;                                      
CN_WN  = (CN/C)*C_W*W_WN;                                                               
CN_WH  = (CN/C)*C_W*W_WH;                                                               
                                                                                        
CH_1PN = (CH/PN)*phi*(1-alphaC) + (CH/C)*C_1PN;                                         
CH_1PH = -(CH/PH)*( rho*(1-alphaH) + phi*alphaH*(1-alphaC) ) + (CH/C)*C_1PH;            
CH_WN  = (CH/C)*C_W*W_WN;                                                               
CH_WH  = (CH/C)*C_W*W_WH;                                                               
                                                                                        
CF_1PN = (CF/PN)*(1-alphaC)*phi + (CF/C)*C_1PN;                                         
CF_1PH = (CF/PH)*alphaH*(rho - phi*(1-alphaC) ) + (CF/C)*C_1PH;                         
CF_WN  = (CF/C)*C_W*W_WN;                                                               
CF_WH  = (CF/C)*C_W*W_WH;   

CH_1lamb = (CH/C)*C_1lambda; 
CN_1lamb = (CN/C)*C_1lambda;
CF_1lamb = (CF/C)*C_1lambda;

% Solutions LH=LH(lambda,WH,WN,PH,PN), LN=LN(lambda,WH,WN,PH,PN)
LH_WH  = (LH/WH)*epsilon*(1-alphaL) + (LH/L)*L_WH; 
LH_WN  = -(LH/WN)*epsilon*(1-alphaL) + (LH/L)*L_WN; 
LH_1PH = (LH/L)*L_1PH; 
LH_1PN = (LH/L)*L_1PN;

LN_WH  = -(LN/WH)*epsilon*alphaL + (LN/L)*L_WH; 
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN; 
LN_1PH = (LN/L)*L_1PH; 
LN_1PN = (LN/L)*L_1PN;

LH_1lamb   = (LH/L)*L_1lambda;
LN_1lamb   = (LN/L)*L_1lambda;

% Partial derivatives of RK(RH,RN)               
R_RH  = (RK/RH)*alphaK;                         
R_RN  = (RK/RN)*(1-alphaK);                     
                                                 
% Solutions Kj=Kj(RH,RN,K), j=H,N                
KH_RH  = (KH/RH)*epsilonK*(1-alphaK);            
KH_RN  = -(KH/RN)*epsilonK*(1-alphaK);           
KH_1K  = (KH/K);                                 
                                                 
KN_RH  = -(KN/RH)*epsilonK*alphaK;               
KN_RN  = (KN/RN)*epsilonK*alphaK;                
KN_1K  = (KN/K);                                    

% Solving for WH,WN,RH,RN(PH,PN,K,uKH,uKN,AH,BH,AN,BN,lambda)
d11 = - ( ((1-sLH)/sigmaH)*(LH_WH/LH) + (1/WH) ); % WH
d12 = - ((1-sLH)/sigmaH)*(LH_WN/LH);  % WN
d13 = ((1-sLH)/sigmaH)*(KH_RH/KH);  % RH
d14 = ((1-sLH)/sigmaH)*(KH_RN/KH); % RN

d21 = - ((1-sLN)/sigmaN)*(LN_WH/LN);  % WH
d22 = - ( ((1-sLN)/sigmaN)*(LN_WN/LN) + (1/WN) ); % WN
d23 = ((1-sLN)/sigmaN)*(KN_RH/KN);  % RH
d24 = ((1-sLN)/sigmaN)*(KN_RN/KN); % RN

d31 = (sLH/sigmaH)*(LH_WH/LH); % WH
d32 = (sLH/sigmaH)*(LH_WN/LH); % WN
d33 = - ( (sLH/sigmaH)*(KH_RH/KH) + (1/RH) ); % RH
d34 = - (sLH/sigmaH)*(KH_RN/KH); % RN

d41 = (sLN/sigmaN)*(LN_WH/LN); % WH
d42 = (sLN/sigmaN)*(LN_WN/LN); % WN
d43 = - (sLN/sigmaN)*(KN_RH/KN); % RH
d44 = - ( (sLN/sigmaN)*(KN_RN/KN) + (1/RN) ); % RN

% PN,PH,K,uKH,uKN,AH,BH,AN,BN,lambda
e11 = ((1-sLH)/sigmaH)*(LH_1PN/LH); % PN
e12 = ((1-sLH)/sigmaH)*(LH_1PH/LH) - (1/PH); % PH
e13 = - ((1-sLH)/sigmaH)*(KH_1K/KH); % K
e14 = - ((1-sLH)/sigmaH); % uKH
e15 = 0; % uKN
e16  = - ( ((sigmaH-1)/sigmaH)+ (sLH/sigmaH) )*(1/AH);  % AH
e17  = - ((1-sLH)/sigmaH)*(1/BH);  % BH
e18  = 0;
e19  = 0;
e110 = ((1-sLH)/sigmaH)*(LH_1lamb/LH); % lambda

e21 = ((1-sLN)/sigmaN)*(LN_1PN/LN) - (1/PN); % PN
e22 = ((1-sLN)/sigmaN)*(LN_1PH/LN);  % PH
e23 = - ((1-sLN)/sigmaN)*(KN_1K/KN); % K
e24 = 0; % uKH
e25 = - ((1-sLN)/sigmaN);  % uKN
e26  = 0;
e27  = 0;
e28  = - ( ((sigmaN-1)/sigmaN) + (sLN/sigmaN) )*(1/AN);  % AN
e29  = - ((1-sLN)/sigmaN)*(1/BN);    % BN
e210 = ((1-sLN)/sigmaN)*(LN_1lamb/LN);  % lambda

e31 = - (sLH/sigmaH)*(LH_1PN/LH); % PN
e32 = - ( (sLH/sigmaH)*(LH_1PH/LH) + (1/PH) ); % PH
e33 = (sLH/sigmaH)*(KH_1K/KH); % K
e34 = (sLH/sigmaH); % uKH
e35 = 0;  % uKN
e36  = - (sLH/sigmaH)*(1/AH); % AH
e37  = - ((sigmaH-sLH)/sigmaH)*(1/BH); % BH
e38  = 0;
e39  = 0;
e310 = - (sLH/sigmaH)*(LH_1lamb/LH); % lambda

e41 = - ( (sLN/sigmaN)*(LN_1PN/LN) + (1/PN) ); % PN
e42 = - (sLN/sigmaN)*(LN_1PH/LN); % PH
e43 = (sLN/sigmaN)*(KN_1K/KN); % K
e44 = 0;  % uKH
e45 = (sLN/sigmaN); % uKN
e46  = 0;
e47  = 0;
e48  = - (sLN/sigmaN)*(1/AN); % AN
e49  = - ((sigmaN-sLN)/sigmaN)*(1/BN); % BN
e410 = - (sLN/sigmaN)*(LN_1lamb/LN); % lambda

M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X2 = [e11 e12 e13 e14 e15 e16 e17 e18 e19 e110; e21 e22 e23 e24 e25 e26 e27 e28 e29 e210; e31 e32 e33 e34 e35 e36 e37 e38 e39 e310; e41 e42 e43 e44 e45 e46 e47 e48 e49 e410];
JST2 = inv(M2);
MST2 = JST2*X2;
WH_1PN = MST2(1,1); WH_1PH = MST2(1,2); WH_1K = MST2(1,3); WH_uKH = MST2(1,4); WH_uKN = MST2(1,5); WH_1AH = MST2(1,6); WH_1BH = MST2(1,7); WH_1AN = MST2(1,8); WH_1BN = MST2(1,9); WH_1lambda = MST2(1,10);
WN_1PN = MST2(2,1); WN_1PH = MST2(2,2); WN_1K = MST2(2,3); WN_uKH = MST2(2,4); WN_uKN = MST2(2,5); WN_1AH = MST2(2,6); WN_1BH = MST2(2,7); WN_1AN = MST2(2,8); WN_1BN = MST2(2,9); WN_1lambda = MST2(2,10);
RH_1PN = MST2(3,1); RH_1PH = MST2(3,2); RH_1K = MST2(3,3); RH_uKH = MST2(3,4); RH_uKN = MST2(3,5); RH_1AH = MST2(3,6); RH_1BH = MST2(3,7); RH_1AN = MST2(3,8); RH_1BN = MST2(3,9); RH_1lambda = MST2(3,10);
RN_1PN = MST2(4,1); RN_1PH = MST2(4,2); RN_1K = MST2(4,3); RN_uKH = MST2(4,4); RN_uKN = MST2(4,5); RN_1AH = MST2(4,6); RN_1BH = MST2(4,7); RN_1AN = MST2(4,8); RN_1BN = MST2(4,9); RN_1lambda = MST2(4,10);

% Solving for sectoral labor and sectoral output - Lj,Kj,Yj(PN,PH,K,uKj,Aj,Bj,lambda)
LH_2PN = LH_1PN + (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_2PH = LH_1PH + (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K  = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKH = (LH_WH*WH_uKH) + (LH_WN*WN_uKH);
LH_uKN = (LH_WH*WH_uKN) + (LH_WN*WN_uKN);
LH_1AH = (LH_WH*WH_1AH) + (LH_WN*WN_1AH);
LH_1BH = (LH_WH*WH_1BH) + (LH_WN*WN_1BH);
LH_1AN = (LH_WH*WH_1AN) + (LH_WN*WN_1AN);
LH_1BN = (LH_WH*WH_1BN) + (LH_WN*WN_1BN);
LH_1lambda = LH_1lamb + (LH_WH*WH_1lambda) + (LH_WN*WN_1lambda);

LN_2PN = LN_1PN + (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_2PH = LN_1PH + (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K  = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKH = (LN_WH*WH_uKH) + (LN_WN*WN_uKH);
LN_uKN = (LN_WH*WH_uKN) + (LN_WN*WN_uKN);
LN_1AH = (LN_WH*WH_1AH) + (LN_WN*WN_1AH);
LN_1BH = (LN_WH*WH_1BH) + (LN_WN*WN_1BH);
LN_1AN = (LN_WH*WH_1AN) + (LN_WN*WN_1AN);
LN_1BN = (LN_WH*WH_1BN) + (LN_WN*WN_1BN);
LN_1lambda = LN_1lamb + (LN_WH*WH_1lambda) + (LN_WN*WN_1lambda);

KH_1PN = (KH_RH*RH_1PN) + (KH_RN*RN_1PN);
KH_1PH = (KH_RH*RH_1PH) + (KH_RN*RN_1PH);
KH_2K  = KH_1K  +(KH_RH*RH_1K)  + (KH_RN*RN_1K);
KH_uKH = (KH_RH*RH_uKH) + (KH_RN*RN_uKH);
KH_uKN = (KH_RH*RH_uKN) + (KH_RN*RN_uKN);
KH_1AH = (KH_RH*RH_1AH) + (KH_RN*RN_1AH);
KH_1BH = (KH_RH*RH_1BH) + (KH_RN*RN_1BH);
KH_1AN = (KH_RH*RH_1AN) + (KH_RN*RN_1AN);
KH_1BN = (KH_RH*RH_1BN) + (KH_RN*RN_1BN);
KH_1lambda = (KH_RH*RH_1lambda) + (KH_RN*RN_1lambda);

KN_1PN = (KN_RH*RH_1PN) + (KN_RN*RN_1PN);
KN_1PH = (KN_RH*RH_1PH) + (KN_RN*RN_1PH);
KN_2K  = KN_1K + (KN_RH*RH_1K)  + (KN_RN*RN_1K);
KN_uKH = (KN_RH*RH_uKH) + (KN_RN*RN_uKH);
KN_uKN = (KN_RH*RH_uKN) + (KN_RN*RN_uKN);
KN_1AH = (KN_RH*RH_1AH) + (KN_RN*RN_1AH);
KN_1BH = (KN_RH*RH_1BH) + (KN_RN*RN_1BH);
KN_1AN = (KN_RH*RH_1AN) + (KN_RN*RN_1AN);
KN_1BN = (KN_RH*RH_1BN) + (KN_RN*RN_1BN);
KN_1lambda = (KN_RH*RH_1lambda) + (KN_RN*RN_1lambda);

YH_1PN = sLH*YH*(LH_2PN/LH) + (1-sLH)*YH*(KH_1PN/KH);                    
YH_1PH = sLH*YH*(LH_2PH/LH) + (1-sLH)*YH*(KH_1PH/KH);                    
YH_1K  = sLH*YH*(LH_1K/LH) + (1-sLH)*YH*(KH_2K/KH);                      
YH_uKH = sLH*YH*(LH_uKH/LH) + (1-sLH)*YH*( (KH_uKH/KH) + 1 );            
YH_uKN = sLH*YH*(LH_uKN/LH) + (1-sLH)*YH*(KH_uKN/KH);                   
YH_1AH = sLH*YH*( (LH_1AH/LH) + (1/AH) ) + (1-sLH)*YH*(KH_1AH/KH);       
YH_1BH = sLH*YH*(LH_1BH/LH) + (1-sLH)*YH*( (KH_1BH/KH) + (1/BH) );       
YH_1AN = sLH*YH*(LH_1AN/LH) + (1-sLH)*YH*(KH_1AN/KH);                    
YH_1BN = sLH*YH*(LH_1BN/LH) + (1-sLH)*YH*(KH_1BN/KH);                    
YH_1lambda =  sLH*YH*(LH_1lambda/LH) + (1-sLH)*YH*(KH_1lambda/KH);       

YN_1PN = sLN*YN*(LN_2PN/LN) + (1-sLN)*YN*(KN_1PN/KN);
YN_1PH = sLN*YN*(LN_2PH/LN) + (1-sLN)*YN*(KN_1PH/KN);
YN_1K  = sLN*YN*(LN_1K/LN) + (1-sLN)*YN*(KN_2K/KN);
YN_uKH = sLN*YN*(LN_uKH/LN) + (1-sLN)*YN*(KN_uKH/KN);
YN_uKN = sLN*YN*(LN_uKN/LN) + (1-sLN)*YN*( (KN_uKN/KN) + 1);
YN_1AH = sLN*YN*(LN_1AH/LN) + (1-sLN)*YN*(KN_1AH/KN);
YN_1BH = sLN*YN*(LN_1BH/LN) + (1-sLN)*YN*(KN_1BH/KN);
YN_1AN = sLN*YN*( (LN_1AN/LN) + (1/AN) ) + (1-sLN)*YN*(KN_1AN/KN);
YN_1BN = sLN*YN*(LN_1BN/LN) + (1-sLN)*YN*( (KN_1BN/KN) + (1/BN) );
YN_1lambda = sLN*YN*(LN_1lambda/LN) + (1-sLN)*YN*(KN_1lambda/KN);    

% Intermediate solution for CN, CH, CF - Cj=Cj(PN,PH,K,uKj,Aj,Bj)   
CN_2PN     = CN_1PN + (CN_WH*WH_1PN) + (CN_WN*WN_1PN);                 
CN_2PH     = CN_1PH + (CN_WH*WH_1PH) + (CN_WN*WN_1PH);                 
CN_1K      = (CN_WH*WH_1K) + (CN_WN*WN_1K);                            
CN_uKH     = (CN_WH*WH_uKH) + (CN_WN*WN_uKH);                          
CN_uKN     = (CN_WH*WH_uKN) + (CN_WN*WN_uKN);                          
CN_1AH     = (CN_WH*WH_1AH) + (CN_WN*WN_1AH);                          
CN_1BH     = (CN_WH*WH_1BH) + (CN_WN*WN_1BH);                          
CN_1AN     = (CN_WH*WH_1AN) + (CN_WN*WN_1AN);                          
CN_1BN     = (CN_WH*WH_1BN) + (CN_WN*WN_1BN);                          
CN_1lambda = CH_1lamb + (CN_WH*WH_1lambda) + (CN_WN*WN_1lambda);       
                                                                       
CH_2PN     = CH_1PN + (CH_WH*WH_1PN) + (CH_WN*WN_1PN);                 
CH_2PH     = CH_1PH + (CH_WH*WH_1PH) + (CH_WN*WN_1PH);                 
CH_1K      = (CH_WH*WH_1K) + (CH_WN*WN_1K);                            
CH_uKH     = (CH_WH*WH_uKH) + (CH_WN*WN_uKH);                          
CH_uKN     = (CH_WH*WH_uKN) + (CH_WN*WN_uKN);                          
CH_1AH     = (CH_WH*WH_1AH) + (CH_WN*WN_1AH);                          
CH_1BH     = (CH_WH*WH_1BH) + (CH_WN*WN_1BH);                          
CH_1AN     = (CH_WH*WH_1AN) + (CH_WN*WN_1AN);                          
CH_1BN     = (CH_WH*WH_1BN) + (CH_WN*WN_1BN);                          
CH_1lambda = CH_1lamb + (CH_WH*WH_1lambda) + (CH_WN*WN_1lambda);       
                                                                       
CF_2PN     = CF_1PN + (CF_WH*WH_1PN) + (CF_WN*WN_1PN);                 
CF_2PH     = CF_1PH + (CF_WH*WH_1PH) + (CF_WN*WN_1PH);                 
CF_1K      = (CF_WH*WH_1K) + (CF_WN*WN_1K);                            
CF_uKH     = (CF_WH*WH_uKH) + (CF_WN*WN_uKH);                          
CF_uKN     = (CF_WH*WH_uKN) + (CF_WN*WN_uKN);                          
CF_1AH     = (CF_WH*WH_1AH) + (CF_WN*WN_1AH);                          
CF_1BH     = (CF_WH*WH_1BH) + (CF_WN*WN_1BH);                          
CF_1AN     = (CF_WH*WH_1AN) + (CF_WN*WN_1AN);                          
CF_1BN     = (CF_WH*WH_1BN) + (CF_WN*WN_1BN);                          
CF_1lambda = CH_1lamb + (CF_WH*WH_1lambda) + (CF_WN*WN_1lambda);       
                                                                                                                                        
% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I      = deltaK*K; 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKH, uKN; uKj(PN,PH,K)                                    
f11 = ((xi2H/xi1H) + (sLH/sigmaH)) - (sLH/sigmaH)*(LH_uKH/LH) + (sLH/sigmaH)*(KH_uKH/KH); % uKH                   
f12 = - (sLH/sigmaH)*(LH_uKN/LH) + (sLH/sigmaH)*(KH_uKN/KH); % uKN                                                
f21 = - (sLN/sigmaN)*(LN_uKH/LN) + (sLN/sigmaN)*(KN_uKH/KN); % uKH                                                
f22 = ((xi2N/xi1N) + (sLN/sigmaN)) - (sLN/sigmaN)*(LN_uKN/LN) + (sLN/sigmaN)*(KN_uKN/KN); % uKN                   
                                                                                                                  
% PN, PH, K, AH, BH, AN, BN, lambda                                                                                                       
g11 = (sLH/sigmaH)*(LH_2PN/LH) - (sLH/sigmaH)*(KH_1PN/KH); % PN                                                   
g12 = (sLH/sigmaH)*(LH_2PH/LH) - (sLH/sigmaH)*(KH_1PH/KH); % PH                                                   
g13 = (sLH/sigmaH)*(LH_1K/LH) - (sLH/sigmaH)*(KH_2K/KH); % K                                                      
g14 = (sLH/sigmaH)*( (LH_1AH/LH) + (1/AH) ) - (sLH/sigmaH)*(KH_1AH/KH); % AH                                      
g15 = (sLH/sigmaH)*(LH_1BH/LH) - (sLH/sigmaH)*(KH_1BH/KH) + ((sigmaH-sLH)/sigmaH)*(1/BH); % BH                                       
g16 = (sLH/sigmaH)*(LH_1AN/LH) - (sLH/sigmaH)*(KH_1AN/KH); % AN                                                   
g17 = (sLH/sigmaH)*(LH_1BN/LH) - (sLH/sigmaH)*(KH_1BN/KH); % BN                                                   
g18 = (sLH/sigmaH)*(LH_1lambda/LH) - (sLH/sigmaH)*(KH_1lambda/KH); % lambda                                       
                                                                                                                  
g21 = (sLN/sigmaN)*(LN_2PN/LN) - (sLN/sigmaN)*(KN_1PN/KN); % PN                                                   
g22 = (sLN/sigmaN)*(LN_2PH/LN) - (sLN/sigmaN)*(KN_1PH/KN); % PH                                                   
g23 = (sLN/sigmaN)*(LN_1K/LN) - (sLN/sigmaN)*(KN_2K/KN); % K                                                      
g24 = (sLN/sigmaN)*(LN_1AH/LN) - (sLN/sigmaN)*(KN_1AH/KN); % AH                                                   
g25 = (sLN/sigmaN)*(LN_1BH/LN) - (sLN/sigmaN)*(KN_1BH/KN); % BH                                                   
g26 = (sLN/sigmaN)*( (LN_1AN/LN) + (1/AN) ) - (sLN/sigmaN)*(KN_1AN/KN); % AN                                      
g27 = (sLN/sigmaN)*(LN_1BN/LN) - (sLN/sigmaN)*(KN_1BN/KN) + ((sigmaN-sLN)/sigmaN)*(1/BN); % BN                                     
g28 = (sLN/sigmaN)*(LN_1lambda/LN) - (sLN/sigmaN)*(KN_1lambda/KN); % lambda                                       

M3 = [f11 f12; f21 f22];
X3 = [g11 g12 g13 g14 g15 g16 g17 g18; g21 g22 g23 g24 g25 g26 g27 g28];
JST3 = inv(M3);
MST3 = JST3*X3;

uKH_PN = MST3(1,1); uKH_PH = MST3(1,2); uKH_1K = MST3(1,3); uKH_1AH = MST3(1,4); uKH_1BH = MST3(1,5); uKH_1AN = MST3(1,6); uKH_1BN = MST3(1,7); uKH_1lambda = MST3(1,8);
uKN_PN = MST3(2,1); uKN_PH = MST3(2,2); uKN_1K = MST3(2,3); uKN_1AH = MST3(2,4); uKN_1BH = MST3(2,5); uKN_1AN = MST3(2,6); uKN_1BN = MST3(2,7); uKN_1lambda = MST3(2,8);

% Solving for Wj,Rj,Lj,Kj,Yj(lambda,K,PH,PN,AH,BH,AN,BN)
WH_2K  = WH_1K + (WH_uKH*uKH_1K) + (WH_uKN*uKN_1K);
WH_PH  = WH_1PH + (WH_uKH*uKH_PH) + (WH_uKN*uKN_PH);
WH_PN  = WH_1PN + (WH_uKH*uKH_PN) + (WH_uKN*uKN_PN);
WH_2AH = WH_1AH + (WH_uKH*uKH_1AH) + (WH_uKN*uKN_1AH);
WH_2BH = WH_1BH + (WH_uKH*uKH_1BH) + (WH_uKN*uKN_1BH);
WH_2AN = WH_1AN + (WH_uKH*uKH_1AN) + (WH_uKN*uKN_1AN);
WH_2BN = WH_1BN + (WH_uKH*uKH_1BN) + (WH_uKN*uKN_1BN);
WH_2lambda = WH_1lambda + (WH_uKH*uKH_1lambda) + (WH_uKN*uKN_1lambda);

WN_2K = WN_1K + (WN_uKH*uKH_1K) + (WN_uKN*uKN_1K);
WN_PH = WN_1PH + (WN_uKH*uKH_PH) + (WN_uKN*uKN_PH);
WN_PN = WN_1PN + (WN_uKH*uKH_PN) + (WN_uKN*uKN_PN);
WN_2AH = WN_1AH + (WN_uKH*uKH_1AH) + (WN_uKN*uKN_1AH);
WN_2BH = WN_1BH + (WN_uKH*uKH_1BH) + (WN_uKN*uKN_1BH);
WN_2AN = WN_1AN + (WN_uKH*uKH_1AN) + (WN_uKN*uKN_1AN);
WN_2BN = WN_1BN + (WN_uKH*uKH_1BN) + (WN_uKN*uKN_1BN);
WN_2lambda = WN_1lambda + (WN_uKH*uKH_1lambda) + (WN_uKN*uKN_1lambda);

RH_2K  = RH_1K + (RH_uKH*uKH_1K) + (RH_uKN*uKN_1K);                              
RH_PH  = RH_1PH + (RH_uKH*uKH_PH) + (RH_uKN*uKN_PH);                             
RH_PN  = RH_1PN + (RH_uKH*uKH_PN) + (RH_uKN*uKN_PN);                             
RH_2AH = RH_1AH + (RH_uKH*uKH_1AH) + (RH_uKN*uKN_1AH);                           
RH_2BH = RH_1BH + (RH_uKH*uKH_1BH) + (RH_uKN*uKN_1BH);                           
RH_2AN = RH_1AN + (RH_uKH*uKH_1AN) + (RH_uKN*uKN_1AN);                           
RH_2BN = RH_1BN + (RH_uKH*uKH_1BN) + (RH_uKN*uKN_1BN);                           
RH_2lambda = RH_1lambda + (RH_uKH*uKH_1lambda) + (RH_uKN*uKN_1lambda);           
                                                                                 
RN_2K = RN_1K + (RN_uKH*uKH_1K) + (RN_uKN*uKN_1K);                               
RN_PH = RN_1PH + (RN_uKH*uKH_PH) + (RN_uKN*uKN_PH);                              
RN_PN = RN_1PN + (RN_uKH*uKH_PN) + (RN_uKN*uKN_PN);                              
RN_2AH = RN_1AH + (RN_uKH*uKH_1AH) + (RN_uKN*uKN_1AH);                           
RN_2BH = RN_1BH + (RN_uKH*uKH_1BH) + (RN_uKN*uKN_1BH);                           
RN_2AN = RN_1AN + (RN_uKH*uKH_1AN) + (RN_uKN*uKN_1AN);                           
RN_2BN = RN_1BN + (RN_uKH*uKH_1BN) + (RN_uKN*uKN_1BN);                           
RN_2lambda = RN_1lambda + (RN_uKH*uKH_1lambda) + (RN_uKN*uKN_1lambda);           

LH_2K = LH_1K + (LH_uKH*uKH_1K) + (LH_uKN*uKN_1K);
LH_PH = LH_2PH + (LH_uKH*uKH_PH) + (LH_uKN*uKN_PH);
LH_PN = LH_2PN + (LH_uKH*uKH_PN) + (LH_uKN*uKN_PN);
LH_2AH = LH_1AH + (LH_uKH*uKH_1AH) + (LH_uKN*uKN_1AH);
LH_2BH = LH_1BH + (LH_uKH*uKH_1BH) + (LH_uKN*uKN_1BH);
LH_2AN = LH_1AN + (LH_uKH*uKH_1AN) + (LH_uKN*uKN_1AN);
LH_2BN = LH_1BN + (LH_uKH*uKH_1BN) + (LH_uKN*uKN_1BN);
LH_2lambda = LH_1lambda + (LH_uKH*uKH_1lambda) + (LH_uKN*uKN_1lambda);

LN_2K = LN_1K + (LN_uKH*uKH_1K) + (LN_uKN*uKN_1K);
LN_PH = LN_2PH + (LN_uKH*uKH_PH) + (LN_uKN*uKN_PH);
LN_PN = LN_2PN + (LN_uKH*uKH_PN) + (LN_uKN*uKN_PN);
LN_2AH = LN_1AH + (LN_uKH*uKH_1AH) + (LN_uKN*uKN_1AH);
LN_2BH = LN_1BH + (LN_uKH*uKH_1BH) + (LN_uKN*uKN_1BH);
LN_2AN = LN_1AN + (LN_uKH*uKH_1AN) + (LN_uKN*uKN_1AN);
LN_2BN = LN_1BN + (LN_uKH*uKH_1BN) + (LN_uKN*uKN_1BN);
LN_2lambda = LN_1lambda + (LN_uKH*uKH_1lambda) + (LN_uKN*uKN_1lambda);

KH_3K = KH_2K + (KH_uKH*uKH_1K) + (KH_uKN*uKN_1K);
KH_PH = KH_1PH + (KH_uKH*uKH_PH) + (KH_uKN*uKN_PH);
KH_PN = KH_1PN + (KH_uKH*uKH_PN) + (KH_uKN*uKN_PN);
KH_2AH = KH_1AH + (KH_uKH*uKH_1AH) + (KH_uKN*uKN_1AH);
KH_2BH = KH_1BH + (KH_uKH*uKH_1BH) + (KH_uKN*uKN_1BH);
KH_2AN = KH_1AN + (KH_uKH*uKH_1AN) + (KH_uKN*uKN_1AN);
KH_2BN = KH_1BN + (KH_uKH*uKH_1BN) + (KH_uKN*uKN_1BN);
KH_2lambda = KH_1lambda + (KH_uKH*uKH_1lambda) + (KH_uKN*uKN_1lambda);

KN_3K = KN_2K + (KN_uKH*uKH_1K) + (KN_uKN*uKN_1K);
KN_PH = KN_1PH + (KN_uKH*uKH_PH) + (KN_uKN*uKN_PH);
KN_PN = KN_1PN + (KN_uKH*uKH_PN) + (KN_uKN*uKN_PN);
KN_2AH = KN_1AH + (KN_uKH*uKH_1AH) + (KN_uKN*uKN_1AH);
KN_2BH = KN_1BH + (KN_uKH*uKH_1BH) + (KN_uKN*uKN_1BH);
KN_2AN = KN_1AN + (KN_uKH*uKH_1AN) + (KN_uKN*uKN_1AN);
KN_2BN = KN_1BN + (KN_uKH*uKH_1BN) + (KN_uKN*uKN_1BN);
KN_2lambda = KN_1lambda + (KN_uKH*uKH_1lambda) + (KN_uKN*uKN_1lambda);

YH_2K = YH_1K + (YH_uKH*uKH_1K) + (YH_uKN*uKN_1K);
YH_PH = YH_1PH + (YH_uKH*uKH_PH) + (YH_uKN*uKN_PH);
YH_PN = YH_1PN + (YH_uKH*uKH_PN) + (YH_uKN*uKN_PN);
YH_2AH = YH_1AH + (YH_uKH*uKH_1AH) + (YH_uKN*uKN_1AH);
YH_2BH = YH_1BH + (YH_uKH*uKH_1BH) + (YH_uKN*uKN_1BH);
YH_2AN = YH_1AN + (YH_uKH*uKH_1AN) + (YH_uKN*uKN_1AN);
YH_2BN = YH_1BN + (YH_uKH*uKH_1BN) + (YH_uKN*uKN_1BN);
YH_2lambda = YH_1lambda + (YH_uKH*uKH_1lambda) + (YH_uKN*uKN_1lambda);

YN_2K = YN_1K + (YN_uKH*uKH_1K) + (YN_uKN*uKN_1K);
YN_PH = YN_1PH + (YN_uKH*uKH_PH) + (YN_uKN*uKN_PH);
YN_PN = YN_1PN + (YN_uKH*uKH_PN) + (YN_uKN*uKN_PN);
YN_2AH = YN_1AH + (YN_uKH*uKH_1AH) + (YN_uKN*uKN_1AH);
YN_2BH = YN_1BH + (YN_uKH*uKH_1BH) + (YN_uKN*uKN_1BH);
YN_2AN = YN_1AN + (YN_uKH*uKH_1AN) + (YN_uKN*uKN_1AN);
YN_2BN = YN_1BN + (YN_uKH*uKH_1BN) + (YN_uKN*uKN_1BN);
YN_2lambda = YN_1lambda + (YN_uKH*uKH_1lambda) + (YN_uKN*uKN_1lambda);

CN_2K = CN_1K + (CN_uKH*uKH_1K) + (CN_uKN*uKN_1K);                          
CN_PH = CN_2PH + (CN_uKH*uKH_PH) + (CN_uKN*uKN_PH);                         
CN_PN = CN_2PN + (CN_uKH*uKH_PN) + (CN_uKN*uKN_PN);                         
CN_2AH = CN_1AH + (CN_uKH*uKH_1AH) + (CN_uKN*uKN_1AH);                      
CN_2BH = CN_1BH + (CN_uKH*uKH_1BH) + (CN_uKN*uKN_1BH);                      
CN_2AN = CN_1AN + (CN_uKH*uKH_1AN) + (CN_uKN*uKN_1AN);                      
CN_2BN = CN_1BN + (CN_uKH*uKH_1BN) + (CN_uKN*uKN_1BN);                      
CN_2lambda = CN_1lambda + (CN_uKH*uKH_1lambda) + (CN_uKN*uKN_1lambda);      
                                                                            
CH_2K = CH_1K + (CH_uKH*uKH_1K) + (CH_uKN*uKN_1K);                          
CH_PH = CH_2PH + (CH_uKH*uKH_PH) + (CH_uKN*uKN_PH);                         
CH_PN = CH_2PN + (CH_uKH*uKH_PN) + (CH_uKN*uKN_PN);                         
CH_2AH = CH_1AH + (CH_uKH*uKH_1AH) + (CH_uKN*uKN_1AH);                      
CH_2BH = CH_1BH + (CH_uKH*uKH_1BH) + (CH_uKN*uKN_1BH);                      
CH_2AN = CH_1AN + (CH_uKH*uKH_1AN) + (CH_uKN*uKN_1AN);                      
CH_2BN = CH_1BN + (CH_uKH*uKH_1BN) + (CH_uKN*uKN_1BN);                      
CH_2lambda = CH_1lambda + (CH_uKH*uKH_1lambda) + (CH_uKN*uKN_1lambda);      
                                                                            
CF_2K = CF_1K + (CF_uKH*uKH_1K) + (CF_uKN*uKN_1K);                          
CF_PH = CF_2PH + (CF_uKH*uKH_PH) + (CF_uKN*uKN_PH);                         
CF_PN = CF_2PN + (CF_uKH*uKH_PN) + (CF_uKN*uKN_PN);                         
CF_2AH = CF_1AH + (CF_uKH*uKH_1AH) + (CF_uKN*uKN_1AH);                      
CF_2BH = CF_1BH + (CF_uKH*uKH_1BH) + (CF_uKN*uKN_1BH);                      
CF_2AN = CF_1AN + (CF_uKH*uKH_1AN) + (CF_uKN*uKN_1AN);                      
CF_2BN = CF_1BN + (CF_uKH*uKH_1BN) + (CF_uKN*uKN_1BN);                      
CF_2lambda = CF_1lambda + (CF_uKH*uKH_1lambda) + (CF_uKN*uKN_1lambda);      

% Partial Derivatives Gj=Gj(G) 
GN_G   = omegaGN/PN; 
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,lambda)     
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1N*uKN_PH);           
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1N*uKN_PN);           
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1H*uKH_PH);   
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1H*uKH_PN);           
                                                            
% K,Q,G,AH,BH,AN,BN,lambda                                                       
k11 = -(YN_2K - CN_2K - JN_1K - (KN*xi1N*uKN_1K));                  
k12 = JN_1Q;    
k13 = GN_G;
k14 = -(YN_2AH - CN_2AH - (KN*xi1N*uKN_1AH));                        
k15 = -(YN_2BH - CN_2BH - (KN*xi1N*uKN_1BH));                        
k16 = -(YN_2AN - CN_2AN - (KN*xi1N*uKN_1AN));                        
k17 = -(YN_2BN - CN_2BN - (KN*xi1N*uKN_1BN));                        
k18 = -((YN_2lambda - CN_2lambda) - (KN*xi1N*uKN_1lambda)); 

k21 = -(YH_2K - CH_2K - JH_1K - (KH*xi1H*uKH_1K));                  
k22 = JH_1Q;  
k23 = GH_G;
k24 = -(YH_2AH - CH_2AH - (KH*xi1H*uKH_1AH));                         
k25 = -(YH_2BH - CH_2BH - (KH*xi1H*uKH_1BH));                         
k26 = -(YH_2AN - CH_2AN - (KH*xi1H*uKH_1AN));                         
k27 = -(YH_2BN - CH_2BN - (KH*xi1H*uKH_1BN));                         
k28 = -((YH_2lambda - CH_2lambda) - (KH*xi1H*uKH_1lambda));  
                                                            
M4 = [h11 h12; h21 h22];                                                                                                                                 
X4 = [k11 k12 k13 k14 k15 k16 k17 k18; k21 k22 k23 k24 k25 k26 k27 k28];                                                                                 
JST4 = inv(M4);                                                                                                                                          
MST4 = JST4*X4;                                                                                                                                          
                                                                                                                                                         
PH_K = MST4(1,1); PH_Q = MST4(1,2); PH_G = MST4(1,3); PH_AH = MST4(1,4); PH_BH = MST4(1,5); PH_AN = MST4(1,6); PH_BN = MST4(1,7); PH_lambda = MST4(1,8); 
PN_K = MST4(2,1); PN_Q = MST4(2,2); PN_G = MST4(2,3); PN_AH = MST4(2,4); PN_BH = MST4(2,5); PN_AN = MST4(2,6); PN_BN = MST4(2,7); PN_lambda = MST4(2,8);                         

% Solving for Lj,Kj,Wj,Rj,Yj,uKj(K,Q,G,Aj,Bj) - 
LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);
LH_AH = LH_2AH + (LH_PH*PH_AH) + (LH_PN*PN_AH); 
LH_BH = LH_2BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_2AN + (LH_PH*PH_AN) + (LH_PN*PN_AN); 
LH_BN = LH_2BN + (LH_PH*PH_BN) + (LH_PN*PN_BN);
LH_lambda = LH_2lambda + (LH_PH*PH_lambda) + (LH_PN*PN_lambda); 

LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G); 
LN_AH = LN_2AH + (LN_PH*PH_AH) + (LN_PN*PN_AH); 
LN_BH = LN_2BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_2AN + (LN_PH*PH_AN) + (LN_PN*PN_AN); 
LN_BN = LN_2BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);
LN_lambda = LN_2lambda + (LN_PH*PH_lambda) + (LN_PN*PN_lambda); 

YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);
YH_AH = YH_2AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_2BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_2AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_2BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);
YH_lambda = YH_2lambda + (YH_PH*PH_lambda) + (YH_PN*PN_lambda);  

YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);
YN_AH = YN_2AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_2BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_2AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_2BN + (YN_PH*PH_BN) + (YN_PN*PN_BN);
YN_lambda = YN_2lambda + (YN_PH*PH_lambda) + (YN_PN*PN_lambda); 

KH_K  = KH_3K + (KH_PH*PH_K) + (KH_PN*PN_K);                     
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);                             
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);                             
KH_AH = KH_2AH + (KH_PH*PH_AH) + (KH_PN*PN_AH);                  
KH_BH = KH_2BH + (KH_PH*PH_BH) + (KH_PN*PN_BH);                  
KH_AN = KH_2AN + (KH_PH*PH_AN) + (KH_PN*PN_AN);                  
KH_BN = KH_2BN + (KH_PH*PH_BN) + (KH_PN*PN_BN);                  
KH_lambda = KH_2lambda + (KH_PH*PH_lambda) + (KH_PN*PN_lambda);  
                                                                 
KN_K = KN_3K + (KN_PH*PH_K) + (KN_PN*PN_K);                      
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);                              
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);                              
KN_AH = KN_2AH + (KN_PH*PH_AH) + (KN_PN*PN_AH);                  
KN_BH = KN_2BH + (KN_PH*PH_BH) + (KN_PN*PN_BH);                  
KN_AN = KN_2AN + (KN_PH*PH_AN) + (KN_PN*PN_AN);                  
KN_BN = KN_2BN + (KN_PH*PH_BN) + (KN_PN*PN_BN);                  
KN_lambda = KN_2lambda + (KN_PH*PH_lambda) + (KN_PN*PN_lambda); 

uKH_K  = uKH_1K + (uKH_PH*PH_K) + (uKH_PN*PN_K);                     
uKH_Q  = (uKH_PH*PH_Q) + (uKH_PN*PN_Q);                              
uKH_G  = (uKH_PH*PH_G) + (uKH_PN*PN_G);                              
uKH_AH = uKH_1AH + (uKH_PH*PH_AH) + (uKH_PN*PN_AH);                  
uKH_BH = uKH_1BH + (uKH_PH*PH_BH) + (uKH_PN*PN_BH);                  
uKH_AN = uKH_1AN + (uKH_PH*PH_AN) + (uKH_PN*PN_AN);                  
uKH_BN = uKH_1BN + (uKH_PH*PH_BN) + (uKH_PN*PN_BN);                  
uKH_lambda = uKH_1lambda + (uKH_PH*PH_lambda) + (uKH_PN*PN_lambda);  
                                                                     
uKN_K = uKN_1K + (uKN_PH*PH_K) + (uKN_PN*PN_K);                      
uKN_Q = (uKN_PH*PH_Q) + (uKN_PN*PN_Q);                               
uKN_G = (uKN_PH*PH_G) + (uKN_PN*PN_G);                               
uKN_AH = uKN_1AH + (uKN_PH*PH_AH) + (uKN_PN*PN_AH);                  
uKN_BH = uKN_1BH + (uKN_PH*PH_BH) + (uKN_PN*PN_BH);                  
uKN_AN = uKN_1AN + (uKN_PH*PH_AN) + (uKN_PN*PN_AN);                  
uKN_BN = uKN_1BN + (uKN_PH*PH_BN) + (uKN_PN*PN_BN);                  
uKN_lambda = uKN_1lambda + (uKN_PH*PH_lambda) + (uKN_PN*PN_lambda);  

% Solving for consumption Cj=Cj(lambda,K,Q,G,Aj,Bj), investment inputs 
% Jj=Jj(K,Q,GH,GN), imports MF=MF(lambda,K,Q,G,Aj,Bj), exports 
%XH=XH(K,Q,G,Aj,Bj)- Final Solutions
CN_K  = CN_2K + (CN_PH*PH_K) + (CN_PN*PN_K);                          
CN_Q  = (CN_PH*PH_Q) + (CN_PN*PN_Q);                                  
CN_G  = (CN_PH*PH_G) + (CN_PN*PN_G);                                  
CN_AH = CN_2AH + (CN_PH*PH_AH) + (CN_PN*PN_AH);                       
CN_BH = CN_2BH + (CN_PH*PH_BH) + (CN_PN*PN_BH);                       
CN_AN = CN_2AN + (CN_PH*PH_AN) + (CN_PN*PN_AN);                       
CN_BN = CN_2BN + (CN_PH*PH_BN) + (CN_PN*PN_BN);                       
CN_lambda = CN_2lambda + (CN_PH*PH_lambda) + (CN_PN*PN_lambda);       
                                                                      
CH_K  = CH_2K + (CH_PH*PH_K) + (CH_PN*PN_K);                          
CH_Q  = (CH_PH*PH_Q) + (CH_PN*PN_Q);                                  
CH_G  = (CH_PH*PH_G) + (CH_PN*PN_G);                                  
CH_AH = CH_2AH + (CH_PH*PH_AH) + (CH_PN*PN_AH);                       
CH_BH = CH_2BH + (CH_PH*PH_BH) + (CH_PN*PN_BH);                       
CH_AN = CH_2AN + (CH_PH*PH_AN) + (CH_PN*PN_AN);                       
CH_BN = CH_2BN + (CH_PH*PH_BN) + (CH_PN*PN_BN);                       
CH_lambda = CH_2lambda + (CH_PH*PH_lambda) + (CH_PN*PN_lambda);       
                                                                      
CF_K  = CF_2K + (CF_PH*PH_K) + (CF_PN*PN_K);                          
CF_Q  = (CF_PH*PH_Q) + (CF_PN*PN_Q);                                  
CF_G  = (CF_PH*PH_G) + (CF_PN*PN_G);                                  
CF_AH = CF_2AH + (CF_PH*PH_AH) + (CF_PN*PN_AH);                       
CF_BH = CF_2BH + (CF_PH*PH_BH) + (CF_PN*PN_BH);                       
CF_AN = CF_2AN + (CF_PH*PH_AN) + (CF_PN*PN_AN);                       
CF_BN = CF_2BN + (CF_PH*PH_BN) + (CF_PN*PN_BN);                       
CF_lambda = CF_2lambda + (CF_PH*PH_lambda) + (CF_PN*PN_lambda);       

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);
JH_lambda  = (JH_PH*PH_lambda) + (JH_PN*PN_lambda);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_BH      = (JN_PH*PH_BH) + (JN_PN*PN_BH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN);
JN_lambda  = (JN_PH*PH_lambda) + (JN_PN*PN_lambda);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN); 
JF_lambda  = (JF_PH*PH_lambda) + (JF_PN*PN_lambda);

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;
XH_lambda = XH_PH*PH_lambda;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);
MF_lambda = (CF_lambda + JF_lambda);
 
% Solving for sectoral return on capital - Rj(K,Q,G,Aj,Bj)                          
RH_K = RH_2K + (RH_PH*PH_K) + (RH_PN*PN_K);                                
RH_Q = (RH_PH*PH_Q) + (RH_PN*PN_Q);                                        
RH_G = (RH_PH*PH_G) + (RH_PN*PN_G);                                        
RH_AH = RH_2AH + (RH_PH*PH_AH) + (RH_PN*PN_AH);                            
RH_BH = RH_2BH + (RH_PH*PH_BH) + (RH_PN*PN_BH);                            
RH_AN = RH_2AN + (RH_PH*PH_AN) + (RH_PN*PN_AN);                            
RH_BN = RH_2BN + (RH_PH*PH_BN) + (RH_PN*PN_BN);                            
RH_lambda = RH_2lambda + (RH_PH*PH_lambda) + (RH_PN*PN_lambda);            
                                                                           
RN_K = RN_2K + (RN_PH*PH_K) + (RN_PN*PN_K);                                
RN_Q = (RN_PH*PH_Q) + (RN_PN*PN_Q);                                        
RN_G = (RN_PH*PH_G) + (RN_PN*PN_G);                                        
RN_AH = RN_2AH + (RN_PH*PH_AH) + (RN_PN*PN_AH);                            
RN_BH = RN_2BH + (RN_PH*PH_BH) + (RN_PN*PN_BH);                            
RN_AN = RN_2AN + (RN_PH*PH_AN) + (RN_PN*PN_AN);                            
RN_BN = RN_2BN + (RN_PH*PH_BN) + (RN_PN*PN_BN);                            
RN_lambda = RN_2lambda + (RN_PH*PH_lambda) + (RN_PN*PN_lambda);            

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(K,Q,G,Aj,Bj,lambda) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_G  = (v_PN*PN_G) + (v_PH*PH_G); 
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);
v_lambda = (v_PN*PN_lambda) + (v_PH*PH_lambda);
 
% Elements of the Jacobian Matrix                                                                                                                                           
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                  
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );                                                                           
Sigma_K   = -( -(RK/K)+(1/K)*( (RH*KH*uKH_K)+(RN*KN*uKN_K)+(RH*KH_K)+(RN*KN_K)+(RH_K*KH)+(RN_K*KN) )-(PH*KH/K)*xi1H*uKH_K-(PN*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) );   
Sigma_Q   = (r+deltaK)-( (1/K)*( (RH*KH*uKH_Q)+(RN*KN*uKN_Q)+(RH*KH_Q)+(RN*KN_Q)+(RH_Q*KH)+(RN_Q*KN) )-(PH*KH/K)*xi1H*uKH_Q-(PN*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) ); 
 
x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    

J = [x11 x12; x21 x22];
[V,nu]=eig(J)
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1); 
nu2 = nu_sorted(2,2); 
omega11 = V_sorted(1,1)/V_sorted(1,1); 
omega21 = V_sorted(2,1)/V_sorted(1,1); 
omega12 = V_sorted(1,2)/V_sorted(1,2); 
omega22 = V_sorted(2,2)/V_sorted(1,2); 
TrJ = trace(J); 
DetJ = det(J); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q);
% Xi_Q=0
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r); 

% Solving for sectoral wages - Wj=Wj(K,Q,G,Aj,Bj)
WH_K = WH_2K + (WH_PH*PH_K) + (WH_PN*PN_K);                       
WH_Q = (WH_PH*PH_Q) + (WH_PN*PN_Q);                               
WH_G = (WH_PH*PH_G) + (WH_PN*PN_G);                               
WH_AH = WH_2AH + (WH_PH*PH_AH) + (WH_PN*PN_AH);                   
WH_BH = WH_2BH + (WH_PH*PH_BH) + (WH_PN*PN_BH);                   
WH_AN = WH_2AN + (WH_PH*PH_AN) + (WH_PN*PN_AN);                   
WH_BN = WH_2BN + (WH_PH*PH_BN) + (WH_PN*PN_BN);                   
WH_lambda = WH_2lambda + (WH_PH*PH_lambda) + (WH_PN*PN_lambda);   
                                                                  
WN_K = WN_2K + (WN_PH*PH_K) + (WN_PN*PN_K);                       
WN_Q = (WN_PH*PH_Q) + (WN_PN*PN_Q);                               
WN_G = (WN_PH*PH_G) + (WN_PN*PN_G);                               
WN_AH = WN_2AH + (WN_PH*PH_AH) + (WN_PN*PN_AH);                   
WN_BH = WN_2BH + (WN_PH*PH_BH) + (WN_PN*PN_BH);                   
WN_AN = WN_2AN + (WN_PH*PH_AN) + (WN_PN*PN_AN);                   
WN_BN = WN_2BN + (WN_PH*PH_BN) + (WN_PN*PN_BN);                   
WN_lambda = WN_2lambda + (WN_PH*PH_lambda) + (WN_PN*PN_lambda); 

% Solution for W as function W=W(lambda,K,Q,AH,BH,AN,BN)                      
W_K       = (W_WH*WH_K) + (W_WN*WN_K);                                          
W_Q       = (W_WH*WH_Q) + (W_WN*WN_Q);  
W_G       = (W_WH*WH_G) + (W_WN*WN_G); 
W_AH      = (W_WH*WH_AH) + (W_WN*WN_AH);                                        
W_BH      = (W_WH*WH_BH) + (W_WN*WN_BH);                                        
W_AN      = (W_WH*WH_AN) + (W_WN*WN_AN);                                        
W_BN      = (W_WH*WH_BN) + (W_WN*WN_BN);                                        
W_lambda  = (W_WH*WH_lambda) + (W_WN*WN_lambda);                                
                                                                                
% Solution for L as function L=L(lambda,K,Q,Aj,Bj)                            
L_K  = (L_W*W_K) + (L_1PN*PN_K) + (L_1PH*PH_K);                                 
L_Q  = (L_W*W_Q) + (L_1PN*PN_Q) + (L_1PH*PH_Q);    
L_G  = (L_W*W_G) + (L_1PN*PN_G) + (L_1PH*PH_G);
L_AH = (L_W*W_AH) + (L_1PN*PN_AH) + (L_1PH*PH_AH);                              
L_BH = (L_W*W_BH) + (L_1PN*PN_BH) + (L_1PH*PH_BH);                              
L_AN = (L_W*W_AN) + (L_1PN*PN_AN) + (L_1PH*PH_AN);                              
L_BN = (L_W*W_BN) + (L_1PN*PN_BN) + (L_1PH*PH_BN);                              
L_lambda  = L_1lambda + (L_W*W_lambda) + (L_1PN*PN_lambda) + (L_1PH*PH_lambda);         

% solving for the Unit Cost for Producing MN=MN(K,Q,PN,G,Aj,Bj)               
MN_K  = sLN*(MN/WN)*WN_K + (1-sLN)*(MN/RN)*RN_K;                              
MN_Q  = sLN*(MN/WN)*WN_Q + (1-sLN)*(MN/RN)*RN_Q;                              
MN_G  = sLN*(MN/WN)*WN_G + (1-sLN)*(MN/RN)*RN_G;                              
MN_AH = sLN*(MN/WN)*WN_AH + (1-sLN)*(MN/RN)*RN_AH;                            
MN_BH = sLN*(MN/WN)*WN_BH + (1-sLN)*(MN/RN)*RN_BH;                            
MN_AN = sLN*(MN/WN)*WN_AN + (1-sLN)*(MN/RN)*RN_AN - sLN*(MN/AN);              
MN_BN = sLN*(MN/WN)*WN_BN + (1-sLN)*(MN/RN)*RN_BN - (1-sLN)*(MN/BN);          
MN_lambda  = sLN*(MN/WN)*WN_lambda + (1-sLN)*(MN/RN)*RN_lambda;               

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 
omegaGT = GT/G; 
omegaGH = (PH*GH)/GT; 
omegaGF = GF/G; 

% Investment 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF;  
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;
RHPH = RH/PH;
RNPN = RN/PN;

% Labor income and Capital income shares
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% Aggregator function for L=L(LH,LN)
VLAB    = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = VLAB^(epsilon/(epsilon+1)); 
L_LH    = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_LN    = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Aggregator function for K=K(KH,KN)                                                                                                      
VCAP    = ( (varthetaK^(-1/epsilonK))*(KH^((epsilonK+1)/epsilonK)) + ((1-varthetaK)^(-1/epsilonK))*(KN^((epsilonK+1)/epsilonK)) );        
K_check = VCAP^(epsilonK/(epsilonK+1));                                                                                                   
K_KH    = ((varthetaK)^(-1/epsilonK))*(KH/K)^(1/epsilonK);                                                                                
K_KN    = ((1-varthetaK)^(-1/epsilonK))*(KN/K)^(1/epsilonK);                                                                             
                                                                                                                                          
% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH =  IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaXHY  = (PH*XH) / Y; 
omegaXHYH = XH / YH;

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Check the closure of the model                                               
cond1  = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH))-RH;       
cond2  = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN))-RN;      
cond3  = PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH))-WH;                
cond4  = PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN))-WN;                
cond5  = (RH*KH)+(RN*KN)-(RK*K);                                               
cond6  = RK-(deltaK+r)*PI;                                                     
cond7  = YN-CN-GN-IN;                                                          
cond8  = YH-CH-GH-IH-XH;                                                       
cond9  = (B-B0) - H1*(K-K0);                                                   
cond10 = DetJ - (nu1*nu2);                                                     
cond11 = TrJ - (nu1+nu2);                                                      
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);                   
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);                          
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                           
cond15 = (W*L) - ((WH*LH)+(WN*LN));                                            
cond16 = -U_L*L_LH - (lambda*WH);                                              
cond17 = -U_L*L_LN - (lambda*WN);                                              
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                                      
cond19 = Sav;                                                                  
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                        
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);                            
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                          
cond23 = (RK*K) - ((RH*KH)+(RN*KN));                                         
cond24 = 1 - (omegaK + omegaL);                                                
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);                          
cond26 = (PT*CT) - ((PH*CH)+CF);                                               
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);                             
cond28 = (PIT*IT) - ((PH*IH)+IF);                                              
cond29 = r*B + (PH*XH) - MF;                                                   
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I);                                                                           
cond31 = K_KH - (RH/RK);                                                            
cond32 = K_KN - (RN/RK);                                                            
cond33 = (KH/KN) - (varthetaK/(1-varthetaK))*(RH/RN)^(epsilonK);    
cond34 = PN - MN;
cond35 = PH - MH;
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kH > kN');
disp('                           The exomark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (exomark)');
disp(sprintf('sigmaH  : %5.2f   gammaH   : %5.2f',sigmaH,gammaH));
disp(sprintf('sigmaN  : %5.2f   gammaN   : %5.2f',sigmaN,gammaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('phi     : %5.2f   varphi   : %5.2f',phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f sigma   : %5.2f',sigmaL,gammaL,sigma));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('epsilonK: %5.2f   varthetaK: %5.2f',epsilonK,varthetaK));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('AH      : %5.2f   BH       : %5.2f',AH,BH));
disp(sprintf('AN      : %5.2f   BN       : %5.2f',AN,BN));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('TFPH    : %5.2f   TFPN     : %5.2f',TFPH,TFPN));
disp(sprintf('omegaYH : %5.2f   Z        : %5.2f TFP        : %5.2f',omegaYH,Z,TFP));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (exomark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));
disp(sprintf('K        : %9.3f   ',K));
disp(sprintf('K_check  : %9.3f   ',K_check));
disp(sprintf('alphaK   : %9.3f   ',alphaK));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('RN                 : %9.3f',RN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('RH                 : %9.3f',RH));
disp(sprintf('Profit             : %9.10f',PiH));

disp(' ');                                                                                      
disp('Wealth');                                                                                 
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));                                          
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));                                     
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA)); 

disp(' ');
disp('The demand side (exomark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (exomark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f',IH,IN));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp('Export and import (exomark)');
disp(sprintf('XH        :   %7.3f   MF : %9.3f',XH,MF));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));

disp('Price of Non Tradables in terms of Imports');                                                                
disp(sprintf('PN_Q        :   %7.3f  PN_K        : %9.3f',PN_Q,PN_K));                          
disp(sprintf('PN_G        :   %7.3f',PN_G)); 
disp(sprintf('PN_AH       :   %7.3f  PN_BH       : %9.3f',PN_AH,PN_BH));
disp(sprintf('PN_AN       :   %7.3f  PN_BN       : %9.3f',PN_AN,PN_BN));
                                                                                                
disp('Terms of Trade');                                                                                            
disp(sprintf('PH_Q        :   %7.3f  PH_K        : %9.3f',PH_Q,PH_K));                          
disp(sprintf('PH_G        :   %7.3f',PH_G));                        
disp(sprintf('PH_AH       :   %7.3f  PH_BH       : %9.3f',PH_AH,PH_BH));
disp(sprintf('PH_AN       :   %7.3f  PH_BN       : %9.3f',PH_AN,PH_BN));                                                                                                

disp(' ');                                                                                      
disp('Partial derivatives CH and CN');                                                          
disp(sprintf('CN_K        :   %7.3f  CH_K      : %9.3f',CN_K,CH_K));                            
disp(sprintf('CN_Q        :   %7.3f  CH_Q      : %9.3f',CN_Q,CH_Q));                            
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));                  
disp(sprintf('CN_G        :   %7.3f  CH_G      : %9.3f',CN_G,CH_G)); 
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));
disp(sprintf('CN_AH       :   %7.3f  CH_AH     : %9.3f',CN_AH,CH_AH));
disp(sprintf('CN_BH       :   %7.3f  CH_BH     : %9.3f',CN_BH,CH_BH));
disp(sprintf('CN_AN       :   %7.3f  CH_AN     : %9.3f',CN_AN,CH_AN));
disp(sprintf('CN_BN       :   %7.3f  CH_BN     : %9.3f',CN_BN,CH_BN));                          
                                                                                                                                                                                                                                                                                                                     
disp('Partial derivatives KH and KN');                                                      
disp(sprintf('KN_Q       :   %7.6f  KH_Q       : %9.6f',KN_Q,KH_Q));                        
disp(sprintf('KN_K       :   %7.6f  KH_K       : %9.6f',KN_K,KH_K));                        
disp(sprintf('KN_lambda  :   %7.3f  KH_lambda  : %9.3f',KN_lambda,KH_lambda));              
disp(sprintf('KN_G       :   %7.6f  KH_G       : %9.6f',KN_G,KH_G));                        
disp(sprintf('KN_AH      :   %7.6f  KH_AH      : %9.6f',KN_AH,KH_AH));                      
disp(sprintf('KN_BH      :   %7.6f  KH_BH      : %9.6f',KN_BH,KH_BH));                      
disp(sprintf('KN_AN      :   %7.6f  KH_AN      : %9.6f',KN_AN,KH_AN));                      
disp(sprintf('KN_BN      :   %7.6f  KH_BN      : %9.6f',KN_BN,KH_BN));                      
                                                                                            
disp('Partial derivatives WH and WN');                                                      
disp(sprintf('WN_Q       :   %7.6f  WH_Q       : %9.6f',WN_Q,WH_Q));                        
disp(sprintf('WN_K       :   %7.6f  WH_K       : %9.6f',WN_K,WH_K));                        
disp(sprintf('WN_lambda  :   %7.3f  WH_lambda  : %9.3f',WN_lambda,WH_lambda));              
disp(sprintf('WN_G       :   %7.6f  WH_G       : %9.6f',WN_G,WH_G));                        
disp(sprintf('WN_AH      :   %7.6f  WH_AH      : %9.6f',WN_AH,WH_AH));                      
disp(sprintf('WN_BH      :   %7.6f  WH_BH      : %9.6f',WN_BH,WH_BH));                      
disp(sprintf('WN_AN      :   %7.6f  WH_AN      : %9.6f',WN_AN,WH_AN));                      
disp(sprintf('WN_BN      :   %7.6f  WH_BN      : %9.6f',WN_BN,WH_BN));                      
                                                                                            
disp('Partial derivatives RH and RN');                                                      
disp(sprintf('RN_Q       :   %7.6f  RH_Q       : %9.6f',RN_Q,RH_Q));                        
disp(sprintf('RN_K       :   %7.6f  RH_K       : %9.6f',RN_K,RH_K));                        
disp(sprintf('RN_lambda  :   %7.3f  RH_lambda  : %9.3f',RN_lambda,RH_lambda));              
disp(sprintf('RN_G       :   %7.6f  RH_G       : %9.6f',RN_G,RH_G));                        
disp(sprintf('RN_AH      :   %7.6f  RH_AH      : %9.6f',RN_AH,RH_AH));                      
disp(sprintf('RN_BH      :   %7.6f  RH_BH      : %9.6f',RN_BH,RH_BH));                      
disp(sprintf('RN_AN      :   %7.6f  RH_AN      : %9.6f',RN_AN,RH_AN));                      
disp(sprintf('RN_BN      :   %7.6f  RH_BN      : %9.6f',RN_BN,RH_BN));                      
                                                                                                
disp('Partial derivatives LH and LN');                                                          
disp(sprintf('LN_Q       :   %7.6f  LH_Q       : %9.6f',LN_Q,LH_Q));                            
disp(sprintf('LN_K       :   %7.6f  LH_K       : %9.6f',LN_K,LH_K));                            
disp(sprintf('LN_lambda  :   %7.3f  LH_lambda  : %9.3f',LN_lambda,LH_lambda));                  
disp(sprintf('LN_G       :   %7.6f  LH_G       : %9.6f',LN_G,LH_G)); 
disp(sprintf('LN_AH      :   %7.6f  LH_AH      : %9.6f',LN_AH,LH_AH));
disp(sprintf('LN_BH      :   %7.6f  LH_BH      : %9.6f',LN_BH,LH_BH));
disp(sprintf('LN_AN      :   %7.6f  LH_AN      : %9.6f',LN_AN,LH_AN));
disp(sprintf('LN_BN      :   %7.6f  LH_BN      : %9.6f',LN_BN,LH_BN));
                                                                                        
disp('Partial derivatives Yj');  
disp(sprintf('YN_1PN     :   %7.6f  YN_1PH     : %9.6f',YN_1PN,YN_1PH));
disp(sprintf('YN_1K      :   %7.6f  YN_1lambda : %9.6f',YN_1K,YN_1lambda));
disp(sprintf('YN_1AH     :   %7.6f  YN_1BH     : %9.6f',YN_1AH,YN_1BH));
disp(sprintf('YN_1AN     :   %7.6f  YN_1BN     : %9.6f',YN_1AN,YH_1BN));
disp(sprintf('YN_uKH     :   %7.6f  YN_uKN     : %9.6f',YN_uKH,YN_uKN));
disp(' ');
disp(sprintf('YH_1PN     :   %7.6f  YH_1PH     : %9.6f',YH_1PN,YH_1PH));
disp(sprintf('YH_1K      :   %7.6f  YH_1lambda : %9.6f',YH_1K,YH_1lambda));
disp(sprintf('YH_1AH     :   %7.6f  YH_1BH     : %9.6f',YH_1AH,YH_1BH));
disp(sprintf('YH_1AN     :   %7.6f  YH_1BN     : %9.6f',YH_1AN,YH_1BN));
disp(sprintf('YH_uKH     :   %7.6f  YH_uKN     : %9.6f',YH_uKH,YH_uKN));
disp(' ');

disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));                            
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));                            
disp(sprintf('YN_lambda  :   %7.3f  YH_lambda  : %9.3f',YN_lambda,YH_lambda));                  
disp(sprintf('YN_G       :   %7.6f  YH_G       : %9.6f',YN_G,YH_G));
disp(sprintf('YN_AH      :   %7.6f  YH_AH      : %9.6f',YN_AH,YH_AH));
disp(sprintf('YN_BH      :   %7.6f  YH_BH      : %9.6f',YN_BH,YH_BH));
disp(sprintf('YN_AN      :   %7.6f  YH_AN      : %9.6f',YN_AN,YH_AN));
disp(sprintf('YN_BN      :   %7.6f  YH_BN      : %9.6f',YN_BN,YH_BN));
                                                                                                                                                                                                                                                                                                                                                                                                    
disp('Partial derivatives of L');                                                               
disp(sprintf('L_Q        :   %7.3f  L_K        : %9.3f',L_Q,L_K));                              
disp(sprintf('L_G        :   %7.3f ',L_G));      
disp(sprintf('L_AH       :   %7.3f  L_BH       : %9.3f',L_AH,L_BH));
disp(sprintf('L_AN       :   %7.3f  L_BN       : %9.3f',L_AN,L_BN));
disp(sprintf('L_lambda   :   %7.3f',L_lambda));  

disp('Partial derivatives of uKj');  
disp(sprintf('uKN_Q       :   %7.6f  uKH_Q       : %9.6f',uKN_Q,uKH_Q));             
disp(sprintf('uKN_K       :   %7.6f  uKH_K       : %9.6f',uKN_K,uKH_K));             
disp(sprintf('uKN_lambda  :   %7.3f  uKH_lambda  : %9.3f',uKN_lambda,uKH_lambda));   
disp(sprintf('uKN_G       :   %7.6f  uKH_G       : %9.6f',uKN_G,uKH_G));             
disp(sprintf('uKN_AH      :   %7.6f  uKH_AH      : %9.6f',uKN_AH,uKH_AH));           
disp(sprintf('uKN_BH      :   %7.6f  uKH_BH      : %9.6f',uKN_BH,uKH_BH));           
disp(sprintf('uKN_AN      :   %7.6f  uKH_AN      : %9.6f',uKN_AN,uKH_AN));           
disp(sprintf('uKN_BN      :   %7.6f  uKH_BN      : %9.6f',uKN_BN,uKH_BN));  
                                                                                                                                                                                                       
disp(' ');                                                                                      
disp('Relative Prices');  
disp(sprintf('PN_K       : %5.4f   PN_Q       : %5.4f',PN_K,PN_Q));                                 
disp(sprintf('PN_G       :  %5.4f  PN_lambda  : %5.4f',PN_G,PN_lambda));  
disp(sprintf('PH_K       : %5.4f   PH_Q       : %5.4f',PH_K,PH_Q));                                 
disp(sprintf('PH_G       :  %5.4f  PH_lambda  : %5.4f',PH_G,PH_lambda)); 
                                                                                                
disp(' ');                                                                                      
disp('Linearization');                                                                          
disp(sprintf('v_K       :  %5.4f  v_Q       : %5.4f',v_K,v_Q));                                 
disp(sprintf('v_G       :  %5.4f',v_G));          
disp(sprintf('v_AH      :  %5.4f  v_BH      : %5.4f',v_AH,v_BH));
disp(sprintf('v_AN      :  %5.4f  v_BN      : %5.4f',v_AN,v_BN));
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));                     
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));                         
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));  
                                                                                                
disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (exomark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/GT  :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));

disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Capital compensation = RH*KH+RN*KN: %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor supply LH/LN       : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));
disp(sprintf('Traded capital supply             : %9.16f   ',cond31));
disp(sprintf('Non-traded capital supply         : %9.16f   ',cond32));
disp(sprintf('Relative capital supply KH/KN     : %9.16f   ',cond33));
disp(sprintf('Unit Cost for Producing N         : %9.16f   ',cond34));
disp(sprintf('Unit Cost for Producing H         : %9.16f   ',cond35));

kH_0 = kH;  kN_0 = kN; PN_0 = PN; K_0 = K; C_0 = C;  
L_0 = L; W_0 = W; P_0 = P; 
YH_0  = YH; YN_0  = YN; Y_0  = Y; YR_0 = Y_0; G_0 = G;     
PC_0 = PC; CN_0 = CN; CH_0 = CH;  
ZH_0 = ZH; ZN_0 = ZN; 
AH_0 = AH; BH_0 = BH; AN_0 = AN; BN_0 = BN; Z_0 = Z; GH_0 = GH; GN_0 = GN; 
LH_0 = LH; LN_0 = LN; KH_0 = KH; KN_0 = KN; WH_0 = WH; WN_0 = WN; 
Omega_0 = Omega; YHYN_0 = YHYN; LHLN_0 = LHLN;
IF_0 = IF; CF_0 = CF; XH_0 = XH; MF_0 = MF; GF_0 = GF; PH_0 = PH; 
PT_0 = PT; PIT_0 = PIT; CT_0 = CT; IT_0 = IT; GT_0 = GT; 

CA_0 = CA; Sav_0 = Sav; NX_0 = NX; I_0 = I; lambda_0  = lambda; A_0 = A; 
B_0 = B; IN_0 = IN; IH_0 = IH; PI_0 = PI; EI_0 = EI; 
WPC_0 = WPC; WHPC_0 = WHPC; WNPC_0 = WNPC; RK_0 = RK; 
yH_0 = yH; yN_0 = yN; 

omegaL_0 = omegaL; omegaK_0 = omegaK; omegaI_0 = omegaI; omegaINYN_0 = omegaINYN;
omegaIHYH_0 = omegaIHYH; omega_IFYH_0 = omegaIFYH; omegaGHYH_0 = omegaGHYH; 
omegaGNYN_0 = omegaGNYN; omegaGN_0 = omegaGN;
omegaYH_0 = omegaYH; omegaYN_0 = omegaYN; omegaLH_0 = omegaLH; omegaLN_0 = omegaLN; 
omegaC_0 =omegaC; omegaNX_0 =omegaNX; omegaG_0 =omegaG; omegaB_0 =omegaB; 
omegaIFYH_0 = omegaIFYH; omegaGFYH_0 = omegaGFYH; 
omegaCH_0 = omegaCH; omegaCF_0 = omegaCF; 
omegaGT_0 = omegaGT; omegaGH_0 = omegaGH; omegaGF_0 = omegaGF; 
omegaKY_0 = omegaKY; omegaIH_0 = omegaIH; omegaIF_0 = omegaIF;
omegaXHY_0 = omegaXHY; omegaXHYH_0 = omegaXHYH; 
alphaL_0 = alphaL; alphaK_0 = alphaK; alphaC_0 = alphaC; 
alphaI_0 = alphaI; alphaH_0 = alphaH; alphaIH_0 = alphaIH; 
sLH_0 = sLH; sLN_0 = sLN; sigmaH_0 = sigmaH; sigmaN_0 = sigmaN;  
TFPH_0 = TFPH; TFPN_0 = TFPN; TFP_0 = TFP; sL_0 = sL; k_0 = k;
VL_0 = VL; RH_0 = RH; RN_0 = RN; RHPH_0 = RHPH; RNPN_0 = RNPN; 
KHK_0 = KHK; RKPC_0 = RKPC; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Temporary Fiscal Shock                          %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B0       = B_0;
K0       = K_0; 
GH       = GH_0; 
GN       = GN_0; 
GF       = GF_0;  
%G        = G_0; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Endogenous response of G, Aj, Bj to an exogenous government spending shock 
barg     = 0.0000000000001; 
xi       = 0.0000000000001;                                                                                                                                
chi      = 0.0000000000001;
gG       = 0.0000000000001;
filename = 'Calibration_shock_nocaput_sym';  
sheet    = 5;                                                                                                                                          
xlRange  = 'C3:F6';                                                                                                                                 
datac = xlsread(filename,sheet,xlRange);                                                                                                            
parameters = xlsread(filename,sheet,xlRange);     
                                                                                                                                                                                                                                                                                                                                                                                                                   
baraH    = parameters(1,1);  
barbH    = parameters(1,2);  
baraN    = parameters(1,3);  
barbN    = parameters(1,4);  
                             
gAH      = parameters(2,1);  
gBH      = parameters(2,2); 
gAN      = parameters(2,3);  
gBN      = parameters(2,4); 
                             
xiAH     = parameters(3,1);  
chiAH    = parameters(4,1);  
xiBH     = parameters(3,2);  
chiBH    = parameters(4,2);  
xiAN     = parameters(3,3);  
chiAN    = parameters(4,3);  
xiBN     = parameters(3,4);  
chiBN    = parameters(4,4);  

AH       = AH_0*(1+gAH); 
BH       = BH_0*(1+gBH); 
AN       = AN_0*(1+gAN);
BN       = BN_0*(1+gBN);
G        = G_0*(1+gG);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                                                                                                                                                                                                     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x0 =[C_0 L_0 RH_0 RN_0 WH_0 WN_0 W_0 RK_0 PN_0 K_0 PH_0 B_0 alphaL_0 alphaK_0 PC_0 PT_0 CN_0 CH_0 CF_0 PI_0 PIT_0 IN_0 IH_0 IF_0 LH_0 LN_0 KH_0 KN_0 YH_0 YN_0 XH_0 MF_0 VL_0 lambda_0];
[x,fval,exitflag]=fsolve('IML_IMK_CAC_TOT_CES_NS_perm_SYM',x0,optimset('display','off','TolFun',1e-011));
C        = x(1)  ; % Consumption                                                              
L        = x(2)  ; % Labor supply                                                             
RH       = x(3)  ; % Return on traded capital                                                 
RN       = x(4)  ; % Return on non-traded capital                                             
WH       = x(5)  ; % Wage rate in sector H                                                    
WN       = x(6)  ; % Wage rate in sector N                                                    
W        = x(7)  ; % Aggregate wage index                                                     
RK       = x(8)  ; % Aggregate capital rental rate                                            
PN       = x(9)  ; % Relative price of non tradables                                          
K        = x(10)  ; % Stock of capital                                                        
PH       = x(11) ; % Terms of trade : PH/PF with PF = numeraire                               
B        = x(12) ; % Stock of Traded Bonds                                                    
alphaL   = x(13) ; % Labor compensation share of tradables                                    
alphaK   = x(14) ; % Capital compensation share of tradables                                  
PC       = x(15) ; % Aggregate consumption price index                                        
PT       = x(16) ; % Consumption price index for tradables                                    
CN       = x(17) ; % Consumption in non tradables                                             
CH       = x(18) ; % Consumption in tradables                                                 
CF       = x(19) ; % Consumption goods imports                                                
PI       = x(20) ; % Aggregate investment price index                                         
PIT      = x(21) ; % Investment price index for tradables                                     
IN       = x(22) ; % Non tradable investment                                                  
IH       = x(23) ; % Investment in home goods                                                 
IF       = x(24) ; % Investment in foreign goods                                              
LH       = x(25) ; % Labor in sector H                                                        
LN       = x(26) ; % Labor in sector N                                                        
KH       = x(27) ; % Capital stock in sector H                                                
KN       = x(28) ; % Capital stock in sector N                                                
YH       = x(29) ; % Traded value added                                                       
YN       = x(30) ; % Non-traded value added                                                   
XH       = x(31) ; % Exports of home traded goods                                             
MF       = x(32) ; % Imports of foreign goods                                                 
VL       = x(33) ; % Desutility labor                                                         
lambda   = x(34) ; % Marginal Utility of Wealth - Intertemporal Solvency Condition 

% Sectoral outputs and sectoral profits        
PiH = (PH*YH) - (RH*KH) - (WH*LH);             
PiN = (PN*YN) - (RN*KN) - (WN*LN);             

% Shares
I       = deltaK*K;
alphaC  = varphi*(PT/PC)^(1-phi);
alphaH  = varphiH*(PH/PT)^(1-rho);
alphaI  = iota*(PIT/PI)^(1-phiI);
alphaIH = iotaH*(PH/PIT)^(1-rhoI);

% Technology                                                                                                  
ZH = ((AH)^(sLH_0))*((BH)^(1-sLH_0));                                                                             
ZN = ((AN)^(sLN_0))*((BN)^(1-sLN_0));                                                                             
Z  = (ZH^omegaYH_0)*(ZN^(1-omegaYH_0));                                                                           
TFPH = YH/(gammaH*(LH^((sigmaH-1)/sigmaH)) + (1-gammaH)*(KH^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1));       
TFPN = YN/(gammaN*(LN^((sigmaN-1)/sigmaN)) + (1-gammaN)*(KN^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1));       
TFP  = (TFPH^omegaYH_0)*(TFPN^(1-omegaYH_0));                                                                     

% Nominal and Real GDP
Y  = (PH*YH) +(PN*YN);
YR = (PH_0*YH) + (PN_0*YN); 
kH  = KH/LH; 
kN  = KN/LN; 
yH  = YH/LH; 
yN  = YN/LN; 
sLH = gammaH*(AH/yH)^((sigmaH-1)/sigmaH);
sLN = gammaN*(AN/yN)^((sigmaN-1)/sigmaN); 
sL  = W*L/Y; 
k   = K/L; 
P   = PN/PH;  
KHK = KH/K; 

% VA shares in real terms
omegaYHR = (PH_0*YH)/YR; 
omegaYNR = (PN_0*YN)/YR; 
omegaLH   = LH / L;
omegaLN   = LN / L;

% Unit cost for producting
MN = ((gammaN^sigmaN)*((WN/AN)^(1-sigmaN)) + ((1-gammaN)^sigmaN)*((RN/BN)^(1-sigmaN)))^(1/(1-sigmaN));   
MH = ((gammaH^sigmaH)*((WH/AH)^(1-sigmaH)) + ((1-gammaH)^sigmaH)*((RH/BH)^(1-sigmaH)))^(1/(1-sigmaH));                                                         
                                                                         
% Non Sep preferences Shimer (2009)
%VL        = ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );
V_L       = (sigma-1)*gammaL*L^(1/sigmaL);
V_LL      = (sigma-1)*(gammaL/sigmaL)*(L^((1/sigmaL)-1));
U_C       =  (C^(-sigma))*(VL^sigma);
U_CC      = -sigma*(C^(-sigma-1))*(VL^sigma);
U_L       = ( (C^(1-sigma))*sigma*V_L*(VL^(sigma-1)) )/(1-sigma);
U_LL      = U_L*( (V_LL/V_L) + (sigma-1)*V_L*(VL^(-1)) ); 
U_CL      = (C^(-sigma))*sigma*V_L*(VL^(sigma-1));
U_LC      = U_CL;

% Solutions C=C(lambda,PN,PH,W); L=L(lambda,PN,PH,W)
a11 = (U_CC/U_C);
a12 = (U_CL/U_C);
a21 = (U_LC/U_L);
a22 = (U_LL/U_L);

% PN, PH, W, lambda
b11 = (1-alphaC)/PN;
b12 = alphaC*alphaH/PH;
b13 = 0;
b14 = (1/lambda);

b21 = 0;
b22 = 0;
b23 = (1/W);
b24 = (1/lambda);

A1 = [a11 a12; a21 a22];
B1 = [b11 b12 b13 b14; b21 b22 b23 b24];
JST1 = inv(A1);
MST1 = JST1*B1;
C_1PN = MST1(1,1); C_1PH = MST1(1,2); C_W = MST1(1,3);
L_1PN = MST1(2,1); L_1PH = MST1(2,2); L_W = MST1(2,3);

% Partial derivatives of W=W(WN,WH)           
W_WH     = (W/WH)*alphaL; 
W_WN     = (W/WN)*(1-alphaL);                                                                                                                         
L_WH     = L_W*W_WH;                                                                    
L_WN     = L_W*W_WN;                                                                    
                                                                                        
% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH,WN,WH)                      
CN_1PN = - (CN/PN)*(alphaC*phi) + (CN/C)*C_1PN;                                         
CN_1PH = (CN/PH)*alphaC*alphaH*phi + (CN/C)*C_1PH;                                      
CN_WN  = (CN/C)*C_W*W_WN;                                                               
CN_WH  = (CN/C)*C_W*W_WH;                                                               
                                                                                        
CH_1PN = (CH/PN)*phi*(1-alphaC) + (CH/C)*C_1PN;                                         
CH_1PH = -(CH/PH)*( rho*(1-alphaH) + phi*alphaH*(1-alphaC) ) + (CH/C)*C_1PH;            
CH_WN  = (CH/C)*C_W*W_WN;                                                               
CH_WH  = (CH/C)*C_W*W_WH;                                                               
                                                                                        
CF_1PN = (CF/PN)*(1-alphaC)*phi + (CF/C)*C_1PN;                                         
CF_1PH = (CF/PH)*alphaH*(rho - phi*(1-alphaC) ) + (CF/C)*C_1PH;                         
CF_WN  = (CF/C)*C_W*W_WN;                                                               
CF_WH  = (CF/C)*C_W*W_WH;   

% Solutions LH=LH(lambda,WH,WN,PH,PN), LN=LN(lambda,WH,WN,PH,PN)
LH_WH  = (LH/WH)*epsilon*(1-alphaL) + (LH/L)*L_WH; 
LH_WN  = -(LH/WN)*epsilon*(1-alphaL) + (LH/L)*L_WN; 
LH_1PH = (LH/L)*L_1PH; 
LH_1PN = (LH/L)*L_1PN;

LN_WH  = -(LN/WH)*epsilon*alphaL + (LN/L)*L_WH; 
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN; 
LN_1PH = (LN/L)*L_1PH; 
LN_1PN = (LN/L)*L_1PN;  

% Partial derivatives of RK(RH,RN)               
R_RH  = (RK/RH)*alphaK;                         
R_RN  = (RK/RN)*(1-alphaK);                     
                                                 
% Solutions Kj=Kj(RH,RN,K), j=H,N                
KH_RH  = (KH/RH)*epsilonK*(1-alphaK);            
KH_RN  = -(KH/RN)*epsilonK*(1-alphaK);           
KH_1K  = (KH/K);                                 
                                                 
KN_RH  = -(KN/RH)*epsilonK*alphaK;               
KN_RN  = (KN/RN)*epsilonK*alphaK;                
KN_1K  = (KN/K);                                                         

% Solving for WH,WN,RH,RN(PH,PN,K,uKH,uKN,AH,BH,AN,BN,lambda)
d11 = - ( ((1-sLH)/sigmaH)*(LH_WH/LH) + (1/WH) ); % WH
d12 = - ((1-sLH)/sigmaH)*(LH_WN/LH);  % WN
d13 = ((1-sLH)/sigmaH)*(KH_RH/KH);  % RH
d14 = ((1-sLH)/sigmaH)*(KH_RN/KH); % RN

d21 = - ((1-sLN)/sigmaN)*(LN_WH/LN);  % WH
d22 = - ( ((1-sLN)/sigmaN)*(LN_WN/LN) + (1/WN) ); % WN
d23 = ((1-sLN)/sigmaN)*(KN_RH/KN);  % RH
d24 = ((1-sLN)/sigmaN)*(KN_RN/KN); % RN

d31 = (sLH/sigmaH)*(LH_WH/LH); % WH
d32 = (sLH/sigmaH)*(LH_WN/LH); % WN
d33 = - ( (sLH/sigmaH)*(KH_RH/KH) + (1/RH) ); % RH
d34 = - (sLH/sigmaH)*(KH_RN/KH); % RN

d41 = (sLN/sigmaN)*(LN_WH/LN); % WH
d42 = (sLN/sigmaN)*(LN_WN/LN); % WN
d43 = - (sLN/sigmaN)*(KN_RH/KN); % RH
d44 = - ( (sLN/sigmaN)*(KN_RN/KN) + (1/RN) ); % RN

% PN,PH,K,uKH,uKN,AH,BH,AN,BN,lambda
e11 = ((1-sLH)/sigmaH)*(LH_1PN/LH); % PN
e12 = ((1-sLH)/sigmaH)*(LH_1PH/LH) - (1/PH); % PH
e13 = - ((1-sLH)/sigmaH)*(KH_1K/KH); % K
e14 = - ((1-sLH)/sigmaH); % uKH
e15 = 0; % uKN
e16 = - ( ((sigmaH-1)/sigmaH)+ (sLH/sigmaH) )*(1/AH);  % AH
e17 = - ((1-sLH)/sigmaH)*(1/BH);  % BH
e18 = 0;
e19 = 0;

e21 = ((1-sLN)/sigmaN)*(LN_1PN/LN) - (1/PN); % PN
e22 = ((1-sLN)/sigmaN)*(LN_1PH/LN);  % PH
e23 = - ((1-sLN)/sigmaN)*(KN_1K/KN); % K
e24 = 0; % uKH
e25 = - ((1-sLN)/sigmaN);  % uKN
e26 = 0;
e27 = 0;
e28 = - ( ((sigmaN-1)/sigmaN) + (sLN/sigmaN) )*(1/AN);  % AN
e29 = - ((1-sLN)/sigmaN)*(1/BN);    % BN

e31 = - (sLH/sigmaH)*(LH_1PN/LH); % PN
e32 = - ( (sLH/sigmaH)*(LH_1PH/LH) + (1/PH) ); % PH
e33 = (sLH/sigmaH)*(KH_1K/KH); % K
e34 = (sLH/sigmaH); % uKH
e35 = 0;  % uKN
e36 = - (sLH/sigmaH)*(1/AH); % AH
e37 = - ((sigmaH-sLH)/sigmaH)*(1/BH); % BH
e38 = 0;
e39 = 0;

e41 = - ( (sLN/sigmaN)*(LN_1PN/LN) + (1/PN) ); % PN
e42 = - (sLN/sigmaN)*(LN_1PH/LN); % PH
e43 = (sLN/sigmaN)*(KN_1K/KN); % K
e44 = 0;  % uKH
e45 = (sLN/sigmaN); % uKN
e46 = 0;
e47 = 0;
e48 = - (sLN/sigmaN)*(1/AN); % AN
e49 = - ((sigmaN-sLN)/sigmaN)*(1/BN); % BN

M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X2 = [e11 e12 e13 e14 e15 e16 e17 e18 e19; e21 e22 e23 e24 e25 e26 e27 e28 e29; e31 e32 e33 e34 e35 e36 e37 e38 e39; e41 e42 e43 e44 e45 e46 e47 e48 e49];
JST2 = inv(M2);
MST2 = JST2*X2;
WH_1PN = MST2(1,1); WH_1PH = MST2(1,2); WH_1K = MST2(1,3); WH_uKH = MST2(1,4); WH_uKN = MST2(1,5); WH_1AH = MST2(1,6); WH_1BH = MST2(1,7); WH_1AN = MST2(1,8); WH_1BN = MST2(1,9);
WN_1PN = MST2(2,1); WN_1PH = MST2(2,2); WN_1K = MST2(2,3); WN_uKH = MST2(2,4); WN_uKN = MST2(2,5); WN_1AH = MST2(2,6); WN_1BH = MST2(2,7); WN_1AN = MST2(2,8); WN_1BN = MST2(2,9);
RH_1PN = MST2(3,1); RH_1PH = MST2(3,2); RH_1K = MST2(3,3); RH_uKH = MST2(3,4); RH_uKN = MST2(3,5); RH_1AH = MST2(3,6); RH_1BH = MST2(3,7); RH_1AN = MST2(3,8); RH_1BN = MST2(3,9);
RN_1PN = MST2(4,1); RN_1PH = MST2(4,2); RN_1K = MST2(4,3); RN_uKH = MST2(4,4); RN_uKN = MST2(4,5); RN_1AH = MST2(4,6); RN_1BH = MST2(4,7); RN_1AN = MST2(4,8); RN_1BN = MST2(4,9);

% Solving for sectoral labor and sectoral output - Lj,Kj,Yj(PN,PH,K,uKj,Aj,Bj,lambda)
LH_2PN = LH_1PN + (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_2PH = LH_1PH + (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K  = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKH = (LH_WH*WH_uKH) + (LH_WN*WN_uKH);
LH_uKN = (LH_WH*WH_uKN) + (LH_WN*WN_uKN);
LH_1AH = (LH_WH*WH_1AH) + (LH_WN*WN_1AH);
LH_1BH = (LH_WH*WH_1BH) + (LH_WN*WN_1BH);
LH_1AN = (LH_WH*WH_1AN) + (LH_WN*WN_1AN);
LH_1BN = (LH_WH*WH_1BN) + (LH_WN*WN_1BN);

LN_2PN = LN_1PN + (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_2PH = LN_1PH + (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K  = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKH = (LN_WH*WH_uKH) + (LN_WN*WN_uKH);
LN_uKN = (LN_WH*WH_uKN) + (LN_WN*WN_uKN);
LN_1AH = (LN_WH*WH_1AH) + (LN_WN*WN_1AH);
LN_1BH = (LN_WH*WH_1BH) + (LN_WN*WN_1BH);
LN_1AN = (LN_WH*WH_1AN) + (LN_WN*WN_1AN);
LN_1BN = (LN_WH*WH_1BN) + (LN_WN*WN_1BN);

KH_1PN = (KH_RH*RH_1PN) + (KH_RN*RN_1PN);
KH_1PH = (KH_RH*RH_1PH) + (KH_RN*RN_1PH);
KH_2K  = KH_1K  +(KH_RH*RH_1K)  + (KH_RN*RN_1K);
KH_uKH = (KH_RH*RH_uKH) + (KH_RN*RN_uKH);
KH_uKN = (KH_RH*RH_uKN) + (KH_RN*RN_uKN);
KH_1AH = (KH_RH*RH_1AH) + (KH_RN*RN_1AH);
KH_1BH = (KH_RH*RH_1BH) + (KH_RN*RN_1BH);
KH_1AN = (KH_RH*RH_1AN) + (KH_RN*RN_1AN);
KH_1BN = (KH_RH*RH_1BN) + (KH_RN*RN_1BN);

KN_1PN = (KN_RH*RH_1PN) + (KN_RN*RN_1PN);
KN_1PH = (KN_RH*RH_1PH) + (KN_RN*RN_1PH);
KN_2K  = KN_1K + (KN_RH*RH_1K)  + (KN_RN*RN_1K);
KN_uKH = (KN_RH*RH_uKH) + (KN_RN*RN_uKH);
KN_uKN = (KN_RH*RH_uKN) + (KN_RN*RN_uKN);
KN_1AH = (KN_RH*RH_1AH) + (KN_RN*RN_1AH);
KN_1BH = (KN_RH*RH_1BH) + (KN_RN*RN_1BH);
KN_1AN = (KN_RH*RH_1AN) + (KN_RN*RN_1AN);
KN_1BN = (KN_RH*RH_1BN) + (KN_RN*RN_1BN);

YH_1PN = sLH*YH*(LH_2PN/LH) + (1-sLH)*YH*(KH_1PN/KH);
YH_1PH = sLH*YH*(LH_2PH/LH) + (1-sLH)*YH*(KH_1PH/KH);
YH_1K  = sLH*YH*(LH_1K/LH) + (1-sLH)*YH*(KH_2K/KH);
YH_uKH = sLH*YH*(LH_uKH/LH) + (1-sLH)*YH*( (KH_uKH/KH) + 1 );
YH_uKN = sLH*YH*(LH_uKN/LH) + (1-sLH)*YH*(KH_uKN/KH);
YH_1AH = sLH*YH*( (LH_1AH/LH) + (1/AH) ) + (1-sLH)*YH*(KH_1AH/KH);
YH_1BH = sLH*YH*(LH_1BH/LH) + (1-sLH)*YH*( (KH_1BH/KH) + (1/BH) );
YH_1AN = sLH*YH*(LH_1AN/LH) + (1-sLH)*YH*(KH_1AN/KH);
YH_1BN = sLH*YH*(LH_1BN/LH) + (1-sLH)*YH*(KH_1BN/KH);

YN_1PN = sLN*YN*(LN_2PN/LN) + (1-sLN)*YN*(KN_1PN/KN);
YN_1PH = sLN*YN*(LN_2PH/LN) + (1-sLN)*YN*(KN_1PH/KN);
YN_1K  = sLN*YN*(LN_1K/LN) + (1-sLN)*YN*(KN_2K/KN);
YN_uKH = sLN*YN*(LN_uKH/LN) + (1-sLN)*YN*(KN_uKH/KN);
YN_uKN = sLN*YN*(LN_uKN/LN) + (1-sLN)*YN*( (KN_uKN/KN) + 1);
YN_1AH = sLN*YN*(LN_1AH/LN) + (1-sLN)*YN*(KN_1AH/KN);
YN_1BH = sLN*YN*(LN_1BH/LN) + (1-sLN)*YN*(KN_1BH/KN);
YN_1AN = sLN*YN*( (LN_1AN/LN) + (1/AN) ) + (1-sLN)*YN*(KN_1AN/KN);
YN_1BN = sLN*YN*(LN_1BN/LN) + (1-sLN)*YN*( (KN_1BN/KN) + (1/BN) );

% Intermediate solution for CN, CH, CF - Cj=Cj(PN,PH,K,uKj,Aj,Bj)
CN_2PN     = CN_1PN + (CN_WH*WH_1PN) + (CN_WN*WN_1PN);
CN_2PH     = CN_1PH + (CN_WH*WH_1PH) + (CN_WN*WN_1PH);
CN_1K      = (CN_WH*WH_1K) + (CN_WN*WN_1K);
CN_uKH     = (CN_WH*WH_uKH) + (CN_WN*WN_uKH);
CN_uKN     = (CN_WH*WH_uKN) + (CN_WN*WN_uKN);
CN_1AH     = (CN_WH*WH_1AH) + (CN_WN*WN_1AH);
CN_1BH     = (CN_WH*WH_1BH) + (CN_WN*WN_1BH);
CN_1AN     = (CN_WH*WH_1AN) + (CN_WN*WN_1AN);
CN_1BN     = (CN_WH*WH_1BN) + (CN_WN*WN_1BN);

CH_2PN     = CH_1PN + (CH_WH*WH_1PN) + (CH_WN*WN_1PN);
CH_2PH     = CH_1PH + (CH_WH*WH_1PH) + (CH_WN*WN_1PH);
CH_1K      = (CH_WH*WH_1K) + (CH_WN*WN_1K);
CH_uKH     = (CH_WH*WH_uKH) + (CH_WN*WN_uKH);
CH_uKN     = (CH_WH*WH_uKN) + (CH_WN*WN_uKN);
CH_1AH     = (CH_WH*WH_1AH) + (CH_WN*WN_1AH);
CH_1BH     = (CH_WH*WH_1BH) + (CH_WN*WN_1BH);
CH_1AN     = (CH_WH*WH_1AN) + (CH_WN*WN_1AN);
CH_1BN     = (CH_WH*WH_1BN) + (CH_WN*WN_1BN);

CF_2PN     = CF_1PN + (CF_WH*WH_1PN) + (CF_WN*WN_1PN);
CF_2PH     = CF_1PH + (CF_WH*WH_1PH) + (CF_WN*WN_1PH);
CF_1K      = (CF_WH*WH_1K) + (CF_WN*WN_1K);
CF_uKH     = (CF_WH*WH_uKH) + (CF_WN*WN_uKH);
CF_uKN     = (CF_WH*WH_uKN) + (CF_WN*WN_uKN);
CF_1AH     = (CF_WH*WH_1AH) + (CF_WN*WN_1AH);
CF_1BH     = (CF_WH*WH_1BH) + (CF_WN*WN_1BH);
CF_1AN     = (CF_WH*WH_1AN) + (CF_WN*WN_1AN);
CF_1BN     = (CF_WH*WH_1BN) + (CF_WN*WN_1BN);

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_1K  = deltaK; 
J_1Q  = K*v_1Q; 
J_PN  = K*v_PN; 
J_PH  = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I      = deltaK*K; 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_1K; 
JN_1Q  = (IN/I)*J_1Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_1K; 
JH_1Q  = (IH/I)*J_1Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_1K; 
JF_1Q  = (IF/I)*J_1Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKH, uKN; uKj(PN,PH,K)
f11 = ((xi2H/xi1H) + (sLH/sigmaH)) - (sLH/sigmaH)*(LH_uKH/LH) + (sLH/sigmaH)*(KH_uKH/KH); % uKH
f12 = - (sLH/sigmaH)*(LH_uKN/LH) + (sLH/sigmaH)*(KH_uKN/KH); % uKN
f21 = - (sLN/sigmaN)*(LN_uKH/LN) + (sLN/sigmaN)*(KN_uKH/KN); % uKH
f22 = ((xi2N/xi1N) + (sLN/sigmaN)) - (sLN/sigmaN)*(LN_uKN/LN) + (sLN/sigmaN)*(KN_uKN/KN); % uKN

% PN, PH, K
g11 = (sLH/sigmaH)*(LH_2PN/LH) - (sLH/sigmaH)*(KH_1PN/KH); % PN
g12 = (sLH/sigmaH)*(LH_2PH/LH) - (sLH/sigmaH)*(KH_1PH/KH); % PH
g13 = (sLH/sigmaH)*(LH_1K/LH) - (sLH/sigmaH)*(KH_2K/KH); % K
g14 = (sLH/sigmaH)*( (LH_1AH/LH) + (1/AH) ) - (sLH/sigmaH)*(KH_1AH/KH); % AH
g15 = (sLH/sigmaH)*(LH_1BH/LH) - (sLH/sigmaH)*(KH_1BH/KH) + ((sigmaH-sLH)/sigmaH)*(1/BH); % BH 
g16 = (sLH/sigmaH)*(LH_1AN/LH) - (sLH/sigmaH)*(KH_1AN/KH); % AN
g17 = (sLH/sigmaH)*(LH_1BN/LH) - (sLH/sigmaH)*(KH_1BN/KH); % BN

g21 = (sLN/sigmaN)*(LN_2PN/LN) - (sLN/sigmaN)*(KN_1PN/KN); % PN
g22 = (sLN/sigmaN)*(LN_2PH/LN) - (sLN/sigmaN)*(KN_1PH/KN); % PH
g23 = (sLN/sigmaN)*(LN_1K/LN) - (sLN/sigmaN)*(KN_2K/KN); % K
g24 = (sLN/sigmaN)*(LN_1AH/LN) - (sLN/sigmaN)*(KN_1AH/KN); % AH
g25 = (sLN/sigmaN)*(LN_1BH/LN) - (sLN/sigmaN)*(KN_1BH/KN); % BH
g26 = (sLN/sigmaN)*( (LN_1AN/LN) + (1/AN) ) - (sLN/sigmaN)*(KN_1AN/KN); % AN
g27 = (sLN/sigmaN)*(LN_1BN/LN) - (sLN/sigmaN)*(KN_1BN/KN) + ((sigmaN-sLN)/sigmaN)*(1/BN); % BN 

M3 = [f11 f12; f21 f22];
X3 = [g11 g12 g13 g14 g15 g16 g17; g21 g22 g23 g24 g25 g26 g27];
JST3 = inv(M3);
MST3 = JST3*X3;

uKH_PN = MST3(1,1); uKH_PH = MST3(1,2); uKH_1K = MST3(1,3); uKH_1AH = MST3(1,4); uKH_1BH = MST3(1,5); uKH_1AN = MST3(1,6); uKH_1BN = MST3(1,7);
uKN_PN = MST3(2,1); uKN_PH = MST3(2,2); uKN_1K = MST3(2,3); uKN_1AH = MST3(2,4); uKN_1BH = MST3(2,5); uKN_1AN = MST3(2,6); uKN_1BN = MST3(2,7);

% Solving for Wj,Rj,Lj,Kj,Yj(lambda,K,PH,PN,AH,BH,AN,BN)
WH_2K  = WH_1K + (WH_uKH*uKH_1K) + (WH_uKN*uKN_1K);
WH_PH  = WH_1PH + (WH_uKH*uKH_PH) + (WH_uKN*uKN_PH);
WH_PN  = WH_1PN + (WH_uKH*uKH_PN) + (WH_uKN*uKN_PN);
WH_2AH = WH_1AH + (WH_uKH*uKH_1AH) + (WH_uKN*uKN_1AH);
WH_2BH = WH_1BH + (WH_uKH*uKH_1BH) + (WH_uKN*uKN_1BH);
WH_2AN = WH_1AN + (WH_uKH*uKH_1AN) + (WH_uKN*uKN_1AN);
WH_2BN = WH_1BN + (WH_uKH*uKH_1BN) + (WH_uKN*uKN_1BN);

WN_2K = WN_1K + (WN_uKH*uKH_1K) + (WN_uKN*uKN_1K);
WN_PH = WN_1PH + (WN_uKH*uKH_PH) + (WN_uKN*uKN_PH);
WN_PN = WN_1PN + (WN_uKH*uKH_PN) + (WN_uKN*uKN_PN);
WN_2AH = WN_1AH + (WN_uKH*uKH_1AH) + (WN_uKN*uKN_1AH);
WN_2BH = WN_1BH + (WN_uKH*uKH_1BH) + (WN_uKN*uKN_1BH);
WN_2AN = WN_1AN + (WN_uKH*uKH_1AN) + (WN_uKN*uKN_1AN);
WN_2BN = WN_1BN + (WN_uKH*uKH_1BN) + (WN_uKN*uKN_1BN);

RH_2K  = RH_1K + (RH_uKH*uKH_1K) + (RH_uKN*uKN_1K);
RH_PH  = RH_1PH + (RH_uKH*uKH_PH) + (RH_uKN*uKN_PH);
RH_PN  = RH_1PN + (RH_uKH*uKH_PN) + (RH_uKN*uKN_PN);
RH_2AH = RH_1AH + (RH_uKH*uKH_1AH) + (RH_uKN*uKN_1AH);
RH_2BH = RH_1BH + (RH_uKH*uKH_1BH) + (RH_uKN*uKN_1BH);
RH_2AN = RH_1AN + (RH_uKH*uKH_1AN) + (RH_uKN*uKN_1AN);
RH_2BN = RH_1BN + (RH_uKH*uKH_1BN) + (RH_uKN*uKN_1BN);

RN_2K = RN_1K + (RN_uKH*uKH_1K) + (RN_uKN*uKN_1K);
RN_PH = RN_1PH + (RN_uKH*uKH_PH) + (RN_uKN*uKN_PH);
RN_PN = RN_1PN + (RN_uKH*uKH_PN) + (RN_uKN*uKN_PN);
RN_2AH = RN_1AH + (RN_uKH*uKH_1AH) + (RN_uKN*uKN_1AH);
RN_2BH = RN_1BH + (RN_uKH*uKH_1BH) + (RN_uKN*uKN_1BH);
RN_2AN = RN_1AN + (RN_uKH*uKH_1AN) + (RN_uKN*uKN_1AN);
RN_2BN = RN_1BN + (RN_uKH*uKH_1BN) + (RN_uKN*uKN_1BN);

LH_2K = LH_1K + (LH_uKH*uKH_1K) + (LH_uKN*uKN_1K);
LH_PH = LH_2PH + (LH_uKH*uKH_PH) + (LH_uKN*uKN_PH);
LH_PN = LH_2PN + (LH_uKH*uKH_PN) + (LH_uKN*uKN_PN);
LH_2AH = LH_1AH + (LH_uKH*uKH_1AH) + (LH_uKN*uKN_1AH);
LH_2BH = LH_1BH + (LH_uKH*uKH_1BH) + (LH_uKN*uKN_1BH);
LH_2AN = LH_1AN + (LH_uKH*uKH_1AN) + (LH_uKN*uKN_1AN);
LH_2BN = LH_1BN + (LH_uKH*uKH_1BN) + (LH_uKN*uKN_1BN);

LN_2K = LN_1K + (LN_uKH*uKH_1K) + (LN_uKN*uKN_1K);
LN_PH = LN_2PH + (LN_uKH*uKH_PH) + (LN_uKN*uKN_PH);
LN_PN = LN_2PN + (LN_uKH*uKH_PN) + (LN_uKN*uKN_PN);
LN_2AH = LN_1AH + (LN_uKH*uKH_1AH) + (LN_uKN*uKN_1AH);
LN_2BH = LN_1BH + (LN_uKH*uKH_1BH) + (LN_uKN*uKN_1BH);
LN_2AN = LN_1AN + (LN_uKH*uKH_1AN) + (LN_uKN*uKN_1AN);
LN_2BN = LN_1BN + (LN_uKH*uKH_1BN) + (LN_uKN*uKN_1BN);

KH_3K = KH_2K + (KH_uKH*uKH_1K) + (KH_uKN*uKN_1K);
KH_PH = KH_1PH + (KH_uKH*uKH_PH) + (KH_uKN*uKN_PH);
KH_PN = KH_1PN + (KH_uKH*uKH_PN) + (KH_uKN*uKN_PN);
KH_2AH = KH_1AH + (KH_uKH*uKH_1AH) + (KH_uKN*uKN_1AH);
KH_2BH = KH_1BH + (KH_uKH*uKH_1BH) + (KH_uKN*uKN_1BH);
KH_2AN = KH_1AN + (KH_uKH*uKH_1AN) + (KH_uKN*uKN_1AN);
KH_2BN = KH_1BN + (KH_uKH*uKH_1BN) + (KH_uKN*uKN_1BN);

KN_3K = KN_2K + (KN_uKH*uKH_1K) + (KN_uKN*uKN_1K);
KN_PH = KN_1PH + (KN_uKH*uKH_PH) + (KN_uKN*uKN_PH);
KN_PN = KN_1PN + (KN_uKH*uKH_PN) + (KN_uKN*uKN_PN);
KN_2AH = KN_1AH + (KN_uKH*uKH_1AH) + (KN_uKN*uKN_1AH);
KN_2BH = KN_1BH + (KN_uKH*uKH_1BH) + (KN_uKN*uKN_1BH);
KN_2AN = KN_1AN + (KN_uKH*uKH_1AN) + (KN_uKN*uKN_1AN);
KN_2BN = KN_1BN + (KN_uKH*uKH_1BN) + (KN_uKN*uKN_1BN);

YH_2K = YH_1K + (YH_uKH*uKH_1K) + (YH_uKN*uKN_1K);
YH_PH = YH_1PH + (YH_uKH*uKH_PH) + (YH_uKN*uKN_PH);
YH_PN = YH_1PN + (YH_uKH*uKH_PN) + (YH_uKN*uKN_PN);
YH_2AH = YH_1AH + (YH_uKH*uKH_1AH) + (YH_uKN*uKN_1AH);
YH_2BH = YH_1BH + (YH_uKH*uKH_1BH) + (YH_uKN*uKN_1BH);
YH_2AN = YH_1AN + (YH_uKH*uKH_1AN) + (YH_uKN*uKN_1AN);
YH_2BN = YH_1BN + (YH_uKH*uKH_1BN) + (YH_uKN*uKN_1BN);

YN_2K = YN_1K + (YN_uKH*uKH_1K) + (YN_uKN*uKN_1K);
YN_PH = YN_1PH + (YN_uKH*uKH_PH) + (YN_uKN*uKN_PH);
YN_PN = YN_1PN + (YN_uKH*uKH_PN) + (YN_uKN*uKN_PN);
YN_2AH = YN_1AH + (YN_uKH*uKH_1AH) + (YN_uKN*uKN_1AH);
YN_2BH = YN_1BH + (YN_uKH*uKH_1BH) + (YN_uKN*uKN_1BH);
YN_2AN = YN_1AN + (YN_uKH*uKH_1AN) + (YN_uKN*uKN_1AN);
YN_2BN = YN_1BN + (YN_uKH*uKH_1BN) + (YN_uKN*uKN_1BN);

CN_2K = CN_1K + (CN_uKH*uKH_1K) + (CN_uKN*uKN_1K);
CN_PH = CN_2PH + (CN_uKH*uKH_PH) + (CN_uKN*uKN_PH);
CN_PN = CN_2PN + (CN_uKH*uKH_PN) + (CN_uKN*uKN_PN);
CN_2AH = CN_1AH + (CN_uKH*uKH_1AH) + (CN_uKN*uKN_1AH);
CN_2BH = CN_1BH + (CN_uKH*uKH_1BH) + (CN_uKN*uKN_1BH);
CN_2AN = CN_1AN + (CN_uKH*uKH_1AN) + (CN_uKN*uKN_1AN);
CN_2BN = CN_1BN + (CN_uKH*uKH_1BN) + (CN_uKN*uKN_1BN);

CH_2K = CH_1K + (CH_uKH*uKH_1K) + (CH_uKN*uKN_1K);
CH_PH = CH_2PH + (CH_uKH*uKH_PH) + (CH_uKN*uKN_PH);
CH_PN = CH_2PN + (CH_uKH*uKH_PN) + (CH_uKN*uKN_PN);
CH_2AH = CH_1AH + (CH_uKH*uKH_1AH) + (CH_uKN*uKN_1AH);
CH_2BH = CH_1BH + (CH_uKH*uKH_1BH) + (CH_uKN*uKN_1BH);
CH_2AN = CH_1AN + (CH_uKH*uKH_1AN) + (CH_uKN*uKN_1AN);
CH_2BN = CH_1BN + (CH_uKH*uKH_1BN) + (CH_uKN*uKN_1BN);

CF_2K = CF_1K + (CF_uKH*uKH_1K) + (CF_uKN*uKN_1K);
CF_PH = CF_2PH + (CF_uKH*uKH_PH) + (CF_uKN*uKN_PH);
CF_PN = CF_2PN + (CF_uKH*uKH_PN) + (CF_uKN*uKN_PN);
CF_2AH = CF_1AH + (CF_uKH*uKH_1AH) + (CF_uKN*uKN_1AH);
CF_2BH = CF_1BH + (CF_uKH*uKH_1BH) + (CF_uKN*uKN_1BH);
CF_2AN = CF_1AN + (CF_uKH*uKH_1AN) + (CF_uKN*uKN_1AN);
CF_2BN = CF_1BN + (CF_uKH*uKH_1BN) + (CF_uKN*uKN_1BN);

% Partial Derivatives Gj=Gj(G) 
GN_G   = omegaGN/PN; 
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN)
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1N*uKN_PH);
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1N*uKN_PN);
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1H*uKH_PH);
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1H*uKH_PN);

% K,Q,G,AH,BH,AN,BN
k11 = -(YN_2K - CN_2K - JN_1K - (KN*xi1N*uKN_1K));
k12 = JN_1Q;
k13 = GN_G;
k14 = -(YN_2AH - CN_2AH - (KN*xi1N*uKN_1AH));
k15 = -(YN_2BH - CN_2BH - (KN*xi1N*uKN_1BH));
k16 = -(YN_2AN - CN_2AN - (KN*xi1N*uKN_1AN));
k17 = -(YN_2BN - CN_2BN - (KN*xi1N*uKN_1BN));

k21 = -(YH_2K - CH_2K - JH_1K - (KH*xi1H*uKH_1K));
k22 = JH_1Q;
k23 = GH_G;
k24 = -(YH_2AH - CH_2AH - (KH*xi1H*uKH_1AH));
k25 = -(YH_2BH - CH_2BH - (KH*xi1H*uKH_1BH));
k26 = -(YH_2AN - CH_2AN - (KH*xi1H*uKH_1AN));
k27 = -(YH_2BN - CH_2BN - (KH*xi1H*uKH_1BN));

M4 = [h11 h12; h21 h22];                                                                                                             
X4 = [k11 k12 k13 k14 k15 k16 k17; k21 k22 k23 k24 k25 k26 k27];                                                                     
JST4 = inv(M4);                                                                                                                      
MST4 = JST4*X4;                                                                                                                      
                                                                                                                                     
PH_K = MST4(1,1); PH_Q = MST4(1,2); PH_G = MST4(1,3); PH_AH = MST4(1,4); PH_BH = MST4(1,5); PH_AN = MST4(1,6); PH_BN = MST4(1,7);    
PN_K = MST4(2,1); PN_Q = MST4(2,2); PN_G = MST4(2,3); PN_AH = MST4(2,4); PN_BH = MST4(2,5); PN_AN = MST4(2,6); PN_BN = MST4(2,7);                           

% Solving for Lj,Kj,Yj,uKj(K,Q,G,Aj,Bj) - Final Solutions
LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K);
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q);
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);
LH_AH = LH_2AH + (LH_PH*PH_AH) + (LH_PN*PN_AH);
LH_BH = LH_2BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_2AN + (LH_PH*PH_AN) + (LH_PN*PN_AN);
LH_BN = LH_2BN + (LH_PH*PH_BN) + (LH_PN*PN_BN);

LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G);
LN_AH = LN_2AH + (LN_PH*PH_AH) + (LN_PN*PN_AH);
LN_BH = LN_2BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_2AN + (LN_PH*PH_AN) + (LN_PN*PN_AN);
LN_BN = LN_2BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);

YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K);
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q);
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);
YH_AH = YH_2AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_2BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_2AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_2BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);

YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);
YN_AH = YN_2AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_2BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_2AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_2BN + (YN_PH*PH_BN) + (YN_PN*PN_BN);

KH_K  = KH_3K + (KH_PH*PH_K) + (KH_PN*PN_K);
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);
KH_AH = KH_2AH + (KH_PH*PH_AH) + (KH_PN*PN_AH);
KH_BH = KH_2BH + (KH_PH*PH_BH) + (KH_PN*PN_BH);
KH_AN = KH_2AN + (KH_PH*PH_AN) + (KH_PN*PN_AN);
KH_BN = KH_2BN + (KH_PH*PH_BN) + (KH_PN*PN_BN);

KN_K = KN_3K + (KN_PH*PH_K) + (KN_PN*PN_K);
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);
KN_AH = KN_2AH + (KN_PH*PH_AH) + (KN_PN*PN_AH);
KN_BH = KN_2BH + (KN_PH*PH_BH) + (KN_PN*PN_BH);
KN_AN = KN_2AN + (KN_PH*PH_AN) + (KN_PN*PN_AN);
KN_BN = KN_2BN + (KN_PH*PH_BN) + (KN_PN*PN_BN);

uKH_K  = uKH_1K + (uKH_PH*PH_K) + (uKH_PN*PN_K);
uKH_Q  = (uKH_PH*PH_Q) + (uKH_PN*PN_Q);
uKH_G  = (uKH_PH*PH_G) + (uKH_PN*PN_G);
uKH_AH = uKH_1AH + (uKH_PH*PH_AH) + (uKH_PN*PN_AH);
uKH_BH = uKH_1BH + (uKH_PH*PH_BH) + (uKH_PN*PN_BH);
uKH_AN = uKH_1AN + (uKH_PH*PH_AN) + (uKH_PN*PN_AN);
uKH_BN = uKH_1BN + (uKH_PH*PH_BN) + (uKH_PN*PN_BN);

uKN_K = uKN_1K + (uKN_PH*PH_K) + (uKN_PN*PN_K);
uKN_Q = (uKN_PH*PH_Q) + (uKN_PN*PN_Q);
uKN_G = (uKN_PH*PH_G) + (uKN_PN*PN_G);
uKN_AH = uKN_1AH + (uKN_PH*PH_AH) + (uKN_PN*PN_AH);
uKN_BH = uKN_1BH + (uKN_PH*PH_BH) + (uKN_PN*PN_BH);
uKN_AN = uKN_1AN + (uKN_PH*PH_AN) + (uKN_PN*PN_AN);
uKN_BN = uKN_1BN + (uKN_PH*PH_BN) + (uKN_PN*PN_BN);               
                            
% Check                                                                                                                
YH_K_check  = (YH_K/YH_0) -  sLH_0*(LH_K/LH_0) - (1-sLH_0)*(uKH_K + (KH_K/KH_0));                                      
YH_Q_check  = (YH_Q/YH_0) -  sLH_0*(LH_Q/LH_0) - (1-sLH_0)*(uKH_Q + (KH_Q/KH_0));                                      
YH_G_check  = (YH_G/YH_0) -  sLH_0*(LH_G/LH_0) - (1-sLH_0)*(uKH_G + (KH_G/KH_0));                                      
YH_AH_check = (YH_AH/YH_0) - sLH_0*(LH_AH/LH_0) - (sLH_0/AH_0) - (1-sLH_0)*(uKH_AH + (KH_AH/KH_0));                    
YH_BH_check = (YH_BH/YH_0) - sLH_0*(LH_BH/LH_0) - (1-sLH_0)*(uKH_BH + (1/BH_0) + (KH_BH/KH_0));                        
YH_AN_check = (YH_AN/YH_0) - sLH_0*(LH_AN/LH_0) - (1-sLH_0)*(uKH_AN + (KH_AN/KH_0));                                   
YH_BN_check = (YH_BN/YH_0) - sLH_0*(LH_BN/LH_0) - (1-sLH_0)*(uKH_BN + (KH_BN/KH_0));                                   
                                                                                                                       
YN_K_check  = (YN_K/YN_0) -   sLN_0*(LN_K/LN_0) - (1-sLN_0)*(uKN_K + (KN_K/KN_0));                                     
YN_Q_check  = (YN_Q/YN_0) -   sLN_0*(LN_Q/LN_0) - (1-sLN_0)*(uKN_Q + (KN_Q/KN_0));                                     
YN_G_check  = (YN_G/YN_0) -   sLN_0*(LN_G/LN_0) - (1-sLN_0)*(uKN_G + (KN_G/KN_0));                                     
YN_AH_check = (YN_AH/YN_0) -  sLN_0*(LN_AH/LN_0) - (1-sLN_0)*(uKN_AH + (KN_AH/KN_0));                                  
YN_BH_check = (YN_BH/YN_0) -  sLN_0*(LN_BH/LN_0) - (1-sLN_0)*(uKN_BH + (KN_BH/KN_0));                                  
YN_AN_check = (YN_AN/YN_0) -  sLN_0*(LN_AN/LN_0) - (sLN_0/AN_0) - (1-sLN_0)*(uKN_AN + (KN_AN/KN_0));                   
YN_BN_check = (YN_BN/YN_0) -  sLN_0*(LN_BN/LN_0) - (1-sLN_0)*(uKN_BN + (1/BN_0) + (KN_BN/KN_0));                       

% Solving for consumption Cj=Cj(lambda,K,Q,GH,GN), investment inputs 
% Jj=Jj(K,Q,GH,GN), imports MF=MF(lambda,K,Q,GH,GN), exports 
%XH=XH(lambda,K,Q,GH,GN)- Final Solutions
CN_K  = CN_2K + (CN_PH*PH_K) + (CN_PN*PN_K);        
CN_Q  = (CN_PH*PH_Q) + (CN_PN*PN_Q);                
CN_G  = (CN_PH*PH_G) + (CN_PN*PN_G);                
CN_AH = CN_2AH + (CN_PH*PH_AH) + (CN_PN*PN_AH);     
CN_BH = CN_2BH + (CN_PH*PH_BH) + (CN_PN*PN_BH);     
CN_AN = CN_2AN + (CN_PH*PH_AN) + (CN_PN*PN_AN);     
CN_BN = CN_2BN + (CN_PH*PH_BN) + (CN_PN*PN_BN);     
                                                    
CH_K  = CH_2K + (CH_PH*PH_K) + (CH_PN*PN_K);        
CH_Q  = (CH_PH*PH_Q) + (CH_PN*PN_Q);                
CH_G  = (CH_PH*PH_G) + (CH_PN*PN_G);                
CH_AH = CH_2AH + (CH_PH*PH_AH) + (CH_PN*PN_AH);     
CH_BH = CH_2BH + (CH_PH*PH_BH) + (CH_PN*PN_BH);     
CH_AN = CH_2AN + (CH_PH*PH_AN) + (CH_PN*PN_AN);     
CH_BN = CH_2BN + (CH_PH*PH_BN) + (CH_PN*PN_BN);     
                                                    
CF_K  = CF_2K + (CF_PH*PH_K) + (CF_PN*PN_K);        
CF_Q  = (CF_PH*PH_Q) + (CF_PN*PN_Q);                
CF_G  = (CF_PH*PH_G) + (CF_PN*PN_G);                
CF_AH = CF_2AH + (CF_PH*PH_AH) + (CF_PN*PN_AH);     
CF_BH = CF_2BH + (CF_PH*PH_BH) + (CF_PN*PN_BH);     
CF_AN = CF_2AN + (CF_PH*PH_AN) + (CF_PN*PN_AN);     
CF_BN = CF_2BN + (CF_PH*PH_BN) + (CF_PN*PN_BN);  

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_BH      = (JN_PH*PH_BH) + (JN_PN*PN_BH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN); 

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);

% Solving for sectoral return on capital - Rj(K,Q,G,Aj,Bj)                  
RH_K = RH_2K + (RH_PH*PH_K) + (RH_PN*PN_K);                                 
RH_Q = (RH_PH*PH_Q) + (RH_PN*PN_Q);                                         
RH_G = (RH_PH*PH_G) + (RH_PN*PN_G);                                         
RH_AH = RH_2AH + (RH_PH*PH_AH) + (RH_PN*PN_AH);                             
RH_BH = RH_2BH + (RH_PH*PH_BH) + (RH_PN*PN_BH);                             
RH_AN = RH_2AN + (RH_PH*PH_AN) + (RH_PN*PN_AN);                             
RH_BN = RH_2BN + (RH_PH*PH_BN) + (RH_PN*PN_BN);                             
                                                                            
RN_K = RN_2K + (RN_PH*PH_K) + (RN_PN*PN_K);                                 
RN_Q = (RN_PH*PH_Q) + (RN_PN*PN_Q);                                         
RN_G = (RN_PH*PH_G) + (RN_PN*PN_G);                                         
RN_AH = RN_2AH + (RN_PH*PH_AH) + (RN_PN*PN_AH);                             
RN_BH = RN_2BH + (RN_PH*PH_BH) + (RN_PN*PN_BH);                             
RN_AN = RN_2AN + (RN_PH*PH_AN) + (RN_PN*PN_AN);                             
RN_BN = RN_2BN + (RN_PH*PH_BN) + (RN_PN*PN_BN);                             

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(K,Q,G,Aj,Bj,lambda) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_G  = (v_PN*PN_G) + (v_PH*PH_G); 
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);

% Elements of the Jacobian Matrix                                                                                                                                           
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                  
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );                                                                           
Sigma_K   = -( -(RK/K)+(1/K)*( (RH*KH*uKH_K)+(RN*KN*uKN_K)+(RH*KH_K)+(RN*KN_K)+(RH_K*KH)+(RN_K*KN) )-(PH*KH/K)*xi1H*uKH_K-(PN*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) );   
Sigma_Q   = (r+deltaK)-( (1/K)*( (RH*KH*uKH_Q)+(RN*KN*uKN_Q)+(RH*KH_Q)+(RN*KN_Q)+(RH_Q*KH)+(RN_Q*KN) )-(PH*KH/K)*xi1H*uKH_Q-(PN*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) ); 

x11   = Upsilon_K;                                                                         
x12   = Upsilon_Q;     
x21   = Sigma_K;                        
x22   = Sigma_Q;
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
omega_12 = V_sorted(1,2)/V_sorted(1,2); 
omega_22 = V_sorted(2,2)/V_sorted(1,2); 

TrJ = trace(J); 
DetJ = det(J); 

% Elements of general solutions for capital K(t) and the relative price P(t)
% K(t) -K = X1(t)+X2(t); P(t)-P = omega21*X1(t)+omega22*X2(t)
% X1(t) = (K0-K)*exp(nu1*t)+Gamma2*exp(nu1*t) - Gamma1*(exp(nu1*t)-exp(-xi*t)); 
% X2(t) = -Gamma2*exp(-xi*t); 
Upsilon_G  = (I/IN)*(YN_G-CN_G-GN_G-(KN*xi1N*uKN_G)) + (alphaI*phiI*I)*( (PN_G/PN) - (alphaIH/PH)*PH_G );
Upsilon_AH = (I/IN)*(YN_AH-CN_AH-(KN*xi1N*uKN_AH)) + (alphaI*phiI*I)*( (PN_AH/PN) - (alphaIH/PH)*PH_AH );
Upsilon_BH = (I/IN)*(YN_BH-CN_BH-(KN*xi1N*uKN_BH)) + (alphaI*phiI*I)*( (PN_BH/PN) - (alphaIH/PH)*PH_BH );
Upsilon_AN = (I/IN)*(YN_AN-CN_AN-(KN*xi1N*uKN_AN)) + (alphaI*phiI*I)*( (PN_AN/PN) - (alphaIH/PH)*PH_AN );
Upsilon_BN = (I/IN)*(YN_BN-CN_BN-(KN*xi1N*uKN_BN)) + (alphaI*phiI*I)*( (PN_BN/PN) - (alphaIH/PH)*PH_BN );
Sigma_G  = -( (1/K)*( (RH*KH*uKH_G)+(RN*KN*uKN_G)+(RH*KH_G)+(RN*KN_G)+(RH_G*KH)+(RN_G*KN) )-(PH*KH/K)*xi1H*uKH_G-(PN*KN/K)*xi1N*uKN_G + (PI*kappa*v_G*deltaK) );
Sigma_AH = -( (1/K)*( (RH*KH*uKH_AH)+(RN*KN*uKN_AH)+(RH*KH_AH)+(RN*KN_AH)+(RH_AH*KH)+(RN_AH*KN) )-(PH*KH/K)*xi1H*uKH_AH-(PN*KN/K)*xi1N*uKN_AH + (PI*kappa*v_AH*deltaK) );
Sigma_BH = -( (1/K)*( (RH*KH*uKH_BH)+(RN*KN*uKN_BH)+(RH*KH_BH)+(RN*KN_BH)+(RH_BH*KH)+(RN_BH*KN) )-(PH*KH/K)*xi1H*uKH_BH-(PN*KN/K)*xi1N*uKN_BH + (PI*kappa*v_BH*deltaK) );
Sigma_AN = -( (1/K)*( (RH*KH*uKH_AN)+(RN*KN*uKN_AN)+(RH*KH_AN)+(RN*KN_AN)+(RH_AN*KH)+(RN_AN*KN) )-(PH*KH/K)*xi1H*uKH_AN-(PN*KN/K)*xi1N*uKN_AN + (PI*kappa*v_AN*deltaK) );
Sigma_BN = -( (1/K)*( (RH*KH*uKH_BN)+(RN*KN*uKN_BN)+(RH*KH_BN)+(RN*KN_BN)+(RH_BN*KH)+(RN_BN*KN) )-(PH*KH/K)*xi1H*uKH_BN-(PN*KN/K)*xi1N*uKN_BN + (PI*kappa*v_BN*deltaK) );
%%%%%%%%%%%%%%%%%% Solutions for Permanent Shocks %%%%%%%%%%%%%%%%%%%%
Vnorm = [omega_11 omega_12; omega_21 omega_22];
Vinv   = inv(Vnorm);
u11    = Vinv(1,1);
u12    = Vinv(1,2);
u21    = Vinv(2,1);
u22    = Vinv(2,2);

s11   = (u11*Upsilon_AH) + (u12*Sigma_AH);
s12   = (u11*Upsilon_BH) + (u12*Sigma_BH);
s13   = (u11*Upsilon_AN) + (u12*Sigma_AN);
s14   = (u11*Upsilon_BN) + (u12*Sigma_BN);
s15   = (u11*Upsilon_G) + (u12*Sigma_G);

s21   = (u21*Upsilon_AH) + (u22*Sigma_AH);
s22   = (u21*Upsilon_BH) + (u22*Sigma_BH);
s23   = (u21*Upsilon_AN) + (u22*Sigma_AN);
s24   = (u21*Upsilon_BN) + (u22*Sigma_BN);
s25   = (u21*Upsilon_G) + (u22*Sigma_G);

DeltaAH_1   = - s11*AH_0*(1/(nu_1+xiAH));
DeltaBH_1   = - s12*BH_0*(1/(nu_1+xiBH));
DeltaAN_1   = - s13*AN_0*(1/(nu_1+xiAN));
DeltaBN_1   = - s14*BN_0*(1/(nu_1+xiBN));
DeltaG_1    = - s15*Y_0*(1/(nu_1+xi));

DeltaAH_2   = s21*AH_0*(1/(nu_2+xiAH));
DeltaBH_2   = s22*BH_0*(1/(nu_2+xiBH));
DeltaAN_2   = s23*AN_0*(1/(nu_2+xiAN));
DeltaBN_2   = s24*BN_0*(1/(nu_2+xiBN));
DeltaG_2    = s25*Y_0*(1/(nu_2+xi));

ThetaAH_1   = (1-baraH)*((nu_1+xiAH)/(nu_1+chiAH));
ThetaAH_2   = (1-baraH)*((nu_2+xiAH)/(nu_2+chiAH));
ThetaBH_1   = (1-barbH)*((nu_1+xiBH)/(nu_1+chiBH));
ThetaBH_2   = (1-barbH)*((nu_2+xiBH)/(nu_2+chiBH));
ThetaAN_1   = (1-baraN)*((nu_1+xiAN)/(nu_1+chiAN));
ThetaAN_2   = (1-baraN)*((nu_2+xiAN)/(nu_2+chiAN));
ThetaBN_1   = (1-barbN)*((nu_1+xiBN)/(nu_1+chiBN));
ThetaBN_2   = (1-barbN)*((nu_2+xiBN)/(nu_2+chiBN));
ThetaG_1    = (1-barg)*((nu_1+xi)/(nu_1+chi));
ThetaG_2    = (1-barg)*((nu_2+xi)/(nu_2+chi));

X20 = - DeltaG_2*(1-ThetaG_2) - DeltaAH_2*(1-ThetaAH_2) - DeltaBH_2*(1-ThetaBH_2) - DeltaAN_2*(1-ThetaAN_2) - DeltaBN_2*(1-ThetaBN_2);
X10 = (K0-K) - X20;
X11 = X10 - DeltaG_1*(1-ThetaG_1) - DeltaAH_1*(1-ThetaAH_1) - DeltaBH_1*(1-ThetaBH_1) - DeltaAN_1*(1-ThetaAN_1) - DeltaBN_1*(1-ThetaBN_1);

% Intertemporal solvency condition - lambda
B_K      = (PH_K*XH) + (PH*XH_K) - MF_K;
B_Q      = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
B_G      = (PH_G*XH) + (PH*XH_G) - MF_G;
B_AH     = (PH_AH*XH) + (PH*XH_AH) - MF_AH;
B_BH     = (PH_BH*XH) + (PH*XH_BH) - MF_BH;
B_AN     = (PH_AN*XH) + (PH*XH_AN) - MF_AN;
B_BN     = (PH_BN*XH) + (PH*XH_BN) - MF_BN;

N1           = (B_K + (B_Q*omega_21));
N2           = (B_K + (B_Q*omega_22));
ThetaG_prime   = (1-barg)*((xi+r)/(chi+r));
ThetaG_1prime  = ThetaG_1*((xi+r)/(chi+r));
ThetaG_2prime  = ThetaG_2*((xi+r)/(chi+r));
ThetaAH_prime  = (1-baraH)*((xiAH+r)/(chiAH+r));
ThetaAH_1prime = ThetaAH_1*((xiAH+r)/(chiAH+r));
ThetaAH_2prime = ThetaAH_2*((xiAH+r)/(chiAH+r));
ThetaBH_prime  = (1-barbH)*((xiBH+r)/(chiBH+r));
ThetaBH_1prime = ThetaBH_1*((xiBH+r)/(chiBH+r));
ThetaBH_2prime = ThetaBH_2*((xiBH+r)/(chiBH+r));
ThetaAN_prime  = (1-baraN)*((xiAN+r)/(chiAN+r));
ThetaAN_1prime = ThetaAN_1*((xiAN+r)/(chiAN+r));
ThetaAN_2prime = ThetaAN_2*((xiAN+r)/(chiAN+r));
ThetaBN_prime  = (1-barbN)*((xiBN+r)/(chiBN+r));
ThetaBN_1prime = ThetaBN_1*((xiBN+r)/(chiBN+r));
ThetaBN_2prime = ThetaBN_2*((xiBN+r)/(chiBN+r));

wB1   = N1*X11;
wBAH2 = B_AH*AH_0*(1-ThetaAH_prime) + N1*DeltaAH_1*(1-ThetaAH_1prime) - N2*DeltaAH_2*(1-ThetaAH_2prime);
wBBH2 = B_BH*BH_0*(1-ThetaBH_prime) + N1*DeltaBH_1*(1-ThetaBH_1prime) - N2*DeltaBH_2*(1-ThetaBH_2prime);
wBAN2 = B_AN*AN_0*(1-ThetaAN_prime) + N1*DeltaAN_1*(1-ThetaAN_1prime) - N2*DeltaAN_2*(1-ThetaAN_2prime);
wBBN2 = B_BN*BN_0*(1-ThetaBN_prime) + N1*DeltaBN_1*(1-ThetaBN_1prime) - N2*DeltaBN_2*(1-ThetaBN_2prime);
wBG2  = B_G*Y_0*(1-ThetaG_prime) + N1*DeltaG_1*(1-ThetaG_1prime) - N2*DeltaG_2*(1-ThetaG_2prime);

% Solution for J = J(K,Q,AH,BH,AN,BN)
J_K       = J_1K + (J_PH*PH_K) + (J_PN*PN_K);             
J_Q       = J_1Q + (J_PH*PH_Q) + (J_PN*PN_Q);  
J_G       = (J_PH*PH_G) + (J_PN*PN_G);  
J_AH      = (J_PH*PH_AH) + (J_PN*PN_AH);                  
J_BH      = (J_PH*PH_BH) + (J_PN*PN_BH);                  
J_AN      = (J_PH*PH_AN) + (J_PN*PN_AN);                  
J_BN      = (J_PH*PH_BN) + (J_PN*PN_BN);  

% Solving for sectoral wages - Wj=Wj(K,Q,G,Aj,Bj)
WH_K = WH_2K + (WH_PH*PH_K) + (WH_PN*PN_K);                       
WH_Q = (WH_PH*PH_Q) + (WH_PN*PN_Q);                               
WH_G = (WH_PH*PH_G) + (WH_PN*PN_G);                               
WH_AH = WH_2AH + (WH_PH*PH_AH) + (WH_PN*PN_AH);                   
WH_BH = WH_2BH + (WH_PH*PH_BH) + (WH_PN*PN_BH);                   
WH_AN = WH_2AN + (WH_PH*PH_AN) + (WH_PN*PN_AN);                   
WH_BN = WH_2BN + (WH_PH*PH_BN) + (WH_PN*PN_BN);                     
                                                                  
WN_K = WN_2K + (WN_PH*PH_K) + (WN_PN*PN_K);                       
WN_Q = (WN_PH*PH_Q) + (WN_PN*PN_Q);                               
WN_G = (WN_PH*PH_G) + (WN_PN*PN_G);                               
WN_AH = WN_2AH + (WN_PH*PH_AH) + (WN_PN*PN_AH);                   
WN_BH = WN_2BH + (WN_PH*PH_BH) + (WN_PN*PN_BH);                   
WN_AN = WN_2AN + (WN_PH*PH_AN) + (WN_PN*PN_AN);                   
WN_BN = WN_2BN + (WN_PH*PH_BN) + (WN_PN*PN_BN);                   

% Solution for W as function W=W(lambda,K,Q,AH,BH,AN,BN)                      
W_K       = (W_WH*WH_K) + (W_WN*WN_K);                                          
W_Q       = (W_WH*WH_Q) + (W_WN*WN_Q);      
W_G       = (W_WH*WH_G) + (W_WN*WN_G);  
W_AH      = (W_WH*WH_AH) + (W_WN*WN_AH);                                        
W_BH      = (W_WH*WH_BH) + (W_WN*WN_BH);                                        
W_AN      = (W_WH*WH_AN) + (W_WN*WN_AN);                                        
W_BN      = (W_WH*WH_BN) + (W_WN*WN_BN);                                                                       
                                                                                
% Solution for L as function L=L(lambda,K,Q,Aj,Bj)                            
L_K  = (L_W*W_K) + (L_1PN*PN_K) + (L_1PH*PH_K);                                 
L_Q  = (L_W*W_Q) + (L_1PN*PN_Q) + (L_1PH*PH_Q);   
L_G  = (L_W*W_G) + (L_1PN*PN_G) + (L_1PH*PH_G);
L_AH = (L_W*W_AH) + (L_1PN*PN_AH) + (L_1PH*PH_AH);                              
L_BH = (L_W*W_BH) + (L_1PN*PN_BH) + (L_1PH*PH_BH);                              
L_AN = (L_W*W_AN) + (L_1PN*PN_AN) + (L_1PH*PH_AN);                              
L_BN = (L_W*W_BN) + (L_1PN*PN_BN) + (L_1PH*PH_BN);                                      

% Solution for C as function C=C(lambda,K,Q,Aj,Bj)                                        
C_K        = (C_W*W_K) + (C_1PH*PH_K) + (C_1PN*PN_K);                                     
C_Q        = (C_W*W_Q) + (C_1PH*PH_Q) + (C_1PN*PN_Q);    
C_G        = (C_W*W_G) + (C_1PH*PH_G) + (C_1PN*PN_G);   
C_AH       = (C_W*W_AH) + (C_1PH*PH_AH) + (C_1PN*PN_AH);                                  
C_BH       = (C_W*W_BH) + (C_1PH*PH_BH) + (C_1PN*PN_BH);                                  
C_AN       = (C_W*W_AN) + (C_1PH*PH_AN) + (C_1PN*PN_AN);                                  
C_BN       = (C_W*W_BN) + (C_1PH*PH_BN) + (C_1PN*PN_BN);    

WHW_K = (WH/W)*( (WH_K/WH) - (W_K/W) );           
WHW_Q = (WH/W)*( (WH_Q/WH) - (W_Q/W) );           
WHW_G = (WH/W)*( (WH_G/WH) - (W_G/W) );           
WHW_AH = (WH/W)*( (WH_AH/WH) - (W_AH/W) );        
WHW_BH = (WH/W)*( (WH_BH/WH) - (W_BH/W) );        
WHW_AN = (WH/W)*( (WH_AN/WH) - (W_AN/W) );        
WHW_BN = (WH/W)*( (WH_BN/WH) - (W_BN/W) );        
                                                  
WNW_K = (WN/W)*( (WN_K/WN) - (W_K/W) );           
WNW_Q = (WN/W)*( (WN_Q/WN) - (W_Q/W) );           
WNW_G = (WN/W)*( (WN_G/WN) - (W_G/W) );           
WNW_AH = (WN/W)*( (WN_AH/WN) - (W_AH/W) );        
WNW_BH = (WN/W)*( (WN_BH/WN) - (W_BH/W) );        
WNW_AN = (WN/W)*( (WN_AN/WN) - (W_AN/W) );        
WNW_BN = (WN/W)*( (WN_BN/WN) - (W_BN/W) );        
                                                  
Omega_K  = Omega*( (WN_K/WN) - (WH_K/WH) );       
Omega_Q  = Omega*( (WN_Q/WN) - (WH_Q/WH) );       
Omega_G  = Omega*( (WN_G/WN) - (WH_G/WH) );       
Omega_AH  = Omega*( (WN_AH/WN) - (WH_AH/WH) );    
Omega_BH  = Omega*( (WN_BH/WN) - (WH_BH/WH) );    
Omega_AN  = Omega*( (WN_AN/WN) - (WH_AN/WH) );    
Omega_BN  = Omega*( (WN_BN/WN) - (WH_BN/WH) );    

% Solution for PC=PC(PH,PN) - PC = PC(K,Q,G,Aj,Bj)
PC_K       = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K; 
PC_Q       = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_G       = (PC/PH)*alphaC*alphaH*PH_G + (PC/PN)*(1-alphaC)*PN_G;
PC_AH      = (PC/PH)*alphaC*alphaH*PH_AH + (PC/PN)*(1-alphaC)*PN_AH;
PC_BH      = (PC/PH)*alphaC*alphaH*PH_BH + (PC/PN)*(1-alphaC)*PN_BH;
PC_AN      = (PC/PH)*alphaC*alphaH*PH_AN + (PC/PN)*(1-alphaC)*PN_AN;
PC_BN      = (PC/PH)*alphaC*alphaH*PH_BN + (PC/PN)*(1-alphaC)*PN_BN;

% Solution for Wj/PC,W/PC(K,Q,G,Aj,Bj)                     
WHPC_K  = WHPC*( (WH_K/WH) - (PC_K/PC) );                  
WHPC_Q  = WHPC*( (WH_Q/WH) - (PC_Q/PC) );                  
WHPC_G  = WHPC*( (WH_G/WH) - (PC_G/PC) );                  
WHPC_AH = WHPC*( (WH_AH/WH) - (PC_AH/PC) );                
WHPC_BH = WHPC*( (WH_BH/WH) - (PC_BH/PC) );                
WHPC_AN = WHPC*( (WH_AN/WH) - (PC_AN/PC) );                
WHPC_BN = WHPC*( (WH_BN/WH) - (PC_BN/PC) );                
                                                           
WNPC_K  = WNPC*( (WN_K/WN) - (PC_K/PC) );                  
WNPC_Q  = WNPC*( (WN_Q/WN) - (PC_Q/PC) );                  
WNPC_G  = WNPC*( (WN_G/WN) - (PC_G/PC) );                  
WNPC_AH = WNPC*( (WN_AH/WN) - (PC_AH/PC) );                
WNPC_BH = WNPC*( (WN_BH/WN) - (PC_BH/PC) );                
WNPC_AN = WNPC*( (WN_AN/WN) - (PC_AN/PC) );                
WNPC_BN = WNPC*( (WN_BN/WN) - (PC_BN/PC) );                
                                                           
WPC_K  = WPC*( (W_K/W) - (PC_K/PC) );                      
WPC_Q  = WPC*( (W_Q/W) - (PC_Q/PC) );                      
WPC_G  = WPC*( (W_G/W) - (PC_G/PC) );                      
WPC_AH = WPC*( (W_AH/W) - (PC_AH/PC) );                    
WPC_BH = WPC*( (W_BH/W) - (PC_BH/PC) );                    
WPC_AN = WPC*( (W_AN/W) - (PC_AN/PC) );                    
WPC_BN = WPC*( (W_BN/W) - (PC_BN/PC) );                    

% Solution for PI=PI(PH,PN) - PI = PI(K,Q,G,Aj,Bj)
PI_K       = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K; 
PI_Q       = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_G       = (PI/PH)*alphaI*alphaIH*PH_G + (PI/PN)*(1-alphaI)*PN_G;  
PI_AH      = (PI/PH)*alphaI*alphaIH*PH_AH + (PI/PN)*(1-alphaI)*PN_AH;
PI_BH      = (PI/PH)*alphaI*alphaIH*PH_BH + (PI/PN)*(1-alphaI)*PN_BH;
PI_AN      = (PI/PH)*alphaI*alphaIH*PH_AN + (PI/PN)*(1-alphaI)*PN_AN;
PI_BN      = (PI/PH)*alphaI*alphaIH*PH_BN + (PI/PN)*(1-alphaI)*PN_BN;

% Solution for GE=PH*GH + PN*GN + GF - G = G(K,Q,G,Aj,Bj)
G_K        = (PH_K*GH) + (PN_K*GN); 
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_G        = (PH_G*GH) + (PN_G*GN) + (PH*GH_G) + (PN*GN_G); %+ GF_G;   
G_AH       = (PH_AH*GH) + (PN_AH*GN);
G_BH       = (PH_BH*GH) + (PN_BH*GN);
G_AN       = (PH_AN*GH) + (PN_AN*GN);
G_BN       = (PH_BN*GH) + (PN_BN*GN);

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(K,Q,G,Aj,Bj); 
P_K  = (P/PN)*PN_K - (P/PH)*PH_K; 
P_Q  = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_G  = (P/PN)*PN_G - (P/PH)*PH_G; 
P_AH = (P/PN)*PN_AH - (P/PH)*PH_AH;
P_BH = (P/PN)*PN_BH - (P/PH)*PH_BH;
P_AN = (P/PN)*PN_AN - (P/PH)*PH_AN;
P_BN = (P/PN)*PN_BN - (P/PH)*PH_BN;

% Solution for Y as function Y=Y(K,Q,lambda,GH,GN) 
Y_K       = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K); 
Y_Q       = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_G       = (PH_G*YH) + (PH*YH_G) + (PN_G*YN) + (PN*YN_G);
Y_AH      = (PH_AH*YH) + (PH*YH_AH) + (PN_AH*YN) + (PN*YN_AH);
Y_BH      = (PH_BH*YH) + (PH*YH_BH) + (PN_BH*YN) + (PN*YN_BH);
Y_AN      = (PH_AN*YH) + (PH*YH_AN) + (PN_AN*YN) + (PN*YN_AN);
Y_BN      = (PH_BN*YH) + (PH*YH_BN) + (PN_BN*YN) + (PN*YN_BN);

% Solution for Real GDP as function YR=YR(K,Q,lambda,GH,GN)
YR_K   = (PH_0*YH_K) + (PN_0*YN_K);                            
YR_Q   = (PH_0*YH_Q) + (PN_0*YN_Q);
YR_G   = (PH_0*YH_G) + (PN_0*YN_G); 
YR_AH  = (PH_0*YH_AH) + (PN_0*YN_AH);
YR_BH  = (PH_0*YH_BH) + (PN_0*YN_BH);
YR_AN  = (PH_0*YH_AN) + (PN_0*YN_AN);
YR_BN  = (PH_0*YH_BN) + (PN_0*YN_BN);

% Solution for the stock of financial wealth
A_K       = ((WH_K*LH)+(WN_K*LN))+((WH*LH_K)+(WN*LN_K))-G_K-((PC_K*C)+(PC*C_K));                  
A_Q       = ((WH_Q*LH)+(WN_Q*LN))+((WH*LH_Q)+(WN*LN_Q))-G_Q-((PC_Q*C)+(PC*C_Q));                  
A_G       = ((WH_G*LH)+(WN_G*LN))+((WH*LH_G)+(WN*LN_G))-G_G-((PC_G*C)+(PC*C_G));                  
A_AH      = ((WH_AH*LH)+(WN_AH*LN))+((WH*LH_AH)+(WN*LN_AH))-G_AH-((PC_AH*C)+(PC*C_AH));           
A_BH      = ((WH_BH*LH)+(WN_BH*LN))+((WH*LH_BH)+(WN*LN_BH))-G_BH-((PC_BH*C)+(PC*C_BH));           
A_AN      = ((WH_AN*LH)+(WN_AN*LN))+((WH*LH_AN)+(WN*LN_AN))-G_AN-((PC_AN*C)+(PC*C_AN));           
A_BN      = ((WH_BN*LH)+(WN_BN*LN))+((WH*LH_BN)+(WN*LN_BN))-G_BN-((PC_BN*C)+(PC*C_BN));           

M1        = A_K + (A_Q*omega_21);
M2        = A_K + (A_Q*omega_22);

wA1   = M1*X11;
wAAH2 = A_AH*AH_0*(1-ThetaAH_prime) + M1*DeltaAH_1*(1-ThetaAH_1prime) + M2*DeltaAH_2*(1-ThetaAH_2prime);
wABH2 = A_BH*BH_0*(1-ThetaBH_prime) + M1*DeltaBH_1*(1-ThetaBH_1prime) + M2*DeltaBH_2*(1-ThetaBH_2prime);
wAAN2 = A_AN*AN_0*(1-ThetaAN_prime) + M1*DeltaAN_1*(1-ThetaAN_1prime) + M2*DeltaAN_2*(1-ThetaAN_2prime);
wABN2 = A_BN*BN_0*(1-ThetaBN_prime) + M1*DeltaBN_1*(1-ThetaBN_1prime) + M2*DeltaBN_2*(1-ThetaBN_2prime);
wAG2  = A_G*Y_0*omegaG_0*(1-ThetaG_prime) + M1*DeltaG_1*(1-ThetaG_1prime) - M2*DeltaG_2*(1-ThetaG_2prime);

dA_biassym = (wA1/(r-nu_1)) + (wAG2/(xi+r)) + (wAAH2/(xiAH+r)) + (wABH2/(xiBH+r)) + (wAAN2/(xiAN+r)) + (wABN2/(xiBN+r));

% RjPj=Rj/Pj=Rj(K,Q,G,Aj,Bj);                            
RHPH_K  = (RH/PH)*((RH_K/RK) - (PH_K/PH));               
RHPH_Q  = (RH/PH)*((RH_Q/RK) - (PH_Q/PH));               
RHPH_G  = (RH/PH)*((RH_G/RK) - (PH_G/PH));               
RHPH_AH = (RH/PH)*((RH_AH/RK) - (PH_AH/PH));             
RHPH_BH = (RH/PH)*((RH_BH/RK) - (PH_BH/PH));             
RHPH_AN = (RH/PH)*((RH_AN/RK) - (PH_AN/PH));             
RHPH_BN = (RH/PH)*((RH_BN/RK) - (PH_BN/PH));             
                                                         
RNPN_K  = (RN/PN)*((RN_K/RK) - (PN_K/PN));               
RNPN_Q  = (RN/PN)*((RN_Q/RK) - (PN_Q/PN));               
RNPN_G  = (RN/PN)*((RN_G/RK) - (PN_G/PN));               
RNPN_AH = (RN/PN)*((RN_AH/RK) - (PN_AH/PN));             
RNPN_BH = (RN/PN)*((RN_BH/RK) - (PN_BH/PN));             
RNPN_AN = (RN/PN)*((RN_AN/RK) - (PN_AN/PN));             
RNPN_BN = (RN/PN)*((RN_BN/RK) - (PN_BN/PN));                                           

% Solution for the labor income share sLj=LISj(K,Q,G,Aj,Bj)=Wj*Lj/Pj*Yj                                        
LISH_K  = sLH*( (WH_K/WH) + (LH_K/LH) - (PH_K/PH) - (YH_K/YH) );                                               
LISH_Q  = sLH*( (WH_Q/WH) + (LH_Q/LH) - (PH_Q/PH) - (YH_Q/YH) );                                               
LISH_G  = sLH*( (WH_G/WH) + (LH_G/LH) - (PH_G/PH) - (YH_G/YH) );                                               
LISH_AH = sLH*( (WH_AH/WH) + (LH_AH/LH) - (PH_AH/PH) - (YH_AH/YH) );                                           
LISH_BH = sLH*( (WH_BH/WH) + (LH_BH/LH) - (PH_BH/PH) - (YH_BH/YH) );                                           
LISH_AN = sLH*( (WH_AN/WH) + (LH_AN/LH) - (PH_AN/PH) - (YH_AN/YH) );                                           
LISH_BN = sLH*( (WH_BN/WH) + (LH_BN/LH) - (PH_BN/PH) - (YH_BN/YH) );                                           
                                                                                                               
LISN_K  = sLN*( (WN_K/WN) + (LN_K/LN) - (PN_K/PN) - (YN_K/YN) );                                               
LISN_Q  = sLN*( (WN_Q/WN) + (LN_Q/LN) - (PN_Q/PN) - (YN_Q/YN) );                                               
LISN_G  = sLN*( (WN_G/WN) + (LN_G/LN) - (PN_G/PN) - (YN_G/YN) );                                               
LISN_AH = sLN*( (WN_AH/WN) + (LN_AH/LN) - (PN_AH/PN) - (YN_AH/YN) );                                           
LISN_BH = sLN*( (WN_BH/WN) + (LN_BH/LN) - (PN_BH/PN) - (YN_BH/YN) );                                           
LISN_AN = sLN*( (WN_AN/WN) + (LN_AN/LN) - (PN_AN/PN) - (YN_AN/YN) );                                           
LISN_BN = sLN*( (WN_BN/WN) + (LN_BN/LN) - (PN_BN/PN) - (YN_BN/YN) );                                           
                                                                                                               
% Solution for LH(K,Q,G,Aj,Bj)/LN(K,Q,G,Aj,Bj)                                                                 
LHLN_K = (LH/LN)*( (LH_K/LH) - (LN_K/LN) );                                                                    
LHLN_Q = (LH/LN)*( (LH_Q/LH) - (LN_Q/LN) );                                                                    
LHLN_G = (LH/LN)*( (LH_G/LH) - (LN_G/LN) );                                                                    
LHLN_AH = (LH/LN)*( (LH_AH/LH) - (LN_AH/LN) );                                                                 
LHLN_BH = (LH/LN)*( (LH_BH/LH) - (LN_BH/LN) );                                                                 
LHLN_AN = (LH/LN)*( (LH_AN/LH) - (LN_AN/LN) );                                                                 
LHLN_BN = (LH/LN)*( (LH_BN/LH) - (LN_BN/LN) );                                                                 
                                                                                                               
% Solution for YH(K,Q,G,Aj,Bj)/YN(K,Q,G,Aj,Bj)                                                                 
YHYN_K = (YH/YN)*( (YH_K/YH) - (YN_K/YN) );                                                                    
YHYN_Q = (YH/YN)*( (YH_Q/YH) - (YN_Q/YN) );                                                                    
YHYN_G = (YH/YN)*( (YH_G/YH) - (YN_G/YN) );                                                                    
YHYN_AH = (YH/YN)*( (YH_AH/YH) - (YN_AH/YN) );                                                                 
YHYN_BH = (YH/YN)*( (YH_BH/YH) - (YN_BH/YN) );                                                                 
YHYN_AN = (YH/YN)*( (YH_AN/YH) - (YN_AN/YN) );                                                                 
YHYN_BN = (YH/YN)*( (YH_BN/YH) - (YN_BN/YN) );                                                                 
                                                                                                               
% Solutions for the employment shares Lj/L=(Lj/L)(K,Q,G,Aj,Bj)                                                 
LHS_K  = (LH/L)*((LH_K/LH)-(L_K/L));                                                                           
LHS_Q  = (LH/L)*((LH_Q/LH)-(L_Q/L));                                                                           
LHS_G  = (LH/L)*((LH_G/LH)-(L_G/L));                                                                           
LHS_AH  = (LH/L)*((LH_AH/LH)-(L_AH/L));                                                                        
LHS_BH  = (LH/L)*((LH_BH/LH)-(L_BH/L));                                                                        
LHS_AN  = (LH/L)*((LH_AN/LH)-(L_AN/L));                                                                        
LHS_BN  = (LH/L)*((LH_BN/LH)-(L_BN/L));                                                                        
                                                                                                               
LNS_K  = (LN/L)*((LN_K/LN)-(L_K/L));                                                                           
LNS_Q  = (LN/L)*((LN_Q/LN)-(L_Q/L));                                                                           
LNS_G  = (LN/L)*((LN_G/LN)-(L_G/L));                                                                           
LNS_AH  = (LN/L)*((LN_AH/LN)-(L_AH/L));                                                                        
LNS_BH  = (LN/L)*((LN_BH/LN)-(L_BH/L));                                                                        
LNS_AN  = (LN/L)*((LN_AN/LN)-(L_AN/L));                                                                        
LNS_BN  = (LN/L)*((LN_BN/LN)-(L_BN/L));                                                                        
                                                                                                               
% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(K,Q,G,Aj,Bj)                                            
YHS_K  = (YH/YR)*( (YH_K/YH) - (YR_K/YR) );                                                                    
YHS_Q  = (YH/YR)*( (YH_Q/YH) - (YR_Q/YR) );                                                                    
YHS_G  = (YH/YR)*( (YH_G/YH) - (YR_G/YR) );                                                                    
YHS_AH  = (YH/YR)*( (YH_AH/YH) - (YR_AH/YR) );                                                                 
YHS_BH  = (YH/YR)*( (YH_BH/YH) - (YR_BH/YR) );                                                                 
YHS_AN  = (YH/YR)*( (YH_AN/YH) - (YR_AN/YR) );                                                                 
YHS_BN  = (YH/YR)*( (YH_BN/YH) - (YR_BN/YR) );                                                                 
                                                                                                               
YNS_K  = (YN/YR)*( (YN_K/YN) - (YR_K/YR) );                                                                    
YNS_Q  = (YN/YR)*( (YN_Q/YN) - (YR_Q/YR) );                                                                    
YNS_G  = (YN/YR)*( (YN_G/YN) - (YR_G/YR) );                                                                    
YNS_AH  = (YN/YR)*( (YN_AH/YN) - (YR_AH/YR) );                                                                 
YNS_BH  = (YN/YR)*( (YN_BH/YN) - (YR_BH/YR) );                                                                 
YNS_AN  = (YN/YR)*( (YN_AN/YN) - (YR_AN/YR) );                                                                 
YNS_BN  = (YN/YR)*( (YN_BN/YN) - (YR_BN/YR) );                                                                 
                                                                                                               
% Solutions for the Kj/K: Kj/K=Kj/K(lambda,K,Q,AH,BH,AN,BN)                                                    
KHK_K  = (KH/K)*( (KH_K/KH) - (1/K) );                                                                         
KHK_Q  = (KH/K)*(KH_Q/KH);                                                                                     
KHK_G  = (KH/K)*(KH_G/KH);                                                                                     
KHK_AH = (KH/K)*(KH_AH/KH);                                                                                    
KHK_BH = (KH/K)*(KH_BH/KH);                                                                                    
KHK_AN = (KH/K)*(KH_AN/KH);                                                                                    
KHK_BN = (KH/K)*(KH_BN/KH);                                                                                    
                                                                                                               
KNK_K  = (KN/K)*( (KN_K/KN) - (1/K) );                                                                         
KNK_Q  = (KN/K)*(KN_Q/KN);                                                                                     
KNK_G  = (KN/K)*(KN_G/KN);                                                                                     
KNK_AH = (KN/K)*(KN_AH/KN);                                                                                    
KNK_BH = (KN/K)*(KN_BH/KN);                                                                                    
KNK_AN = (KN/K)*(KN_AN/KN);                                                                                    
KNK_BN = (KN/K)*(KN_BN/KN);  

% Solution for RK as function RK=R(lambda,K,Q,G,AH,BH,AN,BN)          
R_K       = (R_RH*RH_K) + (R_RN*RN_K);                                
R_Q       = (R_RH*RH_Q) + (R_RN*RN_Q);                                
R_G       = (R_RH*RH_G) + (R_RN*RN_G);                                
R_AH      = (R_RH*RH_AH) + (R_RN*RN_AH);                              
R_BH      = (R_RH*RH_BH) + (R_RN*RN_BH);                              
R_AN      = (R_RH*RH_AN) + (R_RN*RN_AN);                              
R_BN      = (R_RH*RH_BN) + (R_RN*RN_BN);                              
R_lambda  = (R_RH*RH_lambda) + (R_RN*RN_lambda);                      

% Solutions for the kj=Kj/Lj(lambda,K,Q,AH,BH,AN,BN)                 
kH_K   = (KH/LH)*( (KH_K/KH) - (LH_K/LH) );          
kH_Q   = (KH/LH)*( (KH_Q/KH) - (LH_Q/LH) );          
kH_G   = (KH/LH)*( (KH_G/KH) - (LH_G/LH) );          
kH_AH  = (KH/LH)*( (KH_AH/KH) - (LH_AH/LH) );      
kH_BH  = (KH/LH)*( (KH_BH/KH) - (LH_BH/LH) );        
kH_AN  = (KH/LH)*( (KH_AN/KH) - (LH_AN/LH) );        
kH_BN  = (KH/LH)*( (KH_BN/KH) - (LH_BN/LH) );                      
                                                                     
kN_K  = (KN/LN)*( (KN_K/KN) - (LN_K/LN) );                           
kN_Q  = (KN/LN)*( (KN_Q/KN) - (LN_Q/LN) );                           
kN_G  = (KN/LN)*( (KN_G/KN) - (LN_G/LN) );                           
kN_AH = (KN/LN)*( (KN_AH/KN) - (LN_AH/LN) );                         
kN_BH = (KN/LN)*( (KN_BH/KN) - (LN_BH/LN) );                         
kN_AN = (KN/LN)*( (KN_AN/KN) - (LN_AN/LN) );                         
kN_BN = (KN/LN)*( (KN_BN/KN) - (LN_BN/LN) );                         
                                                                                                               
% Solutions for the alphaKj=Rj*Kj/RK*K(lambda,K,Q,G,AH,BH,AN,BN)                          
alphaKH_K  = alphaK*( (RH_K/RH)  + (KH_K/KH)  - (R_K/RK)  - (1/K) );                      
alphaKH_Q  = alphaK*( (RH_Q/RH)  + (KH_Q/KH)  - (R_Q/RK)  );                              
alphaKH_G  = alphaK*( (RH_G/RH)  + (KH_G/KH)  - (R_G/RK)  );                              
alphaKH_AH = alphaK*( (RH_AH/RH) + (KH_AH/KH) - (R_AH/RK) );                              
alphaKH_BH = alphaK*( (RH_BH/RH) + (KH_BH/KH) - (R_BH/RK) );                              
alphaKH_AN = alphaK*( (RH_AN/RH) + (KH_AN/KH) - (R_AN/RK) );                              
alphaKH_BN = alphaK*( (RH_BN/RH) + (KH_BN/KH) - (R_BN/RK) );                              
                                                                                          
alphaKN_K  = (1-alphaK)*( (RN_K/RN)  + (KN_K/KN)  - (R_K/RK)  - (1/K) );                  
alphaKN_Q  = (1-alphaK)*( (RN_Q/RN)  + (KN_Q/KN)  - (R_Q/RK)  );                          
alphaKN_G  = (1-alphaK)*( (RN_G/RN)  + (KN_G/KN)  - (R_G/RK)  );                          
alphaKN_AH = (1-alphaK)*( (RN_AH/RN) + (KN_AH/KN) - (R_AH/RK) );                          
alphaKN_BH = (1-alphaK)*( (RN_BH/RN) + (KN_BH/KN) - (R_BH/RK) );                          
alphaKN_AN = (1-alphaK)*( (RN_AN/RN) + (KN_AN/KN) - (R_AN/RK) );                          
alphaKN_BN = (1-alphaK)*( (RN_BN/RN) + (KN_BN/KN) - (R_BN/RK) );                                                                
                                                                                                               
% Aggregate capital utilization rate uK = (alphaK*uKH) + (1-alphaK)*uKN                                                                                                                                                     
uK_K   = alphaKH_K  + alphaKN_K  + (alphaK*uKH_K)  + (1-alphaK)*uKN_K;                                         
uK_Q   = alphaKH_Q  + alphaKN_Q  + (alphaK*uKH_Q)  + (1-alphaK)*uKN_Q;                                         
uK_G   = alphaKH_G  + alphaKN_G  + (alphaK*uKH_G)  + (1-alphaK)*uKN_G;                                         
uK_AH  = alphaKH_AH + alphaKN_AH + (alphaK*uKH_AH) + (1-alphaK)*uKN_AH;                                        
uK_BH  = alphaKH_BH + alphaKN_BH + (alphaK*uKH_BH) + (1-alphaK)*uKN_BH;                                        
uK_AN  = alphaKH_AN + alphaKN_AN + (alphaK*uKH_AN) + (1-alphaK)*uKN_AN;                                        
uK_BN  = alphaKH_BN + alphaKN_BN + (alphaK*uKH_BN) + (1-alphaK)*uKN_BN;                                        
                                                                                                               
% Solutions TFPj(K,Q,G,Aj,Bj);                                                                                 
TFPH_K      = (ZH/YH)*YH_K  - sLH*(ZH/LH)*LH_K  - (1-sLH)*(ZH/KH)*KH_K;                                        
TFPH_Q      = (ZH/YH)*YH_Q  - sLH*(ZH/LH)*LH_Q  - (1-sLH)*(ZH/KH)*KH_Q;                                        
TFPH_G      = (ZH/YH)*YH_G  - sLH*(ZH/LH)*LH_G  - (1-sLH)*(ZH/KH)*KH_G;                                        
TFPH_AH     = (ZH/YH)*YH_AH - sLH*(ZH/LH)*LH_AH - (1-sLH)*(ZH/KH)*KH_AH;                                       
TFPH_BH     = (ZH/YH)*YH_BH - sLH*(ZH/LH)*LH_BH - (1-sLH)*(ZH/KH)*KH_BH;                                       
TFPH_AN     = (ZH/YH)*YH_AN - sLH*(ZH/LH)*LH_AN - (1-sLH)*(ZH/KH)*KH_AN;                                       
TFPH_BN     = (ZH/YH)*YH_BN - sLH*(ZH/LH)*LH_BN - (1-sLH)*(ZH/KH)*KH_BN;                                       
                                                                                                               
TFPN_K      = (ZN/YN)*YN_K  - sLN*(ZN/LN)*LN_K  - (1-sLN)*(ZN/KN)*KN_K;                                        
TFPN_Q      = (ZN/YN)*YN_Q  - sLN*(ZN/LN)*LN_Q  - (1-sLN)*(ZN/KN)*KN_Q;                                        
TFPN_G      = (ZN/YN)*YN_G  - sLN*(ZN/LN)*LN_G  - (1-sLN)*(ZN/KN)*KN_G;                                        
TFPN_AH     = (ZN/YN)*YN_AH - sLN*(ZN/LN)*LN_AH - (1-sLN)*(ZN/KN)*KN_AH;                                       
TFPN_BH     = (ZN/YN)*YN_BH - sLN*(ZN/LN)*LN_BH - (1-sLN)*(ZN/KN)*KN_BH;                                       
TFPN_AN     = (ZN/YN)*YN_AN - sLN*(ZN/LN)*LN_AN - (1-sLN)*(ZN/KN)*KN_AN;                                       
TFPN_BN     = (ZN/YN)*YN_BN - sLN*(ZN/LN)*LN_BN - (1-sLN)*(ZN/KN)*KN_BN;                                       
                                                                                                               
TFP_K      =  omegaYH*(Z/ZH)*TFPH_K + (1-omegaYH)*(Z/ZN)*TFPN_K;                                               
TFP_Q      =  omegaYH*(Z/ZH)*TFPH_Q + (1-omegaYH)*(Z/ZN)*TFPN_Q;                                               
TFP_G      =  omegaYH*(Z/ZH)*TFPH_G + (1-omegaYH)*(Z/ZN)*TFPN_G;                                               
TFP_AH     =  omegaYH*(Z/ZH)*TFPH_AH + (1-omegaYH)*(Z/ZN)*TFPN_AH;                                             
TFP_BH     =  omegaYH*(Z/ZH)*TFPH_BH + (1-omegaYH)*(Z/ZN)*TFPN_BH;                                             
TFP_AN     =  omegaYH*(Z/ZH)*TFPH_AN + (1-omegaYH)*(Z/ZN)*TFPN_AN;                                             
TFP_BN     =  omegaYH*(Z/ZH)*TFPH_BN + (1-omegaYH)*(Z/ZN)*TFPN_BN;                                             
                                                                                                               
TFPH_K_check      = (1-sLH)*ZH*uKH_K;                                                                          
TFPH_Q_check      = (1-sLH)*ZH*uKH_Q;                                                                          
TFPH_G_check      = (1-sLH)*ZH*uKH_G;                                                                          
TFPH_AH_check     = sLH*(ZH/AH) + (1-sLH)*ZH*uKH_AH;                                                           
TFPH_BH_check     = (1-sLH)*ZH*( (1/BH) + uKH_BH);                                                             
TFPH_AN_check     = (1-sLH)*ZH*uKH_AN;                                                                         
TFPH_BN_check     = (1-sLH)*ZH*uKH_BN;                                                                         
                                                                                                               
TFPN_K_check      =  (1-sLN)*ZN*uKN_K;                                                                         
TFPN_Q_check      =  (1-sLN)*ZN*uKN_Q;                                                                         
TFPN_G_check      =  (1-sLN)*ZN*uKN_G;                                                                         
TFPN_AH_check     =  (1-sLN)*ZN*uKN_AH;                                                                        
TFPN_BH_check     =  (1-sLN)*ZN*uKN_BH;                                                                        
TFPN_AN_check     =  sLN*(ZN/AN) + (1-sLN)*ZN*uKN_AN;                                                          
TFPN_BN_check     =  (1-sLN)*ZN*( (1/BN) + uKN_BN);                                                            
                                                                                                               
% Ratio of traded to non-traded TFP                                                                            
TFPR_K  = (ZH/ZN)*( (TFPH_K/ZH) - (TFPN_K/ZN) );                                                               
TFPR_Q  = (ZH/ZN)*( (TFPH_Q/ZH) - (TFPN_Q/ZN) );                                                               
TFPR_G  = (ZH/ZN)*( (TFPH_G/ZH) - (TFPN_G/ZN) );                                                               
TFPR_AH = (ZH/ZN)*( (TFPH_AH/ZH) - (TFPN_AH/ZN) );                                                             
TFPR_BH = (ZH/ZN)*( (TFPH_BH/ZH) - (TFPN_BH/ZN) );                                                             
TFPR_AN = (ZH/ZN)*( (TFPH_AN/ZH) - (TFPN_AN/ZN) );                                                             
TFPR_BN = (ZH/ZN)*( (TFPH_BN/ZH) - (TFPN_BN/ZN) );                                                             

% Aggregate capital-labor ratio k = K/L          
k_K  =  (K/L)*( (1/K) - (L_K/L) );               
k_Q  = -(K/L)*(L_Q/L);                           
k_G  = -(K/L)*(L_G/L);                           
k_AH = -(K/L)*(L_AH/L);                          
k_BH = -(K/L)*(L_BH/L);                          
k_AN = -(K/L)*(L_AN/L);                          
k_BN = -(K/L)*(L_BN/L);                          

% Aggregate LIS                                                              
LIS_K  = sL*( (W_K/W) + (L_K/L)  - (Y_K/Y) );                                
LIS_Q  = sL*( (W_Q/W) + (L_Q/L)  - (Y_Q/Y) );                                
LIS_G  = sL*( (W_G/W) + (L_G/L)  - (Y_G/Y) );                                
LIS_AH = sL*( (W_AH/W) + (L_AH/L) - (Y_AH/Y) );                              
LIS_BH = sL*( (W_BH/W) + (L_BH/L) - (Y_BH/Y) );                              
LIS_AN = sL*( (W_AN/W) + (L_AN/L) - (Y_AN/Y) );                              
LIS_BN = sL*( (W_BN/W) + (L_BN/L) - (Y_BN/Y) );                              
                                                                             
% Output share of non-tradables at current prices                            
omegaYN_K  = omegaYN*( (PN_K/PN) + (YN_K/YN) - (Y_K/Y) );                    
omegaYN_Q  = omegaYN*( (PN_Q/PN) + (YN_Q/YN) - (Y_Q/Y) );                    
omegaYN_G  = omegaYN*( (PN_G/PN) + (YN_G/YN) - (Y_G/Y) );                    
omegaYN_AH = omegaYN*( (PN_AH/PN) + (YN_AH/YN) - (Y_AH/Y) );                 
omegaYN_BH = omegaYN*( (PN_BH/PN) + (YN_BH/YN) - (Y_BH/Y) );                 
omegaYN_AN = omegaYN*( (PN_AN/PN) + (YN_AN/YN) - (Y_AN/Y) );                 
omegaYN_BN = omegaYN*( (PN_BN/PN) + (YN_BN/YN) - (Y_BN/Y) );                 
                                                                             
tildeKH_K  = KH_K + (KH*uKH_K);                                              
tildeKH_Q  = KH_Q + (KH*uKH_Q);                                              
tildeKH_G  = KH_G + (KH*uKH_G);                                              
tildeKH_AH = KH_AH + (KH*uKH_AH);                                            
tildeKH_BH = KH_BH + (KH*uKH_BH);                                            
tildeKH_AN = KH_AN + (KH*uKH_AN);                                            
tildeKH_BN = KH_BN + (KH*uKH_BN);                                            
                                                                             
tildeKN_K  = KN_K + (KN*uKN_K);                                              
tildeKN_Q  = KN_Q + (KN*uKN_Q);                                              
tildeKN_G  = KN_G + (KN*uKN_G);                                              
tildeKN_AH = KN_AH + (KN*uKN_AH);                                            
tildeKN_BH = KN_BH + (KN*uKN_BH);                                            
tildeKN_AN = KN_AN + (KN*uKN_AN);                                            
tildeKN_BN = KN_BN + (KN*uKN_BN);                                            
                                                                             
tildekH_K  = kH*( (tildeKH_K/KH) - (LH_K/LH) );                              
tildekH_Q  = kH*( (tildeKH_Q/KH) - (LH_Q/LH) );                              
tildekH_G  = kH*( (tildeKH_G/KH) - (LH_G/LH) );                              
tildekH_AH = kH*( (tildeKH_AH/KH) - (LH_AH/LH) );                            
tildekH_BH = kH*( (tildeKH_BH/KH) - (LH_BH/LH) );                            
tildekH_AN = kH*( (tildeKH_AN/KH) - (LH_AN/LH) );                            
tildekH_BN = kH*( (tildeKH_BN/KH) - (LH_BN/LH) );                            
                                                                             
tildekN_K  = kN*( (tildeKN_K/KN) - (LN_K/LN) );                              
tildekN_Q  = kN*( (tildeKN_Q/KN) - (LN_Q/LN) );                              
tildekN_G  = kN*( (tildeKN_G/KN) - (LN_G/LN) );                              
tildekN_AH = kN*( (tildeKN_AH/KN) - (LN_AH/LN) );                            
tildekN_BH = kN*( (tildeKN_BH/KN) - (LN_BH/LN) );                            
tildekN_AN = kN*( (tildeKN_AN/KN) - (LN_AN/LN) );                            
tildekN_BN = kN*( (tildeKN_BN/KN) - (LN_BN/LN) );                             

% Solution for NX = NX(K,Q,AH,BH,AN,BN)          
NX_K          = (PH_K*XH) + (PH*XH_K) - MF_K;    
NX_Q          = (PH_Q*XH) + (PH*XH_Q) - MF_Q;    
NX_G          = (PH_G*XH) + (PH*XH_G) - MF_G;  
NX_AH         = (PH_AH*XH) + (PH*XH_AH) - MF_AH; 
NX_BH         = (PH_BH*XH) + (PH*XH_BH) - MF_BH; 
NX_AN         = (PH_AN*XH) + (PH*XH_AN) - MF_AN; 
NX_BN         = (PH_BN*XH) + (PH*XH_BN) - MF_BN; 

% Solution for Q/PI(H,PN))             
QPI_K  = - (PI_K/PI);                  
QPI_Q  = (1/PI) - (PI_Q/PI);           
QPI_G  = - (PI_G/PI);                  
QPI_AH = - (PI_AH/PI);                 
QPI_BH = - (PI_BH/PI);                 
QPI_AN = - (PI_AN/PI);                 
QPI_BN = - (PI_BN/PI);                          

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% Aggregator function for L=L(LH,LN)
VLAB    = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = VLAB^(epsilon/(epsilon+1)); 
L_LH    = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_LN    = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Aggregator function for K=K(KH,KN)                                                                                                      
VCAP    = ( (varthetaK^(-1/epsilonK))*(KH^((epsilonK+1)/epsilonK)) + ((1-varthetaK)^(-1/epsilonK))*(KN^((epsilonK+1)/epsilonK)) );        
K_check = VCAP^(epsilonK/(epsilonK+1));                                                                                                   
K_KH    = ((varthetaK)^(-1/epsilonK))*(KH/K)^(1/epsilonK);                                                                                
K_KN    = ((1-varthetaK)^(-1/epsilonK))*(KN/K)^(1/epsilonK);   

% Investment 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));   
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF; 
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real return on inputs 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;
RHPH = RH/PH;
RNPN = RN/PN;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);
                                                                         
% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH = IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    = (GH+PN*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Confirmation
% Check the closure of the model                                                                                                         
cond1  = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH))-RH;                                                                 
cond2  = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN))-RN;                                                                
cond3  = PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH))-WH;                                                                          
cond4  = PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN))-WN;                                                                          
cond5  = (RH*KH)+(RN*KN)-(RK*K);                                                                                                         
cond6  = RK-(deltaK+r)*PI;                                                                                                               
cond7  = YN-CN-GN-IN;                                                                                                                    
cond8  = YH-CH-GH-IH-XH;                                                                                                                 
cond9  = (B-B0)-( (wB1/(r-nu_1)) + (wBG2/(xi+r)) + (wBAH2/(xiAH+r)) + (wBBH2/(xiBH+r)) + (wBAN2/(xiAN+r)) + (wBBN2/(xiBN+r)) );          
cond10 = DetJ - (nu_1*nu_2);                                                                                                               
cond11 = TrJ - (nu_1+nu_2);                                                                                                                
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);                                                                             
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);                                                                                    
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                                                                                     
cond15 = (W*L) - ((WH*LH)+(WN*LN));                                                                                                      
cond16 = -U_L*L_LH - (lambda*WH);                                                                                                        
cond17 = -U_L*L_LN - (lambda*WN);                                                                                                        
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                                                                                                
cond19 = Sav;                                                                                                                            
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                                                                                  
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);                                                                                      
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                                                                                    
cond23 = (RK*K) - ((RH*KH)+(RN*KN));                                                                                                   
cond24 = 1 - (omegaK + omegaL);                                                                                                          
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);                                                                                    
cond26 = (PT*CT) - ((PH*CH)+CF);                                                                                                         
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);                                                                                       
cond28 = (PIT*IT) - ((PH*IH)+IF);                                                                                                        
cond29 = r*B + (PH*XH) - MF;                                                                                                             
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I);                                                                                     
cond31 = K_KH - (RH/RK);                                                            
cond32 = K_KN - (RN/RK);                                                            
cond33 = (KH/KN) - (varthetaK/(1-varthetaK))*(RH/RN)^(epsilonK);    
cond34 = PN - MN;
cond35 = PH - MH;
                                                                                                                                          
% Define New steady-state values
kH_biassym = kH; kN_biassym = kN; PN_biassym = PN; K_biassym = K; C_biassym = C;  
L_biassym  = L; W_biassym = W; P_biassym = P; 
YH_biassym = YH; YN_biassym = YN; Y_biassym = Y; G_biassym = G;     
PC_biassym = PC; CN_biassym = CN; CH_biassym = CH;  
GH_biassym = GH; GN_biassym = GN; ZH_biassym = ZH; ZN_biassym = ZN; Z_biassym = Z; 
AH_biassym = AH; BH_biassym = BH; AN_biassym = AN; BN_biassym = BN;
LH_biassym = LH; LN_biassym = LN; KH_biassym = KH; KN_biassym = KN; WH_biassym = WH; WN_biassym = WN; 
Omega_biassym = Omega; WPC_biassym = WPC; WHPC_biassym = WHPC; WNPC_biassym = WNPC;
IF_biassym = IF; CF_biassym = CF; XH_biassym = XH; MF_biassym = MF; GF_biassym = GF; PH_biassym = PH; 
PT_biassym = PT; PIT_biassym = PIT; CT_biassym = CT; IT_biassym = IT; GT_biassym = GT; 

YHYN_biassym = YHYN; LHLN_biassym = LHLN; IH_biassym = IH; IN_biassym = IN; PI_biassym = PI; 
EI_biassym = EI; CA_biassym = CA; Sav_biassym = Sav; NX_biassym = NX; I_biassym = I; A_biassym = A; 
B_biassym = B; lambda_biassym  = lambda; RK_biassym = RK; YR_biassym = YR; 
yH_biassym = yH; yN_biassym = yN; 

omegaL_biassym = omegaL; omegaK_biassym = omegaK; omegaI_biassym = omegaI; omegaINYN_biassym = omegaINYN;
omegaIHYH_biassym = omegaIHYH; omega_IFYH_biassym = omegaIFYH; omegaGHYH_biassym = omegaGHYH; 
omegaGFYH_biassym = omegaGFYH; omegaGNYN_biassym = omegaGNYN; omegaGN_biassym = omegaGN;
omegaYH_biassym = omegaYH; omegaYN_biassym = omegaYN; omegaLH_biassym = omegaLH; omegaLN_biassym = omegaLN; 
omegaC_biassym =omegaC; omegaNX_biassym =omegaNX; omegaG_biassym =omegaG; omegaB_biassym =omegaB; 
omegaKY_biassym = omegaKY; omegaIH_biassym = omegaIH; omegaIF_biassym = omegaIF; 
omegaGT_biassym = omegaGT; omegaGH_biassym = omegaGH; omegaGF_biassym = omegaGF;
alphaL_biassym = alphaL; alphaK_biassym = alphaK; alphaC_biassym = alphaC; 
alphaI_biassym = alphaI; alphaH_biassym = alphaH; alphaIH_biassym = alphaIH;
omegaYHR_biassym = omegaYHR; omegaYNR_biassym = omegaYNR;
sLH_biassym = sLH; sLN_biassym = sLN; TFPH_biassym = TFPH; TFPN_biassym = TFPN; 
TFP_biassym = TFP; sL_biassym = sL; k_biassym = k; VL_biassym = VL; 
RH_biassym = RH; RN_biassym = RN; KHK_biassym = KHK; RHPH_biassym =RHPH; 
RNPN_biassym = RNPN; 

% Steady-State Changes
dC       = C_biassym - C_0; % Steady-state change of real consumption 
dK       = K_biassym - K_0; % Steady-state change of real capital 
dL       = L_biassym - L_0; % Steady-state change of employment 
dPN      = PN_biassym - PN_0; % Steady-state change of non traded good prices
dPH      = PH_biassym - PH_0; % Steady-state change of terms of trade (price of exports in terms if imports)
dP       = P_biassym - P_0; % Steady-state change of non traded goods prices relative to tradable home goods prices
dB       = B_biassym - B_0; % Steady-state change of traded bonds holding 
dlambda  = lambda_biassym - lambda_0; % Steady-state change of marginal utility of wealth 
dY       = Y_biassym - Y_0; % Steady-state change of GDP 
dYR      = YR_biassym - Y_0; % Steady-state change of real GDP 
dA       = A_biassym - A_0; % Steady-state change of financial wealth 
dW       = W_biassym - W_0; % Steady-state change of the wage rate 
dWPC     = WPC_biassym - WPC_0; % Steady-state change of the real aggregate wage W/PC 
dOmega   = Omega_biassym - Omega_0; % Steady-state change of the sector wage ratio

dCH   = CH_biassym - CH_0; % Steady-state change of CH
dCN   = CN_biassym - CN_0; % Steady-state change of CN
dLH   = LH_biassym - LH_0; % Steady-state change of real capital 
dLN   = LN_biassym - LN_0; % Steady-state change of employment 
dKH   = KH_biassym - KH_0; % Steady-state change of real capital 
dKN   = KN_biassym - KN_0; % Steady-state change of employment 
dYH   = YH_biassym - YH_0; % Steady-state change of YH
dYN   = YN_biassym - YN_0; % Steady-state change of YN
dWH   = WH_biassym - WH_0; % Steady-state change of WH
dWN   = WN_biassym - WN_0; % Steady-state change of WN
dRH   = RH_biassym - RH_0; % Steady-state change of RH  
dRN   = RN_biassym - RN_0; % Steady-state change of RN  
dWHPC = WHPC_biassym - WHPC_0; % Steady-state change of WH/PC
dWNPC = WNPC_biassym - WNPC_0; % Steady-state change of WN/PC
dkH   = kH_biassym - kH_0; % Steady-state change of kH 
dkN   = kN_biassym - kN_0; % Steady-state change of kN
dLHLN = LHLN_biassym - LHLN_0; % Steady-state change of LH/LN
dYHYN = YHYN_biassym - YHYN_0; % Steady-state change of LH/LN
dsLH  = sLH_biassym - sLH_0; % Steady-state change of labor income share in the home traded good sector
dsLN  = sLN_biassym - sLN_0; % Steady-state change of labor income share in the non traded good sector

dGH   = GH_biassym - GH_0; 
dGN   = GN_biassym - GN_0; 
dGF   = GF_biassym - GF_0; 
dG    = G_biassym - G_0;
dTFPH = TFPH_biassym - TFPH_0; 
dTFPN = TFPN_biassym - TFPN_0; 
dTFP  = TFP_biassym - TFP_0;
dZH   = ZH_biassym - Z_0;
dZN   = ZH_biassym - Z_0;
dZ    = Z_biassym - Z_0; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solution for investment PI*K, 
EK1   = PI + (K*omega_21); % Q(t)*K(t) - Q*K = EK1*X1(t) + EK2*X2(t)
EK2   = PI + (K*omega_22);
 
% Solution for the Relative Price of Non tradables P=P(K,Q,G,Aj,Bj)
wP_1   = P_K + (P_Q*omega_21); 
wP_2   = P_K + (P_Q*omega_22); 

% Solution for the Price of Non tradables PN=PN(K,Q,G,Aj,Bj);                                
wPN_1  =  PN_K + (PN_Q*omega_21);                                                                    
wPN_2  =  PN_K + (PN_Q*omega_22);  

% Solution for the TOT PH=PH(K,Q,G,Aj,Bj)
wPH_1  = PH_K + (PH_Q*omega_21); 
wPH_2  = PH_K + (PH_Q*omega_22);
                                                                                                  
% Solution for the Consumption Price index PC=PC(K,Q,G,Aj,Bj)                                         
wPC_1  =  PC_K + (PC_Q*omega_21);                                                                     
wPC_2  =  PC_K + (PC_Q*omega_22); 

% Solution for the Investment Price index PI=PI(K,Q,G,Aj,Bj)                                          
wPI_1  =  PI_K + (PI_Q*omega_21);                                                                     
wPI_2  =  PI_K + (PI_Q*omega_22); 

% Solution for capital and technology utilization rates uKj,uZj(K,Q,G,Aj,Bj)
wuKH_1  =  uKH_K + (uKH_Q*omega_21);
wuKH_2  =  uKH_K + (uKH_Q*omega_22);
wuKN_1  =  uKN_K + (uKN_Q*omega_21);
wuKN_2  =  uKN_K + (uKN_Q*omega_22);

wuK_1   =  uK_K + (uK_Q*omega_21);  
wuK_2   =  uK_K + (uK_Q*omega_22);  
                                                                                                                                                                                                                                                                                                               
% Solution for Q(t)/PI(P(t))                                                                           
wQPI_1  = QPI_K + (QPI_Q*omega_21);                                                                  
wQPI_2  = QPI_K + (QPI_Q*omega_22); 
                                                                                                       
% Solution for Consumption C=C(K,Q,G,Aj,Bj)                                                               
wC_1   = C_K + (C_Q*omega_21);                                                                          
wC_2   = C_K + (C_Q*omega_22);     

% Solution for Consumption J=J(K,Q,G,Aj,Bj)                                                               
wJ_1   = J_K + (J_Q*omega_21);                                                                          
wJ_2   = J_K + (J_Q*omega_22); 

% Solution for Consumption J=J(K,Q,G,Aj,Bj)                                                               
wNX_1   = NX_K + (NX_Q*omega_21);                                                                          
wNX_2   = NX_K + (NX_Q*omega_22); 
                                                                                                      
% Solution for the Aggregate Wage Index W=W(K,Q,G,Aj,Bj)                                           
wW_1  =  W_K + (W_Q*omega_21);                                                                         
wW_2  =  W_K + (W_Q*omega_22);   
                                                                                                    
% Solution for the Capital Rental Rate RK=R(K,Q,G,Aj,Bj)                                           
wR_1  =  R_K + (R_Q*omega_21);                                                                         
wR_2  =  R_K + (R_Q*omega_22);         
                                                                                                      
% Solution for the Real Consumption Wage W(K,Q,G,Aj,Bj)/PC(P)                                      
wWPC_1  = WPC_K + (WPC_Q*omega_21);                                                               
wWPC_2  = WPC_K + (WPC_Q*omega_22);    
                                                                                                         
% Solution for Labor L=L(lambda,W)=L(K,Q,G,Aj,Bj)                                                     
wL_1  =  L_K + (L_Q*omega_21);                                                                         
wL_2  =  L_K + (L_Q*omega_22);      
                                                                                                     
% Solutions for the Sectoral Labor kj,K(K,Q,G,Aj,Bj)                                                 
wkH_1  =  kH_K + (kH_Q*omega_21);                                                                     
wkH_2  =  kH_K + (kH_Q*omega_22);                                                                                                                                                             
wkN_1  =  kN_K + (kN_Q*omega_21);                                                                     
wkN_2  =  kN_K + (kN_Q*omega_22);  

wtildekH_1  =  tildekH_K + (tildekH_Q*omega_21);  
wtildekH_2  =  tildekH_K + (tildekH_Q*omega_22);                                             
wtildekN_1  =  tildekN_K + (tildekN_Q*omega_21);  
wtildekN_2  =  tildekN_K + (tildekN_Q*omega_22);  
                                                                                                   
% Solutions for the Sectoral Labor Lj=Lj(K,Q,G,Aj,Bj)                                                 
wLH_1  =  LH_K + (LH_Q*omega_21);                                                                     
wLH_2  =  LH_K + (LH_Q*omega_22);                                                     
                                                                                                       
wLN_1  =  LN_K + (LN_Q*omega_21);                                                                     
wLN_2  =  LN_K + (LN_Q*omega_22);                                                     
                                                                                                       
% Solution for Real GDP YR=YR(K,Q,G,Aj,Bj)                                                                                                                                                                                                                              
wYR_1  = YR_K + (YR_Q*omega_21);                            
wYR_2  = YR_K + (YR_Q*omega_22);

% Solutions for the Sectoral Output Yj=Yj(K,Q,G,Aj,Bj)                                                
wYH_1  = YH_K + (YH_Q*omega_21);                                                                      
wYH_2  = YH_K + (YH_Q*omega_22);                                                                                                                                                        
wYN_1  = YN_K + (YN_Q*omega_21);                                                                      
wYN_2  = YN_K + (YN_Q*omega_22);

% Solutions for YH/YN,LH/LN(K,Q,G,Aj,Bj)
wLHLN_1  = LHLN_K + (LHLN_Q*omega_21);
wLHLN_2  = LHLN_K + (LHLN_Q*omega_22);
wYHYN_1  = YHYN_K + (YHYN_Q*omega_21);
wYHYN_2  = YHYN_K + (YHYN_Q*omega_22);

% Solutions for the Sectoral Wages Wj=Wj(K,Q,G,Aj,Bj)                                              
wWH_1  = WH_K + (WH_Q*omega_21);                                                                      
wWH_2  = WH_K + (WH_Q*omega_22);  
wWN_1  = WN_K + (WN_Q*omega_21);                                                                      
wWN_2  = WN_K + (WN_Q*omega_22);

% Solutions for the Real Sectoral Wages Wj(K,Q,G,Aj,Bj)/PC(K,Q,G,Aj,Bj)     
wWHPC_1  = WHPC_K + (WHPC_Q*omega_21);                 
wWHPC_2  = WHPC_K + (WHPC_Q*omega_22);                 
wWNPC_1  = WNPC_K + (WNPC_Q*omega_21);                 
wWNPC_2  = WNPC_K + (WNPC_Q*omega_22);                 
                                                       
% Solutions for the relative wages Wj/W: WjW=WjW(K,Q,G,Aj,Bj) -     
% Solution for Omega = WN(K,Q,G,Aj,Bj)/WH(K,Q,G,Aj,Bj) 
wWHW_1  = WHW_K + (WHW_Q*omega_21);                
wWHW_2  = WHW_K + (WHW_Q*omega_22);                
wWNW_1  = WNW_K + (WNW_Q*omega_21);                
wWNW_2  = WNW_K + (WNW_Q*omega_22);                
                                                                                                                                                                     
wOmega_1  =  Omega_K + (Omega_Q*omega_21);                       
wOmega_2  =  Omega_K + (Omega_Q*omega_22);     
                                                                                                                                              
% Solution for YH(K,Q,G,Aj,Bj)/YN(K,Q,G,Aj,Bj), Solution for LH(K,Q,G,Aj,Bj)/LN(K,Q,G,Aj,Bj)                               
% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(K,Q,G,Aj,Bj)          
% Solutions for the employment shares Lj/L=(Lj/L)(K,Q,G,Aj,Bj)               
% Solutions for the employment shares sLj=LISj(K,Q,G,Aj,Bj) -  
                                   
wLHS_1  = LHS_K + (LHS_Q*omega_21);   
wLHS_2  = LHS_K + (LHS_Q*omega_22);   
wLNS_1  = LNS_K + (LNS_Q*omega_21);   
wLNS_2  = LNS_K + (LNS_Q*omega_22);   
                                      
wYHS_1  = YHS_K + (YHS_Q*omega_21);   
wYHS_2  = YHS_K + (YHS_Q*omega_22);   
wYNS_1  = YNS_K + (YNS_Q*omega_21);   
wYNS_2  = YNS_K + (YNS_Q*omega_22);   

% sLj = Wj*Lj/(Pj*Yj) -                                                                                
wLISH_1  = LISH_K + (LISH_Q*omega_21);                                    
wLISH_2  = LISH_K + (LISH_Q*omega_22);                                                                                                                                                                
wLISN_1  = LISN_K + (LISN_Q*omega_21); 
wLISN_2  = LISN_K + (LISN_Q*omega_22);                                                      
                                                                                                 
% Solutions for the Kj/K: Kj/K=Kj/K(lambda,K,Q,AH,BH,AN,BN) -                                    
wKHK_1  = KHK_K + (KHK_Q*omega_21);  
wKHK_2  = KHK_K + (KHK_Q*omega_22);  
wKNK_1  = KNK_K + (KNK_Q*omega_21);  
wKNK_2  = KNK_K + (KNK_Q*omega_22); 

% Solutions for TFPj,TFP(lambda,K,Q,AH,BH,AN,BN) -
wTFPH_1  = TFPH_K + (TFPH_Q*omega_21);
wTFPH_2  = TFPH_K + (TFPH_Q*omega_22);
wTFPN_1  = TFPN_K + (TFPN_Q*omega_21);
wTFPN_2  = TFPN_K + (TFPN_Q*omega_22);

wTFPH_1_check  = TFPH_K_check + (TFPH_Q_check*omega_21);
wTFPH_2_check  = TFPH_K_check + (TFPH_Q_check*omega_22);
wTFPN_1_check  = TFPN_K_check + (TFPN_Q_check*omega_21);
wTFPN_2_check  = TFPN_K_check + (TFPN_Q_check*omega_22);

wTFP_1   = TFP_K + (TFP_Q*omega_21);
wTFP_2   = TFP_K + (TFP_Q*omega_22);

wTFPR_1  = TFPR_K + (TFPR_Q*omega_21);  
wTFPR_2  = TFPR_K + (TFPR_Q*omega_22);  
     
% Solutions for the relative return on capital Rj,Rj/Pj(K,Q,G,Aj,Bj) -     
wRH_1  = RH_K + (RH_Q*omega_21);                                           
wRH_2  = RH_K + (RH_Q*omega_22);                                           
wRN_1  = RN_K + (RN_Q*omega_21);                                           
wRN_2  = RN_K + (RN_Q*omega_22);                                           
                                                                           
wRHPH_1  = RHPH_K + (RHPH_Q*omega_21);                                     
wRHPH_2  = RHPH_K + (RHPH_Q*omega_22);                                     
wRNPN_1  = RNPN_K + (RNPN_Q*omega_21);                                     
wRNPN_2  = RNPN_K + (RNPN_Q*omega_22);                                     

% Solutions for aggregate capital-labor ratio k, aggregate LIS sL, output
% share of non-tradables at current prices omegaYN
wk_1   =  k_K + (k_Q*omega_21);                                                                     
wk_2   =  k_K + (k_Q*omega_22); 

wLIS_1   =  LIS_K + (LIS_Q*omega_21); 
wLIS_2   =  LIS_K + (LIS_Q*omega_22); 

womegaYN_1   =  omegaYN_K + (omegaYN_Q*omega_21); 
womegaYN_2   =  omegaYN_K + (omegaYN_Q*omega_22); 
                                                                                                                                                                                                                                                                                           
% Transitional Paths 
time0 = [Tm:Tu:0]; % Span of time t= [-20..0[ 
pathdGY0    = (omegaG_0 - omegaG_0) + 0*time0;
pathCY0     = (C_0 - C_0) + 0*time0;
pathdP0     = (P_0 - P_0) + 0*time0;
pathdPH0    = (PH_0 - PH_0) + 0*time0;
pathdPN0    = (PN_0 - PN_0) + 0*time0;
pathdZ0     = (Z_0 - Z_0) + 0*time0;
pathdZH0    = (ZH_0 - ZH_0) + 0*time0;
pathdZN0    = (ZN_0 - ZN_0) + 0*time0;
pathCAY0    = CA_0 + 0*time0;
pathdL0     = (L_0 - L_0) + 0*time0;
pathdK0     = (K_0 - K_0) + 0*time0;
pathdLH0    = (LH_0 - LH_0) + 0*time0;
pathdLN0    = (LN_0 - LN_0) + 0*time0;
pathdkH0    = (kH_0 - kH_0) + 0*time0;
pathdkN0    = (kN_0 - kN_0) + 0*time0;
pathdYH0    = (YH_0 - YH_0) + 0*time0;
pathdYN0    = (YN_0 - YN_0) + 0*time0;
pathIY0     = (I_0 - I_0) + 0*time0;
pathSY0     = CA_0 + 0*time0;
pathdW0     = (W_0 - W_0) + 0*time0;
pathdY0     = (Y_0 - Y_0) + 0*time0;
pathdWH0    = (WH_0 - WH_0) + 0*time0;
pathdWN0    = (WN_0 - WN_0) + 0*time0;
pathdOmega0 = (Omega_0 - Omega_0) + 0*time0;
pathdYHYN0  = (YHYN_0 - YHYN_0) + 0*time0;
pathdLHLN0  = (LHLN_0 - LHLN_0) + 0*time0;
pathdWPC0   = (WPC_0 - WPC_0) + 0*time0;
pathdQ0     = (PI_0 - PI_0) + 0*time0;  
pathdR0     = (RK_0 - RK_0) + 0*time0; 
pathdLISH0  = (sLH_0 - sLH_0) + 0*time0;
pathdLISN0  = (sLN_0 - sLN_0) + 0*time0;

time1        = [0:Tu:Tg]; % span of time t = [0..100]
VG           = exp(-xi*time1) - (1-barg)*exp(-chi*time1);
VG1          = exp(-xi*time1) - ThetaG_1*exp(-chi*time1); 
VG2          = exp(-xi*time1) - ThetaG_2*exp(-chi*time1);
VAH          = exp(-xiAH*time1) - (1-baraH)*exp(-chiAH*time1);
VBH          = exp(-xiBH*time1) - (1-barbH)*exp(-chiBH*time1);
VAN          = exp(-xiAN*time1) - (1-baraN)*exp(-chiAN*time1);
VBN          = exp(-xiBN*time1) - (1-barbN)*exp(-chiBN*time1);
VAH1          = exp(-xiAH*time1) - ThetaAH_1*exp(-chiAH*time1);
VAH2          = exp(-xiAH*time1) - ThetaAH_2*exp(-chiAH*time1);
VBH1          = exp(-xiBH*time1) - ThetaBH_1*exp(-chiBH*time1);
VBH2          = exp(-xiBH*time1) - ThetaBH_2*exp(-chiBH*time1);
VAN1          = exp(-xiAN*time1) - ThetaAN_1*exp(-chiAN*time1);
VAN2          = exp(-xiAN*time1) - ThetaAN_2*exp(-chiAN*time1);
VBN1          = exp(-xiBN*time1) - ThetaBN_1*exp(-chiBN*time1);
VBN2          = exp(-xiBN*time1) - ThetaBN_2*exp(-chiBN*time1);
VG1prime      = xi*exp(-xi*time1) - chi*ThetaG_1*exp(-chi*time1);
VG2prime      = xi*exp(-xi*time1) - chi*ThetaG_2*exp(-chi*time1);
VGprime       = xi*exp(-xi*time1) - chi*(1-barg)*exp(-chi*time1);
VAH1prime     = xiAH*exp(-xiAH*time1) - chiAH*ThetaAH_1*exp(-chiAH*time1);
VAH2prime     = xiAH*exp(-xiAH*time1) - chiAH*ThetaAH_2*exp(-chiAH*time1);
VBH1prime     = xiBH*exp(-xiBH*time1) - chiBH*ThetaBH_1*exp(-chiBH*time1);
VBH2prime     = xiBH*exp(-xiBH*time1) - chiBH*ThetaBH_2*exp(-chiBH*time1);
VAN1prime     = xiAN*exp(-xiAN*time1) - chiAN*ThetaAN_1*exp(-chiAN*time1);
VAN2prime     = xiAN*exp(-xiAN*time1) - chiAN*ThetaAN_2*exp(-chiAN*time1);
VBN1prime     = xiBN*exp(-xiBN*time1) - chiBN*ThetaBN_1*exp(-chiBN*time1);
VBN2prime     = xiBN*exp(-xiBN*time1) - chiBN*ThetaBN_2*exp(-chiBN*time1);

VBG1prime     = xi*exp(-xi*time1) - chi*ThetaG_1prime*exp(-chi*time1);
VBG2prime     = xi*exp(-xi*time1) - chi*ThetaG_2prime*exp(-chi*time1);
VBGprime      = xi*exp(-xi*time1) - chi*ThetaG_prime*exp(-chi*time1);

VBAH1prime     = xiAH*exp(-xiAH*time1) - chiAH*ThetaAH_1prime*exp(-chiAH*time1);
VBAH2prime     = xiAH*exp(-xiAH*time1) - chiAH*ThetaAH_2prime*exp(-chiAH*time1);
VBBH1prime     = xiBH*exp(-xiBH*time1) - chiBH*ThetaBH_1prime*exp(-chiBH*time1);
VBBH2prime     = xiBH*exp(-xiBH*time1) - chiBH*ThetaBH_2prime*exp(-chiBH*time1);
VBAN1prime     = xiAN*exp(-xiAN*time1) - chiAN*ThetaAN_1prime*exp(-chiAN*time1);
VBAN2prime     = xiAN*exp(-xiAN*time1) - chiAN*ThetaAN_2prime*exp(-chiAN*time1);
VBBN1prime     = xiBN*exp(-xiBN*time1) - chiBN*ThetaBN_1prime*exp(-chiBN*time1);
VBBN2prime     = xiBN*exp(-xiBN*time1) - chiBN*ThetaBN_2prime*exp(-chiBN*time1);

VBAHprime      = xiAH*exp(-xiAH*time1) - chiAH*ThetaAH_prime*exp(-chiAH*time1); 
VBBHprime      = xiBH*exp(-xiBH*time1) - chiBH*ThetaBH_prime*exp(-chiBH*time1); 
VBANprime      = xiAN*exp(-xiAN*time1) - chiAN*ThetaAN_prime*exp(-chiAN*time1); 
VBBNprime      = xiBN*exp(-xiBN*time1) - chiBN*ThetaBN_prime*exp(-chiBN*time1); 

VgG           = gG + exp(-xi*time1) - (1-barg)*exp(-chi*time1);               
VgAH          = gAH + exp(-xiAH*time1) - (1-baraH)*exp(-chiAH*time1);         
VgBH          = gBH + exp(-xiBH*time1) - (1-barbH)*exp(-chiBH*time1);         
VgAN          = gAN + exp(-xiAN*time1) - (1-baraN)*exp(-chiAN*time1);         
VgBN          = gBN + exp(-xiBN*time1) - (1-barbN)*exp(-chiBN*time1);         

X1 = X11*exp(nu_1*time1) + (DeltaG_1*VG1) + (DeltaAH_1*VAH1) + (DeltaBH_1*VBH1) + (DeltaAN_1*VAN1) + (DeltaBN_1*VBN1);   
X2 = -  (DeltaG_2*VG2) - (DeltaAH_2*VAH2) - (DeltaBH_2*VBH2) - (DeltaAN_2*VAN2) - (DeltaBN_2*VBN2);                      
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathdGHY1    = omegaGH*(1-omegaGN)*omegaG*VgG*100;
pathdGNY1    = omegaGH*omegaGN*omegaG*VgG*100;
pathdGFY1    = (1-omegaGH)*(1-omegaGN)*omegaG*VgG*100;
pathdGY1     = omegaG_0*VgG*100;
pathdAH1     = VgAH*100;
pathdBH1     = VgBH*100;
pathdAN1     = VgAN*100;
pathdBN1     = VgBN*100;
pathdZH1     = ((sLH_0*VgAH) + (1-sLH_0)*VgBH )*100;
pathdZN1     = ((sLN_0*VgAN) + (1-sLN_0)*VgBN )*100;
pathdZ1      = ( omegaYH_0*((sLH_0*VgAH) + (1-sLH_0)*VgBH ) + (1-omegaYH_0)*((sLN_0*VgAN) + (1-sLN_0)*VgBN ) )*100;
pathdFBTCH1  = ((1-sigmaH)/sigmaH)*( VgBH - VgAH )*100;
pathdFBTCN1  = ((1-sigmaN)/sigmaN)*( VgBN - VgAN )*100;

pathdK1      = (((K_biassym-K_0) + (X1 + X2) )/K_0)*100;
pathdQ1      = (((PI_biassym-PI_0) + (omega_21*X1) + (omega_22*X2) )/PI_0)*100;
pathdP1      = (((P_biassym-P_0) + (wP_1*X1) + (wP_2*X2) + (P_G*Y_0*VG) + (P_AH*AH_0*VAH) + (P_BH*BH_0*VBH) + (P_AN*AN_0*VAN) + (P_BN*BN_0*VBN) )/P_0)*100;
pathdPH1     = (((PH_biassym-PH_0) + (wPH_1*X1) + (wPH_2*X2) + (PH_G*Y_0*VG) + (PH_AH*AH_0*VAH) + (PH_BH*BH_0*VBH) + (PH_AN*AN_0*VAN) + (PH_BN*BN_0*VBN) )/PH_0)*100;
pathdPN1     = (((PN_biassym-PN_0) + (wPN_1*X1) + (wPN_2*X2) + (PN_G*Y_0*VG) + (PN_AH*AH_0*VAH) + (PN_BH*BH_0*VBH) + (PN_AN*AN_0*VAN) + (PN_BN*BN_0*VBN) )/PN_0)*100;
pathdCY1     = ( PC_0*((C_biassym-C_0) + (wC_1*X1) + (wC_2*X2) + (C_G*Y_0*VG) + (C_AH*AH_0*VAH) + (C_BH*BH_0*VBH) + (C_AN*AN_0*VAN) + (C_BN*BN_0*VBN) )/Y_0 )*100;
pathdJY1     = ( PI_0*((I_biassym-I_0) + (wJ_1*X1) + (wJ_2*X2) + (J_G*Y_0*VG) + (J_AH*AH_0*VAH) + (J_BH*BH_0*VBH) + (J_AN*AN_0*VAN) + (J_BN*BN_0*VBN) )/Y_0 )*100;
pathdNXY1    = ( ((NX_biassym-NX_0) + (wNX_1*X1) + (wNX_2*X2) + (NX_G*Y_0*VG) + (NX_AH*AH_0*VAH) + (NX_BH*BH_0*VBH) + (NX_AN*AN_0*VAN) + (NX_BN*BN_0*VBN) )/Y_0 )*100;

pathdQPI1    = ( (wQPI_1*X1) + (wQPI_2*X2) + (QPI_G*Y_0*VG) + (QPI_AH*AH_0*VAH) + (QPI_BH*BH_0*VBH) + (QPI_AN*AN_0*VAN) + (QPI_BN*BN_0*VBN) )*100;                                
pathdL1      = (((L_biassym-L_0)  + (wL_1*X1) + (wL_2*X2) + (L_G*Y_0*VG) + (L_AH*AH_0*VAH) + (L_BH*BH_0*VBH) + (L_AN*AN_0*VAN) + (L_BN*BN_0*VBN) )/L_0)*100;                
pathdLH1     = ( (WH_0/W_0)*( (LH_biassym-LH_0) + (wLH_1*X1) + (wLH_2*X2) + (LH_G*Y_0*VG) + (LH_AH*AH_0*VAH) + (LH_BH*BH_0*VBH) + (LH_AN*AN_0*VAN) + (LH_BN*BN_0*VBN) )/L_0)*100; 
pathdLN1     = ( (WN_0/W_0)*( (LN_biassym-LN_0) + (wLN_1*X1) + (wLN_2*X2) + (LN_G*Y_0*VG) + (LN_AH*AH_0*VAH) + (LN_BH*BH_0*VBH) + (LN_AN*AN_0*VAN) + (LN_BN*BN_0*VBN) )/L_0)*100; 
pathdW1      = (((W_biassym-W_0) + (wW_1*X1) + (wW_2*X2) + (W_G*Y_0*VG) + (W_AH*AH_0*VAH) + (W_BH*BH_0*VBH) + (W_AN*AN_0*VAN) + (W_BN*BN_0*VBN) )/W_0)*100;     
pathdR1      = (((RK_biassym-RK_0) + (wR_1*X1) + (wR_2*X2) + (R_G*Y_0*VG) + (R_AH*AH_0*VAH) + (R_BH*BH_0*VBH) + (R_AN*AN_0*VAN) + (R_BN*BN_0*VBN) )/RK_0)*100;
pathdWPC1    = (((WPC_biassym-WPC_0) + (wWPC_1*X1) + (wWPC_2*X2) + (WPC_G*Y_0*VG)  + (WPC_AH*AH_0*VAH) + (WPC_BH*BH_0*VBH) + (WPC_AN*AN_0*VAN) + (WPC_BN*BN_0*VBN) )/WPC_0)*100;                      
pathdYR1     = (((YR_biassym-Y_0) + (wYR_1*X1) + (wYR_2*X2) + (YR_G*Y_0*VG) + (YR_AH*AH_0*VAH) + (YR_BH*BH_0*VBH) + (YR_AN*AN_0*VAN) + (YR_BN*BN_0*VBN) )/Y_0)*100;             
pathdYH1     = ( PH_0*((YH_biassym-YH_0) + (wYH_1*X1) + (wYH_2*X2) + (YH_G*Y_0*VG) + (YH_AH*AH_0*VAH) + (YH_BH*BH_0*VBH) + (YH_AN*AN_0*VAN) + (YH_BN*BN_0*VBN) )/Y_0)*100;            
pathdYN1     = ( PN_0*((YN_biassym-YN_0) + (wYN_1*X1) + (wYN_2*X2) + (YN_G*Y_0*VG) + (YN_AH*AH_0*VAH) + (YN_BH*BH_0*VBH) + (YN_AN*AN_0*VAN) + (YN_BN*BN_0*VBN) )/Y_0)*100;   
pathdWH1     = (((WH_biassym-WH_0) + (wWH_1*X1) + (wWH_2*X2) + (WH_G*Y_0*VG) + (WH_AH*AH_0*VAH) + (WH_BH*BH_0*VBH) + (WH_AN*AN_0*VAN) + (WH_BN*BN_0*VBN) )/WH_0)*100;           
pathdWN1     = (((WN_biassym-WN_0) + (wWN_1*X1) + (wWN_2*X2) + (WN_G*Y_0*VG) + (WN_AH*AH_0*VAH) + (WN_BH*BH_0*VBH) + (WN_AN*AN_0*VAN) + (WN_BN*BN_0*VBN) )/WN_0)*100;           
pathdWHPC1   = (((WHPC_biassym-WHPC_0) + (wWHPC_1*X1) + (wWHPC_2*X2) + (WHPC_G*Y_0*VG)  + (WHPC_AH*AH_0*VAH) + (WHPC_BH*BH_0*VBH) + (WHPC_AN*AN_0*VAN) + (WHPC_BN*BN_0*VBN) )/WHPC_0)*100;
pathdWNPC1   = (((WNPC_biassym-WNPC_0) + (wWNPC_1*X1) + (wWNPC_2*X2) + (WNPC_G*Y_0*VG)  + (WNPC_AH*AH_0*VAH) + (WNPC_BH*BH_0*VBH) + (WNPC_AN*AN_0*VAN) + (WNPC_BN*BN_0*VBN) )/WNPC_0)*100;
pathdRH1     = (((RH_biassym-RH_0) + (wRH_1*X1) + (wRH_2*X2) + (RH_G*Y_0*VG) + (RH_AH*AH_0*VAH) + (RH_BH*BH_0*VBH) + (RH_AN*AN_0*VAN) + (RH_BN*BN_0*VBN) )/RH_0)*100;                                       
pathdRN1     = (((RN_biassym-RN_0) + (wRN_1*X1) + (wRN_2*X2) + (RN_G*Y_0*VG) + (RN_AH*AH_0*VAH) + (RN_BH*BH_0*VBH) + (RN_AN*AN_0*VAN) + (RN_BN*BN_0*VBN) )/RN_0)*100;                                       
pathdRHPH1   = ((((RH_biassym/PH_biassym)-(RH_0/PH_0)) + (wRHPH_1*X1) + (wRHPH_2*X2) + (RHPH_G*Y_0*VG) + (RHPH_AH*AH_0*VAH) + (RHPH_BH*BH_0*VBH) + (RHPH_AN*AN_0*VAN) + (RHPH_BN*BN_0*VBN) )/(RH_0/PH_0))*100; 
pathdRNPN1   = ((((RN_biassym/PN_biassym)-(RN_0/PN_0)) + (wRNPN_1*X1) + (wRNPN_2*X2) + (RNPN_G*Y_0*VG) + (RNPN_AH*AH_0*VAH) + (RNPN_BH*BH_0*VBH) + (RNPN_AN*AN_0*VAN) + (RNPN_BN*BN_0*VBN) )/(RN_0/PN_0))*100; 

pathdOmega1  = (((Omega_biassym-Omega_0) + (wOmega_1*X1) + (wOmega_2*X2) + (Omega_G*Y_0*VG) + (Omega_AH*AH_0*VAH) + (Omega_BH*BH_0*VBH) + (Omega_AN*AN_0*VAN) + (Omega_BN*BN_0*VBN) )/Omega_0)*100;
pathdYHYN1   = (PH_0/PN_0)*( ((YH_biassym/YN_biassym)-(YH_0/YN_0)) + (wYHYN_1*X1) + (wYHYN_2*X2) + (YHYN_G*Y_0*VG) + (YHYN_AH*AH_0*VAH) + (YHYN_BH*BH_0*VBH) + (YHYN_AN*AN_0*VAN) + (YHYN_BN*BN_0*VBN) )*100;
pathdLHLN1   = (WH_0/WN_0)*( ((LH_biassym/LN_biassym)-(LH_0/LN_0)) + (wLHLN_1*X1) + (wLHLN_2*X2) + (LHLN_G*Y_0*VG) + (LHLN_AH*AH_0*VAH) + (LHLN_BH*BH_0*VBH) + (LHLN_AN*AN_0*VAN) + (LHLN_BN*BN_0*VBN) )*100;
pathdLHS1    = (WH_0/W_0)*( ((LH_biassym/L_biassym)- (LH_0/L_0)) + (wLHS_1*X1) + (wLHS_2*X2) + (LHS_G*Y_0*VG) + (LHS_AH*AH_0*VAH) + (LHS_BH*BH_0*VBH) + (LHS_AN*AN_0*VAN) + (LHS_BN*BN_0*VBN) )*100;
pathdLNS1    = (WN_0/W_0)*( ((LN_biassym/L_biassym)- (LN_0/L_0)) + (wLNS_1*X1) + (wLNS_2*X2) + (LNS_G*Y_0*VG) + (LNS_AH*AH_0*VAH)  + (LNS_BH*BH_0*VBH) + (LNS_AN*AN_0*VAN) + (LNS_BN*BN_0*VBN) )*100;
pathdYHS1    = PH_0*( ((YH_biassym/YR_biassym)- (YH_0/YR_0)) + (wYHS_1*X1) + (wYHS_2*X2) + (YHS_G*Y_0*VG) + (YHS_AH*AH_0*VAH) + (YHS_BH*BH_0*VBH) + (YHS_AN*AN_0*VAN) + (YHS_BN*BN_0*VBN) )*100;
pathdYNS1    = PN_0*( ((YN_biassym/YR_biassym)- (YN_0/YR_0)) + (wYNS_1*X1) + (wYNS_2*X2) + (YNS_G*Y_0*VG) + (YNS_AH*AH_0*VAH) + (YNS_BH*BH_0*VBH) + (YNS_AN*AN_0*VAN) + (YNS_BN*BN_0*VBN) )*100;
pathdWHW1    = (( ((WH_biassym/W_biassym)-(WH_0/W_0)) + (wWHW_1*X1) + (wWHW_2*X2) + (WHW_G*Y_0*VG) + (WHW_AH*AH_0*VAH) + (WHW_BH*BH_0*VBH) + (WHW_AN*AN_0*VAN) + (WHW_BN*BN_0*VBN) )/(WH_0/W_0) )*100; 
pathdWNW1    = (( ((WN_biassym/W_biassym)-(WN_0/W_0)) + (wWNW_1*X1) + (wWNW_2*X2) + (WNW_G*Y_0*VG) + (WNW_AH*AH_0*VAH) + (WNW_BH*BH_0*VBH) + (WNW_AN*AN_0*VAN) + (WNW_BN*BN_0*VBN) )/(WN_0/W_0) )*100; 
pathdKHK1    =  ( ((KH_biassym/K_biassym)-(KH_0/K_0)) + (wKHK_1*X1) + (wKHK_2*X2) + (KHK_G*Y_0*VG) + (KHK_AH*AH_0*VAH) + (KHK_BH*BH_0*VBH) + (KHK_AN*AN_0*VAN) + (KHK_BN*BN_0*VBN) )*100;              
pathdKNK1    =  ( ((KN_biassym/K_biassym)-(KN_0/K_0)) + (wKNK_1*X1) + (wKNK_2*X2) + (KNK_G*Y_0*VG) + (KNK_AH*AH_0*VAH) + (KNK_BH*BH_0*VBH) + (KNK_AN*AN_0*VAN) + (KNK_BN*BN_0*VBN) )*100;              

pathdkH1     = ( LH_0*((kH_biassym-kH_0) + (wkH_1*X1) + (wkH_2*X2) + (kH_G*Y_0*VG) + (kH_AH*AH_0*VAH) + (kH_BH*BH_0*VBH) + (kH_AN*AN_0*VAN) + (kH_BN*BN_0*VBN) )/K_0)*100;
pathdkN1     = ( LN_0*((kN_biassym-kN_0) + (wkN_1*X1) + (wkN_2*X2) + (kN_G*Y_0*VG) + (kN_AH*AH_0*VAH) + (kN_BH*BH_0*VBH) + (kN_AN*AN_0*VAN) + (kN_BN*BN_0*VBN) )/K_0)*100;
pathdLISH1   = ( (sLH_biassym-sLH_0) + (wLISH_1*X1) + (wLISH_2*X2) + (LISH_G*Y_0*VG) + (LISH_AH*AH_0*VAH) + (LISH_BH*BH_0*VBH) + (LISH_AN*AN_0*VAN) + (LISH_BN*BN_0*VBN) )*100;
pathdLISN1   = ( (sLN_biassym-sLN_0) + (wLISN_1*X1) + (wLISN_2*X2) + (LISN_G*Y_0*VG) + (LISN_AH*AH_0*VAH) + (LISN_BH*BH_0*VBH) + (LISN_AN*AN_0*VAN) + (LISN_BN*BN_0*VBN) )*100;
pathdomegaYN1 = ((omegaYN_biassym-omegaYN_0) + (womegaYN_1*X1) + (womegaYN_2*X2) + (omegaYN_G*Y_0*VG) + (omegaYN_AH*AH_0*VAH) + (omegaYN_BH*BH_0*VBH) + (omegaYN_AN*AN_0*VAN) + (omegaYN_BN*BN_0*VBN) )*100;

CA_AH = (B_AH*AH_0/(xiAH+r))*VBAHprime + (N1*DeltaAH_1/(xiAH+r))*VBAH1prime - (N2*DeltaAH_2/(xiAH+r))*VBAH2prime;
CA_BH = (B_BH*BH_0/(xiBH+r))*VBBHprime + (N1*DeltaBH_1/(xiBH+r))*VBBH1prime - (N2*DeltaBH_2/(xiBH+r))*VBBH2prime;
CA_AN = (B_AN*AN_0/(xiAN+r))*VBANprime + (N1*DeltaAN_1/(xiAN+r))*VBAN1prime - (N2*DeltaAN_2/(xiAN+r))*VBAN2prime;
CA_BN = (B_BN*BN_0/(xiBN+r))*VBBNprime + (N1*DeltaBN_1/(xiBN+r))*VBBN1prime - (N2*DeltaBN_2/(xiBN+r))*VBBN2prime;
CA_G  = (B_G*Y_0*omegaG_0/(xi+r))*VBGprime + (N1*DeltaG_1/(xi+r))*VBG1prime - (N2*DeltaG_2/(xi+r))*VBG2prime;

SAV_AH = (A_AH*AH_0/(xiAH+r))*VBAHprime + (M1*DeltaAH_1/(xiAH+r))*VBAH1prime - (M2*DeltaAH_2/(xiAH+r))*VBAH2prime;
SAV_BH = (A_BH*BH_0/(xiBH+r))*VBBHprime + (M1*DeltaBH_1/(xiBH+r))*VBBH1prime - (M2*DeltaBH_2/(xiBH+r))*VBBH2prime;
SAV_AN = (A_AN*AN_0/(xiAN+r))*VBANprime + (M1*DeltaAN_1/(xiAN+r))*VBAN1prime - (M2*DeltaAN_2/(xiAN+r))*VBAN2prime;
SAV_BN = (A_BN*BN_0/(xiBN+r))*VBBNprime + (M1*DeltaBN_1/(xiBN+r))*VBBN1prime - (M2*DeltaBN_2/(xiBN+r))*VBBN2prime;
SAV_G  = (A_G*Y_0*omegaG_0/(xi+r))*VBGprime + (M1*DeltaG_1/(xi+r))*VBG1prime - (M2*DeltaG_2/(xi+r))*VBG2prime;

dotX1 = nu_1*X11*exp(nu_1*time1) - (DeltaAH_1*VAH1prime) - (DeltaBH_1*VBH1prime) - (DeltaAN_1*VAN1prime) - (DeltaBN_1*VBN1prime) - (DeltaG_1*VG1prime);
dotX2 = (DeltaAH_2*VAH2prime) +(DeltaBH_2*VBH2prime) + (DeltaAN_2*VAN2prime) + (DeltaBN_2*VBN2prime) + (DeltaG_2*VG2prime);

pathCAY1 = (( -nu_1*(wB1/(r-nu_1))*exp(nu_1*time1) + CA_AH + CA_BH + CA_AN + CA_BN + CA_G )/Y_0 )*100;
pathSY1  = (( -nu_1*(wA1/(r-nu_1))*exp(nu_1*time1) + SAV_AH + SAV_BH + SAV_AN + SAV_BN + SAV_G )/Y_0 )*100;
pathIY1 = (( (EK1*dotX1) + (EK2*dotX2) )/Y_0)*100;

%%%%%%%%% Transitional paths - including capital utilization rates and TFP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathduKH1    = ( (wuKH_1*X1) + (wuKH_2*X2) + (uKH_G*Y_0*VG) + (uKH_AH*AH_0*VAH) + (uKH_BH*BH_0*VBH) + (uKH_AN*AN_0*VAN) + (uKH_BN*BN_0*VBN) )*100; 
pathduKN1    = ( (wuKN_1*X1) + (wuKN_2*X2) + (uKN_G*Y_0*VG) + (uKN_AH*AH_0*VAH) + (uKN_BH*BH_0*VBH) + (uKN_AN*AN_0*VAN) + (uKN_BN*BN_0*VBN) )*100; 
pathduK1     = ( (wuK_1*X1) + (wuK_2*X2) + (uK_G*Y_0*VG) + (uK_AH*AH_0*VAH) + (uK_BH*BH_0*VBH) + (uK_AN*AN_0*VAN) + (uK_BN*BN_0*VBN) )*100; 
pathdTFPH1   = (( (ZH_biassym-ZH_0) + (wTFPH_1*X1) + (wTFPH_2*X2) + (TFPH_G*Y_0*VG) + (TFPH_AH*AH_0*VAH) + (TFPH_BH*BH_0*VBH) + (TFPH_AN*AN_0*VAN) + (TFPH_BN*BN_0*VBN) )/ZH_0)*100;
pathdTFPN1   = (( (ZN_biassym-ZN_0) + (wTFPN_1*X1) + (wTFPN_2*X2) + (TFPN_G*Y_0*VG) + (TFPN_AH*AH_0*VAH) + (TFPN_BH*BH_0*VBH) + (TFPN_AN*AN_0*VAN) + (TFPN_BN*BN_0*VBN) )/ZN_0)*100;
pathdTFP1    = (( (Z_biassym-Z_0) + (wTFP_1*X1) + (wTFP_2*X2) + (TFP_G*Y_0*VG) + (TFP_AH*AH_0*VAH) + (TFP_BH*BH_0*VBH) + (TFP_AN*AN_0*VAN) + (TFP_BN*BN_0*VBN) )/Z_0)*100;
pathdTFPH1_check   = (( (ZH_biassym-ZH_0) + (wTFPH_1_check*X1) + (wTFPH_2_check*X2) + (TFPH_G_check*Y_0*VG) + (TFPH_AH_check*AH_0*VAH) + (TFPH_BH_check*BH_0*VBH) + (TFPH_AN_check*AN_0*VAN) + (TFPH_BN_check*BN_0*VBN) )/ZH_0)*100;
pathdTFPN1_check   = (( (ZN_biassym-ZN_0) + (wTFPN_1_check*X1) + (wTFPN_2_check*X2) + (TFPN_G_check*Y_0*VG) + (TFPN_AH_check*AH_0*VAH) + (TFPN_BH_check*BH_0*VBH) + (TFPN_AN_check*AN_0*VAN) + (TFPN_BN_check*BN_0*VBN) )/ZN_0)*100;
pathdTFPR1   = (( ((ZH_biassym/ZN_biassym)-(ZH_0/ZN_0)) + (wTFPR_1*X1) + (wTFPR_2*X2) + (TFPR_G*Y_0*VG) + (TFPR_AH*AH_0*VAH) + (TFPR_BH*BH_0*VBH) + (TFPR_AN*AN_0*VAN) + (TFPR_BN*BN_0*VBN) )/(ZH_0/ZN_0))*100;

% IRF
timetemp = [time0 time1];
pathdGHY_biassym   = [pathdGY0  pathdGHY1];
pathdGFY_biassym   = [pathdGY0  pathdGFY1];
pathdGNY_biassym   = [pathdGY0  pathdGNY1];
pathdGY_biassym    = [pathdGY0  pathdGY1];
pathdAH_biassym    = [pathdZH0  pathdAH1];
pathdBH_biassym    = [pathdZH0  pathdBH1];
pathdAN_biassym    = [pathdZN0  pathdAN1];
pathdBN_biassym    = [pathdZN0  pathdBN1];
pathdFBTCH_biassym = [pathdZH0  pathdFBTCH1];
pathdFBTCN_biassym = [pathdZN0  pathdFBTCN1];
pathdZH_biassym    = [pathdZH0  pathdZH1];
pathdZN_biassym    = [pathdZN0  pathdZN1];
pathdZ_biassym     = [pathdZH0  pathdZ1];
pathdQ_biassym     = [pathdQ0  pathdQ1];
pathdQPI_biassym   = [pathdQ0  pathdQPI1];
pathdPH_biassym    = [pathdP0  pathdPH1];
pathdPN_biassym    = [pathdP0  pathdPN1];
pathdP_biassym     = [pathdP0  pathdP1]; 
pathdCY_biassym    = [pathCY0  pathdCY1];   
pathdJY_biassym    = [pathIY0  pathdJY1]; 
pathdNXY_biassym   = [pathIY0  pathdNXY1];
pathdL_biassym     = [pathdL0  pathdL1];
pathdK_biassym     = [pathdK0  pathdK1];
pathdLH_biassym    = [pathdLH0 pathdLH1];             
pathdLN_biassym    = [pathdLN0 pathdLN1];  
pathdW_biassym     = [pathdW0 pathdW1]; 
pathdR_biassym     = [pathdR0 pathdR1]; 
pathdWPC_biassym   = [pathdWPC0 pathdWPC1];  
pathdYR_biassym    = [pathdY0 pathdYR1];
pathdYH_biassym    = [pathdY0 pathdYH1];               
pathdYN_biassym    = [pathdY0 pathdYN1];               
pathdWH_biassym    = [pathdWH0  pathdWH1];              
pathdWN_biassym    = [pathdWN0  pathdWN1]; 
pathdWHPC_biassym  = [pathdWH0 pathdWHPC1];
pathdWNPC_biassym  = [pathdWN0 pathdWNPC1];
pathdRHPH_biassym  = [pathdR0 pathdRHPH1];
pathdRNPN_biassym  = [pathdR0 pathdRNPN1];

pathdLHS_biassym   = [pathdLH0 pathdLHS1];             
pathdLNS_biassym   = [pathdLN0 pathdLNS1];
pathdYHS_biassym   = [pathdY0 pathdYHS1];             
pathdYNS_biassym   = [pathdY0 pathdYNS1];
pathdWHW_biassym   = [pathdWH0 pathdWHW1];
pathdWNW_biassym   = [pathdWN0 pathdWNW1];
pathdKHK_biassym   = [pathdkH0 pathdKHK1];             
pathdKNK_biassym   = [pathdkN0 pathdKNK1];

pathdkH_biassym    = [pathdkH0 pathdkH1];             
pathdkN_biassym    = [pathdkN0 pathdkN1];
pathdLISH_biassym  = [pathdLISH0 pathdLISH1];             
pathdLISN_biassym  = [pathdLISN0 pathdLISN1];
pathdomegaYN_biassym = [pathdY0 pathdomegaYN1];

pathdOmega_biassym = [pathdOmega0 pathdOmega1];         
pathdYHYN_biassym  = [pathdYHYN0 pathdYHYN1];           
pathdLHLN_biassym  = [pathdLHLN0 pathdLHLN1];

pathIY_biassym     = [pathIY0  pathIY1];                        
pathCAY_biassym    = [pathCAY0 pathCAY1];               
pathSY_biassym     = [pathSY0  pathSY1];

% IRF including technology and capital utilization rates
pathduKH_biassym   = [pathdkH0 pathduKH1];             
pathduKN_biassym   = [pathdkN0 pathduKN1];
pathduK_biassym    = [pathdkN0 pathduK1];
pathdTFPH_biassym  = [pathdkH0 pathdTFPH1];             
pathdTFPN_biassym  = [pathdkN0 pathdTFPN1];
pathdTFP_biassym   = [pathdkN0 pathdTFP1];
pathdTFPH_check_biassym  = [pathdkH0 pathdTFPH1_check];             
pathdTFPN_check_biassym  = [pathdkN0 pathdTFPN1_check];
pathdTFPR_biassym  = [pathdkH0 pathdTFPR1];
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Dynamic and steadty-state effects of a Permanent increase in ZH/ZN %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Impact effects of fiscal shock: dynamic processes 
VG0            = 1 - (1-barg);                   
VG10           = 1 - ThetaG_1;                   
VG20           = 1 - ThetaG_2;                   
VAH0           = 1 - (1-baraH);                  
VBH0           = 1 - (1-barbH);                  
VAN0           = 1 - (1-baraN);                  
VBN0           = 1 - (1-barbN);                  
VAH10          = 1 - ThetaAH_1;                  
VAH20          = 1 - ThetaAH_2;                  
VBH10          = 1 - ThetaBH_1;                  
VBH20          = 1 - ThetaBH_2;                  
VAN10          = 1 - ThetaAN_1;                  
VAN20          = 1 - ThetaAN_2;                  
VBN10          = 1 - ThetaBN_1;                  
VBN20          = 1 - ThetaBN_2;                  
VG1prime0      = xi - chi*ThetaG_1;            
VG2prime0      = xi - chi*ThetaG_2;            
VGprime0       = xi - chi*(1-barg);            
VAH1prime0     = xiAH - (chiAH*ThetaAH_1);         
VAH2prime0     = xiAH - (chiAH*ThetaAH_2);         
VBH1prime0     = xiBH - (chiBH*ThetaBH_1);         
VBH2prime0     = xiBH - (chiBH*ThetaBH_2);         
VAN1prime0     = xiAN - (chiAN*ThetaAN_1);         
VAN2prime0     = xiAN - (chiAN*ThetaAN_2);         
VBN1prime0     = xiBN - (chiBN*ThetaBN_1);         
VBN2prime0     = xiBN - (chiBN*ThetaBN_2);         
                                                 
VBG1prime0     = xi - (chi*ThetaG_1prime);       
VBG2prime0     = xi - (chi*ThetaG_2prime);       
VBGprime0      = xi - (chi*ThetaG_prime);        
                                                 
VBAH1prime0     = xiAH - (chiAH*ThetaAH_1prime); 
VBAH2prime0     = xiAH - (chiAH*ThetaAH_2prime); 
VBBH1prime0     = xiBH - (chiBH*ThetaBH_1prime); 
VBBH2prime0     = xiBH - (chiBH*ThetaBH_2prime); 
VBAN1prime0     = xiAN - (chiAN*ThetaAN_1prime); 
VBAN2prime0     = xiAN - (chiAN*ThetaAN_2prime); 
VBBN1prime0     = xiBN - (chiBN*ThetaBN_1prime); 
VBBN2prime0     = xiBN - (chiBN*ThetaBN_2prime); 
VBAHprime0      = xiAH - (chiAH*ThetaAH_prime);  
VBBHprime0      = xiBH - (chiBH*ThetaBH_prime);  
VBANprime0      = xiAN - (chiAN*ThetaAN_prime);  
VBBNprime0      = xiBN - (chiBN*ThetaBN_prime);     

VgG0        = gG + 1 - (1-barg);
VgAH0       = gAH + 1 - (1-baraH);
VgBH0       = gBH + 1 - (1-barbH);
VgAN0       = gAN + 1 - (1-baraN);
VgBN0       = gBN + 1 - (1-barbN);

X10 = X11 + (DeltaG_1*VG10) + (DeltaAH_1*VAH10) + (DeltaBH_1*VBH10) + (DeltaAN_1*VAN10) + (DeltaBN_1*VBN10);
X20 = -  (DeltaG_2*VG20) - (DeltaAH_2*VAH20) - (DeltaBH_2*VBH20) - (DeltaAN_2*VAN20) - (DeltaBN_2*VBN20);
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dGHYtime0_biassym    = omegaGH*(1-omegaGN)*omegaG*VgG0*100;
dGNYtime0_biassym    = omegaGH*omegaGN*omegaG*VgG0*100;
dGFYtime0_biassym    = (1-omegaGH)*(1-omegaGN)*omegaG*VgG0*100;
dGYtime0_biassym     = omegaG_0*VgG0*100;
dAHtime0_biassym     = VgAH0*100;
dBHtime0_biassym     = VgBH0*100;
dANtime0_biassym     = VgAN0*100;
dBNtime0_biassym     = VgBN0*100;
dZHtime0_biassym     = ((sLH_0*VgAH0) + (1-sLH_0)*VgBH0 )*100;
dZNtime0_biassym     = ((sLN_0*VgAN0) + (1-sLN_0)*VgBN0 )*100;
dZAtime0_biassym      = ( omegaYH_0*((sLH_0*VgAH0) + (1-sLH_0)*VgBH0 ) + (1-omegaYH_0)*((sLN_0*VgAN0) + (1-sLN_0)*VgBN0 ) )*100;
dFBTCHtime0_biassym  = ((1-sigmaH)/sigmaH)*( VgBH0 - VgAH0 )*100;
dFBTCNtime0_biassym  = ((1-sigmaN)/sigmaN)*( VgBN0 - VgAN0 )*100;

dKtime0_biassym      = (((K_biassym-K_0) + (X10 + X20) )/K_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
dQtime0_biassym      = (((PI_biassym-PI_0) + (omega_21*X10) + (omega_22*X20) )/PI_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
dPtime0_biassym      = (((P_biassym-P_0) + (wP_1*X10) + (wP_2*X20) + (P_G*Y_0*VG0) + (P_AH*AH_0*VAH0) + (P_BH*BH_0*VBH0) + (P_AN*AN_0*VAN0) + (P_BN*BN_0*VBN0) )/P_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
dPHtime0_biassym     = (((PH_biassym-PH_0) + (wPH_1*X10) + (wPH_2*X20) + (PH_G*Y_0*VG0) + (PH_AH*AH_0*VAH0) + (PH_BH*BH_0*VBH0) + (PH_AN*AN_0*VAN0) + (PH_BN*BN_0*VBN0) )/PH_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
dPNtime0_biassym     = (((PN_biassym-PN_0) + (wPN_1*X10) + (wPN_2*X20) + (PN_G*Y_0*VG0) + (PN_AH*AH_0*VAH0) + (PN_BH*BH_0*VBH0) + (PN_AN*AN_0*VAN0) + (PN_BN*BN_0*VBN0) )/PN_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
dCYtime0_biassym     = ( PC_0*((C_biassym-C_0) + (wC_1*X10) + (wC_2*X20) + (C_G*Y_0*VG0) + (C_AH*AH_0*VAH0) + (C_BH*BH_0*VBH0) + (C_AN*AN_0*VAN0) + (C_BN*BN_0*VBN0) )/Y_0 )*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
dQPItime0_biassym    = ( (wQPI_1*X10) + (wQPI_2*X20) + (QPI_G*Y_0*VG0) + (QPI_AH*AH_0*VAH0) + (QPI_BH*BH_0*VBH0) + (QPI_AN*AN_0*VAN0) + (QPI_BN*BN_0*VBN0) )*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
dLtime0_biassym      = (((L_biassym-L_0)  + (wL_1*X10) + (wL_2*X20) + (L_G*Y_0*VG0) + (L_AH*AH_0*VAH0) + (L_BH*BH_0*VBH0) + (L_AN*AN_0*VAN0) + (L_BN*BN_0*VBN0) )/L_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
dLHtime0_biassym     = ( (WH_0/W_0)*((LH_biassym-LH_0) + (wLH_1*X10) + (wLH_2*X20) + (LH_G*Y_0*VG0) + (LH_AH*AH_0*VAH0) + (LH_BH*BH_0*VBH0) + (LH_AN*AN_0*VAN0) + (LH_BN*BN_0*VBN0) )/L_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
dLNtime0_biassym     = ( (WN_0/W_0)*((LN_biassym-LN_0) + (wLN_1*X10) + (wLN_2*X20) + (LN_G*Y_0*VG0) + (LN_AH*AH_0*VAH0) + (LN_BH*BH_0*VBH0) + (LN_AN*AN_0*VAN0) + (LN_BN*BN_0*VBN0) )/L_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
dWtime0_biassym      = (((W_biassym-W_0) + (wW_1*X10) + (wW_2*X20) + (W_G*Y_0*VG0) + (W_AH*AH_0*VAH0) + (W_BH*BH_0*VBH0) + (W_AN*AN_0*VAN0) + (W_BN*BN_0*VBN0) )/W_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
dWPCtime0_biassym    = (((WPC_biassym-WPC_0) + (wWPC_1*X10) + (wWPC_2*X20) + (WPC_G*Y_0*VG0)  + (WPC_AH*AH_0*VAH0) + (WPC_BH*BH_0*VBH0) + (WPC_AN*AN_0*VAN0) + (WPC_BN*BN_0*VBN0) )/WPC_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
dYRtime0_biassym     = (((YR_biassym-Y_0) + (wYR_1*X10) + (wYR_2*X20) + (YR_G*Y_0*VG0) + (YR_AH*AH_0*VAH0) + (YR_BH*BH_0*VBH0) + (YR_AN*AN_0*VAN0) + (YR_BN*BN_0*VBN0) )/Y_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
dYHtime0_biassym     = (PH_0*((YH_biassym-YH_0) + (wYH_1*X10) + (wYH_2*X20) + (YH_G*Y_0*VG0) + (YH_AH*AH_0*VAH0) + (YH_BH*BH_0*VBH0) + (YH_AN*AN_0*VAN0) + (YH_BN*BN_0*VBN0) )/Y_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
dYNtime0_biassym     = (PN_0*((YN_biassym-YN_0) + (wYN_1*X10) + (wYN_2*X20) + (YN_G*Y_0*VG0) + (YN_AH*AH_0*VAH0) + (YN_BH*BH_0*VBH0) + (YN_AN*AN_0*VAN0) + (YN_BN*BN_0*VBN0) )/Y_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
dWHtime0_biassym     = (((WH_biassym-WH_0) + (wWH_1*X10) + (wWH_2*X20) + (WH_G*Y_0*VG0) + (WH_AH*AH_0*VAH0) + (WH_BH*BH_0*VBH0) + (WH_AN*AN_0*VAN0) + (WH_BN*BN_0*VBN0) )/WH_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
dWNtime0_biassym     = (((WN_biassym-WN_0) + (wWN_1*X10) + (wWN_2*X20) + (WN_G*Y_0*VG0) + (WN_AH*AH_0*VAH0) + (WN_BH*BH_0*VBH0) + (WN_AN*AN_0*VAN0) + (WN_BN*BN_0*VBN0) )/WN_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
dWHPCtime0_biassym   = (((WHPC_biassym-WHPC_0) + (wWHPC_1*X10) + (wWHPC_2*X20) + (WHPC_G*Y_0*VG0)  + (WHPC_AH*AH_0*VAH0) + (WHPC_BH*BH_0*VBH0) + (WHPC_AN*AN_0*VAN0) + (WHPC_BN*BN_0*VBN0) )/WHPC_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
dWNPCtime0_biassym   = (((WNPC_biassym-WNPC_0) + (wWNPC_1*X10) + (wWNPC_2*X20) + (WNPC_G*Y_0*VG0)  + (WNPC_AH*AH_0*VAH0) + (WNPC_BH*BH_0*VBH0) + (WNPC_AN*AN_0*VAN0) + (WNPC_BN*BN_0*VBN0) )/WNPC_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
dOmegatime0_biassym  = (((Omega_biassym-Omega_0) + (wOmega_1*X10) + (wOmega_2*X20) + (Omega_G*Y_0*VG0) + (Omega_AH*AH_0*VAH0) + (Omega_BH*BH_0*VBH0) + (Omega_AN*AN_0*VAN0) + (Omega_BN*BN_0*VBN0) )/Omega_0)*100;
dYHYNtime0_biassym   = (PH_0/PN_0)*( ((YH_biassym/YN_biassym)-(YH_0/YN_0)) + (wYHYN_1*X10) + (wYHYN_2*X20) + (YHYN_G*Y_0*VG0) + (YHYN_AH*AH_0*VAH0) + (YHYN_BH*BH_0*VBH0) + (YHYN_AN*AN_0*VAN0) + (YHYN_BN*BN_0*VBN0) )*100;
dLHLNtime0_biassym   = (WH_0/WN_0)*( ((LH_biassym/LN_biassym)-(LH_0/LN_0)) + (wLHLN_1*X10) + (wLHLN_2*X20) + (LHLN_G*Y_0*VG0) + (LHLN_AH*AH_0*VAH0) + (LHLN_BH*BH_0*VBH0) + (LHLN_AN*AN_0*VAN0) + (LHLN_BN*BN_0*VBN0) )*100;
dLHStime0_biassym    = (WH_0/W_0)*( ((LH_biassym/L_biassym)- (LH_0/L_0)) + (wLHS_1*X10) + (wLHS_2*X20) + (LHS_G*Y_0*VG0) + (LHS_AH*AH_0*VAH0) + (LHS_BH*BH_0*VBH0) + (LHS_AN*AN_0*VAN0) + (LHS_BN*BN_0*VBN0) )*100;
dLNStime0_biassym    = (WN_0/W_0)*( ((LN_biassym/L_biassym)- (LN_0/L_0)) + (wLNS_1*X10) + (wLNS_2*X20) + (LNS_G*Y_0*VG0) + (LNS_AH*AH_0*VAH0) + (LNS_BH*BH_0*VBH0) + (LNS_AN*AN_0*VAN0) + (LNS_BN*BN_0*VBN0) )*100;
dYHStime0_biassym    = PH_0*( ((YH_biassym/YR_biassym)- (YH_0/YR_0)) + (wYHS_1*X10) + (wYHS_2*X20) + (YHS_G*Y_0*VG0) + (YHS_AH*AH_0*VAH0) + (YHS_BH*BH_0*VBH0) + (YHS_AN*AN_0*VAN0) + (YHS_BN*BN_0*VBN0) )*100;
dYNStime0_biassym    = PN_0*( ((YN_biassym/YR_biassym)- (YN_0/YR_0)) + (wYNS_1*X10) + (wYNS_2*X20) + (YNS_G*Y_0*VG0) + (YNS_AH*AH_0*VAH0) + (YNS_BH*BH_0*VBH0) + (YNS_AN*AN_0*VAN0) + (YNS_BN*BN_0*VBN0) )*100;
dWHWtime0_biassym    = (( ((WH_biassym/W_biassym)-(WH_0/W_0)) + (wWHW_1*X10) + (wWHW_2*X20) + (WHW_G*Y_0*VG0) + (WHW_AH*AH_0*VAH0) + (WHW_BH*BH_0*VBH0) + (WHW_AN*AN_0*VAN0) + (WHW_BN*BN_0*VBN0) )/(WH_0/W_0) )*100;
dWNWtime0_biassym    = (( ((WN_biassym/W_biassym)-(WN_0/W_0)) + (wWNW_1*X10) + (wWNW_2*X20) + (WNW_G*Y_0*VG0) + (WNW_AH*AH_0*VAH0) + (WNW_BH*BH_0*VBH0) + (WNW_AN*AN_0*VAN0) + (WNW_BN*BN_0*VBN0) )/(WN_0/W_0) )*100;
dKHKtime0_biassym    =  ( ((KH_biassym/K_biassym)-(KH_0/K_0)) + (wKHK_1*X10) + (wKHK_2*X20) + (KHK_G*Y_0*VG0) + (KHK_AH*AH_0*VAH0) + (KHK_BH*BH_0*VBH0) + (KHK_AN*AN_0*VAN0) + (KHK_BN*BN_0*VBN0) )*100;
dKNKtime0_biassym    =  ( ((KN_biassym/K_biassym)-(KN_0/K_0)) + (wKNK_1*X10) + (wKNK_2*X20) + (KNK_G*Y_0*VG0) + (KNK_AH*AH_0*VAH0) + (KNK_BH*BH_0*VBH0) + (KNK_AN*AN_0*VAN0) + (KNK_BN*BN_0*VBN0) )*100;
dRHPHtime0_biassym   = (( ((RH_biassym/PH_biassym)-(RH_0/PH_0)) + (wRHPH_1*X10) + (wRHPH_2*X20) + (RHPH_G*Y_0*VG0) + (RHPH_AH*AH_0*VAH0) + (RHPH_BH*BH_0*VBH0) + (RHPH_AN*AN_0*VAN0) + (RHPH_BN*BN_0*VBN0) )/(RH_0/PH_0))*100;
dRNPNtime0_biassym   = (( ((RN_biassym/PN_biassym)-(RN_0/PN_0)) + (wRNPN_1*X10) + (wRNPN_2*X20) + (RNPN_G*Y_0*VG0) + (RNPN_AH*AH_0*VAH0) + (RNPN_BH*BH_0*VBH0) + (RNPN_AN*AN_0*VAN0) + (RNPN_BN*BN_0*VBN0) )/(RN_0/PN_0))*100;
dRtime0_biassym      = ( ((RK_biassym-RK_0) + (wR_1*X10) + (wR_2*X20) + (R_G*Y_0*VG0) + (R_AH*AH_0*VAH0) + (R_BH*BH_0*VBH0) + (R_AN*AN_0*VAN0) + (R_BN*BN_0*VBN0) )/RK_0)*100;  

dkHtime0_biassym     = ( LH_0*((kH_biassym-kH_0) + (wkH_1*X10) + (wkH_2*X20) + (kH_G*Y_0*VG0) + (kH_AH*AH_0*VAH0) + (kH_BH*BH_0*VBH0) + (kH_AN*AN_0*VAN0) + (kH_BN*BN_0*VBN0) )/K_0)*100;
dkNtime0_biassym     = ( LN_0*((kN_biassym-kN_0) + (wkN_1*X10) + (wkN_2*X20) + (kN_G*Y_0*VG0) + (kN_AH*AH_0*VAH0) + (kN_BH*BH_0*VBH0) + (kN_AN*AN_0*VAN0) + (kN_BN*BN_0*VBN0) )/K_0)*100;
dLISHtime0_biassym   = ( (sLH_biassym-sLH_0) + (wLISH_1*X10) + (wLISH_2*X20) + (LISH_G*Y_0*VG0) + (LISH_AH*AH_0*VAH0) + (LISH_BH*BH_0*VBH0) + (LISH_AN*AN_0*VAN0) + (LISH_BN*BN_0*VBN0) )*100;
dLISNtime0_biassym   = ( (sLN_biassym-sLN_0) + (wLISN_1*X10) + (wLISN_2*X20) + (LISN_G*Y_0*VG0) + (LISN_AH*AH_0*VAH0) + (LISN_BH*BH_0*VBH0) + (LISN_AN*AN_0*VAN0) + (LISN_BN*BN_0*VBN0) )*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
domegaYNtime0_biassym = ((omegaYN_biassym-omegaYN_0) + (womegaYN_1*X10) + (womegaYN_2*X20) + (omegaYN_G*Y_0*VG0) + (omegaYN_AH*AH_0*VAH0) + (omegaYN_BH*BH_0*VBH0) + (omegaYN_AN*AN_0*VAN0) + (omegaYN_BN*BN_0*VBN0) )*100;

CA_AH0 = (B_AH*AH_0/(xiAH+r))*VBAHprime0 + (N1*DeltaAH_1/(xiAH+r))*VBAH1prime0 - (N2*DeltaAH_2/(xiAH+r))*VBAH2prime0;
CA_BH0 = (B_BH*BH_0/(xiBH+r))*VBBHprime0 + (N1*DeltaBH_1/(xiBH+r))*VBBH1prime0 - (N2*DeltaBH_2/(xiBH+r))*VBBH2prime0;
CA_AN0 = (B_AN*AN_0/(xiAN+r))*VBANprime0 + (N1*DeltaAN_1/(xiAN+r))*VBAN1prime0 - (N2*DeltaAN_2/(xiAN+r))*VBAN2prime0;
CA_BN0 = (B_BN*BN_0/(xiBN+r))*VBBNprime0 + (N1*DeltaBN_1/(xiBN+r))*VBBN1prime0 - (N2*DeltaBN_2/(xiBN+r))*VBBN2prime0;
CA_G0  = (B_G*Y_0/(xi+r))*VBGprime0 + (N1*DeltaG_1/(xi+r))*VBG1prime0 - (N2*DeltaG_2/(xi+r))*VBG2prime0;

SAV_AH0 = (A_AH*AH_0/(xiAH+r))*VBAHprime0 + (M1*DeltaAH_1/(xiAH+r))*VBAH1prime0 - (M2*DeltaAH_2/(xiAH+r))*VBAH2prime0;
SAV_BH0 = (A_BH*BH_0/(xiBH+r))*VBBHprime0 + (M1*DeltaBH_1/(xiBH+r))*VBBH1prime0 - (M2*DeltaBH_2/(xiBH+r))*VBBH2prime0;
SAV_AN0 = (A_AN*AN_0/(xiAN+r))*VBANprime0 + (M1*DeltaAN_1/(xiAN+r))*VBAN1prime0 - (M2*DeltaAN_2/(xiAN+r))*VBAN2prime0;
SAV_BN0 = (A_BN*BN_0/(xiBN+r))*VBBNprime0 + (M1*DeltaBN_1/(xiBN+r))*VBBN1prime0 - (M2*DeltaBN_2/(xiBN+r))*VBBN2prime0;
SAV_G0  = (A_G*Y_0/(xi+r))*VBGprime0 + (M1*DeltaG_1/(xi+r))*VBG1prime0 - (M2*DeltaG_2/(xi+r))*VBG2prime0;

dotX10 = (nu_1*X11) - (DeltaAH_1*VAH1prime0) - (DeltaBH_1*VBH1prime0) - (DeltaAN_1*VAN1prime0) - (DeltaBN_1*VBN1prime0) - (DeltaG_1*VG1prime0);
dotX20 = (DeltaAH_2*VAH2prime0) +(DeltaBH_2*VBH2prime0) + (DeltaAN_2*VAN2prime0) + (DeltaBN_2*VBN2prime0) + (DeltaG_2*VG2prime0);

CAYtime0_biassym = (( -nu_1*(wB1/(r-nu_1)) + CA_AH0 + CA_BH0 + CA_AN0 + CA_BN0 + CA_G0 )/Y_0 )*100;
SYtime0_biassym  = (( -nu_1*(wA1/(r-nu_1)) + SAV_AH0 + SAV_BH0 + SAV_AN0 + SAV_BN0 + SAV_G0 )/Y_0 )*100;
IYtime0_biassym = (( (EK1*dotX10) + (EK2*dotX20) )/Y_0)*100;

CAYtime0_biassym_check = SYtime0_biassym - IYtime0_biassym;

%%%%%%%%% Transitional paths - including capital utilization rates and TFP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
duKHtime0_biassym        = ( (wuKH_1*X10) + (wuKH_2*X20) + (uKH_G*Y_0*VG0) + (uKH_AH*AH_0*VAH0) + (uKH_BH*BH_0*VBH0) + (uKH_AN*AN_0*VAN0) + (uKH_BN*BN_0*VBN0) )*100;                                                                                    
duKNtime0_biassym        = ( (wuKN_1*X10) + (wuKN_2*X20) + (uKN_G*Y_0*VG0) + (uKN_AH*AH_0*VAH0) + (uKN_BH*BH_0*VBH0) + (uKN_AN*AN_0*VAN0) + (uKN_BN*BN_0*VBN0) )*100;                                                                                    
duKtime0_biassym         = ( (wuK_1*X10) + (wuK_2*X20) + (uK_G*Y_0*VG0) + (uK_AH*AH_0*VAH0) + (uK_BH*BH_0*VBH0) + (uK_AN*AN_0*VAN0) + (uK_BN*BN_0*VBN0) )*100;                                                                                           
dTFPHtime0_biassym       = (( (ZH_biassym-ZH_0) + (wTFPH_1*X10) + (wTFPH_2*X20) + (TFPH_G*Y_0*VG0) + (TFPH_AH*AH_0*VAH0) + (TFPH_BH*BH_0*VBH0) + (TFPH_AN*AN_0*VAN0) + (TFPH_BN*BN_0*VBN0) )/ZH_0)*100;
dTFPNtime0_biassym       = (( (ZN_biassym-ZN_0) + (wTFPN_1*X10) + (wTFPN_2*X20) + (TFPN_G*Y_0*VG0) + (TFPN_AH*AH_0*VAH0) + (TFPN_BH*BH_0*VBH0) + (TFPN_AN*AN_0*VAN0) + (TFPN_BN*BN_0*VBN0) )/ZN_0)*100;
dTFPtime0_biassym        = (( (Z_biassym-Z_0) + (wTFP_1*X10) + (wTFP_2*X20) + (TFP_G*Y_0*VG0) + (TFP_AH*AH_0*VAH0) + (TFP_BH*BH_0*VBH0) + (TFP_AN*AN_0*VAN0) + (TFP_BN*BN_0*VBN0) )/Z_0)*100;
dTFPHtime0_check_biassym = (( (ZH_biassym-ZH_0) + (wTFPH_1_check*X10) + (wTFPH_2_check*X20) + (TFPH_G_check*Y_0*VG0) + (TFPH_AH_check*AH_0*VAH0) + (TFPH_BH_check*BH_0*VBH0) + (TFPH_AN_check*AN_0*VAN0) + (TFPH_BN_check*BN_0*VBN0) )/ZH_0)*100;
dTFPNtime0_check_biassym = (( (ZN_biassym-ZN_0) + (wTFPN_1_check*X10) + (wTFPN_2_check*X20) + (TFPN_G_check*Y_0*VG0) + (TFPN_AH_check*AH_0*VAH0) + (TFPN_BH_check*BH_0*VBH0) + (TFPN_AN_check*AN_0*VAN0) + (TFPN_BN_check*BN_0*VBN0) )/ZN_0)*100;
dTFPRtime0_biassym       = (( ((ZH_biassym/ZN_biassym)-(ZH_0/ZN_0)) + (wTFPR_1*X10) + (wTFPR_2*X20) + (TFPR_G*Y_0*VG0) + (TFPR_AH*AH_0*VAH0) + (TFPR_BH*BH_0*VBH0) + (TFPR_AN*AN_0*VAN0) + (TFPR_BN*BN_0*VBN0) )/(ZH_0/ZN_0))*100;

% Steady-state changes and impact effects - scaled to their initial values 
hatlambda_biassym       = (dlambda/lambda_0)*100; 
dCoverY_biassym         = ((PC_0*dC)/Y_0)*100; % Rate of change of the real consumption
dGNY_biassym            = PN_0*(dGN/Y_0)*100; % Change in GN
dGHY_biassym            = PH_0*(dGH/Y_0)*100; % Change in GH
dGFY_biassym            = (dGF/Y_0)*100; % Change in GH
dGY_biassym             = (dG/Y_0)*100; % Chane in G
hatL_biassym            = (dL/L_0)*100; % Rate of change of employment
hatK_biassym            = (dK/K_0)*100; % Rate of change of the stock of foreign assets
dLHoverL_biassym        = (WH_0/W_0)*(dLH/L_0)*100; % Rate of change of LH
dLNoverL_biassym        = (WN_0/W_0)*(dLN/L_0)*100; % Rate of change of LN
dLHLN_biassym           = (WH_0/WN_0)*((LH/LN)-(LH_0/LN_0))*100; %  Change of LH/LN
hatPH_biassym           = (dPH/PH_0)*100; % Rate of change of PH
hatPN_biassym           = (dPN/PN_0)*100; % Rate of change of PN
hatP_biassym            = (dP/P_0)*100; % Rate of change of PN/PH
dBoverY_biassym         = (dB/Y_0)*100; % Rate of change of the stock of foreign assets
dAoverY_biassym         = (dA/Y_0)*100; % Rate of change of the stock of financial assets
hatW_biassym            = (dW/W_0)*100; % Rate of change of wage
hatWPC_biassym          = (dWPC/WPC_0)*100; % Rate of change of Real Aggregate Wage W/pc
hatY_biassym            = (dY/Y_0)*100; % Rate of change of GDP
hatYR_biassym           = ((YR-Y_0)/Y_0)*100; % Rate of change of Real GDP
dYHoverY_biassym        = (PH_0*dYH/Y_0)*100; % Rate of change of YH
dYNoverY_biassym        = (PN_0*dYN/Y_0)*100; % Rate of change of YN
dYHYN_biassym           = (PH_0/PN_0)*((YH/YN)-(YH_0/YN_0))*100; % Rate of change of YH/YN
hatWH_biassym           = (dWH/WH_0)*100; % Rate of change of WH
hatWN_biassym           = (dWN/WN_0)*100; % Rate of change of WN
hatOmega_biassym        = (dOmega/Omega_0)*100; % Rate of change of omega
hatWHPC_biassym         = (dWHPC/WHPC_0)*100; % Rate of change of WH/PC
hatWNPC_biassym         = (dWNPC/WNPC_0)*100; % Rate of change of WN/PC
dkH_biassym             = LH_0*(dkH/K_0)*100; % Rate of change of kH
dkN_biassym             = LN_0*(dkN/K_0)*100; % Rate of change of kN
dLHS_biassym            = (WH_0/W_0)*((LH/L)-(LH_0/L_0))*100; % change in  the labor share of T
dLNS_biassym            = (WN_0/W_0)*((LN/L)-(LN_0/L_0))*100; % change in the labor share of NT
dYHS_biassym            = PH_0*((YH/YR)-(YH_0/YR_0))*100; % change in the output share of T
dYNS_biassym            = PN_0*((YN/YR)-(YN_0/YR_0))*100; % change in the output share of NT
dLISH_biassym           = (sLH_biassym-sLH_0)*100; % Change in the labor income share H
dLISN_biassym           = (sLN_biassym-sLN_0)*100; % Change in the labor income share N
dWHW_biassym            = (((WH/W)-(WH_0/W_0))/((WH_0/W_0)))*100; % Change in the relative wage H
dWNW_biassym            = (((WN/W)-(WN_0/W_0))/((WH_0/W_0)))*100; % Change in the relative wage N
dKHK_biassym            = ((KH/K)-(KH_0/K_0))*100; % Change in the capital share of H
dKNK_biassym            = ((KN/K)-(KN_0/K_0))*100; % Change in the capital share of N

% Technology                       
hatTFPH_biassym = dTFPH/TFPH_0;       
hatTFPN_biassym = dTFPN/TFPN_0;       
hatTFP_biassym  = dTFP/TFP_0;         
hatZH_biassym   = dZH/ZH_0;           
hatZN_biassym   = dZN/ZN_0;           
hatZ_biassym    = dZ/Z_0;      

disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                    Final Steady State with kH > kN');
disp('                           The exomark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (exomark)');
disp('The structural parameters (exomark)');
disp(sprintf('sigmaH  : %5.2f   gammaH   : %5.2f',sigmaH,gammaH));
disp(sprintf('sigmaN  : %5.2f   gammaN   : %5.2f',sigmaN,gammaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('phi     : %5.2f   varphi   : %5.2f',phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f sigma   : %5.2f',sigmaL,gammaL,sigma));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('AH      : %5.2f   BH       : %5.2f',AH,BH));
disp(sprintf('AN      : %5.2f   BN       : %5.2f',AN,BN));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('TFPH    : %5.2f   TFPN     : %5.2f',TFPH,TFPN));
disp(sprintf('omegaYH : %5.2f   Z        : %5.2f TFP        : %5.2f',omegaYH,Z,TFP));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (exomark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));
disp(sprintf('K        : %9.3f   ',K));
disp(sprintf('K_check  : %9.3f   ',K_check));
disp(sprintf('alphaK   : %9.3f   ',alphaK));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('RN                 : %9.3f',RN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('RH                 : %9.3f',RH));
disp(sprintf('Profit             : %9.10f',PiH));

disp(' ');                                                                                      
disp('Wealth');                                                                                 
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));                                          
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));                                     
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA)); 

disp(' ');
disp('The demand side (exomark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (exomark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f IF     : %9.3f',IH,IN,IF));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp('Linearization');
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('Upsilon_G :  %5.4f  Sigma_G   : %5.4f',Upsilon_G,Sigma_G));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));
disp(sprintf('B_G       :  %5.4f  A_G       : %5.4f',B_G,A_G));
disp(sprintf('A_K       :  %5.4f  A_Q       : %5.4f',A_K,A_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu_1,nu_2));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp('Eigenvectors');
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega_11,omega_12));

disp('Partial derivatives of Yj');                                                          
disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));                        
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));                        
disp(sprintf('YN_G       :   %7.6f  YH_G       : %9.6f',YN_G,YH_G));                        
disp(sprintf('YN_AH      :   %7.6f  YH_AH      : %9.6f',YN_AH,YH_AH));                      
disp(sprintf('YN_BH      :   %7.6f  YH_BH      : %9.6f',YN_BH,YH_BH));                      
disp(sprintf('YN_AN      :   %7.6f  YH_AN      : %9.6f',YN_AN,YH_AN));                      
disp(sprintf('YN_BN      :   %7.6f  YH_BN      : %9.6f',YN_BN,YH_BN));                      
                                                                                              
disp('Partial derivatives of Yj/YR');                                                             
disp(sprintf('YNS_Q       :   %7.6f  YHS_Q       : %9.6f',YNS_Q,YHS_Q));                          
disp(sprintf('YNS_K       :   %7.6f  YHS_K       : %9.6f',YNS_K,YHS_K));                          
disp(sprintf('YNS_G       :   %7.6f  YHS_G       : %9.6f',YNS_G,YHS_G));                          
disp(sprintf('YNS_AH      :   %7.6f  YHS_AH      : %9.6f',YNS_AH,YHS_AH));                        
disp(sprintf('YNS_BH      :   %7.6f  YHS_BH      : %9.6f',YNS_BH,YHS_BH));                        
disp(sprintf('YNS_AN      :   %7.6f  YHS_AN      : %9.6f',YNS_AN,YHS_AN));                        
disp(sprintf('YNS_BN      :   %7.6f  YHS_BN      : %9.6f',YNS_BN,YHS_BN));                        
                                                                                                  
disp(' ');
disp('Steady State Equilibrium ratios (exomark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WH*LH/W*L   :  %5.3f RH*KH/RK*K  :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));
disp(' ');
disp(' ');
disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LH/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));
disp(sprintf('Traded capital supply             : %9.16f   ',cond31));
disp(sprintf('Non-traded capital supply         : %9.16f   ',cond32));
disp(sprintf('Relative capital supply KH/KN     : %9.16f   ',cond33));
disp(sprintf('Unit Cost for Producing N         : %9.16f   ',cond34));
disp(sprintf('Unit Cost for Producing H         : %9.16f   ',cond35));


disp('-------------------------------------------------------------------------------------------------------- ');
disp('                       Increase in gN : Impact and Steady State Changes (after a rise in gN)     ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('                               |     Temporary   |');
disp('-------------------------------------------------------------------------------------------------------- ');
disp(' ');

disp(' ');
disp(' Steady State Deviations ( = (x-x0)/x0 where x0 is the value of x at the initial steady state)  ');
disp(sprintf('hatlambda_biassym        :         |           |%10.3f',hatlambda_biassym));
disp(sprintf('dGY_biassym              :         |           |%10.3f',dGY_biassym));
disp(sprintf('dGHY_biassym             :         |           |%10.3f',dGHY_biassym));
disp(sprintf('dGNY_biassym             :         |           |%10.3f',dGNY_biassym));
disp(sprintf('dCoverY_biassym          :         |           |%10.3f',dCoverY_biassym));
disp(sprintf('dLoverL_biassym          :         |           |%10.3f',hatL_biassym));
disp(sprintf('dYRoverY_biassym         :         |           |%10.3f',hatYR_biassym));
disp(sprintf('dKoverK_biassym          :         |           |%10.3f',hatK_biassym));
disp(sprintf('dLHoverL_biassym         :         |           |%10.3f',dLHoverL_biassym));
disp(sprintf('dLNover_biassym          :         |           |%10.3f',dLNoverL_biassym));
disp(sprintf('dLHLN_biassym            :         |           |%10.3f',dLHLN_biassym));
disp(sprintf('dYHoverY_biassym         :         |           |%10.3f',dYHoverY_biassym));
disp(sprintf('dYNoverY_biassym         :         |           |%10.3f',dYNoverY_biassym));
disp(sprintf('dYHYN_biassym            :         |           |%10.3f',dYHYN_biassym));
disp(sprintf('hatPH_biassym            :         |           |%10.3f',hatPH_biassym));
disp(sprintf('hatPN_biassym            :         |           |%10.3f',hatPN_biassym));
disp(sprintf('hatP_biassym             :         |           |%10.3f',hatP_biassym));
disp(sprintf('dBoverY_biassym          :         |           |%10.3f',dBoverY_biassym));
disp(sprintf('dAoverY_biassym          :         |           |%10.3f',dAoverY_biassym));
disp(sprintf('dWoverW_biassym          :         |           |%10.3f',hatW_biassym));
disp(sprintf('dWPCoverWPC_biassym      :         |           |%10.3f',hatWPC_biassym));
disp(sprintf('dWHoverWH_biassym        :         |           |%10.3f',hatWH_biassym));
disp(sprintf('dWNoverWN_biassym        :         |           |%10.3f',hatWN_biassym));
disp(sprintf('hatOmega_biassym         :         |           |%10.3f',hatOmega_biassym));
disp(sprintf('dWHPCoverWHPC_biassym    :         |           |%10.3f',hatWHPC_biassym));
disp(sprintf('dWNPCoverWNPC_biassym    :         |           |%10.3f',hatWNPC_biassym));
disp(sprintf('dkHoverK_biassym         :         |           |%10.3f',dkH_biassym));
disp(sprintf('dkNoverK_biassym         :         |           |%10.3f',dkN_biassym));

disp(' ');
disp('Reallocation : long-run');   
disp(sprintf('dLHS_biassym             :         |           |%10.3f',dLHS_biassym));
disp(sprintf('dLNS_biassym             :         |           |%10.3f',dLNS_biassym));
disp(sprintf('dYHS_biassym             :         |           |%10.3f',dYHS_biassym));
disp(sprintf('dYNS_biassym             :         |           |%10.3f',dYNS_biassym));
disp(sprintf('dLISH_biassym            :         |           |%10.3f',dLISH_biassym));
disp(sprintf('dLISN_biassym            :         |           |%10.3f',dLISN_biassym));
disp(sprintf('dWHW_biassym             :         |           |%10.3f',dWHW_biassym));
disp(sprintf('dWNW_biassym             :         |           |%10.3f',dWNW_biassym));

disp(' ');                                                                                   
disp('Technology : long-run');                                                               
disp(sprintf('hatZH_biassym             :         |           |%10.3f',hatZH_biassym));            
disp(sprintf('hatZN_biassym             :         |           |%10.3f',hatZN_biassym));            
disp(sprintf('hatZ_biassym              :         |           |%10.3f',hatZ_biassym));             
disp(sprintf('hatTFPH_biassym           :         |           |%10.3f',hatTFPH_biassym));          
disp(sprintf('hatTFPN_biassym           :         |           |%10.3f',hatTFPN_biassym));          
disp(sprintf('hatTFP_biassym            :         |           |%10.3f',hatTFP_biassym));  

disp(' ');
disp('                                           Initial responses ');
disp(sprintf('dGYtime0_biassym        :                |                 |%10.3f',dGYtime0_biassym));
disp(sprintf('dGHYtime0_biassym       :                |                 |%10.3f',dGHYtime0_biassym));
disp(sprintf('dGNYtime0_biassym       :                |                 |%10.3f',dGNYtime0_biassym));
disp(sprintf('dZHtime0_biassym        :                |                 |%10.3f',dZHtime0_biassym));
disp(sprintf('dZNtime0_biassym        :                |                 |%10.3f',dZNtime0_biassym));
disp(sprintf('dZAtime0_biassym         :                |                 |%10.3f',dZAtime0_biassym));
disp(sprintf('dAHtime0_biassym        :                |                 |%10.3f',dAHtime0_biassym));
disp(sprintf('dBHtime0_biassym        :                |                 |%10.3f',dBHtime0_biassym));
disp(sprintf('dANtime0_biassym        :                |                 |%10.3f',dANtime0_biassym));
disp(sprintf('dBNtime0_biassym        :                |                 |%10.3f',dBNtime0_biassym));
disp(sprintf('dFBTCHtime0_biassym     :                |                 |%10.3f',dFBTCHtime0_biassym));
disp(sprintf('dFBTCNtime0_biassym     :                |                 |%10.3f',dFBTCNtime0_biassym));

disp('                Initial responses including capital and technology utilization rates');
disp(sprintf('duKHtime0_biassym            :                |                 |%10.3f',duKHtime0_biassym));     
disp(sprintf('duKNtime0_biassym            :                |                 |%10.3f',duKNtime0_biassym));     
disp(sprintf('duKtime0_biassym             :                |                 |%10.3f',duKtime0_biassym));      
disp(sprintf('dTFPHtime0_biassym           :                |                 |%10.3f',dTFPHtime0_biassym));
disp(sprintf('dTFPNtime0_biassym           :                |                 |%10.3f',dTFPNtime0_biassym));
disp(sprintf('dTFPHtime0_check_biassym     :                |                 |%10.3f',dTFPHtime0_check_biassym));
disp(sprintf('dTFPNtime0_check_biassym     :                |                 |%10.3f',dTFPNtime0_check_biassym));
disp(sprintf('dTFPtime0_biassym            :                |                 |%10.3f',dTFPtime0_biassym));
disp(sprintf('dTFPRtime0_biassym           :                |                 |%10.3f',dTFPRtime0_biassym));

disp('                                           Initial responses ');
disp(sprintf('dKtime0_biassym         :                |                 |%10.3f',dKtime0_biassym));
disp(' ');
disp(sprintf('dCYtime0_biassym        :                |                 |%10.3f',dCYtime0_biassym));
disp(sprintf('dLtime0_biassym         :                |                 |%10.3f',dLtime0_biassym));
disp(sprintf('dLHtime0_biassym        :                |                 |%10.3f',dLHtime0_biassym));
disp(sprintf('dLNtime0_biassym        :                |                 |%10.3f',dLNtime0_biassym));
disp(sprintf('dLHLNtime0_biassym      :                |                 |%10.3f',dLHLNtime0_biassym));
disp(sprintf('dYRtime0_biassym        :                |                 |%10.3f',dYRtime0_biassym));
disp(sprintf('dYHtime0_biassym        :                |                 |%10.3f',dYHtime0_biassym));
disp(sprintf('dYNtime0_biassym        :                |                 |%10.3f',dYNtime0_biassym));
disp(sprintf('dYHYNtime0_biassym      :                |                 |%10.3f',dYHYNtime0_biassym));
disp(sprintf('dPHtime0_biassym        :                |                 |%10.3f',dPHtime0_biassym));
disp(sprintf('dPNtime0_biassym        :                |                 |%10.3f',dPNtime0_biassym));
disp(sprintf('dPtime0_biassym         :                |                 |%10.3f',dPtime0_biassym));
disp(sprintf('domegaYNtime0_biassym   :                |                 |%10.3f',domegaYNtime0_biassym));
disp(sprintf('dSYtime0_biassym        :                |                 |%10.3f',SYtime0_biassym));
disp(sprintf('dIYtime0_biassym        :                |                 |%10.3f',IYtime0_biassym));
disp(sprintf('dCAYtime0_biassym       :                |                 |%10.5f',CAYtime0_biassym)); 
disp(sprintf('dCAYtime0_biassym_check :                |                 |%10.5f',CAYtime0_biassym_check)); 
disp(sprintf('dWtime0_biassym         :                |                 |%10.3f',dWtime0_biassym));
disp(sprintf('dWPCtime0_biassym       :                |                 |%10.3f',dWPCtime0_biassym));
disp(sprintf('dWHtime0_biassym        :                |                 |%10.3f',dWHtime0_biassym));
disp(sprintf('dWNtime0_biassym        :                |                 |%10.3f',dWNtime0_biassym));
disp(sprintf('dOmegatime0_biassym     :                |                 |%10.3f',dOmegatime0_biassym));
disp(sprintf('dWHPCtime0_biassym      :                |                 |%10.3f',dWHPCtime0_biassym));
disp(sprintf('dWNPCtime0_biassym      :                |                 |%10.3f',dWNPCtime0_biassym));
disp(sprintf('dkHKtime0_biassym       :                |                 |%10.3f',dkHtime0_biassym));
disp(sprintf('dkNKtime0_biassym       :                |                 |%10.3f',dkNtime0_biassym));
disp(sprintf('dLHStime0_biassym       :                |                 |%10.3f',dLHStime0_biassym));
disp(sprintf('dLNStime0_biassym       :                |                 |%10.3f',dLNStime0_biassym));
disp(sprintf('dYHStime0_biassym       :                |                 |%10.3f',dYHStime0_biassym));
disp(sprintf('dYNStime0_biassym       :                |                 |%10.3f',dYNStime0_biassym));
disp(sprintf('dWHWtime0_biassym       :                |                 |%10.3f',dWHWtime0_biassym));
disp(sprintf('dWNWtime0_biassym       :                |                 |%10.3f',dWNWtime0_biassym));
disp(sprintf('dLISHtime0_biassym      :                |                 |%10.3f',dLISHtime0_biassym));
disp(sprintf('dLISNtime0_biassym      :                |                 |%10.3f',dLISNtime0_biassym));
disp(sprintf('dKHKtime0_biassym       :                |                 |%10.3f',dKHKtime0_biassym));   
disp(sprintf('dKNKtime0_biassym       :                |                 |%10.3f',dKNKtime0_biassym));   
disp(sprintf('dRtime0_biassym         :                |                 |%10.3f',dRtime0_biassym));
disp(sprintf('dRHPHtime0_biassym      :                |                 |%10.3f',dRHPHtime0_biassym));   
disp(sprintf('dRNPNtime0_biassym      :                |                 |%10.3f',dRNPNtime0_biassym));   
                                                                                                                 
disp(' ');
disp('Steady State Equilibrium ratios (exomark)');
disp(sprintf('sigmaH  : %5.2f   sigmaN   : %5.2f',sigmaH_0,sigmaN_0));
disp(sprintf('YH / Y   :  %5.3f     PN*YN / Y  : %5.3f',omegaYH_0,omegaYN_0));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH_0,omegaLN_0));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC_0,omegaNX_0));
disp(sprintf('PI*I / Y  :  %5.3f      G / Y     : %5.3f',omegaI_0,omegaG_0));
disp(' ');
disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH_0,omegaGNYN_0,omegaGN_0));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f    GT/G     : %5.3f',omegaGH_0,omegaGF_0,omegaGT_0));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f',omegaINYN_0,omegaIHYH_0));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH_0,omegaGFYH_0));
disp(sprintf('WH*LH/PH*YH :  %5.3f WN*LN/PN*YN :  %5.3f',sLH_0,sLN_0));
disp(sprintf('WH*LH/W*L   :  %5.3f RH*KH/R*K   :  %5.3f',alphaL_0,alphaK_0));
disp(sprintf('PT*IT/PI*I  :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI_0,alphaC_0));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH_0,alphaH_0));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH_0,omegaCH_0));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF_0,omegaCF_0));
disp(sprintf('PH*XH/Y     :  %5.3f    XH / YH  :  %5.3f',omegaXHY_0,omegaXHYH_0));
disp(sprintf('W*L/P*Y     :  %5.3f R*K/P*Y     :  %5.3f',omegaL_0,omegaK_0));
disp(sprintf('K/Y         :  %5.3f KH/K        :  %5.3f',omegaKY_0,KHK_0));
disp(' ');
disp(sprintf('xi1H    : %5.5f   xi2H     : %5.5f',xi1H,xi2H));                             
disp(sprintf('xi1N    : %5.5f   xi2N     : %5.5f',xi1N,xi2N));                             
disp(sprintf('xi     : %5.5f  chi       : %5.5f  barg      : %5.5f',xi,chi,barg));         
disp(sprintf('xiAH   : %5.5f  chiAH     : %5.5f  baraH     : %5.5f',xiAH,chiAH,baraH));    
disp(sprintf('xiBH   : %5.5f  chiBB     : %5.5f  barbH     : %5.5f',xiBH,chiBH,barbH));    
disp(sprintf('xiAN  : %5.5f   chiAN     : %5.5f  baraN     : %5.5f',xiAN,chiAN,baraN));    
disp(sprintf('xiBN  : %5.5f   chiBN     : %5.5f  barbN     : %5.5f',xiBN,chiBN,barbN));         
disp(' ');
disp(sprintf('TFPH       : %5.5f   ZH_0     : %5.5f',TFPH_0,ZH_0));                             
disp(sprintf('TFPH_biassym  : %5.5f   ZH_biassym  : %5.5f',TFPH_biassym,ZH_biassym));
disp(sprintf('TFPN       : %5.5f   ZN_0     : %5.5f',TFPN_0,ZN_0));                             
disp(sprintf('TFPN_biassym  : %5.5f   ZN_biassym  : %5.5f',TFPN_biassym,ZN_biassym));
disp(' ');


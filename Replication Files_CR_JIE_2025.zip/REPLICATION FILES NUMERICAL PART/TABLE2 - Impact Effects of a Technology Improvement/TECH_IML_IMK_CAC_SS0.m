function g = TECH_IML_IMK_CAC_SS0(x)

global sigma phi varphi 
global gammaL sigmaL phiI varphiI
global epsilon vartheta 
global epsilonK varthetaK 
global r deltaK omegaG omegaGN
global ZT ZN thetaT thetaN kappa
global B0 K0  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    VARAIABLES of the MODEL                      %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption
L       = x(2)  ; % Labor supply
RT      = x(3)  ; % Return on traded capital
RN      = x(4)  ; % Return on non-traded capital
WT      = x(5)  ; % Wage rate in sector H
WN      = x(6)  ; % Wage rate in sector N
W       = x(7)  ; % Aggregate wage index
RK      = x(8)  ; % Aggregate capital rental rate
P       = x(9)  ; % Relative price of non tradables
K       = x(10)  ; % Stock of capital
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Labor compensation share of tradables
alphaK  = x(13) ; % Capital compensation share of tradables
CN      = x(14) ; % Consumption in non tradables
CT      = x(15) ; % Consumption in tradables
PC      = x(16) ; % Consumption price index
alphaC  = x(17) ; % Tradable share of consumption - alphaC
IN      = x(18) ; % Non tradable investment
IT      = x(19) ; % Tradable investment
PI      = x(20) ; % Investment price index
alphaI  = x(21) ; % Tradable share of investment
LT      = x(22) ; % Labor in sector T
LN      = x(23) ; % Labor in sector N
KT      = x(24) ; % Capital in sector T
KN      = x(25) ; % Capital in sector N
GT      = x(26) ; % Government spending in tradables
GN      = x(27) ; % Government spending in non tradables
YT      = x(28) ; % Output in sector T
YN      = x(29) ; % Output in sector N
VL      = x(30) ; % Labor disutility
lambda  = x(31) ; % Intertemporal Solvency Condition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    STEADY STATE of the MODEL                    %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Aggregate Consumption -  C
g(1)= (C^(-sigma))*(VL^sigma) - (PC*lambda);

% Aggregate labor supply - L
g(2)= (C^(1-sigma))*sigma*gammaL*(L^(1/sigmaL))*(VL^(sigma-1)) - (lambda*W);

% MRPKT = RT - RT -
g(3)= ZT*(1-thetaT)*(LT^thetaT)*(KT^(-thetaT)) - RT;

% MRPKN = RN - RN
g(4)= P*ZN*(1-thetaN)*(LN^thetaN)*(KN^(-thetaN)) - RN;

% MRPLH = WT - WT
g(5)= ZT*thetaT*(LT^(thetaT-1))*(KT^(1-thetaT)) - WT;

% MRPLN = WN - WN
g(6)= P*ZN*thetaN*(LN^(thetaN-1))*(KN^(1-thetaN)) - WN;

% Aggregate wage index - W
g(7)= W - ((vartheta*(WT)^(epsilon+1)) + ((1-vartheta)*(WN)^(epsilon+1)))^(1/(epsilon+1));

% Aggregate capital rental rate index - RK
g(8)= RK - ((varthetaK*(RT)^(epsilonK+1)) + ((1-varthetaK)*(RN)^(epsilonK+1)))^(1/(epsilonK+1));

% Return on capital is equal to capital cost dotQ=0 - PN
g(9)= RK - (deltaK + r)*PI;

% Non traded market good market clearing condition - K
g(10)= YN - CN - GN - IN;

% Traded good market clearing condition - B
g(11)= (r*B) + YT - CT - GT - IT;

% Tradable share of labor income - alphaL
g(12)= alphaL - (vartheta*(WT)^(epsilon+1))/( vartheta*(WT)^(epsilon+1) + (1-vartheta)*(WN)^(epsilon+1) );

% Capital compensation share of tradables RH*KH/RK*K- alphaK
g(13)= alphaK - (varthetaK*(RT)^(epsilonK+1))/( varthetaK*(RT)^(epsilonK+1) + (1-varthetaK)*(RN)^(epsilonK+1) );

% Consumption in non tradables - CN
g(14)= CN - C*(1-varphi)*(P/PC)^(-phi);

% Consumption in tradables - CT
g(15)= CT - C*varphi*(1/PC)^(-phi);

% Consumption price index - PC
g(16)= PC - (varphi+(1-varphi)*P^(1-phi))^(1/(1-phi));

% Tradable share of consumption - alphaC
g(17)= alphaC - (varphi*(1/PC)^(1-phi));

% Non tradable Investment - IN
g(18)= IN - (deltaK*K)*(1-varphiI)*((P/PI)^(-phiI));

% Tradable Investment - IT
g(19)= IT - (deltaK*K)*varphiI*((1/PI)^(-phiI));

% Investment price index - PI
g(20)= PI - (varphiI+(1-varphiI)*P^(1-phiI))^(1/(1-phiI));

% Tradable share of investment - alphaI
g(21)= alphaI - (varphiI*(1/PI)^(1-phiI));

% Employment in the traded sector - LT
g(22)= LT - L*(vartheta*(WT/W)^epsilon);

% Employment in the non traded sector - LN
g(23)= LN - L*((1-vartheta)*(WN/W)^epsilon);

% Capital stock in the traded sector - KT
g(24)= KT - K*varthetaK*(RT/RK)^epsilonK;

% Capital stock in the non traded sector - KN
g(25)= KN - K*(1-varthetaK)*(RN/RK)^epsilonK;

% Total government spending - GT
g(26)= (GT+(P*GN)) - omegaG*(YT + (P*YN));

% Non tradable share of government spending
g(27)= (P*GN) - omegaGN*(GT+(P*GN));

% Output per worker in the traded sector - YT
g(28)= YT - ZT*(LT^thetaT)*(KT^(1-thetaT));

% Output per worker in the non traded sector - YN
g(29)= YN - ZN*(LN^thetaN)*(KN^(1-thetaN));

% Desutility from labor
g(30)= VL - ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) ); % Desutility labor

% Non Sep preferences Shimer (2009)
I     = deltaK*K;

%VL        = ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );
V_L       = (sigma-1)*gammaL*L^(1/sigmaL);
V_LL      = (sigma-1)*(gammaL/sigmaL)*(L^((1/sigmaL)-1));
U_C       =  (C^(-sigma))*(VL^sigma);
U_CC      = -sigma*(C^(-sigma-1))*(VL^sigma);
U_L       = ( (C^(1-sigma))*sigma*V_L*(VL^(sigma-1)) )/(1-sigma);
U_LL      = U_L*( (V_LL/V_L) + (sigma-1)*V_L*(VL^(-1)) );
U_CL      = (C^(-sigma))*sigma*V_L*(VL^(sigma-1));
U_LC      = U_CL;

% Solutions C=C(lambda,PN,PH,W); L=L(lambda,PN,PH,W)
a11 = (U_CC/U_C);
a12 = (U_CL/U_C);
a21 = (U_LC/U_L);
a22 = (U_LL/U_L);

% PN, PH, W, lambda
b11 = (1-alphaC)/P;
b12 = 0;

b21 = 0;
b22 = (1/W);

A1 = [a11 a12; a21 a22];
B1 = [b11 b12; b21 b22];
JST1 = inv(A1);
MST1 = JST1*B1;
C_1P = MST1(1,1); C_W = MST1(1,2);
L_1P = MST1(2,1); L_W = MST1(2,2);

% Partial derivatives of W=W(WN,WH)
W_WT   = (W/WT)*alphaL;
W_WN   = (W/WN)*(1-alphaL);
L_WT   = L_W*W_WT;
L_WN   = L_W*W_WN;

% Intermediate solution for CN, CT - Cj=Cj(lambda,P,W)
CN_1P = -(CN/P)*(alphaC*phi) + (CN/C)*C_1P;
CN_WN = (CN/C)*C_W*W_WN;
CN_WT = (CN/C)*C_W*W_WT;

CT_1P = (CT/P)*phi*(1-alphaC) + (CT/C)*C_1P;
CT_WN = (CT/C)*C_W*W_WN;
CT_WT = (CT/C)*C_W*W_WT;

% Solutions LT=LT(lambda,WT,WN,P), LN=LN(lambda,WT,WN,P)
LT_WT  = (LT/WT)*epsilon*(1-alphaL) + (LT/L)*L_WT;
LT_WN  = -(LT/WN)*epsilon*(1-alphaL) + (LT/L)*L_WN;
LT_1P  = (LT/L)*L_1P;

LN_WT  = -(LN/WT)*epsilon*alphaL + (LN/L)*L_WT;
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN;
LN_1P  = (LN/L)*L_1P;

% Solutions Kj=Kj(RH,RN,K), j=H,N
KT_RT = (KT/RT)*epsilonK*(1-alphaK);
KT_RN = -(KT/RN)*epsilonK*(1-alphaK);
KT_1K = (KT/K);

KN_RT = -(KN/RT)*epsilonK*alphaK;
KN_RN = (KN/RN)*epsilonK*alphaK;
KN_1K = (KN/K);

% Solving for WT,WN,RT,RN(P,K,ZT,ZN,lambda)
d11 = - ( (1-thetaT)*(LT_WT/LT) + (1/WT) ); % WT
d12 = - (1-thetaT)*(LT_WN/LT);  % WN
d13 = (1-thetaT)*(KT_RT/KT);  % RT
d14 = (1-thetaT)*(KT_RN/KT); % RN

d21 = - (1-thetaN)*(LN_WT/LN);  % WT
d22 = - ( (1-thetaN)*(LN_WN/LN) + (1/WN) ); % WN
d23 = (1-thetaN)*(KN_RT/KN);  % RT
d24 = (1-thetaN)*(KN_RN/KN); % RN

d31 = thetaT*(LT_WT/LT); % WT
d32 = thetaT*(LT_WN/LT); % WN
d33 = - ( thetaT*(KT_RT/KT) + (1/RT) ); % RT
d34 = - thetaT*(KT_RN/KT); % RN

d41 = thetaN*(LN_WT/LN); % WT
d42 = thetaN*(LN_WN/LN); % WN
d43 = - thetaN*(KN_RT/KN); % RT
d44 = - ( thetaN*(KN_RN/KN) + (1/RN) ); % RN

% P,K,ZT,ZN,lambda
e11  = (1-thetaT)*(LT_1P/LT);    % P
e12  = - (1-thetaT)*(KT_1K/KT);  % K

e21  = (1-thetaN)*(LN_1P/LN) - (1/P); % P
e22  = - (1-thetaN)*(KN_1K/KN);       % K

e31  = - thetaT*(LT_1P/LT);    % P
e32  = thetaT*(KT_1K/KT);      % K

e41  = - ( thetaN*(LN_1P/LN) + (1/P) );    % P
e42  = thetaN*(KN_1K/KN);                   % K

M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X2 = [e11 e12; e21 e22; e31 e32; e41 e42];
JST2 = inv(M2);
MST2 = JST2*X2;
WT_1P = MST2(1,1); WT_1K = MST2(1,2);
WN_1P = MST2(2,1); WN_1K = MST2(2,2);
RT_1P = MST2(3,1); RT_1K = MST2(3,2);
RN_1P = MST2(4,1); RN_1K = MST2(4,2);

% Solving for sectoral labor and sectoral output - Lj,Kj,Yj,(P,K,ZT,ZN,lambda)
LT_P   = LT_1P + (LT_WT*WT_1P) + (LT_WN*WN_1P);
LT_1K  = (LT_WT*WT_1K)  + (LT_WN*WN_1K);

LN_P   = LN_1P + (LN_WT*WT_1P) + (LN_WN*WN_1P);
LN_1K  = (LN_WT*WT_1K)  + (LN_WN*WN_1K);

KT_P   = (KT_RT*RT_1P) + (KT_RN*RN_1P);
KT_2K  = KT_1K  +(KT_RT*RT_1K)  + (KT_RN*RN_1K);

KN_P   = (KN_RT*RT_1P) + (KN_RN*RN_1P);
KN_2K  = KN_1K + (KN_RT*RT_1K)  + (KN_RN*RN_1K);

YT_P   = thetaT*YT*(LT_P/LT) + (1-thetaT)*YT*(KT_P/KT);
YT_1K  = thetaT*YT*(LT_1K/LT) + (1-thetaT)*YT*(KT_2K/KT);

YN_P   = thetaN*YN*(LN_P/LN) + (1-thetaN)*YN*(KN_P/KN);
YN_1K  = thetaN*YN*(LN_1K/LN) + (1-thetaN)*YN*(KN_2K/KN);

% Intermediate solution for CN, CT- Cj=Cj(P,K,ZT,ZN,lambda)
CN_P   = CN_1P + (CN_WT*WT_1P) + (CN_WN*WN_1P);
CN_1K  = (CN_WT*WT_1K) + (CN_WN*WN_1K);

CT_P   = CT_1P + (CT_WT*WT_1P) + (CT_WN*WN_1P);
CT_1K   = (CT_WT*WT_1K) + (CT_WN*WN_1K);

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI);
v_P  = - (1-alphaI)/(kappa*P);

% Solution for J = J(K,Q,PN,PH)
J_P  = K*v_P;
J_1K = deltaK;
J_1Q = K*v_1Q;

% Solution for JN, JT - Jj=Jj(P,K,Q)
I     = deltaK*K;
JN_P = -(IN/P)*(phiI*alphaI) + (IN/I)*J_P;
JN_1K = (IN/I)*J_1K;
JN_1Q = (IN/I)*J_1Q;

JT_P  =  (IT/P)*phiI*(1-alphaI) + (IT/I)*J_P;
JT_1K  = (IT/I)*J_1K;
JT_1Q  = (IT/I)*J_1Q;

% Solving for the relative price P=P(lambda,K,Q,GN)
DeltaP  = (YN_P-CN_P-JN_P);
P_K     = -(1/DeltaP)*(YN_1K - CN_1K - JN_1K);
P_Q     = (JN_1Q/DeltaP);

% Final solutions X=X(K,Q,ZT,ZN)
LT_K  = LT_1K + (LT_P*P_K);
LT_Q  = (LT_P*P_Q);

LN_K  = LN_1K + (LN_P*P_K);
LN_Q  = (LN_P*P_Q);

KT_K  = KT_2K + (KT_P*P_K);
KT_Q  = (KT_P*P_Q);

KN_K  = KN_2K + (KN_P*P_K);
KN_Q  = (KN_P*P_Q);

YT_K  = YT_1K + (YT_P*P_K);
YT_Q  = (YT_P*P_Q);

YN_K  = YN_1K + (YN_P*P_K);
YN_Q  = (YN_P*P_Q);

CT_K  = CT_1K + (CT_P*P_K);
CT_Q  = CT_P*P_Q;

CN_K  = CN_1K + (CN_P*P_K);
CN_Q  = CN_P*P_Q;

JT_K  = JT_1K + (JT_P*P_K);
JT_Q  = JT_1Q + (JT_P*P_Q);

JN_K  = JN_1K + (JN_P*P_K);
JN_Q  = JN_1Q + (JN_P*P_Q);

v_K  = (v_P*P_K);
v_Q  = v_1Q + (v_P*P_Q);

% Solving for sectoral capital rental rats - Rj(K,Q,ZT,ZN)
RT_K = RT_1K + (RT_1P*P_K);
RT_Q = (RT_1P*P_Q);

RN_K = RN_1K + (RN_1P*P_K);
RN_Q = (RN_1P*P_Q);

R_RT = alphaK*(RK/RT);
R_RN = (1-alphaK)*(RK/RN);
R_K  = (R_RT*RT_K) + (R_RN*RN_K);
R_Q  = (R_RT*RT_Q) + (R_RN*RN_Q);

% Elements of the Jacobian Matrix
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + alphaI*phiI*I*(P_K/P);
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + alphaI*phiI*I*(P_Q/P);
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) );
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) );

x11 = Upsilon_K;
x12 = Upsilon_Q;
x21 = Sigma_K;
x22 = Sigma_Q;

J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1);
nu_2 = nu_sorted(2,2);
omega_11 = V_sorted(1,1)/V_sorted(1,1);
omega_21 = V_sorted(2,1)/V_sorted(1,1);

% Intertemporal solvency condition - lambda
B_K   = (YT_K - CT_K - JT_K);
B_Q   = (YT_Q - CT_Q - JT_Q);
N1    = (B_K + (B_Q*omega_21));
H1    = N1/(nu_1-r);
g(31) = (B - B0) - H1*(K-K0);

%clc
%clear

global sigma phi varphi beta
global gammaL sigmaL phiI varphiI
global epsilon vartheta 
global epsilonK varthetaK 
global r deltaK omegaG omegaGN
global ZT ZN ZT_0 ZN_0 thetaT thetaN kappa
global B0 K0 GT GN sigmaT sigmaN
global xiZT chiZT xiZN chiZN barzT barzN gZT gZN 
global barg gG xi chi

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% PML CAC kT>kN                                           %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ZT_0         = 1.00;  
ZN_0         = 1.00;
omegaG       = 0.198; 
omegaGN      = 0.838; 
thetaT_0     = 0.629; 
thetaN_0     = 0.683; 
sigmaL_0     = 3; 
gammaL       = 1; 
sigma        = 2; 
phi_0        = 0.35; 
varphi_0     = 0.467;                   
phiI_0       = 1.00001;                    
varphiI_0    = 0.319;  
kappa_0      = 17; 

epsilon_0    = 0.80; 
vartheta_0   = 0.383;
epsilonK_0   = 0.15;
varthetaK_0  = 0.388; 
  
r            = 0.027; 
beta         = r; 
deltaK       = 0.062;

B0           = 7.7;
K0           = 0;

ZT           = ZT_0;       
ZN           = ZN_0;       
thetaT       = thetaT_0;   
thetaN       = thetaN_0;    
sigmaL       = sigmaL_0;   
phi          = phi_0 ;     
varphi       = varphi_0;  
phiI         = phiI_0;    
varphiI      = varphiI_0; 
kappa        = kappa_0; 
epsilon      = epsilon_0;  
vartheta     = vartheta_0;
epsilonK     = epsilonK_0;  
varthetaK    = varthetaK_0;

sigmaT       = 1; 
sigmaN       = 1; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.270  ; % Consumption
L_ini        = 0.905  ; % Total hours worked
RT_ini       = 0.220  ; % Capital rental rate in sector H
RN_ini       = 0.220  ; % Capital rental rate in sector N
WT_ini       = 3.763  ; % Wage rate in sector H
WN_ini       = 4.244  ; % Wage rate in sector N
W_ini        = 4.065  ; % Aggregate wage index
RK_ini       = 0.220  ; % Aggregate capital rental rate
P_ini        = 3.104  ; % Non-traded good prices
K_ini        = 8.447  ; % Stock of capital
B_ini        = 0.63   ; % Stock of traded Bonds
alphaL_ini   = 0.333  ; % Labor compensation share of tradables
alphaK_ini   = 0.389  ; % Capital compensation share of tradables
CN_ini       = 0.299   ; % Consumption in non tradables 
CT_ini       = 0.589   ; % Consumption in tradables 
PC_ini       = 1.186   ; % Consumption price index
alphaC_ini   = 0.430   ; % Non tradables share of consumption expenditure
IN_ini       = 0.235   ; % Non traded investment
IT_ini       = 0.000   ; % Traded investment
alphaI_ini   = 1.000   ; % Non tradable share of investment expenditure
PI_ini       = 1.486   ; % Investment price index
LT_ini       = 0.322   ; % Labor in sector T
LN_ini       = 0.712   ; % Labor in sector N 
KT_ini       = 3.282  ; % Capital stock in sector H
KN_ini       = 5.165  ; % Capital stock in sector N
GT_ini       = 0.03    ; % Government spending in tradables
GN_ini       = 0.21    ; % Government spending in non tradables 
YT_ini       = 1.935   ; % Output per worker in sector T 
YN_ini       = 1.408   ; % Output per worker in sector N     
VL_ini       = 1.41   ; % Desutility labor 
lambda_ini   = 0.967   ; % Intertemporal Solvency Condition          
                                                          
x0 =[C_ini L_ini RT_ini RN_ini WT_ini WN_ini W_ini RK_ini P_ini K_ini B_ini alphaL_ini alphaK_ini CN_ini CT_ini PC_ini alphaC_ini IN_ini IT_ini alphaI_ini PI_ini LT_ini LN_ini KT_ini KN_ini GT_ini GN_ini YT_ini YN_ini VL_ini lambda_ini];
[x,fval,exitflag]=fsolve('TECH_IML_IMK_CAC_SS0',x0,optimset('display','off','TolFun',1e-011));

C       = x(1)  ; % Consumption
L       = x(2)  ; % Labor supply
RT      = x(3)  ; % Return on traded capital
RN      = x(4)  ; % Return on non-traded capital
WT      = x(5)  ; % Wage rate in sector H
WN      = x(6)  ; % Wage rate in sector N
W       = x(7)  ; % Aggregate wage index
RK      = x(8)  ; % Aggregate capital rental rate
P       = x(9)  ; % Relative price of non tradables
K       = x(10)  ; % Stock of capital
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Labor compensation share of tradables
alphaK  = x(13) ; % Capital compensation share of tradables
CN      = x(14) ; % Consumption in non tradables
CT      = x(15) ; % Consumption in tradables
PC      = x(16) ; % Consumption price index
alphaC  = x(17) ; % Tradable share of consumption - alphaC
IN      = x(18) ; % Non tradable investment
IT      = x(19) ; % Tradable investment
PI      = x(20) ; % Investment price index
alphaI  = x(21) ; % Tradable share of investment
LT      = x(22) ; % Labor in sector T
LN      = x(23) ; % Labor in sector N
KT      = x(24) ; % Capital in sector T
KN      = x(25) ; % Capital in sector N
GT      = x(26) ; % Government spending in tradables
GN      = x(27) ; % Government spending in non tradables
YT      = x(28) ; % Output in sector T
YN      = x(29) ; % Output in sector N
VL      = x(30) ; % Labor disutility
lambda  = x(31) ; % Intertemporal Solvency Condition

% Sectoral outputs and sectoral profits
PiT = YT - (RT*KT) - (WT*LT);
PiN = (P*YN) - (RN*KN) - (WN*LN);
RNP = RN/P;
uKT = 1; 
uKN = 1;  

% Value added and labor share
Y         = (YT) +(P*YN);
omegaYT   = (YT) / Y;
omegaYN   = (P*YN) /Y;
omegaLT   = LT / L;
omegaLN   = LN / L;

% Labor income share in the home traded good and non traded good sector
kT  = KT/LT;
kN  = KN/LN;
yT  = YT/LT;
yN  = YN/LN;
sLT = WT*LT/(YT);
sLN = WN*LN/(P*YN);
sL  = W*L/Y;
k   = K/L;
KTK = KT/K;

% Technology
TFPT    = YT/((LT^thetaT)*(KT^(1-thetaT)));
TFPN    = YN/((LN^thetaN)*(KN^(1-thetaN)));
ZA  = (ZT^omegaYT)*(ZN^(1-omegaYT));

% Unit cost for producting
MN  = ((WN^thetaN)*(RN^(1-thetaN)))/((thetaN^thetaN)*((1-thetaN)^(1-thetaN)));
MT  = ((WT^thetaT)*(RT^(1-thetaT)))/((thetaT^thetaT)*((1-thetaT)^(1-thetaT)));

% Non Sep preferences Shimer (2009)
%VL        = ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );
V_L       = (sigma-1)*gammaL*L^(1/sigmaL);
V_LL      = (sigma-1)*(gammaL/sigmaL)*(L^((1/sigmaL)-1));
U_C       =  (C^(-sigma))*(VL^sigma);
U_CC      = -sigma*(C^(-sigma-1))*(VL^sigma);
U_L       = ( (C^(1-sigma))*sigma*V_L*(VL^(sigma-1)) )/(1-sigma);
U_LL      = U_L*( (V_LL/V_L) + (sigma-1)*V_L*(VL^(-1)) );
U_CL      = (C^(-sigma))*sigma*V_L*(VL^(sigma-1));
U_LC      = U_CL;

% Solutions C=C(lambda,P,W); L=L(lambda,P,W)
a11 = (U_CC/U_C);
a12 = (U_CL/U_C);
a21 = (U_LC/U_L);
a22 = (U_LL/U_L);

% P, W, lambda
b11 = (1-alphaC)/P;
b12 = 0;
b13 = (1/lambda);

b21 = 0;
b22 = (1/W);
b23 = (1/lambda);

A1 = [a11 a12; a21 a22];
B1 = [b11 b12 b13; b21 b22 b23];
JST1 = inv(A1);
MST1 = JST1*B1;
C_1P = MST1(1,1); C_W = MST1(1,2); C_1lambda = MST1(1,3);
L_1P = MST1(2,1); L_W = MST1(2,2); L_1lambda = MST1(2,3);

% Partial derivatives of W=W(WN,WH)
W_WT   = (W/WT)*alphaL;
W_WN   = (W/WN)*(1-alphaL);
L_WT   = L_W*W_WT;
L_WN   = L_W*W_WN;

% Intermediate solution for CN, CT - Cj=Cj(lambda,P,W)
CN_1P = -(CN/P)*(alphaC*phi) + (CN/C)*C_1P;
CN_WN = (CN/C)*C_W*W_WN;
CN_WT = (CN/C)*C_W*W_WT;

CT_1P = (CT/P)*phi*(1-alphaC) + (CT/C)*C_1P;
CT_WN = (CT/C)*C_W*W_WN;
CT_WT = (CT/C)*C_W*W_WT;

CT_1lamb = (CT/C)*C_1lambda;
CN_1lamb = (CN/C)*C_1lambda;

% Solutions LT=LT(lambda,WT,WN,P), LN=LN(lambda,WT,WN,P)
LT_WT  = (LT/WT)*epsilon*(1-alphaL) + (LT/L)*L_WT;
LT_WN  = -(LT/WN)*epsilon*(1-alphaL) + (LT/L)*L_WN;
LT_1P  = (LT/L)*L_1P;

LN_WT  = -(LN/WT)*epsilon*alphaL + (LN/L)*L_WT;
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN;
LN_1P  = (LN/L)*L_1P;

LT_1lamb   = (LT/L)*L_1lambda;
LN_1lamb   = (LN/L)*L_1lambda;

% Solutions Kj=Kj(RH,RN,K), j=H,N
KT_RT = (KT/RT)*epsilonK*(1-alphaK);
KT_RN = -(KT/RN)*epsilonK*(1-alphaK);
KT_1K = (KT/K);

KN_RT = -(KN/RT)*epsilonK*alphaK;
KN_RN = (KN/RN)*epsilonK*alphaK;
KN_1K = (KN/K);

% Solving for WT,WN,RT,RN(P,K,ZT,ZN,lambda)
d11 = - ( (1-thetaT)*(LT_WT/LT) + (1/WT) ); % WT
d12 = - (1-thetaT)*(LT_WN/LT);  % WN
d13 = (1-thetaT)*(KT_RT/KT);  % RT
d14 = (1-thetaT)*(KT_RN/KT); % RN

d21 = - (1-thetaN)*(LN_WT/LN);  % WT
d22 = - ( (1-thetaN)*(LN_WN/LN) + (1/WN) ); % WN
d23 = (1-thetaN)*(KN_RT/KN);  % RT
d24 = (1-thetaN)*(KN_RN/KN); % RN

d31 = thetaT*(LT_WT/LT); % WT
d32 = thetaT*(LT_WN/LT); % WN
d33 = - ( thetaT*(KT_RT/KT) + (1/RT) ); % RT
d34 = - thetaT*(KT_RN/KT); % RN

d41 = thetaN*(LN_WT/LN); % WT
d42 = thetaN*(LN_WN/LN); % WN
d43 = - thetaN*(KN_RT/KN); % RT
d44 = - ( thetaN*(KN_RN/KN) + (1/RN) ); % RN

% P,K,ZT,ZN,lambda
e11  = (1-thetaT)*(LT_1P/LT);    % P
e12  = - (1-thetaT)*(KT_1K/KT);  % K
e13  = - (1/ZT);                 % ZT
e14  = 0;                        % ZN
e15  = (1-thetaT)*(LT_1lamb/LT); % lambda

e21  = (1-thetaN)*(LN_1P/LN) - (1/P); % P
e22  = - (1-thetaN)*(KN_1K/KN);       % K
e23  = 0;                             % ZT
e24  = - (1/ZN);                      % ZN
e25  = (1-thetaN)*(LN_1lamb/LN);      % lambda

e31  = - thetaT*(LT_1P/LT);    % P
e32  = thetaT*(KT_1K/KT);      % K
e33  = - (1/ZT);               % ZT
e34  = 0;                      % ZN
e35  = - thetaT*(LT_1lamb/LT); % lambda

e41  = - ( thetaN*(LN_1P/LN) + (1/P) );    % P
e42  = thetaN*(KN_1K/KN);                   % K
e43  = 0;                                   % ZT
e44  = - (1/ZN);                            % ZN
e45  = - thetaN*(LN_1lamb/LN);              % lambda

M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X2 = [e11 e12 e13 e14 e15; e21 e22 e23 e24 e25; e31 e32 e33 e34 e35; e41 e42 e43 e44 e45];
JST2 = inv(M2);
MST2 = JST2*X2;
WT_1P = MST2(1,1); WT_1K = MST2(1,2); WT_1ZT = MST2(1,3); WT_1ZN = MST2(1,4); WT_1lambda = MST2(1,5);
WN_1P = MST2(2,1); WN_1K = MST2(2,2); WN_1ZT = MST2(2,3); WN_1ZN = MST2(2,4); WN_1lambda = MST2(2,5);
RT_1P = MST2(3,1); RT_1K = MST2(3,2); RT_1ZT = MST2(3,3); RT_1ZN = MST2(3,4); RT_1lambda = MST2(3,5);
RN_1P = MST2(4,1); RN_1K = MST2(4,2); RN_1ZT = MST2(4,3); RN_1ZN = MST2(4,4); RN_1lambda = MST2(4,5);

% Solving for sectoral labor and sectoral output - Lj,Kj,Yj,(P,K,ZT,ZN,lambda)
LT_P   = LT_1P + (LT_WT*WT_1P) + (LT_WN*WN_1P);
LT_1K  = (LT_WT*WT_1K)  + (LT_WN*WN_1K);
LT_1ZT = (LT_WT*WT_1ZT) + (LT_WN*WN_1ZT);
LT_1ZN = (LT_WT*WT_1ZN) + (LT_WN*WN_1ZN);
LT_1lambda = LT_1lamb + (LT_WT*WT_1lambda) + (LT_WN*WN_1lambda);

LN_P   = LN_1P + (LN_WT*WT_1P) + (LN_WN*WN_1P);
LN_1K  = (LN_WT*WT_1K)  + (LN_WN*WN_1K);
LN_1ZT = (LN_WT*WT_1ZT) + (LN_WN*WN_1ZT);
LN_1ZN = (LN_WT*WT_1ZN) + (LN_WN*WN_1ZN);
LN_1lambda = LN_1lamb + (LN_WT*WT_1lambda) + (LN_WN*WN_1lambda);

KT_P   = (KT_RT*RT_1P) + (KT_RN*RN_1P);
KT_2K  = KT_1K  +(KT_RT*RT_1K)  + (KT_RN*RN_1K);
KT_1ZT = (KT_RT*RT_1ZT) + (KT_RN*RN_1ZT);
KT_1ZN = (KT_RT*RT_1ZN) + (KT_RN*RN_1ZN);
KT_1lambda = (KT_RT*RT_1lambda) + (KT_RN*RN_1lambda);

KN_P   = (KN_RT*RT_1P) + (KN_RN*RN_1P);
KN_2K  = KN_1K + (KN_RT*RT_1K)  + (KN_RN*RN_1K);
KN_1ZT = (KN_RT*RT_1ZT) + (KN_RN*RN_1ZT);
KN_1ZN = (KN_RT*RT_1ZN) + (KN_RN*RN_1ZN);
KN_1lambda = (KN_RT*RT_1lambda) + (KN_RN*RN_1lambda);

YT_P   = thetaT*YT*(LT_P/LT) + (1-thetaT)*YT*(KT_P/KT);
YT_1K  = thetaT*YT*(LT_1K/LT) + (1-thetaT)*YT*(KT_2K/KT);
YT_1ZT = thetaT*YT*(LT_1ZT/LT) + (1-thetaT)*YT*(KT_1ZT/KT) + (YT/ZT);
YT_1ZN = thetaT*YT*(LT_1ZN/LT) + (1-thetaT)*YT*(KT_1ZN/KT);
YT_1lambda =  thetaT*YT*(LT_1lambda/LT) + (1-thetaT)*YT*(KT_1lambda/KT);

YN_P   = thetaN*YN*(LN_P/LN) + (1-thetaN)*YN*(KN_P/KN);
YN_1K  = thetaN*YN*(LN_1K/LN) + (1-thetaN)*YN*(KN_2K/KN);
YN_1ZT = thetaN*YN*(LN_1ZT/LN) + (1-thetaN)*YN*(KN_1ZT/KN);
YN_1ZN = thetaN*YN*(LN_1ZN/LN) + (1-thetaN)*YN*(KN_1ZN/KN) + (YN/ZN);
YN_1lambda = thetaN*YN*(LN_1lambda/LN) + (1-thetaN)*YN*(KN_1lambda/KN);

% Intermediate solution for CN, CT- Cj=Cj(P,K,ZT,ZN,lambda)
CN_P       = CN_1P + (CN_WT*WT_1P) + (CN_WN*WN_1P);
CN_1K      = (CN_WT*WT_1K) + (CN_WN*WN_1K);
CN_1ZT     = (CN_WT*WT_1ZT) + (CN_WN*WN_1ZT);
CN_1ZN     = (CN_WT*WT_1ZN) + (CN_WN*WN_1ZN);
CN_1lambda = CT_1lamb + (CN_WT*WT_1lambda) + (CN_WN*WN_1lambda);

CT_P       = CT_1P + (CT_WT*WT_1P) + (CT_WN*WN_1P);
CT_1K      = (CT_WT*WT_1K) + (CT_WN*WN_1K);
CT_1ZT     = (CT_WT*WT_1ZT) + (CT_WN*WN_1ZT);
CT_1ZN     = (CT_WT*WT_1ZN) + (CT_WN*WN_1ZN);
CT_1lambda = CT_1lamb + (CT_WT*WT_1lambda) + (CT_WN*WN_1lambda);

% Investment function I/K = v(Q/PI(P))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI);
v_P  = - (1-alphaI)/(kappa*P);

% Solution for J = J(K,Q,P)
J_1K = deltaK;
J_1Q = K*v_1Q;
J_P  = K*v_P;

% Solution for JN, JT - Jj=Jj(P,K,Q)
I     = deltaK*K;
JN_P  = -(IN/P)*(phiI*alphaI) + (IN/I)*J_P;
JN_1K = (IN/I)*J_1K;
JN_1Q = (IN/I)*J_1Q;

JT_P  =  (IT/P)*phiI*(1-alphaI) + (IT/I)*J_P;
JT_1K = (IT/I)*J_1K;
JT_1Q = (IT/I)*J_1Q;

% Solving for the relative price P=P(lambda,K,Q,ZT,ZN)
DeltaP  = (YN_P-CN_P-JN_P);
P_K     = -(1/DeltaP)*(YN_1K - CN_1K - JN_1K);
P_Q     = (JN_1Q/DeltaP);
P_ZT    = -(1/DeltaP)*(YN_1ZT - CN_1ZT);
P_ZN    = -(1/DeltaP)*(YN_1ZN - CN_1ZN);
P_lambda = -(1/DeltaP)*(YN_1lambda - CN_1lambda);

% Final solutions X=X(K,Q,ZT,ZN)
LT_K  = LT_1K + (LT_P*P_K);
LT_Q  = (LT_P*P_Q);
LT_ZT = LT_1ZT + (LT_P*P_ZT);
LT_ZN = LT_1ZN + (LT_P*P_ZN);
LT_lambda = LT_1lambda + (LT_P*P_lambda);

LN_K  = LN_1K + (LN_P*P_K);
LN_Q  = (LN_P*P_Q);
LN_ZT = LN_1ZT + (LN_P*P_ZT);
LN_ZN = LN_1ZN + (LN_P*P_ZN);
LN_lambda = LN_1lambda + (LN_P*P_lambda);

KT_K  = KT_2K + (KT_P*P_K);
KT_Q  = (KT_P*P_Q);
KT_ZT = KT_1ZT + (KT_P*P_ZT);
KT_ZN = KT_1ZN + (KT_P*P_ZN);
KT_lambda = KT_1lambda + (KT_P*P_lambda);

KN_K  = KN_2K + (KN_P*P_K);
KN_Q  = (KN_P*P_Q);
KN_ZT = KN_1ZT + (KN_P*P_ZT);
KN_ZN = KN_1ZN + (KN_P*P_ZN);
KN_lambda = KN_1lambda + (KN_P*P_lambda);

YT_K  = YT_1K + (YT_P*P_K);
YT_Q  = (YT_P*P_Q);
YT_ZT = YT_1ZT + (YT_P*P_ZT);
YT_ZN = YT_1ZN + (YT_P*P_ZN);
YT_lambda = YT_1lambda + (YT_P*P_lambda);

YN_K  = YN_1K + (YN_P*P_K);
YN_Q  = (YN_P*P_Q);
YN_ZT = YN_1ZT + (YN_P*P_ZT);
YN_ZN = YN_1ZN + (YN_P*P_ZN);
YN_lambda = YN_1lambda + (YN_P*P_lambda);

CT_K  = CT_1K + (CT_P*P_K);
CT_Q  = CT_P*P_Q;
CT_ZT = CT_1ZT + (CT_P*P_ZT);
CT_ZN = CT_1ZN + (CT_P*P_ZN);
CT_lambda = CT_1lambda + (CT_P*P_lambda);

CN_K  = CN_1K + (CN_P*P_K);
CN_Q  = CN_P*P_Q;
CN_ZT = CN_1ZT + (CN_P*P_ZT);
CN_ZN = CN_1ZN + (CN_P*P_ZN);
CN_lambda = CN_1lambda + (CN_P*P_lambda);

JT_K  = JT_1K + (JT_P*P_K);
JT_Q  = JT_1Q + (JT_P*P_Q);
JT_ZT = (JT_P*P_ZT);
JT_ZN = (JT_P*P_ZN);
JT_lambda = (JT_P*P_lambda);

JN_K  = JN_1K + (JN_P*P_K);
JN_Q  = JN_1Q + (JN_P*P_Q);
JN_ZT = (JN_P*P_ZT);
JN_ZN = (JN_P*P_ZN);
JN_lambda = (JN_P*P_lambda);

v_K  = (v_P*P_K);
v_Q  = v_1Q + (v_P*P_Q);
v_ZT = (v_P*P_ZT);
v_ZN = (v_P*P_ZN);
v_lambda = (v_P*P_lambda);

% Solving for sectoral capital rental rats - Rj(K,Q,ZT,ZN)
RT_K = RT_1K + (RT_1P*P_K);
RT_Q = (RT_1P*P_Q);
RT_ZT = RT_1ZT + (RT_1P*P_ZT);
RT_ZN = RT_1ZN + (RT_1P*P_ZN);
RT_lambda = RT_1lambda + (RT_1P*P_lambda);

RN_K = RN_1K + (RN_1P*P_K);
RN_Q = (RN_1P*P_Q);
RN_ZT = RN_1ZT + (RN_1P*P_ZT);
RN_ZN = RN_1ZN + (RN_1P*P_ZN);
RN_lambda = RN_1lambda + (RN_1P*P_lambda);

R_RT = alphaK*(RK/RT); 
R_RN = (1-alphaK)*(RK/RN);
R_K  = (R_RT*RT_K) + (R_RN*RN_K);
R_Q  = (R_RT*RT_Q) + (R_RN*RN_Q);
R_ZT = (R_RT*RT_ZT) + (R_RN*RN_ZT);
R_ZN = (R_RT*RT_ZN) + (R_RN*RN_ZN);
R_lambda = (R_RT*RT_lambda) + (R_RN*RN_lambda);

% Eigenvalues and Eigenvectors
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + alphaI*phiI*I*(P_K/P);
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + alphaI*phiI*I*(P_Q/P);
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) );
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) );

x11 = Upsilon_K;
x12 = Upsilon_Q;
x21 = Sigma_K;
x22 = Sigma_Q;

J = [x11 x12; x21 x22];
[V,nu]=eig(J);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1);
nu2 = nu_sorted(2,2);
omega11 = V_sorted(1,1)/V_sorted(1,1);
omega21 = V_sorted(2,1)/V_sorted(1,1);
omega12 = V_sorted(1,2)/V_sorted(1,2);
omega22 = V_sorted(2,2)/V_sorted(1,2);

TrJ  = trace(J);
DetJ = det(J);

% Intertemporal solvency condition - lambda
B_K   = (YT_K - CT_K - JT_K);
B_Q   = (YT_Q - CT_Q - JT_Q);
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r);

% Solution for Y as function Y=Y(K,P,lambda,ZT,ZN)
Y_K       = YT_K + (P*YN_K) + (P_K*YN);
Y_Q       = YT_Q + (P*YN_Q) + (P_Q*YN);
Y_ZT      = YT_ZT + (P*YN_ZT) + (P_ZT*YN);
Y_ZN      = YT_ZN + (P*YN_ZN) + (P_ZN*YN);
Y_lambda  = YT_lambda + (P*YN_lambda) + (P_lambda*YN);

% Solutions for Wj(K,Q,ZT,ZN,lambda)
WT_K  = WT_1K + (WT_1P*P_K);
WT_Q  = (WT_1P*P_Q);
WT_ZT = WT_1ZT + (WT_1P*P_ZT);
WT_ZN = WT_1ZN + (WT_1P*P_ZN);
WT_lambda = WT_1lambda + (WT_1P*P_lambda);

WN_K  = WN_1K + (WN_1P*P_K);
WN_Q  = (WN_1P*P_Q);
WN_ZT = WN_1ZT + (WN_1P*P_ZT);
WN_ZN = WN_1ZN + (WN_1P*P_ZN);
WN_lambda = WN_1lambda + (WN_1P*P_lambda);

% Solution for W as function W=W((K,Q,ZT,ZN,lambda)
W_K       = (W_WT*WT_K) + (W_WN*WN_K);
W_Q       = (W_WT*WT_Q) + (W_WN*WN_Q);
W_ZT      = (W_WT*WT_ZT) + (W_WN*WN_ZT);
W_ZN      = (W_WT*WT_ZN) + (W_WN*WN_ZN);
W_lambda  = (W_WT*WT_lambda) + (W_WN*WN_lambda);

% Solution for L as function L=L(K,Q,ZT,ZN,lambda)
L_K  = (L_W*W_K) + (L_1P*P_K);
L_Q  = (L_W*W_Q) + (L_1P*P_Q);
L_ZT = (L_W*W_ZT) + (L_1P*P_ZT);
L_ZN = (L_W*W_ZN) + (L_1P*P_ZN);
L_lambda  = L_1lambda + (L_W*W_lambda) + (L_1P*P_lambda);

% Solution for C as function C=C(K,Q,ZT,ZN,lambda)
C_K        = (C_W*W_K) + (C_1P*P_K);
C_Q        = (C_W*W_Q) + (C_1P*P_Q);
C_ZT       = (C_W*W_ZT) + (C_1P*P_ZT);
C_ZN       = (C_W*W_ZN) + (C_1P*P_ZN);
C_lambda   = C_1lambda + (C_W*W_lambda) + (C_1P*P_lambda);

% Solution for J = J(K,Q,ZT,ZN)
J_K   = J_1K + (J_P*P_K);
J_Q   = J_1Q + (J_P*P_Q);
J_ZT  = (J_P*P_ZT);
J_ZN  = (J_P*P_ZN);
J_lambda = (J_P*P_lambda);

% Solution for PC,PI(K,Q,ZT,ZN)
PC_K   = (PC/P)*(1-alphaC)*P_K;
PC_Q   = (PC/P)*(1-alphaC)*P_Q;
PC_ZT  = (PC/P)*(1-alphaC)*P_ZT;
PC_ZN  = (PC/P)*(1-alphaC)*P_ZN;
PC_lambda  = (PC/P)*(1-alphaC)*P_lambda;

PI_K   = (PI/P)*(1-alphaI)*P_K;
PI_Q   = (PI/P)*(1-alphaI)*P_Q;
PI_ZT  = (PI/P)*(1-alphaI)*P_ZT;
PI_ZN  = (PI/P)*(1-alphaI)*P_ZN;
PI_lambda  = (PI/P)*(1-alphaI)*P_lambda;

% Solution for GE=GT + P*GN = G(K,Q,ZT,ZN,G)
G_K   = (P_K*GN);
G_Q   = (P_Q*GN);
G_ZT  = (P_ZT*GN);
G_ZN  = (P_ZN*GN);
G_lambda  = (P_lambda*GN);

% Government spending
G  = GT+ (P*GN);

% Investment
I_check = ( (varphiI^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-varphiI)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1));
I = deltaK*K;
EI = PI*I;
omegaI = PI*I/Y;

% Net exports, current account and saving
NX  = YT-CT-GT-IT;
CA  = (r*B) + YT - CT - GT - IT;
A   = B + (PI*K);
Tax = GT + (P*GN);
Sav = (r*A) + (W*L) - (PC*C) - Tax;

% Real Aggregate Wage
WPC  = W/PC;
WTPC = WT/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Labor income and Capital income shares
alphaL  = (WT*LT)/(W*L);
EL      = W*L;
omegaL  = EL/Y;
EK      = RK*K;
omegaK  = EK/Y;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WT);
YTYN  = (YT/YN);
LTLN  = (LT/LN);

% Consumption
C_check = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1));

% Aggregator function for L=L(LT,LN)
VLAB    = ( (vartheta^(-1/epsilon))*(LT^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) );
L_check = VLAB^(epsilon/(epsilon+1));
L_LT    = ((vartheta)^(-1/epsilon))*(LT/L)^(1/epsilon);
L_LN    = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Aggregator function for K=K(KT,KN)
VCAP    = ( (varthetaK^(-1/epsilonK))*(KT^((epsilonK+1)/epsilonK)) + ((1-varthetaK)^(-1/epsilonK))*(KN^((epsilonK+1)/epsilonK)) );
K_check = VCAP^(epsilonK/(epsilonK+1));
K_KT    = ((varthetaK)^(-1/epsilonK))*(KT/K)^(1/epsilonK);
K_KN    = ((1-varthetaK)^(-1/epsilonK))*(KN/K)^(1/epsilonK);

% Sectoral ratios
omegaINYN = IN/YN;
omegaITYT = IT/YT;
omegaGTYT =  GT / YT;
omegaGNYN =  GN / (YN);
omegaGN   =  (P*GN) / G;

% Targeted ratios
omegaC    =  (PC*C) / Y;
omegaNX   =  NX / Y;
omegaG    =  (GT+P*GN)/Y;
omegaB    = (r*B)/Y;
omegaKY   = K/Y;

% Check the closure of the model
cond1  = (1-thetaT)*(YT/KT)-RT;
cond2  = P*(1-thetaN)*(YN/KN)-RN;
cond3  = thetaT*(YT/LT)-WT;
cond4  = P*thetaN*(YN/LN)-WN;
cond5  = (RT*KT)+(RN*KN)-(RK*K);
cond6  = RK-(deltaK+r)*PI;
cond7  = YN-CN-GN-IN;
cond8  = YT-CT-GT-IT+(r*B);
cond9  = (B-B0) - H1*(K-K0);
cond10 = DetJ - (nu1*nu2);
cond11 = TrJ - (nu1+nu2);
cond12 = (WT*LT) + (WN*LN) - (W*L);
cond13 = (CT/CN) - (varphi/(1-varphi))*P^(phi);
cond14 = (PC*C) - (CT+(P*CN));
cond15 = (W*L) - ((WT*LT)+(WN*LN));
cond16 = Y - (PC*C) - G - (PI*I) + (r*B);
cond17 = Sav;
cond18 = (PC*C) - (CT+(P*CN));
cond19 = (IT/IN) - (varphiI/(1-varphiI))*P^(phiI);
cond20 = (PI*I) - (IT+(P*IN));
cond21 = (RK*K) - ((RT*KT)+(RN*KN));
cond22 = 1 - (omegaK + omegaL);
cond23 = -(U_L*L_LT) - (lambda*WT);
cond24 = -(U_L*L_LN) - (lambda*WN);
cond25 = K_KT - (RT/RK);
cond26 = K_KN - (RN/RK);
cond27 = (KT/KN) - (varthetaK/(1-varthetaK))*(RT/RN)^(epsilonK);
cond28 = P - MN;
cond29 = 1 - MT;

disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaT  : %5.2f   thetaN   : %5.2f',thetaT,thetaN));
disp(sprintf('phi     : %5.2f   varphi   : %5.2f',phi,varphi));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,varphiI));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('epsilonK: %5.2f   varthetaK: %5.2f',epsilonK,varthetaK));
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f sigma   : %5.2f',sigmaL,gammaL,sigma));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZT      : %5.2f   ZN       : %5.2f',ZT,ZN));
disp(sprintf('GT      : %5.2f   GN       : %5.2f  G      : %5.2f',GT,GN,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kT       : %9.3f    kN   : %9.3f',kT,kN));
disp(sprintf('LT       : %9.3f    LN   : %9.3f',LT,LN));
disp(sprintf('KT       : %9.3f    KN   : %9.3f',KT,KN));
disp(sprintf('YT       : %9.3f    YN   : %9.3f',YT,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('alphaL   : %9.3f   ',alphaL));
disp(sprintf('K_check  : %9.3f   ',K_check));
disp(sprintf('alphaK   : %9.3f   ',alphaK));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('CT       :   %7.3f    CN     : %9.3f',CT,CN));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('IT       :   %7.3f    IN     : %9.3f',IT,IN));
disp(sprintf('EI       :   %7.3f',EI));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('RN                 : %9.3f',RN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YT)  : %9.3f',YT));
disp(sprintf('WT                 : %9.3f',WT));
disp(sprintf('RHT                : %9.3f',RT));
disp(sprintf('Profit             : %9.10f',PiT));

disp(' ');
disp('Partial derivatives CT and CN');
disp(sprintf('CN_P  :   %7.3f    CT_P    : %9.3f',CN_P,CT_P));

disp('Partial derivatives LT and LN');
disp(sprintf('LN_K        :   %7.3f  LT_K       : %9.3f',LN_K,LT_K));
disp(sprintf('LN_P        :   %7.3f  LT_P       : %9.3f',LN_P,LT_P));
disp(sprintf('LN_lamb     :   %7.3f  LT_lamb    : %9.3f',LN_lambda,LT_lambda));
disp(sprintf('LN_ZT       :   %7.3f  LT_ZT      : %9.3f',LN_ZT,LT_ZT));
disp(sprintf('LN_ZN       :   %7.3f  LT_ZN      : %9.3f',LN_ZN,LT_ZN));

disp('Partial derivatives KH and KN');
disp(sprintf('KN_Q       :   %7.6f  KT_Q       : %9.6f',KN_Q,KT_Q));
disp(sprintf('KN_K       :   %7.6f  KT_K       : %9.6f',KN_K,KT_K));
disp(sprintf('KN_lambda  :   %7.3f  KT_lambda  : %9.3f',KN_lambda,KT_lambda));
disp(sprintf('KN_ZT      :   %7.6f  KT_ZT      : %9.6f',KN_ZT,KT_ZT));
disp(sprintf('KN_ZN      :   %7.6f  KT_ZN      : %9.6f',KN_ZN,KT_ZN));

disp('Partial derivatives WT and WN');
disp(sprintf('WN_Q       :   %7.6f  WT_Q       : %9.6f',WN_Q,WT_Q));
disp(sprintf('WN_K       :   %7.6f  WT_K       : %9.6f',WN_K,WT_K));
disp(sprintf('WN_lambda  :   %7.3f  WT_lambda  : %9.3f',WN_lambda,WT_lambda));
disp(sprintf('WN_ZT      :   %7.6f  WT_ZT      : %9.6f',WN_ZT,WT_ZT));
disp(sprintf('WN_ZN      :   %7.6f  WT_ZN      : %9.6f',WN_ZN,WT_ZN));

disp('Partial derivatives Y');
disp(sprintf('YN_P       :   %7.6f  YT_P       : %9.6f',YN_P,YT_P));
disp(sprintf('YN_K       :   %7.6f  YT_K       : %9.6f',YN_K,YT_K));
disp(sprintf('YN_lambda  :   %7.3f  YT_lambda  : %9.3f',YN_lambda,YT_lambda));
disp(sprintf('YN_ZT      :   %7.6f  YT_ZT      : %9.6f',YN_ZT,YT_ZT));
disp(sprintf('YN_ZN      :   %7.6f  YT_ZN      : %9.6f',YN_ZN,YT_ZN));

disp('Partial derivatives RT and RN');
disp(sprintf('RN_Q       :   %7.6f  RT_Q       : %9.6f',RN_Q,RT_Q));
disp(sprintf('RN_K       :   %7.6f  RT_K       : %9.6f',RN_K,RT_K));
disp(sprintf('RN_lambda  :   %7.3f  RT_lambda  : %9.3f',RN_lambda,RT_lambda));
disp(sprintf('RN_ZT      :   %7.6f  RT_ZT      : %9.6f',RN_ZT,RT_ZT));
disp(sprintf('RN_ZN      :   %7.6f  RT_ZN      : %9.6f',RN_ZN,RT_ZN));


disp('Partial derivatives of L');
disp(sprintf('L_K        :   %7.3f  L_Q        : %9.3f',L_K,L_Q));
disp(sprintf('L_ZT       :   %7.3f  L_ZN       : %9.3f',L_ZT,L_ZN));
disp(sprintf('L_lambda   :   %7.3f  L_W        : %9.3f',L_lambda,L_W));
disp(sprintf('W_K        :   %7.3f  W_Q        : %9.3f',W_K,W_Q));
disp(sprintf('W_ZT       :   %7.3f  W_ZN       : %9.3f',W_ZT,W_ZN));


disp('Partial derivatives of W');
disp(sprintf('W_K    :   %7.3f   W_Q : %7.3f',W_K,W_Q));
disp(sprintf('W_ZT   :   %7.3f  W_ZN : %9.3f',W_ZT,W_ZN));

disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp(' ');
disp('Linearization');
disp(sprintf('R_K       :  %5.4f  R_Q       : %5.4f',R_K,R_Q));
disp(sprintf('R_ZT      :  %5.4f  R_ZN      : %5.4f',R_ZT,R_ZN));
disp(sprintf('DeltaP    :  %5.4f  P_K       : %5.4f  P_Q     : %5.4f',DeltaP,P_K,P_Q));
disp(sprintf('P_ZT      :  %5.4f  P_ZN      : %5.4f',P_ZT,P_ZN));
disp(sprintf('v_K       :  %5.4f  v_Q       : %5.4f',v_K,v_Q));
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT,omegaYN));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT,omegaGNYN,omegaGN));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN,omegaITYT,omegaB));
disp(sprintf('WT*LT/W*L :  %5.3f RT*KT/R*K :  %5.3f',alphaL,alphaK));
disp(sprintf('IT/PI*I :  %5.3f CT/PC*C :  %5.3f',alphaI,alphaC));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y       :  %5.3f',omegaKY));

disp(' ');                                                                 
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));      
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));      
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));      
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));      
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));      
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));      
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));      
disp(sprintf('Market clearing condition good T  : %9.16f   ',cond8));      
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));      
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));     
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));     
disp(sprintf('Resource constraint for labor     : %9.16f   ',cond12));     
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));     
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));     
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));     
disp(sprintf('Global market clearing condition  : %9.16f   ',cond16));     
disp(sprintf('Private Savings                   : %9.16f   ',cond17));     
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond18));     
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond19));     
disp(sprintf('Investment expenditure check      : %9.16f   ',cond20));     
disp(sprintf('Capital income R*K                : %9.16f   ',cond21));     
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond22));     
disp(sprintf('-U_L = lambda*WT                  : %9.16f   ',cond23));     
disp(sprintf('-U_L = lambda*WN                  : %9.16f   ',cond24));     
disp(sprintf('Traded capital supply             : %9.16f   ',cond25));     
disp(sprintf('Non-traded capital supply         : %9.16f   ',cond26));     
disp(sprintf('Relative capital supply KH/KN     : %9.16f   ',cond27));     
disp(sprintf('P = MN                            : %9.16f   ',cond28));     
disp(sprintf('1 = MT                            : %9.16f   ',cond29));     

kT_0 = kT;  kN_0 = kN; P_0 = P; K_0 = K; C_0 = C;
L_0 = L; W_0 = W; YT_0  = YT; YN_0  = YN; Y_0  = Y; G_0 = G;
PC_0 = PC; CN_0 = CN; CT_0 = CT;
ZT_0 = ZT; ZN_0 = ZN; ZA_0 = ZA; GT_0 = GT; GN_0 = GN;
LT_0 = LT; LN_0 = LN; KT_0 = KT; KN_0 = KN; WT_0 = WT; WN_0 = WN;
Omega_0 = Omega; YTYN_0 = YTYN; LTLN_0 = LTLN;

CA_0 = CA; Sav_0 = Sav; NX_0 = NX; I_0 = I; lambda_0  = lambda; A_0 = A;
B_0 = B; IN_0 = IN; IT_0 = IT; PI_0 = PI; EI_0 = EI;
WPC_0 = WPC; WTPC_0 = WTPC; WNPC_0 = WNPC; RK_0 = RK; PT_0 = 1; PN_0 = P;
uKT_0 = uKT; uKN_0 = uKN;

omegaL_0 = omegaL; omegaK_0 = omegaK; omegaI_0 = omegaI; omegaINYN_0 = omegaINYN;
omegaITYT_0 = omegaITYT; omegaGTYT_0 = omegaGTYT; omegaGNYN_0 = omegaGNYN; omegaGN_0 = omegaGN;
omegaYT_0 = omegaYT; omegaYN_0 = omegaYN; omegaLT_0 = omegaLT; omegaLN_0 = omegaLN;
omegaC_0 =omegaC; omegaNX_0 =omegaNX; omegaG_0 =omegaG; omegaB_0 =omegaB; omegaKY_0 = omegaKY;
alphaL_0 = alphaL; alphaK_0 = alphaK; alphaC_0 = alphaC; alphaI_0 = alphaI;
sLT_0 = sLT; sLN_0 = sLN; sL_0 = sL; VL_0 = VL;
RT_0 = RT; RN_0 = RN; RNP_0 = RNP;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Permanent Technology Shock                      %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B0       = B_0;
K0       = K_0; 
GT       = GT_0; 
GN       = GN_0;                                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                  
%%%%%%%  Permanent increase in ZA %%%  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
barg     = 0.0000000000001;                                                      
xi       = 0.0000000000001;                                                      
chi      = 0.0000000000001;                                                      
gG       = 0.0000000000001;                                                       
filename = 'Calibration_shock_exoTOT_asym'; 
sheet    = 5;                                                                    
xlRange  = 'C3:D6';                                                              
datac = xlsread(filename,sheet,xlRange);                                         
parameters = xlsread(filename,sheet,xlRange);                                  
                                                                                 
barzT    = parameters(1,1);                                                      
barzN    = parameters(1,2);                                                      
                                                                                 
gZT      = parameters(2,1);                                                      
gZN      = parameters(2,2);                                                      
                                                                                 
xiZT     = parameters(3,1);                                                      
chiZT    = parameters(4,1);                                                      
xiZN     = parameters(3,2);                                                      
chiZN    = parameters(4,2);                                                      
                                                                                 
ZT       = ZT_0*(1+gZT);                                                         
ZN       = ZN_0*(1+gZN);                                                         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                                                                     
x0 =[C_0 L_0 RT_0 RN_0 WT_0 WN_0 W_0 RK_0 P_0 K_0 B_0 alphaL_0 alphaK_0 CN_0 CT_0 PC_0 IN_0 IT_0 PI_0 LT_0 LN_0 KT_0 KN_0 YT_0 YN_0 VL_0 lambda_0];
[x,fval,exitflag]=fsolve('TECH_IML_IMK_CAC_perm',x0,optimset('display','off','TolFun',1e-011));
C       = x(1)  ; % Consumption                                 
L       = x(2)  ; % Labor supply                                
RT      = x(3)  ; % Return on traded capital                    
RN      = x(4)  ; % Return on non-traded capital                
WT      = x(5)  ; % Wage rate in sector H                       
WN      = x(6)  ; % Wage rate in sector N                       
W       = x(7)  ; % Aggregate wage index                        
RK      = x(8)  ; % Aggregate capital rental rate               
P       = x(9)  ; % Relative price of non tradables             
K       = x(10)  ; % Stock of capital                           
B       = x(11) ; % Stock of Traded Bonds                       
alphaL  = x(12) ; % Labor compensation share of tradables       
alphaK  = x(13) ; % Capital compensation share of tradables     
CN      = x(14) ; % Consumption in non tradables                
CT      = x(15) ; % Consumption in tradables                    
PC      = x(16) ; % Consumption price index                     
IN      = x(17) ; % Non tradable investment                     
IT      = x(18) ; % Tradable investment                         
PI      = x(19) ; % Investment price index                      
LT      = x(20) ; % Labor in sector T                           
LN      = x(21) ; % Labor in sector N                           
KT      = x(22) ; % Capital in sector T                         
KN      = x(23) ; % Capital in sector N                         
YT      = x(24) ; % Output in sector T                          
YN      = x(25) ; % Output in sector N                          
VL      = x(26) ; % Labor disutility                            
lambda  = x(27) ; % Intertemporal Solvency Condition 

% Shares
I = deltaK*K; 
alphaC = CT/(PC*C); 
alphaI = IT/(PI*I); 
alphaL_check = WT*LT/(W*L); 
alphaC_check = (varphi*(1/PC)^(1-phi));
alphaI_check = (varphiI*(1/PI)^(1-phiI));

% Unit cost for producing                                                        
MN  = (((WN/ZN)^thetaN)*((RN/ZN)^(1-thetaN)))/((thetaN^thetaN)*((1-thetaN)^(1-thetaN)));   
MT  = (((WT/ZT)^thetaT)*((RT/ZT)^(1-thetaT)))/((thetaT^thetaT)*((1-thetaT)^(1-thetaT)));
% Unit cost for producting
%MN  = ((WN^thetaN)*(RN^(1-thetaN)))/((thetaN^thetaN)*((1-thetaN)^(1-thetaN)));
%MT  = ((WT^thetaT)*(RT^(1-thetaT)))/((thetaT^thetaT)*((1-thetaT)^(1-thetaT)));

% Sectoral outputs and sectoral profits
PiT = YT - (RT*KT) - (WT*LT);
PiN = (P*YN) - (RN*KN) - (WN*LN);
RNP = RN/P;
PT = 1;

% Value added and labor share
omegaYT   = (YT) / Y;
omegaYN   = (P*YN) /Y;
omegaLT   = LT / L;
omegaLN   = LN / L;

% Labor income share in the home traded good and non traded good sector
kT  = KT/LT;
kN  = KN/LN;
yT  = YT/LT;
yN  = YN/LN;
sLT = WT*LT/(YT);
sLN = WN*LN/(P*YN);
sL  = W*L/Y;
k   = K/L;
KTK = KT/K;
Y   = YT + (P*YN);
YR  = YT + (P_0*YN); 
uKT = 1; 
uKN = 1; 

% Technology
TFPT    = YT/((LT^thetaT)*(KT^(1-thetaT)));
TFPN    = YN/((LN^thetaN)*(KN^(1-thetaN)));
ZA  = (ZT^omegaYT_0)*(ZN^(1-omegaYT_0));

% Non Sep preferences Shimer (2009)
%VL        = ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );
V_L       = (sigma-1)*gammaL*L^(1/sigmaL);
V_LL      = (sigma-1)*(gammaL/sigmaL)*(L^((1/sigmaL)-1));
U_C       =  (C^(-sigma))*(VL^sigma);
U_CC      = -sigma*(C^(-sigma-1))*(VL^sigma);
U_L       = ( (C^(1-sigma))*sigma*V_L*(VL^(sigma-1)) )/(1-sigma);
U_LL      = U_L*( (V_LL/V_L) + (sigma-1)*V_L*(VL^(-1)) );
U_CL      = (C^(-sigma))*sigma*V_L*(VL^(sigma-1));
U_LC      = U_CL;

% Solutions C=C(lambda,P,W); L=L(lambda,P,W)
a11 = (U_CC/U_C);
a12 = (U_CL/U_C);
a21 = (U_LC/U_L);
a22 = (U_LL/U_L);

% P, W, lambda
b11 = (1-alphaC)/P;
b12 = 0;
b13 = (1/lambda);

b21 = 0;
b22 = (1/W);
b23 = (1/lambda);

A1 = [a11 a12; a21 a22];
B1 = [b11 b12 b13; b21 b22 b23];
JST1 = inv(A1);
MST1 = JST1*B1;
C_1P = MST1(1,1); C_W = MST1(1,2);
L_1P = MST1(2,1); L_W = MST1(2,2);

% Partial derivatives of W=W(WN,WH)
W_WT   = (W/WT)*alphaL;
W_WN   = (W/WN)*(1-alphaL);
L_WT   = L_W*W_WT;
L_WN   = L_W*W_WN;

% Intermediate solution for CN, CT - Cj=Cj(lambda,P,W)
CN_1P = -(CN/P)*(alphaC*phi) + (CN/C)*C_1P;
CN_WN = (CN/C)*C_W*W_WN;
CN_WT = (CN/C)*C_W*W_WT;

CT_1P = (CT/P)*phi*(1-alphaC) + (CT/C)*C_1P;
CT_WN = (CT/C)*C_W*W_WN;
CT_WT = (CT/C)*C_W*W_WT;

% Solutions LT=LT(lambda,WT,WN,P), LN=LN(lambda,WT,WN,P)
LT_WT  = (LT/WT)*epsilon*(1-alphaL) + (LT/L)*L_WT;
LT_WN  = -(LT/WN)*epsilon*(1-alphaL) + (LT/L)*L_WN;
LT_1P  = (LT/L)*L_1P;

LN_WT  = -(LN/WT)*epsilon*alphaL + (LN/L)*L_WT;
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN;
LN_1P  = (LN/L)*L_1P;

% Solutions Kj=Kj(RH,RN,K), j=H,N
KT_RT = (KT/RT)*epsilonK*(1-alphaK);
KT_RN = -(KT/RN)*epsilonK*(1-alphaK);
KT_1K  = (KT/K);

KN_RT = -(KN/RT)*epsilonK*alphaK;
KN_RN = (KN/RN)*epsilonK*alphaK;
KN_1K  = (KN/K);

% Solving for WT,WN,RT,RN(P,K,ZT,ZN,lambda)
d11 = - ( (1-thetaT)*(LT_WT/LT) + (1/WT) ); % WT
d12 = - (1-thetaT)*(LT_WN/LT);  % WN
d13 = (1-thetaT)*(KT_RT/KT);  % RT
d14 = (1-thetaT)*(KT_RN/KT); % RN

d21 = - (1-thetaN)*(LN_WT/LN);  % WT
d22 = - ( (1-thetaN)*(LN_WN/LN) + (1/WN) ); % WN
d23 = (1-thetaN)*(KN_RT/KN);  % RT
d24 = (1-thetaN)*(KN_RN/KN); % RN

d31 = thetaT*(LT_WT/LT); % WT
d32 = thetaT*(LT_WN/LT); % WN
d33 = - ( thetaT*(KT_RT/KT) + (1/RT) ); % RT
d34 = - thetaT*(KT_RN/KT); % RN

d41 = thetaN*(LN_WT/LN); % WT
d42 = thetaN*(LN_WN/LN); % WN
d43 = - thetaN*(KN_RT/KN); % RT
d44 = - ( thetaN*(KN_RN/KN) + (1/RN) ); % RN

% P,K,ZT,ZN,lambda
e11  = (1-thetaT)*(LT_1P/LT);    % P
e12  = - (1-thetaT)*(KT_1K/KT);  % K
e13  = - (1/ZT);                 % ZT
e14  = 0;                        % ZN

e21  = (1-thetaN)*(LN_1P/LN) - (1/P); % P
e22  = - (1-thetaN)*(KN_1K/KN);       % K
e23  = 0;                             % ZT
e24  = - (1/ZN);                      % ZN

e31  = - thetaT*(LT_1P/LT);    % P
e32  = thetaT*(KT_1K/KT);      % K
e33  = - (1/ZT);               % ZT
e34  = 0;                      % ZN

e41  = - ( thetaN*(LN_1P/LN) + (1/P) );    % P
e42  = thetaN*(KN_1K/KN);                   % K
e43  = 0;                                   % ZT
e44  = - (1/ZN);                            % ZN

M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X2 = [e11 e12 e13 e14; e21 e22 e23 e24; e31 e32 e33 e34; e41 e42 e43 e44];
JST2 = inv(M2);
MST2 = JST2*X2;
WT_1P = MST2(1,1); WT_1K = MST2(1,2); WT_1ZT = MST2(1,3); WT_1ZN = MST2(1,4);
WN_1P = MST2(2,1); WN_1K = MST2(2,2); WN_1ZT = MST2(2,3); WN_1ZN = MST2(2,4);
RT_1P = MST2(3,1); RT_1K = MST2(3,2); RT_1ZT = MST2(3,3); RT_1ZN = MST2(3,4);
RN_1P = MST2(4,1); RN_1K = MST2(4,2); RN_1ZT = MST2(4,3); RN_1ZN = MST2(4,4);

% Solving for sectoral labor and sectoral output - Lj,Kj,Yj,(P,K,ZT,ZN,lambda)
LT_P   = LT_1P + (LT_WT*WT_1P) + (LT_WN*WN_1P);
LT_1K  = (LT_WT*WT_1K)  + (LT_WN*WN_1K);
LT_1ZT = (LT_WT*WT_1ZT) + (LT_WN*WN_1ZT);
LT_1ZN = (LT_WT*WT_1ZN) + (LT_WN*WN_1ZN);

LN_P   = LN_1P + (LN_WT*WT_1P) + (LN_WN*WN_1P);
LN_1K  = (LN_WT*WT_1K)  + (LN_WN*WN_1K);
LN_1ZT = (LN_WT*WT_1ZT) + (LN_WN*WN_1ZT);
LN_1ZN = (LN_WT*WT_1ZN) + (LN_WN*WN_1ZN);

KT_P   = (KT_RT*RT_1P) + (KT_RN*RN_1P);
KT_2K  = KT_1K  +(KT_RT*RT_1K)  + (KT_RN*RN_1K);
KT_1ZT = (KT_RT*RT_1ZT) + (KT_RN*RN_1ZT);
KT_1ZN = (KT_RT*RT_1ZN) + (KT_RN*RN_1ZN);

KN_P   = (KN_RT*RT_1P) + (KN_RN*RN_1P);
KN_2K  = KN_1K + (KN_RT*RT_1K)  + (KN_RN*RN_1K);
KN_1ZT = (KN_RT*RT_1ZT) + (KN_RN*RN_1ZT);
KN_1ZN = (KN_RT*RT_1ZN) + (KN_RN*RN_1ZN);

YT_P   = thetaT*YT*(LT_P/LT) + (1-thetaT)*YT*(KT_P/KT);                    
YT_1K  = thetaT*YT*(LT_1K/LT) + (1-thetaT)*YT*(KT_2K/KT);                  
YT_1ZT = thetaT*YT*(LT_1ZT/LT) + (1-thetaT)*YT*(KT_1ZT/KT) + (YT/ZT);      
YT_1ZN = thetaT*YT*(LT_1ZN/LT) + (1-thetaT)*YT*(KT_1ZN/KT);                

YN_P   = thetaN*YN*(LN_P/LN) + (1-thetaN)*YN*(KN_P/KN);                
YN_1K  = thetaN*YN*(LN_1K/LN) + (1-thetaN)*YN*(KN_2K/KN);              
YN_1ZT = thetaN*YN*(LN_1ZT/LN) + (1-thetaN)*YN*(KN_1ZT/KN);            
YN_1ZN = thetaN*YN*(LN_1ZN/LN) + (1-thetaN)*YN*(KN_1ZN/KN) + (YN/ZN);  

% Intermediate solution for CN, CT- Cj=Cj(P,K,ZT,ZN,lambda)
CN_P       = CN_1P + (CN_WT*WT_1P) + (CN_WN*WN_1P);
CN_1K      = (CN_WT*WT_1K) + (CN_WN*WN_1K);
CN_1ZT     = (CN_WT*WT_1ZT) + (CN_WN*WN_1ZT);
CN_1ZN     = (CN_WT*WT_1ZN) + (CN_WN*WN_1ZN);

CT_P       = CT_1P + (CT_WT*WT_1P) + (CT_WN*WN_1P);
CT_1K      = (CT_WT*WT_1K) + (CT_WN*WN_1K);
CT_1ZT     = (CT_WT*WT_1ZT) + (CT_WN*WN_1ZT);
CT_1ZN     = (CT_WT*WT_1ZN) + (CT_WN*WN_1ZN);

% Investment function I/K = v(Q/PI(P))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI);
v_P  = - (1-alphaI)/(kappa*P);

% Solution for J = J(K,Q,P)
J_1K = deltaK;
J_1Q = K*v_1Q;
J_P  = K*v_P;

% Solution for JN, JT - Jj=Jj(P,K,Q)
I     = deltaK*K;
JN_P  = -(IN/P)*(phiI*alphaI) + (IN/I)*J_P;
JN_1K = (IN/I)*J_1K;
JN_1Q = (IN/I)*J_1Q;

JT_P  =  (IT/P)*phiI*(1-alphaI) + (IT/I)*J_P;
JT_1K = (IT/I)*J_1K;
JT_1Q = (IT/I)*J_1Q;

% Solving for the relative price P=P(lambda,K,Q,ZT,ZN)
DeltaP  = (YN_P-CN_P-JN_P);
P_K     = -(1/DeltaP)*(YN_1K - CN_1K - JN_1K);
P_Q     = (JN_1Q/DeltaP);
P_ZT    = -(1/DeltaP)*(YN_1ZT - CN_1ZT);
P_ZN    = -(1/DeltaP)*(YN_1ZN - CN_1ZN);

% Final solutions X=X(K,Q,ZT,ZN)
LT_K  = LT_1K + (LT_P*P_K);
LT_Q  = (LT_P*P_Q);
LT_ZT = LT_1ZT + (LT_P*P_ZT);
LT_ZN = LT_1ZN + (LT_P*P_ZN);

LN_K  = LN_1K + (LN_P*P_K);
LN_Q  = (LN_P*P_Q);
LN_ZT = LN_1ZT + (LN_P*P_ZT);
LN_ZN = LN_1ZN + (LN_P*P_ZN);

KT_K  = KT_2K + (KT_P*P_K);
KT_Q  = (KT_P*P_Q);
KT_ZT = KT_1ZT + (KT_P*P_ZT);
KT_ZN = KT_1ZN + (KT_P*P_ZN);

KN_K  = KN_2K + (KN_P*P_K);
KN_Q  = (KN_P*P_Q);
KN_ZT = KN_1ZT + (KN_P*P_ZT);
KN_ZN = KN_1ZN + (KN_P*P_ZN);

YT_K  = YT_1K + (YT_P*P_K);
YT_Q  = (YT_P*P_Q);
YT_ZT = YT_1ZT + (YT_P*P_ZT);
YT_ZN = YT_1ZN + (YT_P*P_ZN);

YN_K  = YN_1K + (YN_P*P_K);
YN_Q  = (YN_P*P_Q);
YN_ZT = YN_1ZT + (YN_P*P_ZT);
YN_ZN = YN_1ZN + (YN_P*P_ZN);

CT_K  = CT_1K + (CT_P*P_K);
CT_Q  = CT_P*P_Q;
CT_ZT = CT_1ZT + (CT_P*P_ZT);
CT_ZN = CT_1ZN + (CT_P*P_ZN);

CN_K  = CN_1K + (CN_P*P_K);
CN_Q  = CN_P*P_Q;
CN_ZT = CN_1ZT + (CN_P*P_ZT);
CN_ZN = CN_1ZN + (CN_P*P_ZN);

JT_K  = JT_1K + (JT_P*P_K);
JT_Q  = JT_1Q + (JT_P*P_Q);
JT_ZT = (JT_P*P_ZT);
JT_ZN = (JT_P*P_ZN);

JN_K  = JN_1K + (JN_P*P_K);
JN_Q  = JN_1Q + (JN_P*P_Q);
JN_ZT = (JN_P*P_ZT);
JN_ZN = (JN_P*P_ZN);

v_K  = (v_P*P_K);
v_Q  = v_1Q + (v_P*P_Q);
v_ZT = (v_P*P_ZT);
v_ZN = (v_P*P_ZN);

% Solving for sectoral capital rental rats - Rj(K,Q,ZT,ZN)
RT_K = RT_1K + (RT_1P*P_K);
RT_Q = (RT_1P*P_Q);
RT_ZT = RT_1ZT + (RT_1P*P_ZT);
RT_ZN = RT_1ZN + (RT_1P*P_ZN);

RN_K = RN_1K + (RN_1P*P_K);
RN_Q = (RN_1P*P_Q);
RN_ZT = RN_1ZT + (RN_1P*P_ZT);
RN_ZN = RN_1ZN + (RN_1P*P_ZN);

R_RT = alphaK*(RK/RT); 
R_RN = (1-alphaK)*(RK/RN);
R_K  = (R_RT*RT_K) + (R_RN*RN_K);
R_Q  = (R_RT*RT_Q) + (R_RN*RN_Q);
R_ZT = (R_RT*RT_ZT) + (R_RN*RN_ZT);
R_ZN = (R_RT*RT_ZN) + (R_RN*RN_ZN);

% Eigenvalues and Eigenvectors
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + alphaI*phiI*I*(P_K/P);
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + alphaI*phiI*I*(P_Q/P);
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) );
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) );

x11 = Upsilon_K;
x12 = Upsilon_Q;
x21 = Sigma_K;
x22 = Sigma_Q;

J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1);
nu_2 = nu_sorted(2,2);
omega_11 = V_sorted(1,1)/V_sorted(1,1);
omega_21 = V_sorted(2,1)/V_sorted(1,1);
omega_12 = V_sorted(1,2)/V_sorted(1,2);
omega_22 = V_sorted(2,2)/V_sorted(1,2);

TrJ = trace(J);
DetJ = det(J);

% Solutions
Upsilon_ZT = (I/IN)*(YN_ZT-CN_ZT) + (alphaI*phiI*I)*(P_ZT/P);
Upsilon_ZN = (I/IN)*(YN_ZN-CN_ZN) + (alphaI*phiI*I)*(P_ZN/P);

Sigma_ZT   = -( R_ZT + (PI*kappa*v_ZT*deltaK) );
Sigma_ZN   = -( R_ZN + (PI*kappa*v_ZN*deltaK) );

%%%%%%%%%%%%%%%%%% Solutions for Permanent Shocks %%%%%%%%%%%%%%%%%%%%
Vnorm = [omega_11 omega_12; omega_21 omega_22];
Vinv   = inv(Vnorm);
u11    = Vinv(1,1);
u12    = Vinv(1,2);
u21    = Vinv(2,1);
u22    = Vinv(2,2);

s11   = (u11*Upsilon_ZT) + (u12*Sigma_ZT);
s12   = (u11*Upsilon_ZN) + (u12*Sigma_ZN);

s21   = (u21*Upsilon_ZT) + (u22*Sigma_ZT);
s22   = (u21*Upsilon_ZN) + (u22*Sigma_ZN);

DeltaZT_1   = - s11*ZT_0*(1/(nu_1+xiZT));
DeltaZN_1   = - s12*ZN_0*(1/(nu_1+xiZN));

DeltaZT_2   = s21*ZT_0*(1/(nu_2+xiZT));
DeltaZN_2   = s22*ZN_0*(1/(nu_2+xiZN));

ThetaG_1    = (1-barg)*((nu_1+xi)/(nu_1+chi));
ThetaG_2    = (1-barg)*((nu_2+xi)/(nu_2+chi));
ThetaZT_1   = (1-barzT)*((nu_1+xiZT)/(nu_1+chiZT));
ThetaZT_2   = (1-barzT)*((nu_2+xiZT)/(nu_2+chiZT));
ThetaZN_1   = (1-barzN)*((nu_1+xiZN)/(nu_1+chiZN));
ThetaZN_2   = (1-barzN)*((nu_2+xiZN)/(nu_2+chiZN));

X20 = - DeltaZT_2*(1-ThetaZT_2) - DeltaZN_2*(1-ThetaZN_2);
X10 = (K0-K) - X20;
X11 = X10 - DeltaZT_1*(1-ThetaZT_1) - DeltaZN_1*(1-ThetaZN_1);

% Intertemporal solvency condition - lambda
B_K    = (YT_K - CT_K - JT_K);
B_Q    = (YT_Q - CT_Q - JT_Q);
B_ZT   = (YT_ZT - CT_ZT - JT_ZT);
B_ZN   = (YT_ZN - CT_ZN - JT_ZN);

N1           = (B_K + (B_Q*omega_21));
N2           = (B_K + (B_Q*omega_22));

ThetaG_prime   = (1-barg)*((xi+r)/(chi+r));
ThetaG_1prime  = ThetaG_1*((xi+r)/(chi+r));
ThetaG_2prime  = ThetaG_2*((xi+r)/(chi+r));
ThetaZT_prime  = (1-barzT)*((xiZT+r)/(chiZT+r));
ThetaZT_1prime = ThetaZT_1*((xiZT+r)/(chiZT+r));
ThetaZT_2prime = ThetaZT_2*((xiZT+r)/(chiZT+r));
ThetaZN_prime  = (1-barzN)*((xiZN+r)/(chiZN+r));
ThetaZN_1prime = ThetaZN_1*((xiZN+r)/(chiZN+r));
ThetaZN_2prime = ThetaZN_2*((xiZN+r)/(chiZN+r));

wB1   = N1*X11;
wBZT2 = B_ZT*ZT_0*(1-ThetaZT_prime) + N1*DeltaZT_1*(1-ThetaZT_1prime) - N2*DeltaZT_2*(1-ThetaZT_2prime);
wBZN2 = B_ZN*ZN_0*(1-ThetaZN_prime) + N1*DeltaZN_1*(1-ThetaZN_1prime) - N2*DeltaZN_2*(1-ThetaZN_2prime);

% Solutions for Wj(K,Q,ZT,ZN,lambda)
WT_K  = WT_1K + (WT_1P*P_K);
WT_Q  = (WT_1P*P_Q);
WT_ZT = WT_1ZT + (WT_1P*P_ZT);
WT_ZN = WT_1ZN + (WT_1P*P_ZN);

WN_K  = WN_1K + (WN_1P*P_K);
WN_Q  = (WN_1P*P_Q);
WN_ZT = WN_1ZT + (WN_1P*P_ZT);
WN_ZN = WN_1ZN + (WN_1P*P_ZN);

% Solution for W as function W=W((K,Q,ZT,ZN,lambda)
W_K       = (W_WT*WT_K) + (W_WN*WN_K);
W_Q       = (W_WT*WT_Q) + (W_WN*WN_Q);
W_ZT      = (W_WT*WT_ZT) + (W_WN*WN_ZT);
W_ZN      = (W_WT*WT_ZN) + (W_WN*WN_ZN);

% Solution for L as function L=L(K,Q,ZT,ZN,lambda)
L_K  = (L_W*W_K) + (L_1P*P_K);
L_Q  = (L_W*W_Q) + (L_1P*P_Q);
L_ZT = (L_W*W_ZT) + (L_1P*P_ZT);
L_ZN = (L_W*W_ZN) + (L_1P*P_ZN);

% Solution for C as function C=C(K,Q,ZT,ZN,lambda)
C_K        = (C_W*W_K) + (C_1P*P_K);
C_Q        = (C_W*W_Q) + (C_1P*P_Q);
C_ZT       = (C_W*W_ZT) + (C_1P*P_ZT);
C_ZN       = (C_W*W_ZN) + (C_1P*P_ZN);

% Solution for J = J(K,Q,ZT,ZN)
J_K   = J_1K + (J_P*P_K);
J_Q   = J_1Q + (J_P*P_Q);
J_ZT  = (J_P*P_ZT);
J_ZN  = (J_P*P_ZN);

% Solution for PC,PI(K,Q,ZT,ZN)
PC_K   = (PC/P)*(1-alphaC)*P_K;
PC_Q   = (PC/P)*(1-alphaC)*P_Q;
PC_ZT  = (PC/P)*(1-alphaC)*P_ZT;
PC_ZN  = (PC/P)*(1-alphaC)*P_ZN;

PI_K   = (PI/P)*(1-alphaI)*P_K;
PI_Q   = (PI/P)*(1-alphaI)*P_Q;
PI_ZT  = (PI/P)*(1-alphaI)*P_ZT;
PI_ZN  = (PI/P)*(1-alphaI)*P_ZN;

% Solution for GE=GT + P*GN = G(K,Q,ZT,ZN,G)
G_K   = (P_K*GN);
G_Q   = (P_Q*GN);
G_ZT  = (P_ZT*GN);
G_ZN  = (P_ZN*GN);

% Solution for the stock of financial wealth
A_K   = (W_K*L)+(W*L_K)-G_K-((PC_K*C)+(PC*C_K));
A_Q   = (W_Q*L)+(W*L_Q)-G_Q-((PC_Q*C)+(PC*C_Q));
A_ZT  = (W_ZT*L)+(W*L_ZT)-G_ZT-((PC_ZT*C)+(PC*C_ZT));
A_ZN  = (W_ZN*L)+(W*L_ZN)-G_ZN-((PC_ZN*C)+(PC*C_ZN));

M1    = A_K + (A_Q*omega_21);
M2    = A_K + (A_Q*omega_22);

wA1   = (M1*X11);
wAZT2 = A_ZT*ZT_0*(1-ThetaZT_prime) + M1*DeltaZT_1*(1-ThetaZT_1prime) - M2*DeltaZT_2*(1-ThetaZT_2prime);
wAZN2 = A_ZN*ZN_0*(1-ThetaZN_prime) + M1*DeltaZN_1*(1-ThetaZN_1prime) - M2*DeltaZN_2*(1-ThetaZN_2prime);
dA_bias = (wA1/(r-nu_1))  + (wAZT2/(xiZT+r)) + (wAZN2/(xiZN+r));

% Solution for the labor income share sLj=LISj(K,Q,ZT,ZN)
LIST_K  = sLT*( (WT_K/WT) + (LT_K/LT)  - (YT_K/YT) );
LIST_Q  = sLT*( (WT_Q/WT) + (LT_Q/LT)  - (YT_Q/YT) );
LIST_ZT = sLT*( (WT_ZT/WT) + (LT_ZT/LT) - (YT_ZT/YT) );
LIST_ZN = sLT*( (WT_ZN/WT) + (LT_ZN/LT) - (YT_ZN/YT) );

LISN_K  = sLN*( (WN_K/WN) + (LN_K/LN) - (P_K/P) - (YN_K/YN) );
LISN_Q  = sLN*( (WN_Q/WN) + (LN_Q/LN) - (P_Q/P) - (YN_Q/YN) );
LISN_ZT = sLN*( (WN_ZT/WN) + (LN_ZT/LN) - (P_ZT/P) - (YN_ZT/YN) );
LISN_ZN = sLN*( (WN_ZN/WN) + (LN_ZN/LN) - (P_ZN/P) - (YN_ZN/YN) );

% Solutions for the relative wages Wj/W(K,Q,ZT,ZN);
WTW_K = (WT/W)*( (WT_K/WT) - (W_K/W) );
WTW_Q = (WT/W)*( (WT_Q/WT) - (W_Q/W) );
WTW_ZT = (WT/W)*( (WT_ZT/WT) - (W_ZT/W) );
WTW_ZN = (WT/W)*( (WT_ZN/WT) - (W_ZN/W) );

WNW_K = (WN/W)*( (WN_K/WN) - (W_K/W) );
WNW_Q = (WN/W)*( (WN_Q/WN) - (W_Q/W) );
WNW_ZT = (WN/W)*( (WN_ZT/WN) - (W_ZT/W) );
WNW_ZN = (WN/W)*( (WN_ZN/WN) - (W_ZN/W) );

% Solution for Wj/PC,W/PC(K,Q,ZT,ZN);
WTPC_K  = WTPC*( (WT_K/WT) - (PC_K/PC) );
WTPC_Q  = WTPC*( (WT_Q/WT) - (PC_Q/PC) );
WTPC_ZT = WTPC*( (WT_ZT/WT) - (PC_ZT/PC) );
WTPC_ZN = WTPC*( (WT_ZN/WT) - (PC_ZN/PC) );

WNPC_K  = WNPC*( (WN_K/WN) - (PC_K/PC) );
WNPC_Q  = WNPC*( (WN_Q/WN) - (PC_Q/PC) );
WNPC_ZT = WNPC*( (WN_ZT/WN) - (PC_ZT/PC) );
WNPC_ZN = WNPC*( (WN_ZN/WN) - (PC_ZN/PC) );

WPC_K  = WPC*( (W_K/W) - (PC_K/PC) );
WPC_Q  = WPC*( (W_Q/W) - (PC_Q/PC) );
WPC_ZT = WPC*( (W_ZT/W) - (PC_ZT/PC) );
WPC_ZN = WPC*( (W_ZN/W) - (PC_ZN/PC) );

% Solution for Y as function Y=Y(K,Q,ZT,ZN)
Y_K   = YT_K + (P_K*YN) + (P*YN_K);
Y_Q   = YT_Q + (P_Q*YN) + (P*YN_Q);
Y_ZT  = YT_ZT+ (P_ZT*YN)+ (P*YN_ZT);
Y_ZN  = YT_ZN+ (P_ZN*YN)+ (P*YN_ZN);

% Solution for Real GDP as function YR=YR(K,Q,ZT,ZN)
YR_K   = (YT_K) + (P_0*YN_K);
YR_Q   = (YT_Q) + (P_0*YN_Q);
YR_ZT  = (YT_ZT)+ (P_0*YN_ZT);
YR_ZN  = (YT_ZN)+ (P_0*YN_ZN);

% Solutions for the employment shares Lj/L(K,Q,ZT,ZN)
LTS_K  = (LT/L)*((LT_K/LT)-(L_K/L));
LTS_Q  = (LT/L)*((LT_Q/LT)-(L_Q/L));
LTS_ZT  = (LT/L)*((LT_ZT/LT)-(L_ZT/L));
LTS_ZN  = (LT/L)*((LT_ZN/LT)-(L_ZN/L));

LNS_K  = (LN/L)*((LN_K/LN)-(L_K/L));
LNS_Q  = (LN/L)*((LN_Q/LN)-(L_Q/L));
LNS_ZT  = (LN/L)*((LN_ZT/LN)-(L_ZT/L));
LNS_ZN  = (LN/L)*((LN_ZN/LN)-(L_ZN/L));

% Solutions for Yj/YR(K,Q,ZT,ZN)
YTS_K  = (YT/YR)*( (YT_K/YT) - (YR_K/YR) );
YTS_Q  = (YT/YR)*( (YT_Q/YT) - (YR_Q/YR) );
YTS_ZT  = (YT/YR)*( (YT_ZT/YT) - (YR_ZT/YR) );
YTS_ZN  = (YT/YR)*( (YT_ZN/YT) - (YR_ZN/YR) );

YNS_K  = (YN/YR)*( (YN_K/YN) - (YR_K/YR) );
YNS_Q  = (YN/YR)*( (YN_Q/YN) - (YR_Q/YR) );
YNS_ZT  = (YN/YR)*( (YN_ZT/YN) - (YR_ZT/YR) );
YNS_ZN  = (YN/YR)*( (YN_ZN/YN) - (YR_ZN/YR) );

% Solutions for the Kj/K: Kj/K(K,Q,ZT,ZN)
KTK_K  = (KT/K)*( (KT_K/KT) - (1/K) );
KTK_Q  = (KT/K)*(KT_Q/KT);
KTK_ZT = (KT/K)*(KT_ZT/KT);
KTK_ZN = (KT/K)*(KT_ZN/KT);

KNK_K  = (KN/K)*( (KN_K/KN) - (1/K) );
KNK_Q  = (KN/K)*(KN_Q/KN);
KNK_ZT = (KN/K)*(KN_ZT/KN);
KNK_ZN = (KN/K)*(KN_ZN/KN);

% Solution for NX = NX(K,Q,ZT,ZN)
NX_K   = YT_K  - CT_K - JT_K;
NX_Q   = YT_Q  - CT_Q - JT_Q;
NX_ZT  = YT_ZT  - CT_ZT - JT_ZT;
NX_ZN  = YT_ZN  - CT_ZN - JT_ZN;

% Solution for Q/PI(K,Q,ZT,ZN)
QPI_K  = - (PI_K/PI);
QPI_Q  = (1/PI) - (PI_Q/PI);
QPI_ZT = - (PI_ZT/PI);
QPI_ZN = - (PI_ZN/PI);

% Aggregate LIS(K,Q,ZT,ZN)
LIS_K  = sL*( (W_K/W) + (L_K/L)  - (Y_K/Y) );
LIS_Q  = sL*( (W_Q/W) + (L_Q/L)  - (Y_Q/Y) );
LIS_ZT = sL*( (W_ZT/W) + (L_ZT/L) - (Y_ZT/Y) );
LIS_ZN = sL*( (W_ZN/W) + (L_ZN/L) - (Y_ZN/Y) );

% Output share of non-tradables at current prices  P*YN/Y(K,Q,ZT,ZN)
omegaYN_K  = omegaYN*( (P_K/P) + (YN_K/YN) - (Y_K/Y) );
omegaYN_Q  = omegaYN*( (P_Q/P) + (YN_Q/YN) - (Y_Q/Y) );
omegaYN_ZT = omegaYN*( (P_ZT/P) + (YN_ZT/YN) - (Y_ZT/Y) );
omegaYN_ZN = omegaYN*( (P_ZN/P) + (YN_ZN/YN) - (Y_ZN/Y) );

% Solutions for the capital-labor ratios kj/W(K,Q,ZT,ZN);           
kT_K = kT*( (KT_K/KT) - (LT_K/LT) );                                
kT_Q = kT*( (KT_Q/KT) - (LT_Q/LT) );                                
kT_ZT = kT*( (KT_ZT/KT) - (LT_ZT/LT) );                             
kT_ZN = kT*( (KT_ZN/KT) - (LT_ZN/LT) );                             
                                                                    
kN_K = kN*( (KN_K/KN) - (LN_K/LN) );                                
kN_Q = kN*( (KN_Q/KN) - (LN_Q/LN) );                                
kN_ZT = kN*( (KN_ZT/KN) - (LN_ZT/LN) );                             
kN_ZN = kN*( (KN_ZN/KN) - (LN_ZN/LN) );                             
                                                                    
% Solution for GE=GT + P*GN = G(K,Q,ZT,ZN,G)
G_K   = (P_K*GN);
G_Q   = (P_Q*GN);
G_ZT  = (P_ZT*GN);
G_ZN  = (P_ZN*GN);

% Government spending
G  = GT+ (P*GN);

% Investment
I_check = ( (varphiI^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-varphiI)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1));
I = deltaK*K;
EI = PI*I;
omegaI = PI*I/Y;

% Net exports, current account and saving
NX  = YT-CT-GT-IT;
CA  = (r*B) + YT - CT - GT - IT;
A   = B + (PI*K);
Tax = GT + (P*GN);
Sav = (r*A) + (W*L) - (PC*C) - Tax;

% Real Aggregate Wage
WPC  = W/PC;
WTPC = WT/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Labor income and Capital income shares
alphaL  = (WT*LT)/(W*L);
EL      = W*L;
omegaL  = EL/Y;
EK      = RK*K;
omegaK  = EK/Y;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WT);
YTYN  = (YT/YN);
LTLN  = (LT/LN);

% Consumption
C_check = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1));

% Aggregator function for L=L(LT,LN)
VLAB    = ( (vartheta^(-1/epsilon))*(LT^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) );
L_check = VLAB^(epsilon/(epsilon+1));
L_LT    = ((vartheta)^(-1/epsilon))*(LT/L)^(1/epsilon);
L_LN    = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Aggregator function for K=K(KT,KN)
VCAP    = ( (varthetaK^(-1/epsilonK))*(KT^((epsilonK+1)/epsilonK)) + ((1-varthetaK)^(-1/epsilonK))*(KN^((epsilonK+1)/epsilonK)) );
K_check = VCAP^(epsilonK/(epsilonK+1));
K_KT    = ((varthetaK)^(-1/epsilonK))*(KT/K)^(1/epsilonK);
K_KN    = ((1-varthetaK)^(-1/epsilonK))*(KN/K)^(1/epsilonK);

% Sectoral ratios
omegaINYN = IN/YN;
omegaITYT = IT/YT;
omegaGTYT =  GT / YT;
omegaGNYN =  GN / (YN);
omegaGN   =  (P*GN) / G;
omegaYN   =  (P*YN)/Y;
omegaLT   =  LT / L;
omegaLN   =  LN / L;

% Targeted ratios
omegaC    =  (PC*C) / Y;
omegaNX   =  NX / Y;
omegaG    =  (GT+P*GN)/Y;
omegaB    = (r*B)/Y;
omegaKY   = K/Y;

% Check the closure of the model
cond1  = (1-thetaT)*(YT/KT)-RT;
cond2  = P*(1-thetaN)*(YN/KN)-RN;
cond3  = thetaT*(YT/LT)-WT;
cond4  = P*thetaN*(YN/LN)-WN;
cond5  = (RT*KT)+(RN*KN)-(RK*K);
cond6  = RK-(deltaK+r)*PI;
cond7  = YN-CN-GN-IN;
cond8  = YT-CT-GT-IT+(r*B);
cond9  = (B-B0)-( (wB1/(r-nu_1)) + (wBZT2/(xiZT+r)) + (wBZN2/(xiZN+r)) ); 
cond10 = DetJ - (nu_1*nu_2);
cond11 = TrJ - (nu_1+nu_2);
cond12 = (WT*LT) + (WN*LN) - (W*L);
cond13 = (CT/CN) - (varphi/(1-varphi))*P^(phi);
cond14 = (PC*C) - (CT+(P*CN));
cond15 = (W*L) - ((WT*LT)+(WN*LN));
cond16 = Y - (PC*C) - G - (PI*I) + (r*B);
cond17 = Sav;
cond18 = (PC*C) - (CT+(P*CN));
cond19 = (IT/IN) - (varphiI/(1-varphiI))*P^(phiI);
cond20 = (PI*I) - (IT+(P*IN));
cond21 = (RK*K) - ((RT*KT)+(RN*KN));
cond22 = 1 - (omegaK + omegaL);
cond23 = -(U_L*L_LT) - (lambda*WT);
cond24 = -(U_L*L_LN) - (lambda*WN);
cond25 = K_KT - (RT/RK);
cond26 = K_KN - (RN/RK);
cond27 = (KT/KN) - (varthetaK/(1-varthetaK))*(RT/RN)^(epsilonK);
cond28 = P - MN;
cond29 = 1 - MT;

% Define New steady-state values
kT_imlimkasym = kT; kN_imlimkasym = kN; P_imlimkasym = P; LT_imlimkasym = LT; K_imlimkasym = K; C_imlimkasym = C;  
LN_imlimkasym = LN; L_imlimkasym  = L; W_imlimkasym = W; 
YT_imlimkasym = YT; YN_imlimkasym = YN; Y_imlimkasym = Y; KT_imlimkasym  = KT; KN_imlimkasym  = KN; G_imlimkasym = G;     
PC_imlimkasym = PC; alphaC_imlimkasym = alphaC; CN_imlimkasym = CN; CT_imlimkasym = CT;  
GT_imlimkasym = GT; GN_imlimkasym = GN; ZT_imlimkasym = ZT; ZN_imlimkasym = ZN; ZA_imlimkasym = ZA; 
LT_imlimkasym = LT; LN_imlimkasym = LN; KT_imlimkasym = KT; KN_imlimkasym = KN; WT_imlimkasym = WT; WN_imlimkasym = WN; 
Omega_imlimkasym = Omega; WPC_imlimkasym = WPC; WTPC_imlimkasym = WTPC; WNPC_imlimkasym = WNPC;
uKT_imlimkasym = uKT; uKN_imlimkasum = uKN;

YTYN_imlimkasym = YTYN; LTLN_imlimkasym = LTLN; IT_imlimkasym = IT; IN_imlimkasym = IN; 
PI_imlimkasym = PI; EI_imlimkasym = EI; I_imlimkasym = I;
CA_imlimkasym = CA; Sav_imlimkasym = Sav; NX_imlimkasym = NX; A_imlimkasym = A; 
B_imlimkasym = B; lambda_imlimkasym  = lambda; RK_imlimkasym = RK; YR_imlimkasym = YR; 

omegaL_imlimkasym = omegaL; omegaK_imlimkasym = omegaK; omegaI_imlimkasym = omegaI; omegaINYN_imlimkasym = omegaINYN;
omegaITYT_imlimkasym = omegaITYT; omegaGTYT_imlimkasym = omegaGTYT; omegaGNYN_imlimkasym = omegaGNYN; omegaGN_imlimkasym = omegaGN;
omegaYT_imlimkasym = omegaYT; omegaYN_imlimkasym = omegaYN; omegaLT_imlimkasym = omegaLT; omegaLN_imlimkasym = omegaLN; 
omegaC_imlimkasym =omegaC; omegaNX_imlimkasym =omegaNX; omegaG_imlimkasym =omegaG; omegaB_imlimkasym =omegaB; omegaKY_imlimkasym = omegaKY; 
alphaL_imlimkasym = alphaL; alphaK_imlimkasym = alphaK; alphaC_imlimkasym = alphaC; alphaI_imlimkasym = alphaI; 
sLT_imlimkasym = sLT; sLN_imlimkasym = sLN; PT_imlimkasym = PT; RT_imlimkasym = RT; RN_imlimkasym = RN; 
% Steady-State Changes
dC       = C_imlimkasym - C_0; % Steady-state change of real consumption 
dK       = K_imlimkasym - K_0; % Steady-state change of real capital 
dL       = L_imlimkasym - L_0; % Steady-state change of employment 
dP       = P_imlimkasym - P_0; % Steady-state change of real exchange rate 
dPT      = PT_imlimkasym - PT_0; % Steady-state change of terms of trade 
dB       = B_imlimkasym - B_0; % Steady-state change of traded bonds holding 
dlambda  = lambda_imlimkasym - lambda_0; % Steady-state change of marginal utility of wealth 
dY       = (YT_imlimkasym+(P_imlimkasym*YN_imlimkasym)) - (YT_0+(P_0*YN_0)); % Steady-state change of real GDP 
dY_check = Y_imlimkasym - Y_0; % Steady-state change of real GDP - Check
dA       = A_imlimkasym - A_0; % Steady-state change of financial wealth 
dW       = W_imlimkasym - W_0; % Steady-state change of the wage rate 
dWPC     = WPC_imlimkasym - WPC_0; % Steady-state change of the real aggregate wage W/PC 
dOmega   = Omega_imlimkasym - Omega_0; % Steady-state change of the sector wage ratio
dRK      = RK_imlimkasym - RK_0; % Steady-state change of the capital rental rate 

dG     = G_imlimkasym - G_0; % Steady-state change of CT
dCT   = CT_imlimkasym - CT_0; % Steady-state change of CT
dCN   = CN_imlimkasym - CN_0; % Steady-state change of CN
dLT   = LT_imlimkasym - LT_0; % Steady-state change of real capital 
dLN   = LN_imlimkasym - LN_0; % Steady-state change of employment 
dKT   = KT_imlimkasym - KT_0; % Steady-state change of real capital 
dKN   = KN_imlimkasym - KN_0; % Steady-state change of employment 
dYT   = YT_imlimkasym - YT_0; % Steady-state change of YT
dYN   = YN_imlimkasym - YN_0; % Steady-state change of YN
dWT   = WT_imlimkasym - WT_0; % Steady-state change of WT
dWN   = WN_imlimkasym - WN_0; % Steady-state change of WN
dWTPC = WTPC_imlimkasym - WTPC_0; % Steady-state change of WT/PC
dWNPC = WNPC_imlimkasym - WNPC_0; % Steady-state change of WN/PC
dkT   = kT_imlimkasym - kT_0; % Steady-state change of kT 
dkN   = kN_imlimkasym - kN_0; % Steady-state change of kN
dLTLN = LTLN_imlimkasym - LTLN_0; % Steady-state change of LT/LN
dYTYN = YTYN_imlimkasym - YTYN_0; % Steady-state change of LT/LN
dRT   = RT_imlimkasym - RT_0; % Steady-state change of RT     
dRN   = RN_imlimkasym - RN_0; % Steady-state change of RN     

dZT   = ZT_imlimkasym - ZT_0; 
dZN   = ZN_imlimkasym - ZN_0; 
dZA   = ZA_imlimkasym - ZA_0; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solution for investment PI*K,
EK1   = PI + (K*omega_21); % Q(t)*K(t) - Q*K = EK1*X1(t) + EK2*X2(t)
EK2   = PI + (K*omega_22);

% Solution for the Relative Price of Non tradables P=P(K,Q,ZT,ZN)
wP_1   = P_K + (P_Q*omega_21);
wP_2   = P_K + (P_Q*omega_22);

% Solution for the Consumption Price index PC=PC(K,Q,ZT,ZN)
wPC_1  =  PC_K + (PC_Q*omega_21);
wPC_2  =  PC_K + (PC_Q*omega_22);

% Solution for the Investment Price index PI=PI(K,Q,ZT,ZN)
wPI_1  =  PI_K + (PI_Q*omega_21);
wPI_2  =  PI_K + (PI_Q*omega_22);

% Solution for Q(t)/PI(P(t))
wQPI_1  = QPI_K + (QPI_Q*omega_21);
wQPI_2  = QPI_K + (QPI_Q*omega_22);

% Solution for Consumption C=C(K,Q,ZT,ZN)
wC_1   = C_K + (C_Q*omega_21);
wC_2   = C_K + (C_Q*omega_22);

% Solution for Consumption J=J(K,Q,ZT,ZN)
wJ_1   = J_K + (J_Q*omega_21);
wJ_2   = J_K + (J_Q*omega_22);

% Solution for Consumption J=J(K,Q,ZT,ZN)
wNX_1   = NX_K + (NX_Q*omega_21);
wNX_2   = NX_K + (NX_Q*omega_22);

% Solution for the Capital Rental Rate R=R(K,Q,ZT,ZN)
wR_1  =  R_K + (R_Q*omega_21);
wR_2  =  R_K + (R_Q*omega_22);

% Solution for the Aggregate Wage Index W=W(K,Q,ZT,ZN)
wW_1  =  W_K + (W_Q*omega_21);
wW_2  =  W_K + (W_Q*omega_22);

% Solution for Labor L=L(lambda,W)=L(K,Q,ZT,ZN)
wL_1  =  L_K + (L_Q*omega_21);
wL_2  =  L_K + (L_Q*omega_22);

% Solutions for the Sectoral Labor kj,K(K,Q,ZT,ZN)
wkT_1  =  kT_K + (kT_Q*omega_21);
wkT_2  =  kT_K + (kT_Q*omega_22);
wkN_1  =  kN_K + (kN_Q*omega_21);
wkN_2  =  kN_K + (kN_Q*omega_22);

% Solutions for the Sectoral Labor Lj=Lj(K,Q,ZT,ZN)
wLT_1  =  LT_K + (LT_Q*omega_21);
wLT_2  =  LT_K + (LT_Q*omega_22);

wLN_1  =  LN_K + (LN_Q*omega_21);
wLN_2  =  LN_K + (LN_Q*omega_22);

% Solutions for the Sectoral Labor Kj=Kj(K,Q,ZT,ZN)             
wKT_1  =  KT_K + (KT_Q*omega_21);                               
wKT_2  =  KT_K + (KT_Q*omega_22);                               
                                                                
wKN_1  =  KN_K + (KN_Q*omega_21);                               
wKN_2  =  KN_K + (KN_Q*omega_22);                               
                                                                
% Solutions for the Sectoral Labor Rj=Rj(K,Q,ZT,ZN)             
wRT_1  =  RT_K + (RT_Q*omega_21);                               
wRT_2  =  RT_K + (RT_Q*omega_22);                               
                                                                
wRN_1  =  RN_K + (RN_Q*omega_21);                               
wRN_2  =  RN_K + (RN_Q*omega_22);                               
                                                                
% Solution for Real GDP YR=YR(K,Q,ZT,ZN)
wYR_1  = YR_K + (YR_Q*omega_21);
wYR_2  = YR_K + (YR_Q*omega_22);

wY_1  = Y_K + (Y_Q*omega_21);
wY_2  = Y_K + (Y_Q*omega_22);

% Solutions for the Sectoral Output Yj=Yj(K,Q,ZT,ZN)
wYT_1  = YT_K + (YT_Q*omega_21);
wYT_2  = YT_K + (YT_Q*omega_22);
wYN_1  = YN_K + (YN_Q*omega_21);
wYN_2  = YN_K + (YN_Q*omega_22);

% Solutions for the Sectoral Wages Wj=Wj(K,Q,ZT,ZN)
wWT_1  = WT_K + (WT_Q*omega_21);
wWT_2  = WT_K + (WT_Q*omega_22);
wWN_1  = WN_K + (WN_Q*omega_21);
wWN_2  = WN_K + (WN_Q*omega_22);

% Solution for YH(K,Q,ZT,ZN)/YN(K,Q,ZT,ZN), Solution for LH(K,Q,ZT,ZN)/LN(K,Q,ZT,ZN)
% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(K,Q,ZT,ZN)
% Solutions for the employment shares Lj/L=(Lj/L)(K,Q,ZT,ZN)
% Solutions for the employment shares sLj=LISj(K,Q,ZT,ZN) -

wLTS_1  = LTS_K + (LTS_Q*omega_21);
wLTS_2  = LTS_K + (LTS_Q*omega_22);
wLNS_1  = LNS_K + (LNS_Q*omega_21);
wLNS_2  = LNS_K + (LNS_Q*omega_22);

wYTS_1  = YTS_K + (YTS_Q*omega_21);
wYTS_2  = YTS_K + (YTS_Q*omega_22);
wYNS_1  = YNS_K + (YNS_Q*omega_21);
wYNS_2  = YNS_K + (YNS_Q*omega_22);

% sLj = Wj*Lj/(Pj*Yj) -
wLIST_1  = LIST_K + (LIST_Q*omega_21);
wLIST_2  = LIST_K + (LIST_Q*omega_22);
wLISN_1  = LISN_K + (LISN_Q*omega_21);
wLISN_2  = LISN_K + (LISN_Q*omega_22);

% Solutions for the Kj/K: Kj/K=Kj/K(lambda,K,Q,AH,BH,AN,BN) -
wKTK_1  = KTK_K + (KTK_Q*omega_21);
wKTK_2  = KTK_K + (KTK_Q*omega_22);
wKNK_1  = KNK_K + (KNK_Q*omega_21);
wKNK_2  = KNK_K + (KNK_Q*omega_22);

% Solutions for aggregate capital-labor ratio k, aggregate LIS sL, output
% share of non-tradables at current prices omegaYN
wLIS_1   =  LIS_K + (LIS_Q*omega_21);
wLIS_2   =  LIS_K + (LIS_Q*omega_22);

womegaYN_1   =  omegaYN_K + (omegaYN_Q*omega_21);
womegaYN_2   =  omegaYN_K + (omegaYN_Q*omega_22);

% Solution for the Real Consumption Wage W/PC(K,Q,ZT,ZN);        
wWPC_1  = WPC_K + (WPC_Q*omega_21);                              
wWPC_2  = WPC_K + (WPC_Q*omega_22);                              
                                                                 
% Solutions for the relative wages Wj/W(K,Q,ZT,ZN);              
wWTW_1  = WTW_K + (WTW_Q*omega_21);                              
wWTW_2  = WTW_K + (WTW_Q*omega_22);                              
wWNW_1  = WNW_K + (WNW_Q*omega_21);                              
wWNW_2  = WNW_K + (WNW_Q*omega_22);                              
                                                                 
% Solutions for the Real Sectoral Wages Wj/PC(K,Q,ZT,ZN);        
wWTPC_1  = WTPC_K + (WTPC_Q*omega_21);                           
wWTPC_2  = WTPC_K + (WTPC_Q*omega_22);                           
wWNPC_1  = WNPC_K + (WNPC_Q*omega_21);                           
wWNPC_2  = WNPC_K + (WNPC_Q*omega_22);                           

% Transitional Paths 
Tm = 0; Tu = 1; Tg = 10;
time0 = [Tm:Tu:0]; % Span of time t= [-20..0[ 
pathdZT0    = (ZT_0 - ZT_0) + 0*time0;
pathdZN0    = (ZN_0 - ZN_0) + 0*time0;
pathdZ0     = (ZA_0 - ZA_0) + 0*time0;
pathCY0     = (C_0 - C_0) + 0*time0;
pathdP0     = (P_0 - P_0) + 0*time0;
pathCAY0    = CA_0 + 0*time0;
pathdL0     = (L_0 - L_0) + 0*time0;
pathdLTL0   = (LN_0 - LN_0) + 0*time0;
pathdLNL0   = (LT_0 - LT_0) + 0*time0;
pathIY0     = (I_0 - I_0) + 0*time0;
pathSY0     = CA_0 + 0*time0;
pathdW0     = (W_0 - W_0) + 0*time0;
pathdY0     = (Y_0 - Y_0) + 0*time0;
pathdWT0    = (WT_0 - WT_0) + 0*time0;
pathdWN0    = (WN_0 - WN_0) + 0*time0;
pathdOmega0 = (Omega_0 - Omega_0) + 0*time0;
pathdYTYN0  = (YTYN_0 - YTYN_0) + 0*time0;
pathdLTLN0  = (LTLN_0 - LTLN_0) + 0*time0;
pathdITY0   = (IN_0 - IN_0) + 0*time0;
pathdINY0   = (IT_0 - IT_0) + 0*time0;
pathdWPC0   = (WPC_0 - WPC_0) + 0*time0;
pathdQ0     = (PI_0 - PI_0) + 0*time0; 
pathdR0     = (RK_0 - RK_0) + 0*time0; 
pathdLIST0  = (sLT_0 - sLT_0) + 0*time0;
pathdLISN0  = (sLN_0 - sLN_0) + 0*time0;

time1        = [0:Tu:Tg]; % span of time t = [0..100]
VG           = exp(-xi*time1) - (1-barg)*exp(-chi*time1);
VG1          = exp(-xi*time1) - ThetaG_1*exp(-chi*time1);
VG2          = exp(-xi*time1) - ThetaG_2*exp(-chi*time1);
VZT          = exp(-xiZT*time1) - (1-barzT)*exp(-chiZT*time1);
VZN          = exp(-xiZN*time1) - (1-barzN)*exp(-chiZN*time1);
VZT1         = exp(-xiZT*time1) - ThetaZT_1*exp(-chiZT*time1);
VZT2         = exp(-xiZT*time1) - ThetaZT_2*exp(-chiZT*time1);
VZN1         = exp(-xiZN*time1) - ThetaZN_1*exp(-chiZN*time1);
VZN2         = exp(-xiZN*time1) - ThetaZN_2*exp(-chiZN*time1);

VG1prime      = xi*exp(-xi*time1) - chi*ThetaG_1*exp(-chi*time1);
VG2prime      = xi*exp(-xi*time1) - chi*ThetaG_2*exp(-chi*time1);
VGprime       = xi*exp(-xi*time1) - chi*(1-barg)*exp(-chi*time1);
VZT1prime     = xiZT*exp(-xiZT*time1) - chiZT*ThetaZT_1*exp(-chiZT*time1);
VZT2prime     = xiZT*exp(-xiZT*time1) - chiZT*ThetaZT_2*exp(-chiZT*time1);
VZN1prime     = xiZN*exp(-xiZN*time1) - chiZN*ThetaZN_1*exp(-chiZN*time1);
VZN2prime     = xiZN*exp(-xiZN*time1) - chiZN*ThetaZN_2*exp(-chiZN*time1);

VBG1prime     = xi*exp(-xi*time1) - chi*ThetaG_1prime*exp(-chi*time1);
VBG2prime     = xi*exp(-xi*time1) - chi*ThetaG_2prime*exp(-chi*time1);
VBGprime      = xi*exp(-xi*time1) - chi*ThetaG_prime*exp(-chi*time1);

VBZT1prime     = xiZT*exp(-xiZT*time1) - chiZT*ThetaZT_1prime*exp(-chiZT*time1);
VBZT2prime     = xiZT*exp(-xiZT*time1) - chiZT*ThetaZT_2prime*exp(-chiZT*time1);
VBZN1prime     = xiZN*exp(-xiZN*time1) - chiZN*ThetaZN_1prime*exp(-chiZN*time1);
VBZN2prime     = xiZN*exp(-xiZN*time1) - chiZN*ThetaZN_2prime*exp(-chiZN*time1);

VBZTprime      = xiZT*exp(-xiZT*time1) - chiZT*ThetaZT_prime*exp(-chiZT*time1);
VBZNprime      = xiZN*exp(-xiZN*time1) - chiZN*ThetaZN_prime*exp(-chiZN*time1);

VgG           = gG + exp(-xi*time1) - (1-barg)*exp(-chi*time1);
VgZT          = gZT + exp(-xiZT*time1) - (1-barzT)*exp(-chiZT*time1);
VgZN          = gZN + exp(-xiZN*time1) - (1-barzN)*exp(-chiZN*time1);

X1 = X11*exp(nu_1*time1) + (DeltaZT_1*VZT1) + (DeltaZN_1*VZN1);
X2 = - (DeltaZT_2*VZT2) - (DeltaZN_2*VZN2);
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathdGTY1    = (1-omegaGN)*omegaG*VgG*100;
pathdGNY1    = omegaGN*omegaG*VgG*100;
pathdGY1     = omegaG_0*VgG*100;
pathdZT1     = VgZT*100;
pathdZN1     = VgZN*100;
pathdZA1     = ( (omegaYT_0*VgZT) +  (1-omegaYT_0)*VgZN )*100;
pathdFBTCH1  = ((1-sigmaT)/sigmaT)*( VgZT - VgZT )*100;
pathdFBTCN1  = ((1-sigmaN)/sigmaN)*( VgZN - VgZN )*100;

pathdK1      = (((K_imlimkasym-K_0) + (X1 + X2) )/K_0)*100;
pathdQ1      = (((PI_imlimkasym-PI_0) + (omega_21*X1) + (omega_22*X2) )/PI_0)*100;
pathdP1      = (((P_imlimkasym-P_0) + (wP_1*X1) + (wP_2*X2)  + (P_ZT*ZT_0*VZT) + (P_ZN*ZN_0*VZN) )/P_0)*100;
pathdCY1     = ( PC_0*((C_imlimkasym-C_0) + (wC_1*X1) + (wC_2*X2)  + (C_ZT*ZT_0*VZT) + (C_ZN*ZN_0*VZN) )/Y_0 )*100;
pathdJY1     = ( PI_0*((I_imlimkasym-I_0) + (wJ_1*X1) + (wJ_2*X2)  + (J_ZT*ZT_0*VZT) + (J_ZN*ZN_0*VZN) )/Y_0 )*100;
pathdNXY1    = ( ((NX_imlimkasym-NX_0) + (wNX_1*X1) + (wNX_2*X2)  + (NX_ZT*ZT_0*VZT) + (NX_ZN*ZN_0*VZN) )/Y_0 )*100;

pathdQPI1    = ( (wQPI_1*X1) + (wQPI_2*X2) + (QPI_ZT*ZT_0*VZT) + (QPI_ZN*ZN_0*VZN) )*100;
pathdL1      = (((L_imlimkasym-L_0)  + (wL_1*X1) + (wL_2*X2) + (L_ZT*ZT_0*VZT) + (L_ZN*ZN_0*VZN) )/L_0)*100;
pathdLT1     = ( (WT_0/W_0)*( (LT_imlimkasym-LT_0) + (wLT_1*X1) + (wLT_2*X2) + (LT_ZT*ZT_0*VZT) + (LT_ZN*ZN_0*VZN)  )/L_0)*100;
pathdLN1     = ( (WN_0/W_0)*( (LN_imlimkasym-LN_0) + (wLN_1*X1) + (wLN_2*X2) + (LN_ZT*ZT_0*VZT) + (LN_ZN*ZN_0*VZN)  )/L_0)*100;
pathdW1      = (((W_imlimkasym-W_0) + (wW_1*X1) + (wW_2*X2)  + (W_ZT*ZT_0*VZT) + (W_ZN*ZN_0*VZN) )/W_0)*100;
pathdWPC1    = (((WPC_imlimkasym-WPC_0) + (wWPC_1*X1) + (wWPC_2*X2)  + (WPC_ZT*ZT_0*VZT) + (WPC_ZN*ZN_0*VZN) )/WPC_0)*100;   
pathdWT1     = (((WT_imlimkasym-WT_0) + (wWT_1*X1) + (wWT_2*X2)  + (WT_ZT*ZT_0*VZT) + (WT_ZN*ZN_0*VZN) )/WT_0)*100;
pathdWN1     = (((WN_imlimkasym-WN_0) + (wWN_1*X1) + (wWN_2*X2)  + (WN_ZT*ZT_0*VZT) + (WN_ZN*ZN_0*VZN) )/WN_0)*100;             
pathdWTPC1   = (((WTPC_imlimkasym-WTPC_0) + (wWTPC_1*X1) + (wWTPC_2*X2)  + (WTPC_ZT*ZT_0*VZT) + (WTPC_ZN*ZN_0*VZN) )/WTPC_0)*100;    
pathdWNPC1   = (((WNPC_imlimkasym-WNPC_0) + (wWNPC_1*X1) + (wWNPC_2*X2)  + (WNPC_ZT*ZT_0*VZT) + (WNPC_ZN*ZN_0*VZN) )/WNPC_0)*100;  
pathdR1      = (((RK_imlimkasym-RK_0) + (wR_1*X1) + (wR_2*X2)  + (R_ZT*ZT_0*VZT) + (R_ZN*ZN_0*VZN) )/RK_0)*100; 
pathdRT1     = (((RT_imlimkasym-RT_0) + (wRT_1*X1) + (wRT_2*X2)  + (RT_ZT*ZT_0*VZT) + (RT_ZN*ZN_0*VZN) )/RT_0)*100;   
pathdRN1     = (((RN_imlimkasym-RN_0) + (wRN_1*X1) + (wRN_2*X2)  + (RN_ZT*ZT_0*VZT) + (RN_ZN*ZN_0*VZN) )/RN_0)*100;   

pathdY1      = (((Y_imlimkasym-Y_0) + (wY_1*X1) + (wY_2*X2) + (Y_ZT*ZT_0*VZT) + (Y_ZN*ZN_0*VZN)  )/Y_0)*100;
pathdYR1     = (((YR_imlimkasym-Y_0) + (wYR_1*X1) + (wYR_2*X2) + (YR_ZT*ZT_0*VZT) + (YR_ZN*ZN_0*VZN)  )/Y_0)*100;
pathdYT1     = (((YT_imlimkasym-YT_0) + (wYT_1*X1) + (wYT_2*X2) + (YT_ZT*ZT_0*VZT) + (YT_ZN*ZN_0*VZN)  )/Y_0)*100;
pathdYN1     = ( P_0*((YN_imlimkasym-YN_0) + (wYN_1*X1) + (wYN_2*X2) + (YN_ZT*ZT_0*VZT) + (YN_ZN*ZN_0*VZN)  )/Y_0)*100;

pathdLTS1    = (WT_0/W_0)*( ((LT_imlimkasym/L_imlimkasym)- (LT_0/L_0)) + (wLTS_1*X1) + (wLTS_2*X2)  + (LTS_ZT*ZT_0*VZT) + (LTS_ZN*ZN_0*VZN)  )*100;
pathdLNS1    = (WN_0/W_0)*( ((LN_imlimkasym/L_imlimkasym)- (LN_0/L_0)) + (wLNS_1*X1) + (wLNS_2*X2)  + (LNS_ZT*ZT_0*VZT) + (LNS_ZN*ZN_0*VZN)  )*100;
pathdWTW1    = (( ((WT_imlimkasym/W_imlimkasym)-(WT_0/W_0)) + (wWTW_1*X1) + (wWTW_2*X2)+ (WTW_ZT*ZT_0*VZT) + (WTW_ZN*ZN_0*VZN) )/(WT_0/W_0) )*100; 
pathdWNW1    = (( ((WN_imlimkasym/W_imlimkasym)-(WN_0/W_0)) + (wWNW_1*X1) + (wWNW_2*X2)+ (WNW_ZT*ZT_0*VZT) + (WNW_ZN*ZN_0*VZN) )/(WN_0/W_0) )*100; 
pathdYTS1    = ( ((YT_imlimkasym/YR_imlimkasym)- (YT_0/Y_0)) + (wYTS_1*X1) + (wYTS_2*X2) + (YTS_ZT*ZT_0*VZT) + (YTS_ZN*ZN_0*VZN)  )*100;
pathdYNS1    = P_0*( ((YN_imlimkasym/YR_imlimkasym)- (YN_0/Y_0)) + (wYNS_1*X1) + (wYNS_2*X2) + (YNS_ZT*ZT_0*VZT) + (YNS_ZN*ZN_0*VZN) )*100;
pathdKTK1    =  ( ((KT_imlimkasym/K_imlimkasym)-(KT_0/K_0)) + (wKTK_1*X1) + (wKTK_2*X2)  + (KTK_ZT*ZT_0*VZT) + (KTK_ZN*ZN_0*VZN) )*100;
pathdKNK1    =  ( ((KN_imlimkasym/K_imlimkasym)-(KN_0/K_0)) + (wKNK_1*X1) + (wKNK_2*X2)  + (KNK_ZT*ZT_0*VZT) + (KNK_ZN*ZN_0*VZN) )*100;
pathdkT1     = ( LT_0*((kT_imlimkasym-kT_0) + (wkT_1*X1) + (wkT_2*X2)  + (kT_ZT*ZT_0*VZT) + (kT_ZN*ZN_0*VZN)  )/K_0)*100;
pathdkN1     = ( LN_0*((kN_imlimkasym-kN_0) + (wkN_1*X1) + (wkN_2*X2)  + (kN_ZT*ZT_0*VZT) + (kN_ZN*ZN_0*VZN)  )/K_0)*100;
pathdLIST1   = ( (sLT_imlimkasym-sLT_0) + (wLIST_1*X1) + (wLIST_2*X2)  + (LIST_ZT*ZT_0*VZT) + (LIST_ZN*ZN_0*VZN)  )*100;
pathdLISN1   = ( (sLN_imlimkasym-sLN_0) + (wLISN_1*X1) + (wLISN_2*X2)  + (LISN_ZT*ZT_0*VZT) + (LISN_ZN*ZN_0*VZN)  )*100;
pathdKT1     =  ( (RT_0/RK_0)*( (KT_imlimkasym-KT_0) + (wKT_1*X1) + (wKT_2*X2)  + (KT_ZT*ZT_0*VZT) + (KT_ZN*ZN_0*VZN) )/K_0)*100;  
pathdKN1     =  ( (RN_0/RK_0)*( (KN_imlimkasym-KN_0) + (wKN_1*X1) + (wKN_2*X2)  + (KN_ZT*ZT_0*VZT) + (KN_ZN*ZN_0*VZN) )/K_0)*100;  

pathdomegaYN1 = ( (omegaYN_imlimkasym-omegaYN_0) + (womegaYN_1*X1) + (womegaYN_2*X2) + (omegaYN_ZT*ZT_0*VZT) + (omegaYN_ZN*ZN_0*VZN) )*100;     

CA_ZT = (B_ZT*ZT_0/(xiZT+r))*VBZTprime + (N1*DeltaZT_1/(xiZT+r))*VBZT1prime - (N2*DeltaZT_2/(xiZT+r))*VBZT2prime;
CA_ZN = (B_ZN*ZN_0/(xiZN+r))*VBZNprime + (N1*DeltaZN_1/(xiZN+r))*VBZN1prime - (N2*DeltaZN_2/(xiZN+r))*VBZN2prime;

SAV_ZT = (A_ZT*ZT_0/(xiZT+r))*VBZTprime + (M1*DeltaZT_1/(xiZT+r))*VBZT1prime - (M2*DeltaZT_2/(xiZT+r))*VBZT2prime;
SAV_ZN = (A_ZN*ZN_0/(xiZN+r))*VBZNprime + (M1*DeltaZN_1/(xiZN+r))*VBZN1prime - (M2*DeltaZN_2/(xiZN+r))*VBZN2prime;

dotX1 = nu_1*X11*exp(nu_1*time1) - (DeltaZT_1*VZT1prime) - (DeltaZN_1*VZN1prime);
dotX2 = (DeltaZT_2*VZT2prime) +(DeltaZN_2*VZN2prime);

pathCAY1 = (( -nu_1*(wB1/(r-nu_1))*exp(nu_1*time1) + CA_ZT + CA_ZN )/Y_0 )*100;
pathSY1  = (( -nu_1*(wA1/(r-nu_1))*exp(nu_1*time1) + SAV_ZT + SAV_ZN )/Y_0 )*100;
pathIY1  = (( (EK1*dotX1) + (EK2*dotX2) )/Y_0)*100;

% Temporal paths over entire period
timeperm = [time0 time1];
pathdZT_imlimkasym    = [pathdZT0  pathdZT1];
pathdZN_imlimkasym    = [pathdZN0  pathdZN1];
pathdZA_imlimkasym     = [pathdZ0  pathdZA1];
pathdQ_imlimkasym     = [pathdQ0  pathdQ1];
pathdQPI_imlimkasym   = [pathdQ0  pathdQPI1];
pathdP_imlimkasym     = [pathdP0  pathdP1]; 
pathCY_imlimkasym     = [pathCY0  pathdCY1];                                             
pathdL_imlimkasym     = [pathdL0  pathdL1];                
pathdLT_imlimkasym   = [pathdLTL0 pathdLT1];             
pathdLN_imlimkasym   = [pathdLNL0 pathdLN1]; 
pathdkT_imlimkasym   = [pathdLTL0 pathdkT1];             
pathdkN_imlimkasym   = [pathdLNL0 pathdkN1]; 
pathdW_imlimkasym     = [pathdW0 pathdW1]; 
pathdWPC_imlimkasym   = [pathdWPC0 pathdWPC1]; 
pathdYR_imlimkasym    = [pathdY0 pathdYR1];
pathdYT_imlimkasym   = [pathdY0 pathdYT1];               
pathdYN_imlimkasym   = [pathdY0 pathdYN1];               
pathdWT_imlimkasym    = [pathdWT0  pathdWT1];              
pathdWN_imlimkasym    = [pathdWN0  pathdWN1]; 
pathdWTPC_imlimkasym  = [pathdWT0 pathdWTPC1];
pathdWNPC_imlimkasym  = [pathdWN0 pathdWNPC1];
pathdRT_imlimkasym    = [pathdWT0  pathdRT1];              
pathdRN_imlimkasym    = [pathdWN0  pathdRN1];
pathdKT_imlimkasym    = [pathdWT0  pathdKT1];              
pathdKN_imlimkasym    = [pathdWN0  pathdKN1];

pathIY_imlimkasym     = [pathIY0  pathIY1];                        
pathCAY_imlimkasym    = [pathCAY0 pathCAY1];               
pathSY_imlimkasym     = [pathSY0  pathSY1];

pathdLTS_imlimkasym   = [pathdLTL0 pathdLTS1];             
pathdLNS_imlimkasym   = [pathdLNL0 pathdLNS1];
pathdWTW_imlimkasym   = [pathdWT0 pathdWTW1];
pathdWNW_imlimkasym   = [pathdWN0 pathdWNW1];
pathdYTS_imlimkasym   = [pathdY0 pathdYTS1];             
pathdYNS_imlimkasym   = [pathdY0 pathdYNS1];

pathdLIST_imlimkasym  = [pathdLIST0 pathdLIST1];             
pathdLISN_imlimkasym  = [pathdLISN0 pathdLISN1];

pathdomegaYN_imlimkasym  = [pathdLISN0 pathdomegaYN1];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Dynamic and steadty-state effects of a Permanent increase in ZH/ZN %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Impact effects of fiscal shock: dynamic processes
VG0          = 1 - (1-barg);
VG10         = 1 - ThetaG_1;
VG20         = 1 - ThetaG_2;
VZT0         = 1 - (1-barzT);
VZN0         = 1 - (1-barzN);

VZT10        = 1 - ThetaZT_1;
VZT20        = 1 - ThetaZT_2;
VZN10        = 1 - ThetaZN_1;
VZN20        = 1 - ThetaZN_2;

VG1prime0    = xi - chi*ThetaG_1;
VG2prime0    = xi - chi*ThetaG_2;
VGprime0     = xi - chi*(1-barg);
VZT1prime0   = xiZT - (chiZT*ThetaZT_1);
VZT2prime0   = xiZT - (chiZT*ThetaZT_2);
VZN1prime0   = xiZN - (chiZN*ThetaZN_1);
VZN2prime0   = xiZN - (chiZN*ThetaZN_2);

VBG1prime0   = xi - (chi*ThetaG_1prime);
VBG2prime0   = xi - (chi*ThetaG_2prime);
VBGprime0    = xi - (chi*ThetaG_prime);

VBZT1prime0 = xiZT - (chiZT*ThetaZT_1prime);
VBZT2prime0 = xiZT - (chiZT*ThetaZT_2prime);
VBZN1prime0 = xiZN - (chiZN*ThetaZN_1prime);
VBZN2prime0 = xiZN - (chiZN*ThetaZN_2prime);

VBZTprime0  = xiZT - (chiZT*ThetaZT_prime);
VBZNprime0  = xiZN - (chiZN*ThetaZN_prime);

VgG0        = gG + 1 - (1-barg);
VgZT0       = gZT + 1 - (1-barzT);
VgZN0       = gZN + 1 - (1-barzN);

X10 = X11 + (DeltaZT_1*VZT10) + (DeltaZN_1*VZN10);
X20 = - (DeltaZT_2*VZT20) - (DeltaZN_2*VZN20);
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dGTYtime0_imlimkasym    = (1-omegaGN)*omegaG*VgG0*100;
dGNYtime0_imlimkasym    = omegaGN*omegaG*VgG0*100;
dGYtime0_imlimkasym     = omegaG_0*VgG0*100;
dZTtime0_imlimkasym     = VgZT0*100;
dZNtime0_imlimkasym     = VgZN0*100;
dZAtime0_imlimkasym     = ( (omegaYT_0*VgZT0) + (1-omegaYT_0)*VgZN0 )*100;
dFBTCTtime0_imlimkasym  = ((1-sigmaT)/sigmaT)*( VgZT0 - VgZT0 )*100;
dFBTCNtime0_imlimkasym  = ((1-sigmaN)/sigmaN)*( VgZN0 - VgZN0 )*100;

dKtime0_imlimkasym      = (((K_imlimkasym-K_0) + (X10 + X20) )/K_0)*100;
dQtime0_imlimkasym      = (((PI_imlimkasym-PI_0) + (omega_21*X10) + (omega_22*X20) )/PI_0)*100;
dPtime0_imlimkasym      = (((P_imlimkasym-P_0) + (wP_1*X10) + (wP_2*X20)  + (P_ZT*ZT_0*VZT0) + (P_ZN*ZN_0*VZN0) )/P_0)*100;
dPTtime0_imlimkasym     = ((PT_imlimkasym-PT_0)/PT_0)*100;
duKTtime0_imlimkasym    = (uKT_imlimk-uKT_0)*100;
duKNtime0_imlimkasym    = (uKN_imlimk-uKN_0)*100;

dCYtime0_imlimkasym     = ( PC_0*((C_imlimkasym-C_0) + (wC_1*X10) + (wC_2*X20)  + (C_ZT*ZT_0*VZT0) + (C_ZN*ZN_0*VZN0) )/Y_0 )*100;
dJYtime0_imlimkasym     = ( PI_0*((I_imlimkasym-I_0) + (wJ_1*X10) + (wJ_2*X20)  + (J_ZT*ZT_0*VZT0) + (J_ZN*ZN_0*VZN0) )/Y_0 )*100;
dNXYtime0_imlimkasym    = ( ((NX_imlimkasym-NX_0) + (wNX_1*X10) + (wNX_2*X20)  + (NX_ZT*ZT_0*VZT0) + (NX_ZN*ZN_0*VZN0) )/Y_0 )*100;

dQPItime0_imlimkasym    = ( (wQPI_1*X10) + (wQPI_2*X20) + (QPI_ZT*ZT_0*VZT0) + (QPI_ZN*ZN_0*VZN0) )*100;
dLtime0_imlimkasym      = (((L_imlimkasym-L_0)  + (wL_1*X10) + (wL_2*X20) + (L_ZT*ZT_0*VZT0) + (L_ZN*ZN_0*VZN0) )/L_0)*100;
dLTtime0_imlimkasym     = ( (WT_0/W_0)*( (LT_imlimkasym-LT_0) + (wLT_1*X10) + (wLT_2*X20) + (LT_ZT*ZT_0*VZT0) + (LT_ZN*ZN_0*VZN0)  )/L_0)*100;
dLNtime0_imlimkasym     = ( (WN_0/W_0)*( (LN_imlimkasym-LN_0) + (wLN_1*X10) + (wLN_2*X20) + (LN_ZT*ZT_0*VZT0) + (LN_ZN*ZN_0*VZN0)  )/L_0)*100;
dWtime0_imlimkasym      = (((W_imlimkasym-W_0) + (wW_1*X10) + (wW_2*X20)  + (W_ZT*ZT_0*VZT0) + (W_ZN*ZN_0*VZN0) )/W_0)*100;
dWTtime0_imlimkasym     = (((WT_imlimkasym-WT_0) + (wWT_1*X10) + (wWT_2*X20)  + (WT_ZT*ZT_0*VZT0) + (WT_ZN*ZN_0*VZN0) )/WT_0)*100;
dWNtime0_imlimkasym     = (((WN_imlimkasym-WN_0) + (wWN_1*X10) + (wWN_2*X20)  + (WN_ZT*ZT_0*VZT0) + (WN_ZN*ZN_0*VZN0) )/WN_0)*100;
dWPCtime0_imlimkasym    = (((WPC_imlimkasym-WPC_0) + (wWPC_1*X10) + (wWPC_2*X20)  + (WPC_ZT*ZT_0*VZT0) + (WPC_ZN*ZN_0*VZN0) )/WPC_0)*100;            
dWTPCtime0_imlimkasym   = (((WTPC_imlimkasym-WTPC_0) + (wWTPC_1*X10) + (wWTPC_2*X20)  + (WTPC_ZT*ZT_0*VZT0) + (WTPC_ZN*ZN_0*VZN0) )/WTPC_0)*100;     
dWNPCtime0_imlimkasym   = (((WNPC_imlimkasym-WNPC_0) + (wWNPC_1*X10) + (wWNPC_2*X20)  + (WNPC_ZT*ZT_0*VZT0) + (WNPC_ZN*ZN_0*VZN0) )/WNPC_0)*100;    
dRtime0_imlimkasym      = (((RK_imlimkasym-RK_0) + (wR_1*X10) + (wR_2*X20)  + (R_ZT*ZT_0*VZT0) + (R_ZN*ZN_0*VZN0) )/RK_0)*100; 

dYtime0_imlimkasym      = (((Y_imlimkasym-Y_0) + (wY_1*X10) + (wY_2*X20) + (Y_ZT*ZT_0*VZT0) + (Y_ZN*ZN_0*VZN0)  )/Y_0)*100;
dYRtime0_imlimkasym     = (((YR_imlimkasym-Y_0) + (wYR_1*X10) + (wYR_2*X20) + (YR_ZT*ZT_0*VZT0) + (YR_ZN*ZN_0*VZN0)  )/Y_0)*100;
dYTtime0_imlimkasym     = (((YT_imlimkasym-YT_0) + (wYT_1*X10) + (wYT_2*X20) + (YT_ZT*ZT_0*VZT0) + (YT_ZN*ZN_0*VZN0)  )/Y_0)*100;
dYNtime0_imlimkasym     = ( PN_0*((YN_imlimkasym-YN_0) + (wYN_1*X10) + (wYN_2*X20) + (YN_ZT*ZT_0*VZT0) + (YN_ZN*ZN_0*VZN0)  )/Y_0)*100;

dLTStime0_imlimkasym    = (WT_0/W_0)*( ((LT_imlimkasym/L_imlimkasym)- (LT_0/L_0)) + (wLTS_1*X10) + (wLTS_2*X20)  + (LTS_ZT*ZT_0*VZT0) + (LTS_ZN*ZN_0*VZN0)  )*100;
dLNStime0_imlimkasym    = (WN_0/W_0)*( ((LN_imlimkasym/L_imlimkasym)- (LN_0/L_0)) + (wLNS_1*X10) + (wLNS_2*X20)  + (LNS_ZT*ZT_0*VZT0) + (LNS_ZN*ZN_0*VZN0)  )*100;
dWTWtime0_imlimkasym    = (( ((WT_imlimkasym/W_imlimkasym)-(WT_0/W_0)) + (wWTW_1*X10) + (wWTW_2*X20)+ (WTW_ZT*ZT_0*VZT0) + (WTW_ZN*ZN_0*VZN0) )/(WT_0/W_0) )*100;     
dWNWtime0_imlimkasym    = (( ((WN_imlimkasym/W_imlimkasym)-(WN_0/W_0)) + (wWNW_1*X10) + (wWNW_2*X20)+ (WNW_ZT*ZT_0*VZT0) + (WNW_ZN*ZN_0*VZN0) )/(WN_0/W_0) )*100;     
dYTStime0_imlimkasym    = ( ((YT_imlimkasym/YR_imlimkasym)- (YT_0/Y_0)) + (wYTS_1*X10) + (wYTS_2*X20) + (YTS_ZT*ZT_0*VZT0) + (YTS_ZN*ZN_0*VZN0)  )*100;
dYNStime0_imlimkasym    = P_0*( ((YN_imlimkasym/YR_imlimkasym)- (YN_0/Y_0)) + (wYNS_1*X10) + (wYNS_2*X20) + (YNS_ZT*ZT_0*VZT0) + (YNS_ZN*ZN_0*VZN0) )*100;
dKTKtime0_imlimkasym    =  ( ((KT_imlimkasym/K_imlimkasym)-(KT_0/K_0)) + (wKTK_1*X10) + (wKTK_2*X20)  + (KTK_ZT*ZT_0*VZT0) + (KTK_ZN*ZN_0*VZN0) )*100;
dKNKtime0_imlimkasym    =  ( ((KN_imlimkasym/K_imlimkasym)-(KN_0/K_0)) + (wKNK_1*X10) + (wKNK_2*X20)  + (KNK_ZT*ZT_0*VZT0) + (KNK_ZN*ZN_0*VZN0) )*100;
dkTtime0_imlimkasym     = ( LT_0*((kT_imlimkasym-kT_0) + (wkT_1*X10) + (wkT_2*X20)  + (kT_ZT*ZT_0*VZT0) + (kT_ZN*ZN_0*VZN0)  )/K_0)*100;
dkNtime0_imlimkasym     = ( LN_0*((kN_imlimkasym-kN_0) + (wkN_1*X10) + (wkN_2*X20)  + (kN_ZT*ZT_0*VZT0) + (kN_ZN*ZN_0*VZN0)  )/K_0)*100;
dLISTtime0_imlimkasym   = ( (sLT_imlimkasym-sLT_0) + (wLIST_1*X10) + (wLIST_2*X20)  + (LIST_ZT*ZT_0*VZT0) + (LIST_ZN*ZN_0*VZN0)  )*100;
dLISNtime0_imlimkasym   = ( (sLN_imlimkasym-sLN_0) + (wLISN_1*X10) + (wLISN_2*X20)  + (LISN_ZT*ZT_0*VZT0) + (LISN_ZN*ZN_0*VZN0)  )*100;
dKTtime0_imlimkasym    =  ( (RT_0/RK_0)*( (KT_imlimkasym-KT_0) + (wKT_1*X10) + (wKT_2*X20)  + (KT_ZT*ZT_0*VZT0) + (KT_ZN*ZN_0*VZN0) )/K_0)*100;        
dKNtime0_imlimkasym    =  ( (RN_0/RK_0)*( (KN_imlimkasym-KN_0) + (wKN_1*X10) + (wKN_2*X20)  + (KN_ZT*ZT_0*VZT0) + (KN_ZN*ZN_0*VZN0) )/K_0)*100;        
dRTtime0_imlimkasym    =  (((RT_imlimkasym-RT_0) + (wRT_1*X10) + (wRT_2*X20)  + (RT_ZT*ZT_0*VZT0) + (RT_ZN*ZN_0*VZN0) )/RT_0)*100;                     
dRNtime0_imlimkasym    =  (((RN_imlimkasym-RN_0) + (wRN_1*X10) + (wRN_2*X20)  + (RN_ZT*ZT_0*VZT0) + (RN_ZN*ZN_0*VZN0) )/RN_0)*100;                               

domegaYNtime0_imlimkasym = ( (omegaYN_imlimkasym-omegaYN_0) + (womegaYN_1*X10) + (womegaYN_2*X20) + (omegaYN_ZT*ZT_0*VZT0) + (omegaYN_ZN*ZN_0*VZN0) )*100; 

CA_ZT0 = (B_ZT*ZT_0/(xiZT+r))*VBZTprime0 + (N1*DeltaZT_1/(xiZT+r))*VBZT1prime0 - (N2*DeltaZT_2/(xiZT+r))*VBZT2prime0;
CA_ZN0 = (B_ZN*ZN_0/(xiZN+r))*VBZNprime0 + (N1*DeltaZN_1/(xiZN+r))*VBZN1prime0 - (N2*DeltaZN_2/(xiZN+r))*VBZN2prime0;

SAV_ZT0 = (A_ZT*ZT_0/(xiZT+r))*VBZTprime0 + (M1*DeltaZT_1/(xiZT+r))*VBZT1prime0 - (M2*DeltaZT_2/(xiZT+r))*VBZT2prime0;
SAV_ZN0 = (A_ZN*ZN_0/(xiZN+r))*VBZNprime0 + (M1*DeltaZN_1/(xiZN+r))*VBZN1prime0 - (M2*DeltaZN_2/(xiZN+r))*VBZN2prime0;

dotX10 = (nu_1*X11) - (DeltaZT_1*VZT1prime0) - (DeltaZN_1*VZN1prime0);
dotX20 = (DeltaZT_2*VZT2prime0) +(DeltaZN_2*VZN2prime0);

CAYtime0_imlimkasym = (( -nu_1*(wB1/(r-nu_1)) + CA_ZT0 + CA_ZN0)/Y_0 )*100;
SYtime0_imlimkasym  = (( -nu_1*(wA1/(r-nu_1)) + SAV_ZT0 + SAV_ZN0 )/Y_0 )*100;
IYtime0_imlimkasym  = (( (EK1*dotX10) + (EK2*dotX20) )/Y_0)*100;

CAYtime0_imlimkasym_check = SYtime0_imlimkasym - IYtime0_imlimkasym;

% Steady-state changes and impact effects - scaled to their initial values
hatlambda_imlimkasym   = (dlambda/lambda_0)*100;
dCoverY_imlimkasym     = ((PC_0*dC)/Y_0)*100; % Rate of change of the real consumption
dGY_imlimkasym         = (dG/Y_0)*100; % Chane in G
hatL_imlimkasym        = (dL/L_0)*100; % Rate of change of employment
hatK_imlimkasym        = (dK/K_0)*100; % Rate of change of the stock of foreign assets
dLToverL_imlimkasym    = (WT_0/W_0)*(dLT/L_0)*100; % Rate of change of LH
dLNoverL_imlimkasym    = (WN_0/W_0)*(dLN/L_0)*100; % Rate of change of LN
hatPT_imlimkasym       = (dPT/PT_0)*100; % Rate of change of PH
hatP_imlimkasym        = (dP/P_0)*100; % Rate of change of PN/PH
dBoverY_imlimkasym     = (dB/Y_0)*100; % Rate of change of the stock of foreign assets
dAoverY_imlimkasym     = (dA/Y_0)*100; % Rate of change of the stock of financial assets
hatW_imlimkasym        = (dW/W_0)*100; % Rate of change of wage
hatWPC_imlimkasym      = (dWPC/WPC_0)*100; % Rate of change of Real Aggregate Wage W/pc
hatY_imlimkasym        = (dY/Y_0)*100; % Rate of change of GDP
hatYR_imlimkasym       = ((YR-Y_0)/Y_0)*100; % Rate of change of Real GDP
dYToverY_imlimkasym    = (PT_0*dYT/Y_0)*100; % Rate of change of YH
dYNoverY_imlimkasym    = (P_0*dYN/Y_0)*100; % Rate of change of YN
hatWT_imlimkasym       = (dWT/WT_0)*100; % Rate of change of WT
hatWN_imlimkasym       = (dWN/WN_0)*100; % Rate of change of WN
hatWTPC_imlimkasym     = (dWTPC/WTPC_0)*100; % Rate of change of WH/PC                             
hatWNPC_imlimkasym     = (dWNPC/WNPC_0)*100; % Rate of change of WN/PC    
dkT_imlimkasym         = LT_0*(dkT/K_0)*100; % Rate of change of kH
dkN_imlimkasym         = LN_0*(dkN/K_0)*100; % Rate of change of kN
dLTS_imlimkasym        = (W_0/W_0)*((LT/L)-(LT_0/L_0))*100; % change in  the labor share of T
dLNS_imlimkasym        = (W_0/W_0)*((LN/L)-(LN_0/L_0))*100; % change in the labor share of NT
dYTS_imlimkasym        = PT_0*((YT/YR)-(YT_0/Y_0))*100; % change in the output share of T
dYNS_imlimkasym        = P_0*((YN/YR)-(YN_0/Y_0))*100; % change in the output share of NT
dLIST_imlimkasym       = (sLT_imlimkasym-sLT_0)*100; % Change in the labor income share H
dLISN_imlimkasym       = (sLN_imlimkasym-sLN_0)*100; % Change in the labor income share N
dWTW_imlimkasym        = (((WT/W)-(WT_0/W_0))/((WT_0/W_0)))*100; % Change in the relative wage H
dWNW_imlimkasym        = (((WN/W)-(WN_0/W_0))/((WT_0/W_0)))*100; % Change in the relative wage N
dKTK_imlimkasym        = ((KT/K)-(KT_0/K_0))*100; % Change in the capital share of H
dKNK_imlimkasym        = ((KN/K)-(KN_0/K_0))*100; % Change in the capital share of N
dKToverK_imlimkasym    = (RT_0/RK_0)*(dKT/K_0)*100; % Rate of change of KT  
dKNoverK_imlimkasym    = (RN_0/RK_0)*(dKN/K_0)*100; % Rate of change of KN  
hatRT_imlimkasym       = (dRT/RT_0)*100; % Rate of change of RT                
hatRN_imlimkasym       = (dRN/RN_0)*100; % Rate of change of RN  
                                    
% Technology
hatZT_imlimkasym   = (dZT/ZT_0)*100;
hatZN_imlimkasym   = (dZN/ZN_0)*100;
hatZA_imlimkasym   = (dZA/ZA_0)*100;                                                                                             
                                                                                                         
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                    Final Steady State with kT > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaT  : %5.2f   thetaN   : %5.2f',thetaT,thetaN));
disp(sprintf('phi     : %5.2f   varphi   : %5.2f',phi,varphi));  
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,varphiI)); 
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('epsilonK: %5.2f   varthetaK: %5.2f',epsilonK,varthetaK));
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f sigma   : %5.2f',sigmaL,gammaL,sigma));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZT      : %5.2f   ZN       : %5.2f',ZT,ZN));
disp(sprintf('GT      : %5.2f   GN       : %5.2f  G      : %5.2f',GT,GN,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kT       : %9.3f    kN   : %9.3f',kT,kN));
disp(sprintf('LT       : %9.3f    LN   : %9.3f',LT,LN));
disp(sprintf('KT       : %9.3f    KN   : %9.3f',KT,KN));
disp(sprintf('YT       : %9.3f    YN   : %9.3f',YT,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('CT       :   %7.3f    CN     : %9.3f',CT,CN));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('IT       :   %7.3f    IN     : %9.3f',IT,IN));
disp(sprintf('EI       :   %7.3f',EI));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector T');
disp(sprintf('Gross output (YT)  : %9.3f',YT));
disp(sprintf('WT                 : %9.3f',WT));
disp(sprintf('Profit             : %9.10f',PiT));


disp('Relative Price P=P(lambda,K,Q,ZT,ZN)');
disp(sprintf('DeltaP   :   %7.3f ',DeltaP));
disp(sprintf('P_K      :   %7.3f    P_Q    : %9.3f',P_K,P_Q));
disp(sprintf('P_ZT     :   %7.3f    P_ZN   : %9.3f',P_ZT,P_ZN));

disp('Linearization');
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu_1,nu_2));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp('Eigenvectors');
disp(sprintf('omega11   :   %5.6f  omega12 : %5.6f',omega_11,omega_12));
disp(sprintf('omega21   :   %5.6f  omega22 : %5.6f',omega_21,omega_22));
disp(sprintf('X10       :   %5.3f  X20     : %5.3f ',X10,X20));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT,omegaYN));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT,omegaGNYN,omegaGN));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN,omegaITYT,omegaB));
disp(sprintf('WN*LN/W*L :  %5.3f RN*KN/R*K :  %5.3f',alphaL,alphaK));
disp(sprintf('P*IN/PI*I :  %5.3f P*CN/PC*C :  %5.3f',alphaI,alphaC));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y       :  %5.3f',omegaKY));
disp(' ');
disp(sprintf('Marginal product of KT = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LT = WT       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good T  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Resource constraint for labor     : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond16));
disp(sprintf('Private Savings                   : %9.16f   ',cond17));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond18));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond19));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond20));
disp(sprintf('Capital income R*K                : %9.16f   ',cond21));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond22));
disp(sprintf('alphaC check                      : %9.16f   ',cond23));
disp(sprintf('alphaI check                      : %9.16f   ',cond24));
disp(sprintf('alphaL check                      : %9.16f   ',cond25));
disp(sprintf('P = MN                            : %9.16f   ',cond26));
disp(sprintf('1 = MT                            : %9.16f   ',cond27));
disp(sprintf('-U_L = lambda*WT                  : %9.16f   ',cond28));
disp(sprintf('-U_L = lambda*WN                  : %9.16f   ',cond29));

disp('-------------------------------------------------------------------------------------------------------- ');
disp('                       Increase in gN : Impact and Steady State Changes (after a rise in gN)     ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('                               |     Temporary   |');
disp('-------------------------------------------------------------------------------------------------------- ');
disp(' ');

disp(' ');
disp(' Steady State Deviations ( = (x-x0)/x0 where x0 is the value of x at the initial steady state)  ');
disp(sprintf('hatlambda_imlimkasym        :         |           |%10.3f',hatlambda_imlimkasym));
disp(sprintf('dZAoverZA_imlimkasym        :         |           |%10.3f',hatZA_imlimkasym));
disp(sprintf('dZToverZT_imlimkasym        :         |           |%10.3f',hatZT_imlimkasym));
disp(sprintf('dZNoverZN_imlimkasym        :         |           |%10.3f',hatZN_imlimkasym));
disp(sprintf('dCoverY_imlimkasym          :         |           |%10.3f',dCoverY_imlimkasym));
disp(sprintf('dLoverL_imlimkasym          :         |           |%10.3f',hatL_imlimkasym));
disp(sprintf('dYoverY_imlimkasym          :         |           |%10.3f',hatY_imlimkasym));
disp(sprintf('dYRoverY_imlimkasym         :         |           |%10.3f',hatYR_imlimkasym));
disp(sprintf('dKoverK_imlimkasym          :         |           |%10.3f',hatK_imlimkasym));
disp(sprintf('dLToverL_imlimkasym         :         |           |%10.3f',dLToverL_imlimkasym));
disp(sprintf('dLNover_imlimkasym          :         |           |%10.3f',dLNoverL_imlimkasym));
disp(sprintf('dYToverY_imlimkasym         :         |           |%10.3f',dYToverY_imlimkasym));
disp(sprintf('dYNoverY_imlimkasym         :         |           |%10.3f',dYNoverY_imlimkasym));
disp(sprintf('hatP_imlimkasym             :         |           |%10.3f',hatP_imlimkasym));
disp(sprintf('hatPT_imlimkasym            :         |           |%10.3f',hatPT_imlimkasym));
disp(sprintf('dBoverY_imlimkasym          :         |           |%10.3f',dBoverY_imlimkasym));
disp(sprintf('dAoverY_imlimkasym          :         |           |%10.3f',dAoverY_imlimkasym));
disp(sprintf('dWoverW_imlimkasym          :         |           |%10.3f',hatW_imlimkasym));
disp(sprintf('dW/PC_imlimkasym            :         |           |%10.3f',hatWPC_imlimkasym));
disp(sprintf('dWToverWT_imlimkasym        :         |           |%10.3f',hatWT_imlimkasym));
disp(sprintf('dWNoverWN_imlimkasym        :         |           |%10.3f',hatWN_imlimkasym));
disp(sprintf('dWT/PC_imlimkasym           :         |           |%10.3f',hatWTPC_imlimkasym));
disp(sprintf('dWN/PC_imlimkasym           :         |           |%10.3f',hatWNPC_imlimkasym));
disp(sprintf('dkToverK_imlimkasym         :         |           |%10.3f',dkT_imlimkasym));
disp(sprintf('dkNoverK_imlimkasym         :         |           |%10.3f',dkN_imlimkasym));
disp(sprintf('domegaLT_imlimkasym         :         |           |%10.3f',dLTS_imlimkasym));
disp(sprintf('domegaLN_imlimkasym         :         |           |%10.3f',dLNS_imlimkasym));
disp(sprintf('domegaYTS_imlimkasym        :         |           |%10.3f',dYTS_imlimkasym));
disp(sprintf('domegaYNS_imlimkasym        :         |           |%10.3f',dYNS_imlimkasym));
disp(sprintf('dLIST_imlimkasym            :         |           |%10.3f',dLIST_imlimkasym));   
disp(sprintf('dLISN_imlimkasym            :         |           |%10.3f',dLISN_imlimkasym));   
disp(sprintf('dWTW_imlimkasym             :         |           |%10.3f',dWTW_imlimkasym));    
disp(sprintf('dWNW_imlimkasym             :         |           |%10.3f',dWNW_imlimkasym)); 
disp(sprintf('dRToverRT_imlimkasym        :         |           |%10.3f',hatRT_imlimkasym));
disp(sprintf('dRNoverRN_imlimkasym        :         |           |%10.3f',hatRN_imlimkasym));
disp(sprintf('dKToverK_imlimkasym         :         |           |%10.3f',dKToverK_imlimkasym));
disp(sprintf('dKNoverK_imlimkasym         :         |           |%10.3f',dKNoverK_imlimkasym));

%disp(' ');
disp('                                           Initial responses ');
disp(sprintf('dZAtime0_imlimkasym        :                |                 |%10.3f',dZAtime0_imlimkasym));
disp(sprintf('dZTtime0_imlimkasym        :                |                 |%10.3f',dZTtime0_imlimkasym));
disp(sprintf('dZNtime0_imlimkasym        :                |                 |%10.3f',dZNtime0_imlimkasym));
disp(sprintf('dCYtime0_imlimkasym        :                |                 |%10.3f',dCYtime0_imlimkasym));
disp(sprintf('dLtime0_imlimkasym         :                |                 |%10.3f',dLtime0_imlimkasym));
disp(sprintf('dLTtime0_imlimkasym        :                |                 |%10.3f',dLTtime0_imlimkasym));
disp(sprintf('dLNtime0_imlimkasym        :                |                 |%10.3f',dLNtime0_imlimkasym));
disp(sprintf('dYtime0_imlimkasym         :                |                 |%10.3f',dYtime0_imlimkasym));
disp(sprintf('dYRtime0_imlimkasym        :                |                 |%10.3f',dYRtime0_imlimkasym));
disp(sprintf('dYTtime0_imlimkasym        :                |                 |%10.3f',dYTtime0_imlimkasym));
disp(sprintf('dYNtime0_imlimkasym        :                |                 |%10.3f',dYNtime0_imlimkasym));
disp(sprintf('domegaYNtime0_imlimkasym   :                |                 |%10.3f',domegaYNtime0_imlimkasym));
disp(sprintf('dPtime0_imlimkasym         :                |                 |%10.3f',dPtime0_imlimkasym));
disp(sprintf('dSYtime0_imlimkasym        :                |                 |%10.3f',SYtime0_imlimkasym));
disp(sprintf('dIYtime0_imlimkasym        :                |                 |%10.3f',IYtime0_imlimkasym));
disp(sprintf('dCAYtime0_imlimkasym       :                |                 |%10.5f',CAYtime0_imlimkasym)); 
disp(sprintf('dCAYtime0_imlimkasym_check :                |                 |%10.5f',CAYtime0_imlimkasym_check)); 
disp(sprintf('dRtime0_imlimkasym         :                |                 |%10.3f',dRtime0_imlimkasym));
disp(sprintf('dWtime0_imlimkasym         :                |                 |%10.3f',dWtime0_imlimkasym));
disp(sprintf('dWPCtime0_imlimkasym       :                |                 |%10.3f',dWPCtime0_imlimkasym));
disp(sprintf('dWTtime0_imlimkasym        :                |                 |%10.3f',dWTtime0_imlimkasym));
disp(sprintf('dWNtime0_imlimkasym        :                |                 |%10.3f',dWNtime0_imlimkasym));
disp(sprintf('dWTPCtime0_imlimkasym      :                |                 |%10.3f',dWTPCtime0_imlimkasym));
disp(sprintf('dWNPCtime0_imlimkasym      :                |                 |%10.3f',dWNPCtime0_imlimkasym));
disp(sprintf('dPTtime0_imlimkasym        :                |                 |%10.3f',dPTtime0_imlimkasym));
disp(sprintf('dPtime0_imlimkasym         :                |                 |%10.3f',dPtime0_imlimkasym));
disp(sprintf('dkTtime0_imlimkasym        :                |                 |%10.3f',dkTtime0_imlimkasym));
disp(sprintf('dkNtime0_imlimkasym        :                |                 |%10.3f',dkNtime0_imlimkasym));
disp(sprintf('dLTStime0_imlimkasym       :                |                 |%10.3f',dLTStime0_imlimkasym));
disp(sprintf('dLNStime0_imlimkasym       :                |                 |%10.3f',dLNStime0_imlimkasym));
disp(sprintf('dYTStime0_imlimkasym       :                |                 |%10.3f',dYTStime0_imlimkasym));
disp(sprintf('dYNStime0_imlimkasym       :                |                 |%10.3f',dYNStime0_imlimkasym)); 
disp(sprintf('dWTWtime0_imlimkasym       :                |                 |%10.3f',dWTWtime0_imlimkasym));       
disp(sprintf('dWNWtime0_imlimkasym       :                |                 |%10.3f',dWNWtime0_imlimkasym));       
disp(sprintf('dLISTtime0_imlimkasym      :                |                 |%10.3f',dLISTtime0_imlimkasym));      
disp(sprintf('dLISNtime0_imlimkasym      :                |                 |%10.3f',dLISNtime0_imlimkasym));  
disp(sprintf('dKTtime0_imlimkasym        :                |                 |%10.3f',dKTtime0_imlimkasym));
disp(sprintf('dKNtime0_imlimkasym        :                |                 |%10.3f',dKNtime0_imlimkasym));
disp(sprintf('dRTtime0_imlimkasym        :                |                 |%10.3f',dRTtime0_imlimkasym));
disp(sprintf('dRNtime0_imlimkasym        :                |                 |%10.3f',dRNtime0_imlimkasym));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT_0,omegaYN_0));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT_0,omegaLN_0));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC_0,omegaNX_0));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI_0,omegaG_0));
disp(' ');
disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT_0,omegaGNYN_0,omegaGN_0));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN_0,omegaITYT_0,omegaB_0));
disp(sprintf('WT*LT/W*L :  %5.3f RT*KT/R*K :  %5.3f',alphaL_0,alphaK_0));
disp(sprintf('IT/PI*I   :  %5.3f CT/PC*C :  %5.3f',alphaI_0,alphaC_0));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL_0,omegaK_0));
disp(sprintf('K/Y       :  %5.3f',omegaKY_0));


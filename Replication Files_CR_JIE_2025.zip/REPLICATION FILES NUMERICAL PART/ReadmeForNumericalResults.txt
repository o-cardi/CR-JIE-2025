Data and Replication Codes for 'Why Hours Worked Decline Less after Technology Shocks' by Olivier Cardi and Romain Restout, April 2025

The Folder 'REPLICATION FILES NUMERICAL PART' comprises three folders: 

1) The folder 'TABLE2 - Impact Effects of a Technology Improvement' contains all Matlab codes 
(plus excel files which contain the shock process) to generate impact effects shown in Table 2 in the main text 
(Table 2 in section 4.2). To generate Table 2 in the main text, run 'TABLE_SYMvsASYM.m' file. 
 
CAC: Capital adjustment costs; 
TOT: Terms of trade; 
IML: Imperfect mobility of labor;
IMK: Imperfect mobility of capital; 
PML: Perfect mobility of labor;
CD: Cobb-Douglas production functions and Hicks neutral technological change;
CES: Constant elasticity of substitution production functions; 
FBTC: Factor-biased technological change;
nocaput: No endogenous intensity in the use of physical capital, i.e., we let xi_2^j tend towards infinity;
NS: Shimer (2009) preferences with non separability between consumption and leisure; 

Extension _SYM means that the model is simulated by considering only symmetric technology shocks;
Extension _ASYM means that the model is simulated by considering only asymmetric technology shocks;
Extension _SYMvsASYM means that the model is simulated by considering a mix of symmetric and asymmetric technology shocks;

Model variants considered (the last model 'IML_IMK_CAC_TOT_CES_NS_NORMALIZED' underneath is the baseline model):  
PML_CAC; Model with CD production functions, NS Preferences, CAC, perfect moility of labor and capital, exogenous TOT, and no endogenous capital utilization rate; 
IML_IMK_CAC; Model with CD production functions, NS Preferences, CAC, IML and IMK, exogenous TOT, and no endogenous capital utilization rate; 
IML_IMK_CAC_TOT_CES_NS_HNTC_NORMALIZED: Model with CES production functions, NS Preferences, CAC, IML and IMK, endogenous TOT. We shut down endogenous capital utilization. 
IML_IMK_CAC_TOT_CES_NS_NORMALIZED: Baseline model with CES production functions, NS Preferences, CAC, IML and IMK, endogenous TOT, endogenous capital utilization and FBTC. 

The CES economy is normalized by using the Cobb-Douglas economy as the normalization point. 
CD_IMK_NS_initial: Model with Cobb-Douglas production functions which generates the initial steady-state which is considered as the reference point for the CES economy (i.e., ensures that ratios are unchanged when we modify the elasticity of substitution between 
capital and labor). 
CD_IMK_NS_HNTC_initial: Same model as the previous one except the initial steady-state which is generated is the one where we abstract from endogenous capital utilization. 

All extensions of Matlab codes '_SS0' compute the initial steady-state
All extensions of Matlab codes '_perm' compute the final steady-state
Note that technically, the assumption beta = world interest rate requires the joint determination of the transition and the steady state because the marginal utility of wealth must remain constant and thus must jump initially to fulfill the intertemporal solvency condition which is a function of eigenvalues and eigenvectors. 
All extensions of Matlab codes '_initial' compute the initial steady-state for the eocnomy with CD production functions which is the normalization point. 

Note that TABLE_SYMvsASYM.m provides more results than those shown in Table 2: 
-Columns 1-3 of TABLE_SYMvsASYM.m show results after an aggrregate, a symmetric, and an asymmetric technology shock, respectively, for the baseline model; 
-Columns 4-6 of TABLE_SYMvsASYM.m show results after an aggrregate, a symmetric, and an asymmetric technology shock, respectively, for the restricted model with Hicks neutral tehcnological change and no capital utilization; 
-Columns 7-9 of TABLE_SYMvsASYM.m show results after an aggrregate, a symmetric, and an asymmetric technology shock, respectively, for the restricted model with CD production functions and exogenous terms of trade;
-Columns 10-12 of TABLE_SYMvsASYM.m show results after an aggrregate, a symmetric, and an asymmetric technology shock, respectively, for the restricted model with CD production functions, exogenous terms of trade, and perfect mobility of inputs across sectors;

2) The folder 'FIGURE 5 - Theoretical vs. Empirical Responses Following a Technology Shock' contains all Matlab codes (plus 'Calibration_sym_asym.xlsx' that contains the shock process) to generate Figure 5 in the main text 
(Figure 5 in section 4.3). To generate the IRFs in the main text, run 'FIGURE5_THEORETICALvsEMPIRICAL_IRF.m' file

3) The folder 'FIGURE 6 - Time-Varying Impact Effects of a Technology Shock' contains all Matlab codes (plus 'Calibration_sym_asym.xlsx' that contains the shock process) to generate Figure 6 in the main text 
(Figure 6 in section 4.4). To generate the IRFs in the main text, first run 'ESTIM_TABLE_SYMvsASYM.m' file. 
It will give you the impact responses for traded, non-traded and total hours after a technology shock whoich is a mix of symmetric and asymmetric technology shocks. 
The results are shown in the excel file 'Time-varying-impact-responses-of-hours.xlsx'. 
Next run 'FIGURE6.m' to generate Figures 6a, 6b, 6c in the main text. Note that you have to specify the right path in 
pathin      = fullfile('C:\Users\Installeur\Documents\FILE',filesep);
pathout     = fullfile('C:\Users\Installeur\Documents\FILE',filesep);

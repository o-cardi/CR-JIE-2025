%clc
%clear

global sigma phi varphi rho varphiH
global gammaL sigmaL
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global epsilonK varthetaK 
global r deltaK kappa
global omegaG omegaGN omegaGH GH GN GF 
global BH BN AH AN gammaH gammaN sigmaH sigmaN ZH ZN
global xi1SH xi1DH xi1SN xi1DN xi2SH xi2DH xi2SN xi2DN
global B0 K0 Y_0 omegaG_0 AH_0 BH_0 AN_0 BN_0 ASH_0 BSH_0 ASN_0 BSN_0 ADH_0 BDH_0 ADN_0 BDN_0 ZH_0 ZN_0 
global xi xiASH xiADH xiBSH xiBDH xiASN xiADN xiBSN xiBDN   
global chi chiASH chiADH chiBSH chiBDH chiASN chiADN chiBSN chiBDN 
global baraSH baraDH barbSH barbDH baraSN baraDN barbSN barbDN barg eta
global gG gASH gADH gBSH gBDH gASN gADN gBSN gBDN 

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

CD_IMK_NS_initial; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% CES and FBTC - TECH EXO   %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigmaH_0     = 0.808;                                                                                                       
sigmaN_0     = 0.865;
gammaH_0     = sLH_0CD*( sLH_0CD + (1-sLH_0CD)*(kH_0CD^((1-sigmaH_0)/sigmaH_0)) )^(-1);                           
gammaN_0     = sLN_0CD*( sLN_0CD + (1-sLN_0CD)*(kN_0CD^((1-sigmaN_0)/sigmaN_0)) )^(-1);                              
ZH_0         = (YH_0CD/LH_0CD)*( gammaH_0 + (1-gammaH_0)*(kH_0CD^((sigmaH_0 - 1)/sigmaH_0)) )^(sigmaH_0/(1-sigmaH_0));      
ZN_0         = (YN_0CD/LN_0CD)*( gammaN_0 + (1-gammaN_0)*(kN_0CD^((sigmaN_0 - 1)/sigmaN_0)) )^(sigmaN_0/(1-sigmaN_0));      
AH_0         = ZH_0;                                                                                                        
AN_0         = ZN_0;                                                                                                        
BH_0         = ZH_0;                                                                                                        
BN_0         = ZN_0; 
eta          = 0.8402; % Share of symmetric technology shocks

omegaG       = 0.198; 
omegaGN      = 0.838; 
omegaGH      = 0.65;
sigmaL_0     = 3;
gammaL       = 1; 
sigma        = 2;  
phi_0        = 0.35;
varphi_0     = alphaC_0CD*( alphaC_0CD + (1-alphaC_0CD)*((PN_0CD/PT_0CD)^(phi_0 -1)) )^(-1); 
rho_0        = 1.3;  
varphiH_0    = alphaH_0CD*( alphaH_0CD + (1-alphaH_0CD)*((PH_0CD)^(1-rho_0)) )^(-1); 
epsilon_0    = 0.8;  
vartheta_0   = alphaL_0CD*( alphaL_0CD + (1-alphaL_0CD)*((WH_0CD/WN_0CD)^(1+epsilon_0)) )^(-1); 
epsilonK_0   = 0.15;  
varthetaK_0  = alphaK_0CD*( alphaK_0CD + (1-alphaK_0CD)*((RH_0CD/RN_0CD)^(1+epsilonK_0)) )^(-1); 
phiI_0       = 1.000001;                    
iota_0       = 0.319;  
rhoI_0       = 1.3;  
iotaH_0      = alphaIH_0CD*( alphaIH_0CD + (1-alphaIH_0CD)*((PH_0CD)^(1-rhoI_0)) )^(-1);
kappa        = 17; 
nuX          = 1.3;
ex           = omegaXHY_0CD*Y_0CD*(PH_0CD)^(nuX-1);

r            = 0.027; 
beta         = r; 
deltaK       = (omegaI_0CD/PI_0CD)*(Y_0CD/K_0CD); 

B0           = Y_0CD*(omegaC_0CD+omegaI_0CD+omegaG-1)/r;                                                               
K0           = K_0CD + ((B0 - B_0CD)/H1_0CD); 
 
AH           = AH_0;       
AN           = AN_0;  
BH           = BH_0;       
BN           = BN_0;
gammaH       = gammaH_0;   
gammaN       = gammaN_0;  
sigmaH       = sigmaH_0;   
sigmaN       = sigmaN_0;       
sigmaL       = sigmaL_0;   
phi          = phi_0;     
varphi       = varphi_0;  
rho          = rho_0;     
varphiH      = varphiH_0;
phiI         = phiI_0;    
iota         = iota_0; 
rhoI         = rhoI_0;    
iotaH        = iotaH_0;
epsilon      = epsilon_0;  
vartheta     = vartheta_0; 
epsilonK     = epsilonK_0;  
varthetaK    = varthetaK_0;
                                                                                                                                                                                                                                                                                                                                                                     
xi2SH     = 0.5;  % capital utiliation adustment costs in the traded sector 
xi2DH     = 0.03; %0.01; %0.02; %0.08; % capital utilization adustment costs in the traded sector
xi2SN     = 0.6;  % capital utilization adustment costs in the non-traded sector 
xi2DN     = 0.5;  % capital utilization adustment costs in the non-traded sector 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.270  ; % Consumption
L_ini        = 0.905  ; % Total hours worked
RH_ini       = 0.220  ; % Capital rental rate in sector H
RN_ini       = 0.220  ; % Capital rental rate in sector N
WH_ini       = 3.763  ; % Wage rate in sector H
WN_ini       = 4.244  ; % Wage rate in sector N
W_ini        = 4.065  ; % Aggregate wage index
RK_ini       = 0.220  ; % Aggregate capital rental rate
PN_ini       = 3.104  ; % Non-traded good prices
K_ini        = 8.447  ; % Stock of capital
PH_ini       = 2.540  ; % Terms of trade
B_ini        = 0.63   ; % Stock of traded Bonds
alphaL_ini   = 0.333  ; % Labor compensation share of tradables
alphaK_ini   = 0.389  ; % Capital compensation share of tradables
PC_ini       = 2.491  ; % Aggregate consumption price index
PT_ini       = 1.898  ; % Consumption price index for tradables
CN_ini       = 0.576  ; % Consumption in non-traded goods
CH_ini       = 0.356  ; % Consumption in home-produced traded goods
CF_ini       = 0.472  ; % Consumption in foreign goods
alphaC_ini   = 0.434  ; % Tradable content of consumption expenditure
alphaH_ini   = 0.657  ; % Home goods content of consumption expenditure on traded goods
PI_ini       = 2.477  ; % Aggregate investment price index
PIT_ini      = 1.531  ; % Investment price index for traded goods
IN_ini       = 0.285  ; % Non traded investment
IH_ini       = 0.069  ; % Home goods investment
IF_ini       = 0.239  ; % Foreign goods investment
alphaI_ini   = 0.319  ; % Tradable content of investment expenditure
alphaIH_ini  = 0.422  ; % Home goods content of investment expenditure on traded goods
LH_ini       = 0.326  ; % Labor in sector H
LN_ini       = 0.578  ; % Labor in sector N
KH_ini       = 3.282  ; % Capital stock in sector H
KN_ini       = 5.165  ; % Capital stock in sector N
GF_ini       = 0.03   ; % Government spending in foreign goods
GH_ini       = 0.05   ; % Government spending in home goods
GN_ini       = 0.30   ; % Government spending in non tradables
YH_ini       = 0.768  ; % Traded value added
YN_ini       = 1.158  ; % Non traded value added
XH_ini       = 0.298  ; % Exports of home traded goods
MF_ini       = 0.773  ; % Imports of foreign goods
xi1SH_ini    = 0.09   ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1DH_ini    = 0.09   ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1SN_ini    = 0.07   ; % Parameter of non-traded capital utilization cost function
xi1DN_ini    = 0.07   ; % Parameter of non-traded capital utilization cost function
VL_ini       = 1.41   ; % Desutility labor
lambda_ini   = 0.494  ; % Intertemporal Solvency Condition

x0 =[C_ini L_ini RH_ini RN_ini WH_ini WN_ini W_ini RK_ini PN_ini K_ini PH_ini B_ini alphaL_ini alphaK_ini PC_ini PT_ini CN_ini CH_ini CF_ini alphaC_ini alphaH_ini PI_ini PIT_ini IN_ini IH_ini IF_ini alphaI_ini alphaIH_ini LH_ini LN_ini KH_ini KN_ini GF_ini GN_ini GH_ini YH_ini YN_ini XH_ini MF_ini xi1SH_ini xi1DH_ini xi1SN_ini xi1DN_ini VL_ini lambda_ini];
[x,~,exitflag]=fsolve('IML_IMK_CAC_TOT_CES_NS_SS0',x0,optimset('display','off','TolFun',1e-011));

C        = x(1)  ; % Consumption
L        = x(2)  ; % Labor supply
RH       = x(3)  ; % Return on traded capital
RN       = x(4)  ; % Return on non-traded capital
WH       = x(5)  ; % Wage rate in sector H
WN       = x(6)  ; % Wage rate in sector N
W        = x(7)  ; % Aggregate wage index
RK       = x(8)  ; % Aggregate capital rental rate
PN       = x(9)  ; % Relative price of non tradables
K        = x(10)  ; % Stock of capital
PH       = x(11) ; % Terms of trade : PH/PF with PF = numeraire
B        = x(12) ; % Stock of Traded Bonds
alphaL   = x(13) ; % Labor compensation share of tradables
alphaK   = x(14) ; % Capital compensation share of tradables
PC       = x(15) ; % Aggregate consumption price index
PT       = x(16) ; % Consumption price index for tradables
CN       = x(17) ; % Consumption in non tradables
CH       = x(18) ; % Consumption in tradables
CF       = x(19) ; % Consumption goods imports
alphaC   = x(20) ; % Tradable content of consumption expenditure
alphaH   = x(21) ; % Home goods content of consumption expenditure on traded goods
PI       = x(22) ; % Aggregate investment price index
PIT      = x(23) ; % Investment price index for tradables
IN       = x(24) ; % Non tradable investment
IH       = x(25) ; % Investment in home goods
IF       = x(26) ; % Investment in foreign goods
alphaI   = x(27) ; % Tradable content of investment expenditure
alphaIH  = x(28) ; % Home goods content of investment expenditure
LH       = x(29) ; % Labor in sector H
LN       = x(30) ; % Labor in sector N
KH       = x(31) ; % Capital stock in sector H
KN       = x(32) ; % Capital stock in sector N
GF       = x(33) ; % Government spending in foreign goods
GN       = x(34) ; % Government spending in non tradables
GH       = x(35) ; % Government spending in home traded goods
YH       = x(36) ; % Traded value added
YN       = x(37) ; % Non-traded value added
XH       = x(38) ; % Exports of home traded goods
MF       = x(39) ; % Imports of foreign goods
xi1SH    = x(40) ; % Parameter of traded capital utilization cost function associated with symmetric technology uKSH
xi1DH    = x(41) ; % Parameter of traded capital utilization cost function associated with asymmetric technology uKDH
xi1SN    = x(42) ; % Parameter of non-traded capital utilization cost function associated with symmetric technology uKSN
xi1DN    = x(43) ; % Parameter of traded capital utilization cost function associated with asymmetric technology uKDN
VL       = x(44) ; % Desutility labor
lambda   = x(45) ; % Marginal Utility of Wealth - Intertemporal Solvency Condition                                                 

% Sectoral outputs and sectoral profits    
PiH = (PH*YH) - (RH*KH) - (WH*LH);  
PiN = (PN*YN) - (RN*KN) - (WN*LN);

% Value added and labor share
Y   = (PH*YH) +(PN*YN);
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L; 

% Labor income share in the home traded good and non traded good sector
kH  = KH/LH; 
kN  = KN/LN; 
yH  = YH/LH; 
yN  = YN/LN; 
sLH = WH*LH/(PH*YH);
sLN = WN*LN/(PN*YN);
sL  = W*L/Y; 
k   = K/L; 
P   = PN/PH; 
KHK = KH/K; 

% Unit cost for producting
MN = ((gammaN^sigmaN)*((WN/AN)^(1-sigmaN)) + ((1-gammaN)^sigmaN)*((RN/BN)^(1-sigmaN)))^(1/(1-sigmaN));   
MH = ((gammaH^sigmaH)*((WH/AH)^(1-sigmaH)) + ((1-gammaH)^sigmaH)*((RH/BH)^(1-sigmaH)))^(1/(1-sigmaH));   

% Technology
ZH = ((AH)^(sLH))*((BH)^(1-sLH)); 
ZN = ((AN)^(sLN))*((BN)^(1-sLN)); 
ZA = (ZH^omegaYH)*(ZN^(1-omegaYH));
TFPH = YH/(gammaH*(LH^((sigmaH-1)/sigmaH)) + (1-gammaH)*(KH^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1)); 
TFPN = YN/(gammaN*(LN^((sigmaN-1)/sigmaN)) + (1-gammaN)*(KN^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1)); 
TFPA = (TFPH^omegaYH)*(TFPN^(1-omegaYH));

% Non Sep preferences Shimer (2009)
%VL        = ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );
V_L       = (sigma-1)*gammaL*L^(1/sigmaL);
V_LL      = (sigma-1)*(gammaL/sigmaL)*(L^((1/sigmaL)-1)); 
U_C       =  (C^(-sigma))*(VL^sigma); 
U_CC      = -sigma*(C^(-sigma-1))*(VL^sigma); 
U_L       = ( (C^(1-sigma))*sigma*V_L*(VL^(sigma-1)) )/(1-sigma);
U_LL      = U_L*( (V_LL/V_L) + (sigma-1)*(V_L/VL) ); 
U_CL      = (C^(-sigma))*sigma*V_L*(VL^(sigma-1));
U_LC      = U_CL; 

% Solutions C=C(lambda,PN,PH,W); L=L(lambda,PN,PH,W)                      
a11 = (U_CC/U_C);                                                         
a12 = (U_CL/U_C);                                                         
a21 = (U_LC/U_L);                                                         
a22 = (U_LL/U_L);                                                         
                                                                          
% PN, PH, W, lambda                                                            
b11 = (1-alphaC)/PN;                                                      
b12 = alphaC*alphaH/PH;                                                   
b13 = 0; 
b14 = (1/lambda); 
                                                                          
b21 = 0;                                                                  
b22 = 0;                                                                  
b23 = (1/W);   
b24 = (1/lambda); 
                                                                          
A1 = [a11 a12; a21 a22];                                                  
B1 = [b11 b12 b13 b14; b21 b22 b23 b24];                                          
JST1 = inv(A1);                                                           
MST1 = JST1*B1;                                                           
C_1PN = MST1(1,1); C_1PH = MST1(1,2); C_W = MST1(1,3); C_1lambda = MST1(1,4);                  
L_1PN = MST1(2,1); L_1PH = MST1(2,2); L_W = MST1(2,3); L_1lambda = MST1(2,4);

% Partial derivatives of W=W(WN,WH)           
W_WH     = (W/WH)*alphaL; 
W_WN     = (W/WN)*(1-alphaL);                                                                                                                         
L_WH     = L_W*W_WH;                                                                    
L_WN     = L_W*W_WN;                                                                    
                                                                                        
% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH,WN,WH)                      
CN_1PN = - (CN/PN)*(alphaC*phi) + (CN/C)*C_1PN;                                         
CN_1PH = (CN/PH)*alphaC*alphaH*phi + (CN/C)*C_1PH;                                      
CN_WN  = (CN/C)*C_W*W_WN;                                                               
CN_WH  = (CN/C)*C_W*W_WH;                                                               
                                                                                        
CH_1PN = (CH/PN)*phi*(1-alphaC) + (CH/C)*C_1PN;                                         
CH_1PH = -(CH/PH)*( rho*(1-alphaH) + phi*alphaH*(1-alphaC) ) + (CH/C)*C_1PH;            
CH_WN  = (CH/C)*C_W*W_WN;                                                               
CH_WH  = (CH/C)*C_W*W_WH;                                                               
                                                                                        
CF_1PN = (CF/PN)*(1-alphaC)*phi + (CF/C)*C_1PN;                                         
CF_1PH = (CF/PH)*alphaH*(rho - phi*(1-alphaC) ) + (CF/C)*C_1PH;                         
CF_WN  = (CF/C)*C_W*W_WN;                                                               
CF_WH  = (CF/C)*C_W*W_WH;   

CH_1lamb = (CH/C)*C_1lambda; 
CN_1lamb = (CN/C)*C_1lambda;
CF_1lamb = (CF/C)*C_1lambda;

% Solutions LH=LH(lambda,WH,WN,PH,PN), LN=LN(lambda,WH,WN,PH,PN)
LH_WH  = (LH/WH)*epsilon*(1-alphaL) + (LH/L)*L_WH; 
LH_WN  = -(LH/WN)*epsilon*(1-alphaL) + (LH/L)*L_WN; 
LH_1PH = (LH/L)*L_1PH; 
LH_1PN = (LH/L)*L_1PN;

LN_WH  = -(LN/WH)*epsilon*alphaL + (LN/L)*L_WH; 
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN; 
LN_1PH = (LN/L)*L_1PH; 
LN_1PN = (LN/L)*L_1PN;

LH_1lamb   = (LH/L)*L_1lambda;
LN_1lamb   = (LN/L)*L_1lambda;

% Partial derivatives of RK(RH,RN)               
R_RH  = (RK/RH)*alphaK;                         
R_RN  = (RK/RN)*(1-alphaK);                     
                                                 
% Solutions Kj=Kj(RH,RN,K), j=H,N                
KH_RH  = (KH/RH)*epsilonK*(1-alphaK);            
KH_RN  = -(KH/RN)*epsilonK*(1-alphaK);           
KH_1K  = (KH/K);                                 
                                                 
KN_RH  = -(KN/RH)*epsilonK*alphaK;               
KN_RN  = (KN/RN)*epsilonK*alphaK;                
KN_1K  = (KN/K);                                    

% Solving for WH,WN,RH,RN(PH,PN,K,uKH,uKN,AH,BH,AN,BN,lambda)
d11 = - ( ((1-sLH)/sigmaH)*(LH_WH/LH) + (1/WH) ); % WH
d12 = - ((1-sLH)/sigmaH)*(LH_WN/LH);  % WN
d13 = ((1-sLH)/sigmaH)*(KH_RH/KH);  % RH
d14 = ((1-sLH)/sigmaH)*(KH_RN/KH); % RN

d21 = - ((1-sLN)/sigmaN)*(LN_WH/LN);  % WH
d22 = - ( ((1-sLN)/sigmaN)*(LN_WN/LN) + (1/WN) ); % WN
d23 = ((1-sLN)/sigmaN)*(KN_RH/KN);  % RH
d24 = ((1-sLN)/sigmaN)*(KN_RN/KN); % RN

d31 = (sLH/sigmaH)*(LH_WH/LH); % WH
d32 = (sLH/sigmaH)*(LH_WN/LH); % WN
d33 = - ( (sLH/sigmaH)*(KH_RH/KH) + (1/RH) ); % RH
d34 = - (sLH/sigmaH)*(KH_RN/KH); % RN

d41 = (sLN/sigmaN)*(LN_WH/LN); % WH
d42 = (sLN/sigmaN)*(LN_WN/LN); % WN
d43 = - (sLN/sigmaN)*(KN_RH/KN); % RH
d44 = - ( (sLN/sigmaN)*(KN_RN/KN) + (1/RN) ); % RN

% PN,PH,K,uKH,uKN,AH,BH,AN,BN,lambda
e11 = ((1-sLH)/sigmaH)*(LH_1PN/LH); % PN
e12 = ((1-sLH)/sigmaH)*(LH_1PH/LH) - (1/PH); % PH
e13 = - ((1-sLH)/sigmaH)*(KH_1K/KH); % K
e14 = - ((1-sLH)/sigmaH); % uKH
e15 = 0; % uKN
e16  = - ( ((sigmaH-1)/sigmaH)+ (sLH/sigmaH) )*(1/AH);  % AH
e17  = - ((1-sLH)/sigmaH)*(1/BH);  % BH
e18  = 0;
e19  = 0;
e110 = ((1-sLH)/sigmaH)*(LH_1lamb/LH); % lambda

e21 = ((1-sLN)/sigmaN)*(LN_1PN/LN) - (1/PN); % PN
e22 = ((1-sLN)/sigmaN)*(LN_1PH/LN);  % PH
e23 = - ((1-sLN)/sigmaN)*(KN_1K/KN); % K
e24 = 0; % uKH
e25 = - ((1-sLN)/sigmaN);  % uKN
e26  = 0;
e27  = 0;
e28  = - ( ((sigmaN-1)/sigmaN) + (sLN/sigmaN) )*(1/AN);  % AN
e29  = - ((1-sLN)/sigmaN)*(1/BN);    % BN
e210 = ((1-sLN)/sigmaN)*(LN_1lamb/LN);  % lambda

e31 = - (sLH/sigmaH)*(LH_1PN/LH); % PN
e32 = - ( (sLH/sigmaH)*(LH_1PH/LH) + (1/PH) ); % PH
e33 = (sLH/sigmaH)*(KH_1K/KH); % K
e34 = (sLH/sigmaH); % uKH
e35 = 0;  % uKN
e36  = - (sLH/sigmaH)*(1/AH); % AH
e37  = - ((sigmaH-sLH)/sigmaH)*(1/BH); % BH
e38  = 0;
e39  = 0;
e310 = - (sLH/sigmaH)*(LH_1lamb/LH); % lambda

e41 = - ( (sLN/sigmaN)*(LN_1PN/LN) + (1/PN) ); % PN
e42 = - (sLN/sigmaN)*(LN_1PH/LN); % PH
e43 = (sLN/sigmaN)*(KN_1K/KN); % K
e44 = 0;  % uKH
e45 = (sLN/sigmaN); % uKN
e46  = 0;
e47  = 0;
e48  = - (sLN/sigmaN)*(1/AN); % AN
e49  = - ((sigmaN-sLN)/sigmaN)*(1/BN); % BN
e410 = - (sLN/sigmaN)*(LN_1lamb/LN); % lambda

M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X2 = [e11 e12 e13 e14 e15 e16 e17 e18 e19 e110; e21 e22 e23 e24 e25 e26 e27 e28 e29 e210; e31 e32 e33 e34 e35 e36 e37 e38 e39 e310; e41 e42 e43 e44 e45 e46 e47 e48 e49 e410];
JST2 = inv(M2);
MST2 = JST2*X2;
WH_1PN = MST2(1,1); WH_1PH = MST2(1,2); WH_1K = MST2(1,3); WH_uKH = MST2(1,4); WH_uKN = MST2(1,5); WH_1AH = MST2(1,6); WH_1BH = MST2(1,7); WH_1AN = MST2(1,8); WH_1BN = MST2(1,9); WH_1lambda = MST2(1,10);
WN_1PN = MST2(2,1); WN_1PH = MST2(2,2); WN_1K = MST2(2,3); WN_uKH = MST2(2,4); WN_uKN = MST2(2,5); WN_1AH = MST2(2,6); WN_1BH = MST2(2,7); WN_1AN = MST2(2,8); WN_1BN = MST2(2,9); WN_1lambda = MST2(2,10);
RH_1PN = MST2(3,1); RH_1PH = MST2(3,2); RH_1K = MST2(3,3); RH_uKH = MST2(3,4); RH_uKN = MST2(3,5); RH_1AH = MST2(3,6); RH_1BH = MST2(3,7); RH_1AN = MST2(3,8); RH_1BN = MST2(3,9); RH_1lambda = MST2(3,10);
RN_1PN = MST2(4,1); RN_1PH = MST2(4,2); RN_1K = MST2(4,3); RN_uKH = MST2(4,4); RN_uKN = MST2(4,5); RN_1AH = MST2(4,6); RN_1BH = MST2(4,7); RN_1AN = MST2(4,8); RN_1BN = MST2(4,9); RN_1lambda = MST2(4,10);

% Solutions uKj(uKSj,uKDj)     
uKH_uKSH = eta;        
uKH_uKDH = (1-eta);    
uKN_uKSN = eta;        
uKN_uKDN = (1-eta); 

% Solutions Rj,Wj(PN,PH,K,uKSj,uKDj)                                                          
RH_uKSH = RH_uKH*uKH_uKSH;                                                                    
RH_uKDH = RH_uKH*uKH_uKDH;                                                                    
RH_uKSN = RH_uKN*uKN_uKSN;                                                                    
RH_uKDN = RH_uKN*uKN_uKDN;                                                                    
                                                                                              
WH_uKSH = WH_uKH*uKH_uKSH;                                                                    
WH_uKDH = WH_uKH*uKH_uKDH;                                                                    
WH_uKSN = WH_uKN*uKN_uKSN;                                                                    
WH_uKDN = WH_uKN*uKN_uKDN;                                                                    
                                                                                              
RN_uKSH = RN_uKH*uKH_uKSH;                                                                    
RN_uKDH = RN_uKH*uKH_uKDH;                                                                    
RN_uKSN = RN_uKN*uKN_uKSN;                                                                    
RN_uKDN = RN_uKN*uKN_uKDN;                                                                    
                                                                                              
WN_uKSH = WN_uKH*uKH_uKSH;                                                                    
WN_uKDH = WN_uKH*uKH_uKDH;                                                                    
WN_uKSN = WN_uKN*uKN_uKSN;                                                                    
WN_uKDN = WN_uKN*uKN_uKDN;                                                                    
                                                                                              
% Solving for sectoral labor and sectoral output - Lj,Kj,Yj(PN,PH,K,uKj,Aj,Bj,lambda)                                     
LH_2PN  = LH_1PN + (LH_WH*WH_1PN) + (LH_WN*WN_1PN);                                                                       
LH_2PH  = LH_1PH + (LH_WH*WH_1PH) + (LH_WN*WN_1PH);                                                                       
LH_1K   = (LH_WH*WH_1K)  + (LH_WN*WN_1K);                                                                                 
LH_uKSH = (LH_WH*WH_uKSH) + (LH_WN*WN_uKSH);                                                                              
LH_uKDH = (LH_WH*WH_uKDH) + (LH_WN*WN_uKDH);                                                                              
LH_uKSN = (LH_WH*WH_uKSN) + (LH_WN*WN_uKSN);                                                                              
LH_uKDN = (LH_WH*WH_uKDN) + (LH_WN*WN_uKDN);                                                                              
LH_1AH  = (LH_WH*WH_1AH) + (LH_WN*WN_1AH);                                                                                
LH_1BH  = (LH_WH*WH_1BH) + (LH_WN*WN_1BH);                                                                                
LH_1AN  = (LH_WH*WH_1AN) + (LH_WN*WN_1AN);                                                                                
LH_1BN  = (LH_WH*WH_1BN) + (LH_WN*WN_1BN);                                                                                
LH_1lambda = LH_1lamb + (LH_WH*WH_1lambda) + (LH_WN*WN_1lambda);                                                          
                                                                                                                          
LN_2PN  = LN_1PN + (LN_WH*WH_1PN) + (LN_WN*WN_1PN);                                                                       
LN_2PH  = LN_1PH + (LN_WH*WH_1PH) + (LN_WN*WN_1PH);                                                                       
LN_1K   = (LN_WH*WH_1K)  + (LN_WN*WN_1K);                                                                                 
LN_uKSH = (LN_WH*WH_uKSH) + (LN_WN*WN_uKSH);                                                                              
LN_uKDH = (LN_WH*WH_uKDH) + (LN_WN*WN_uKDH);                                                                              
LN_uKSN = (LN_WH*WH_uKSN) + (LN_WN*WN_uKSN);                                                                              
LN_uKDN = (LN_WH*WH_uKDN) + (LN_WN*WN_uKDN);                                                                              
LN_1AH  = (LN_WH*WH_1AH) + (LN_WN*WN_1AH);                                                                                
LN_1BH  = (LN_WH*WH_1BH) + (LN_WN*WN_1BH);                                                                                
LN_1AN  = (LN_WH*WH_1AN) + (LN_WN*WN_1AN);                                                                                
LN_1BN  = (LN_WH*WH_1BN) + (LN_WN*WN_1BN);                                                                                
LN_1lambda = LN_1lamb + (LN_WH*WH_1lambda) + (LN_WN*WN_1lambda);                                                          
                                                                                                                          
KH_1PN  = (KH_RH*RH_1PN) + (KH_RN*RN_1PN);                                                                                
KH_1PH  = (KH_RH*RH_1PH) + (KH_RN*RN_1PH);                                                                                
KH_2K   = KH_1K  +(KH_RH*RH_1K)  + (KH_RN*RN_1K);                                                                         
KH_uKSH = (KH_RH*RH_uKSH) + (KH_RN*RN_uKSH);                                                                              
KH_uKDH = (KH_RH*RH_uKDH) + (KH_RN*RN_uKDH);                                                                              
KH_uKSN = (KH_RH*RH_uKSN) + (KH_RN*RN_uKSN);                                                                              
KH_uKDN = (KH_RH*RH_uKDN) + (KH_RN*RN_uKDN);                                                                              
KH_1AH  = (KH_RH*RH_1AH) + (KH_RN*RN_1AH);                                                                                
KH_1BH  = (KH_RH*RH_1BH) + (KH_RN*RN_1BH);                                                                                
KH_1AN  = (KH_RH*RH_1AN) + (KH_RN*RN_1AN);                                                                                
KH_1BN  = (KH_RH*RH_1BN) + (KH_RN*RN_1BN);                                                                                
KH_1lambda = (KH_RH*RH_1lambda) + (KH_RN*RN_1lambda);                                                                     
                                                                                                                          
KN_1PN  = (KN_RH*RH_1PN) + (KN_RN*RN_1PN);                                                                                
KN_1PH  = (KN_RH*RH_1PH) + (KN_RN*RN_1PH);                                                                                
KN_2K   = KN_1K + (KN_RH*RH_1K)  + (KN_RN*RN_1K);                                                                         
KN_uKSH = (KN_RH*RH_uKSH) + (KN_RN*RN_uKSH);                                                                              
KN_uKDH = (KN_RH*RH_uKDH) + (KN_RN*RN_uKDH);                                                                              
KN_uKSN = (KN_RH*RH_uKSN) + (KN_RN*RN_uKSN);                                                                              
KN_uKDN = (KN_RH*RH_uKDN) + (KN_RN*RN_uKDN);                                                                              
KN_1AH  = (KN_RH*RH_1AH) + (KN_RN*RN_1AH);                                                                                
KN_1BH  = (KN_RH*RH_1BH) + (KN_RN*RN_1BH);                                                                                
KN_1AN  = (KN_RH*RH_1AN) + (KN_RN*RN_1AN);                                                                                
KN_1BN  = (KN_RH*RH_1BN) + (KN_RN*RN_1BN);                                                                                
KN_1lambda = (KN_RH*RH_1lambda) + (KN_RN*RN_1lambda);                                                                     
                                                                                                                          
YH_1PN  = sLH*YH*(LH_2PN/LH) + (1-sLH)*YH*(KH_1PN/KH);                                                                    
YH_1PH  = sLH*YH*(LH_2PH/LH) + (1-sLH)*YH*(KH_1PH/KH);                                                                    
YH_1K   = sLH*YH*(LH_1K/LH) + (1-sLH)*YH*(KH_2K/KH);                                                                      
YH_uKSH = sLH*YH*(LH_uKSH/LH) + (1-sLH)*YH*( (KH_uKSH/KH) + eta );                                                        
YH_uKDH = sLH*YH*(LH_uKDH/LH) + (1-sLH)*YH*( (KH_uKDH/KH) + (1-eta) );                                                    
YH_uKSN = sLH*YH*(LH_uKSN/LH) + (1-sLH)*YH*(KH_uKSN/KH);                                                                  
YH_uKDN = sLH*YH*(LH_uKDN/LH) + (1-sLH)*YH*(KH_uKDN/KH);                                                                  
YH_1AH  = sLH*YH*( (LH_1AH/LH) + (1/AH) ) + (1-sLH)*YH*(KH_1AH/KH);                                                       
YH_1BH  = sLH*YH*(LH_1BH/LH) + (1-sLH)*YH*( (KH_1BH/KH) + (1/BH) );                                                       
YH_1AN  = sLH*YH*(LH_1AN/LH) + (1-sLH)*YH*(KH_1AN/KH);                                                                    
YH_1BN  = sLH*YH*(LH_1BN/LH) + (1-sLH)*YH*(KH_1BN/KH);                                                                    
YH_1lambda =  sLH*YH*(LH_1lambda/LH) + (1-sLH)*YH*(KH_1lambda/KH);                                                        
                                                                                                                          
YN_1PN  = sLN*YN*(LN_2PN/LN) + (1-sLN)*YN*(KN_1PN/KN);                                                                    
YN_1PH  = sLN*YN*(LN_2PH/LN) + (1-sLN)*YN*(KN_1PH/KN);                                                                    
YN_1K   = sLN*YN*(LN_1K/LN) + (1-sLN)*YN*(KN_2K/KN);                                                                      
YN_uKSH = sLN*YN*(LN_uKSH/LN) + (1-sLN)*YN*(KN_uKSH/KN);                                                                  
YN_uKDH = sLN*YN*(LN_uKDH/LN) + (1-sLN)*YN*(KN_uKDH/KN);                                                                  
YN_uKSN = sLN*YN*(LN_uKSN/LN) + (1-sLN)*YN*( (KN_uKSN/KN) + eta);                                                         
YN_uKDN = sLN*YN*(LN_uKDN/LN) + (1-sLN)*YN*( (KN_uKDN/KN) + (1-eta) );                                                    
YN_1AH  = sLN*YN*(LN_1AH/LN) + (1-sLN)*YN*(KN_1AH/KN);                                                                    
YN_1BH  = sLN*YN*(LN_1BH/LN) + (1-sLN)*YN*(KN_1BH/KN);                                                                    
YN_1AN  = sLN*YN*( (LN_1AN/LN) + (1/AN) ) + (1-sLN)*YN*(KN_1AN/KN);                                                       
YN_1BN  = sLN*YN*(LN_1BN/LN) + (1-sLN)*YN*( (KN_1BN/KN) + (1/BN) );                                                       
YN_1lambda = sLN*YN*(LN_1lambda/LN) + (1-sLN)*YN*(KN_1lambda/KN);                                                         
                                                                                                                          
% Intermediate solution for CN, CH, CF - Cj=Cj(PN,PH,K,uKSj,uKDj,Aj,Bj)                                                   
CN_2PN     = CN_1PN + (CN_WH*WH_1PN) + (CN_WN*WN_1PN);                                                                    
CN_2PH     = CN_1PH + (CN_WH*WH_1PH) + (CN_WN*WN_1PH);                                                                    
CN_1K      = (CN_WH*WH_1K) + (CN_WN*WN_1K);                                                                               
CN_uKSH    = (CN_WH*WH_uKSH) + (CN_WN*WN_uKSH);                                                                           
CN_uKDH    = (CN_WH*WH_uKDH) + (CN_WN*WN_uKDH);                                                                           
CN_uKSN    = (CN_WH*WH_uKSN) + (CN_WN*WN_uKSN);                                                                           
CN_uKDN    = (CN_WH*WH_uKDN) + (CN_WN*WN_uKDN);                                                                           
CN_1AH     = (CN_WH*WH_1AH) + (CN_WN*WN_1AH);                                                                             
CN_1BH     = (CN_WH*WH_1BH) + (CN_WN*WN_1BH);                                                                             
CN_1AN     = (CN_WH*WH_1AN) + (CN_WN*WN_1AN);                                                                             
CN_1BN     = (CN_WH*WH_1BN) + (CN_WN*WN_1BN);                                                                             
CN_1lambda = CH_1lamb + (CN_WH*WH_1lambda) + (CN_WN*WN_1lambda);                                                          
                                                                                                                          
CH_2PN     = CH_1PN + (CH_WH*WH_1PN) + (CH_WN*WN_1PN);                                                                    
CH_2PH     = CH_1PH + (CH_WH*WH_1PH) + (CH_WN*WN_1PH);                                                                    
CH_1K      = (CH_WH*WH_1K) + (CH_WN*WN_1K);                                                                               
CH_uKSH    = (CH_WH*WH_uKSH) + (CH_WN*WN_uKSH);                                                                           
CH_uKDH    = (CH_WH*WH_uKDH) + (CH_WN*WN_uKDH);                                                                           
CH_uKSN    = (CH_WH*WH_uKSN) + (CH_WN*WN_uKSN);                                                                           
CH_uKDN    = (CH_WH*WH_uKDN) + (CH_WN*WN_uKDN);                                                                           
CH_1AH     = (CH_WH*WH_1AH) + (CH_WN*WN_1AH);                                                                             
CH_1BH     = (CH_WH*WH_1BH) + (CH_WN*WN_1BH);                                                                             
CH_1AN     = (CH_WH*WH_1AN) + (CH_WN*WN_1AN);                                                                             
CH_1BN     = (CH_WH*WH_1BN) + (CH_WN*WN_1BN);                                                                             
CH_1lambda = CH_1lamb + (CH_WH*WH_1lambda) + (CH_WN*WN_1lambda);                                                          
                                                                                                                          
CF_2PN     = CF_1PN + (CF_WH*WH_1PN) + (CF_WN*WN_1PN);                                                                    
CF_2PH     = CF_1PH + (CF_WH*WH_1PH) + (CF_WN*WN_1PH);                                                                    
CF_1K      = (CF_WH*WH_1K) + (CF_WN*WN_1K);                                                                               
CF_uKSH    = (CF_WH*WH_uKSH) + (CF_WN*WN_uKSH);                                                                           
CF_uKDH    = (CF_WH*WH_uKDH) + (CF_WN*WN_uKDH);                                                                           
CF_uKSN    = (CF_WH*WH_uKSN) + (CF_WN*WN_uKSN);                                                                           
CF_uKDN    = (CF_WH*WH_uKDN) + (CF_WN*WN_uKDN);                                                                           
CF_1AH     = (CF_WH*WH_1AH) + (CF_WN*WN_1AH);                                                                             
CF_1BH     = (CF_WH*WH_1BH) + (CF_WN*WN_1BH);                                                                             
CF_1AN     = (CF_WH*WH_1AN) + (CF_WN*WN_1AN);                                                                             
CF_1BN     = (CF_WH*WH_1BN) + (CF_WN*WN_1BN);                                                                             
CF_1lambda = CH_1lamb + (CF_WH*WH_1lambda) + (CF_WN*WN_1lambda);                                                          
                                                                                                                                                                                                                                                                    
% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I      = deltaK*K; 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKSj,uKDj(PN,PH,K)                                                                       
f11 = ((xi2SH/xi1SH) + (1-eta) + eta*(sLH/sigmaH)) - (sLH/sigmaH)*(LH_uKSH/LH) + (sLH/sigmaH)*(KH_uKSH/KH); % uKSH                               
f12 = -((sigmaH-sLH)/sigmaH)*(1-eta) - (sLH/sigmaH)*(LH_uKDH/LH) + (sLH/sigmaH)*(KH_uKDH/KH); % uKDH                                             
f13 = - (sLH/sigmaH)*(LH_uKSN/LH) + (sLH/sigmaH)*(KH_uKSN/KH); % uKSN                                                                            
f14 = - (sLH/sigmaH)*(LH_uKDN/LH) + (sLH/sigmaH)*(KH_uKDN/KH); % uKDN                                                                            
                                                                                                                                                 
f21 = -((sigmaH-sLH)/sigmaH)*eta - (sLH/sigmaH)*(LH_uKSH/LH) + (sLH/sigmaH)*(KH_uKSH/KH); % uKSH                                                 
f22 = ((xi2DH/xi1DH) + eta + (1-eta)*(sLH/sigmaH)) - (sLH/sigmaH)*(LH_uKDH/LH) + (sLH/sigmaH)*(KH_uKDH/KH); %uKDH                                                            
f23 = - (sLH/sigmaH)*(LH_uKSN/LH) + (sLH/sigmaH)*(KH_uKSN/KH); % uKSN                                                                            
f24 = - (sLH/sigmaH)*(LH_uKDN/LH) + (sLH/sigmaH)*(KH_uKDN/KH); % uKDN                                                                            
                                                                                                                                                 
f31 =  - (sLN/sigmaN)*(LN_uKSH/LN) + (sLN/sigmaN)*(KN_uKSH/KN); %uKSH                                                                            
f32 =  - (sLN/sigmaN)*(LN_uKDH/LN) + (sLN/sigmaN)*(KN_uKDH/KN); %uKDH                                                                            
f33 = ((xi2SN/xi1SN) + (1-eta) + eta*(sLN/sigmaN))  - (sLN/sigmaN)*(LN_uKSN/LN) + (sLN/sigmaN)*(KN_uKSN/KN); %uKSN                               
f34 = -((sigmaN-sLN)/sigmaN)*(1-eta)  - (sLN/sigmaN)*(LN_uKDN/LN) + (sLN/sigmaN)*(KN_uKDN/KN); %uKDN                                             
                                                                                                                                                 
f41 = - (sLN/sigmaN)*(LN_uKSH/LN) + (sLN/sigmaN)*(KN_uKSH/KN); %uKSH                                                                             
f42 = - (sLN/sigmaN)*(LN_uKDH/LN) + (sLN/sigmaN)*(KN_uKDH/KN); %uKDH                                                                             
f43 = -((sigmaN-sLN)/sigmaN)*eta  - (sLN/sigmaN)*(LN_uKSN/LN) + (sLN/sigmaN)*(KN_uKSN/KN); %uKSN                                                 
f44 = ((xi2DN/xi1DN) + eta + (1-eta)*(sLN/sigmaN)) - (sLN/sigmaN)*(LN_uKDN/LN) + (sLN/sigmaN)*(KN_uKDN/KN); %uKDN                                
                                                                                                                                                 
% PN, PH, K, AH, BH, AN, BN, lambda                                                                                                              
g11 = (sLH/sigmaH)*(LH_2PN/LH) - (sLH/sigmaH)*(KH_1PN/KH); % PN                                                                                  
g12 = (sLH/sigmaH)*(LH_2PH/LH) - (sLH/sigmaH)*(KH_1PH/KH); % PH                                                                                  
g13 = (sLH/sigmaH)*(LH_1K/LH) - (sLH/sigmaH)*(KH_2K/KH); % K                                                                                     
g14 = (sLH/sigmaH)*( (LH_1AH/LH) + (1/AH) ) - (sLH/sigmaH)*(KH_1AH/KH); % AH                                                                     
g15 = (sLH/sigmaH)*(LH_1BH/LH) - (sLH/sigmaH)*(KH_1BH/KH) + ((sigmaH-sLH)/sigmaH)*(1/BH); % BH                                                   
g16 = (sLH/sigmaH)*(LH_1AN/LH) - (sLH/sigmaH)*(KH_1AN/KH); % AN                                                                                  
g17 = (sLH/sigmaH)*(LH_1BN/LH) - (sLH/sigmaH)*(KH_1BN/KH); % BN                                                                                  
g18 = (sLH/sigmaH)*(LH_1lambda/LH) - (sLH/sigmaH)*(KH_1lambda/KH); % lambda                                                                      
                                                                                                                                                 
g21 = (sLH/sigmaH)*(LH_2PN/LH) - (sLH/sigmaH)*(KH_1PN/KH); % PN                                                                                  
g22 = (sLH/sigmaH)*(LH_2PH/LH) - (sLH/sigmaH)*(KH_1PH/KH); % PH                                                                                  
g23 = (sLH/sigmaH)*(LH_1K/LH) - (sLH/sigmaH)*(KH_2K/KH); % K                                                                                     
g24 = (sLH/sigmaH)*( (LH_1AH/LH) + (1/AH) ) - (sLH/sigmaH)*(KH_1AH/KH); % AH                                                                     
g25 = (sLH/sigmaH)*(LH_1BH/LH) - (sLH/sigmaH)*(KH_1BH/KH) + ((sigmaH-sLH)/sigmaH)*(1/BH); % BH                                                   
g26 = (sLH/sigmaH)*(LH_1AN/LH) - (sLH/sigmaH)*(KH_1AN/KH); % AN                                                                                  
g27 = (sLH/sigmaH)*(LH_1BN/LH) - (sLH/sigmaH)*(KH_1BN/KH); % BN                                                                                  
g28 = (sLH/sigmaH)*(LH_1lambda/LH) - (sLH/sigmaH)*(KH_1lambda/KH); % lambda                                                                      
                                                                                                                                                 
g31 = (sLN/sigmaN)*(LN_2PN/LN) - (sLN/sigmaN)*(KN_1PN/KN); % PN                                                                                  
g32 = (sLN/sigmaN)*(LN_2PH/LN) - (sLN/sigmaN)*(KN_1PH/KN); % PH                                                                                  
g33 = (sLN/sigmaN)*(LN_1K/LN) - (sLN/sigmaN)*(KN_2K/KN); % K                                                                                     
g34 = (sLN/sigmaN)*(LN_1AH/LN) - (sLN/sigmaN)*(KN_1AH/KN); % AH                                                                                  
g35 = (sLN/sigmaN)*(LN_1BH/LN) - (sLN/sigmaN)*(KN_1BH/KN); % BH                                                                                  
g36 = (sLN/sigmaN)*( (LN_1AN/LN) + (1/AN) ) - (sLN/sigmaN)*(KN_1AN/KN); % AN                                                                     
g37 = (sLN/sigmaN)*(LN_1BN/LN) - (sLN/sigmaN)*(KN_1BN/KN) + ((sigmaN-sLN)/sigmaN)*(1/BN); % BN                                                   
g38 = (sLN/sigmaN)*(LN_1lambda/LN) - (sLN/sigmaN)*(KN_1lambda/KN); % lambda                                                                      
                                                                                                                                                 
g41 = (sLN/sigmaN)*(LN_2PN/LN) - (sLN/sigmaN)*(KN_1PN/KN); % PN                                                                                  
g42 = (sLN/sigmaN)*(LN_2PH/LN) - (sLN/sigmaN)*(KN_1PH/KN); % PH                                                                                  
g43 = (sLN/sigmaN)*(LN_1K/LN) - (sLN/sigmaN)*(KN_2K/KN); % K                                                                                     
g44 = (sLN/sigmaN)*(LN_1AH/LN) - (sLN/sigmaN)*(KN_1AH/KN); % AH                                                                                  
g45 = (sLN/sigmaN)*(LN_1BH/LN) - (sLN/sigmaN)*(KN_1BH/KN); % BH                                                                                  
g46 = (sLN/sigmaN)*( (LN_1AN/LN) + (1/AN) ) - (sLN/sigmaN)*(KN_1AN/KN); % AN                                                                     
g47 = (sLN/sigmaN)*(LN_1BN/LN) - (sLN/sigmaN)*(KN_1BN/KN) + ((sigmaN-sLN)/sigmaN)*(1/BN); % BN                                                   
g48 = (sLN/sigmaN)*(LN_1lambda/LN) - (sLN/sigmaN)*(KN_1lambda/KN); % lambda                                                                      
                                                                                                                                                 
M3 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X3 = [g11 g12 g13 g14 g15 g16 g17 g18; g21 g22 g23 g24 g25 g26 g27 g28; g31 g32 g33 g34 g35 g36 g37 g38; g41 g42 g43 g44 g45 g46 g47 g48];
JST3 = inv(M3);
MST3 = JST3*X3;

uKSH_PN = MST3(1,1); uKSH_PH = MST3(1,2); uKSH_1K = MST3(1,3); uKSH_1AH = MST3(1,4); uKSH_1BH = MST3(1,5); uKSH_1AN = MST3(1,6); uKSH_1BN = MST3(1,7); uKSH_1lambda = MST3(1,8);
uKDH_PN = MST3(2,1); uKDH_PH = MST3(2,2); uKDH_1K = MST3(2,3); uKDH_1AH = MST3(2,4); uKDH_1BH = MST3(2,5); uKDH_1AN = MST3(2,6); uKDH_1BN = MST3(2,7); uKDH_1lambda = MST3(2,8);
uKSN_PN = MST3(3,1); uKSN_PH = MST3(3,2); uKSN_1K = MST3(3,3); uKSN_1AH = MST3(3,4); uKSN_1BH = MST3(3,5); uKSN_1AN = MST3(3,6); uKSN_1BN = MST3(3,7); uKSN_1lambda = MST3(3,8);
uKDN_PN = MST3(4,1); uKDN_PH = MST3(4,2); uKDN_1K = MST3(4,3); uKDN_1AH = MST3(4,4); uKDN_1BH = MST3(4,5); uKDN_1AN = MST3(4,6); uKDN_1BN = MST3(4,7); uKDN_1lambda = MST3(4,8);
                                                                                                                                                
% Solving for Wj,Rj,Lj,Kj,Yj,Cg(lambda,K,PH,PN,AH,BH,AN,BN)
WH_2K = WH_1K + (WH_uKSH*uKSH_1K) + (WH_uKDH*uKDH_1K) + (WH_uKSN*uKSN_1K) + (WH_uKDN*uKDN_1K);
WH_PH = WH_1PH + (WH_uKSH*uKSH_PH) +  (WH_uKDH*uKDH_PH) + (WH_uKSN*uKSN_PH) + (WH_uKDN*uKDN_PH);
WH_PN = WH_1PN + (WH_uKSH*uKSH_PN) + (WH_uKDH*uKDH_PN) + (WH_uKSN*uKSN_PN) + (WH_uKDN*uKDN_PN);
WH_2AH = WH_1AH + (WH_uKSH*uKSH_1AH) + (WH_uKDH*uKDH_1AH) + (WH_uKSN*uKSN_1AH) + (WH_uKDN*uKDN_1AH);
WH_2BH = WH_1BH + (WH_uKSH*uKSH_1BH) + (WH_uKDH*uKDH_1BH) + (WH_uKSN*uKSN_1BH) + (WH_uKDN*uKDN_1BH);
WH_2AN = WH_1AN + (WH_uKSH*uKSH_1AN) + (WH_uKDH*uKDH_1AN) + (WH_uKSN*uKSN_1AN) + (WH_uKDN*uKDN_1AN);
WH_2BN = WH_1BN + (WH_uKSH*uKSH_1BN) + (WH_uKDH*uKDH_1BN) + (WH_uKSN*uKSN_1BN) + (WH_uKDN*uKDN_1BN);
WH_2lambda = WH_1lambda + (WH_uKSH*uKSH_1lambda) + (WH_uKDH*uKDH_1lambda) + (WH_uKSN*uKSN_1lambda) + (WH_uKDN*uKDN_1lambda);

WN_2K = WN_1K + (WN_uKSH*uKSH_1K) +  (WN_uKDH*uKDH_1K) + (WN_uKSN*uKSN_1K) + (WN_uKDN*uKDN_1K);
WN_PH = WN_1PH + (WN_uKSH*uKSH_PH) + (WN_uKDH*uKDH_PH) + (WN_uKSN*uKSN_PH) + (WN_uKDN*uKDN_PH);
WN_PN = WN_1PN + (WN_uKSH*uKSH_PN) + (WN_uKDH*uKDH_PN) + (WN_uKSN*uKSN_PN) + (WN_uKDN*uKDN_PN);
WN_2AH = WN_1AH + (WN_uKSH*uKSH_1AH) + (WN_uKDH*uKDH_1AH) + (WN_uKSN*uKSN_1AH) + (WN_uKDN*uKDN_1AH);
WN_2BH = WN_1BH + (WN_uKSH*uKSH_1BH) + (WN_uKDH*uKDH_1BH) + (WN_uKSN*uKSN_1BH) + (WN_uKDN*uKDN_1BH);
WN_2AN = WN_1AN + (WN_uKSH*uKSH_1AN) + (WN_uKDH*uKDH_1AN) + (WN_uKSN*uKSN_1AN) + (WN_uKDN*uKDN_1AN);
WN_2BN = WN_1BN + (WN_uKSH*uKSH_1BN) + (WN_uKDH*uKDH_1BN) + (WN_uKSN*uKSN_1BN) + (WN_uKDN*uKDN_1BN);
WN_2lambda = WN_1lambda + (WN_uKSH*uKSH_1lambda) + (WN_uKDH*uKDH_1lambda) + (WN_uKSN*uKSN_1lambda) + (WN_uKDN*uKDN_1lambda);

RH_2K = RH_1K + (RH_uKSH*uKSH_1K) + (RH_uKDH*uKDH_1K) + (RH_uKSN*uKSN_1K) + (RH_uKDN*uKDN_1K);
RH_PH = RH_1PH + (RH_uKSH*uKSH_PH) +  (RH_uKDH*uKDH_PH) + (RH_uKSN*uKSN_PH) + (RH_uKDN*uKDN_PH);
RH_PN = RH_1PN + (RH_uKSH*uKSH_PN) + (RH_uKDH*uKDH_PN) + (RH_uKSN*uKSN_PN) + (RH_uKDN*uKDN_PN);
RH_2AH = RH_1AH + (RH_uKSH*uKSH_1AH) + (RH_uKDH*uKDH_1AH) + (RH_uKSN*uKSN_1AH) + (RH_uKDN*uKDN_1AH);
RH_2BH = RH_1BH + (RH_uKSH*uKSH_1BH) + (RH_uKDH*uKDH_1BH) + (RH_uKSN*uKSN_1BH) + (RH_uKDN*uKDN_1BH);
RH_2AN = RH_1AN + (RH_uKSH*uKSH_1AN) + (RH_uKDH*uKDH_1AN) + (RH_uKSN*uKSN_1AN) + (RH_uKDN*uKDN_1AN);
RH_2BN = RH_1BN + (RH_uKSH*uKSH_1BN) + (RH_uKDH*uKDH_1BN) + (RH_uKSN*uKSN_1BN) + (RH_uKDN*uKDN_1BN);
RH_2lambda = RH_1lambda + (RH_uKSH*uKSH_1lambda) + (RH_uKDH*uKDH_1lambda) + (RH_uKSN*uKSN_1lambda) + (RH_uKDN*uKDN_1lambda);

RN_2K = RN_1K + (RN_uKSH*uKSH_1K) +  (RN_uKDH*uKDH_1K) + (RN_uKSN*uKSN_1K) + (RN_uKDN*uKDN_1K);
RN_PH = RN_1PH + (RN_uKSH*uKSH_PH) + (RN_uKDH*uKDH_PH) + (RN_uKSN*uKSN_PH) + (RN_uKDN*uKDN_PH);
RN_PN = RN_1PN + (RN_uKSH*uKSH_PN) + (RN_uKDH*uKDH_PN) + (RN_uKSN*uKSN_PN) + (RN_uKDN*uKDN_PN);
RN_2AH = RN_1AH + (RN_uKSH*uKSH_1AH) + (RN_uKDH*uKDH_1AH) + (RN_uKSN*uKSN_1AH) + (RN_uKDN*uKDN_1AH);
RN_2BH = RN_1BH + (RN_uKSH*uKSH_1BH) + (RN_uKDH*uKDH_1BH) + (RN_uKSN*uKSN_1BH) + (RN_uKDN*uKDN_1BH);
RN_2AN = RN_1AN + (RN_uKSH*uKSH_1AN) + (RN_uKDH*uKDH_1AN) + (RN_uKSN*uKSN_1AN) + (RN_uKDN*uKDN_1AN);
RN_2BN = RN_1BN + (RN_uKSH*uKSH_1BN) + (RN_uKDH*uKDH_1BN) + (RN_uKSN*uKSN_1BN) + (RN_uKDN*uKDN_1BN);
RN_2lambda = RN_1lambda + (RN_uKSH*uKSH_1lambda) + (RN_uKDH*uKDH_1lambda) + (RN_uKSN*uKSN_1lambda) + (RN_uKDN*uKDN_1lambda);

LH_2K = LH_1K + (LH_uKSH*uKSH_1K) + (LH_uKDH*uKDH_1K) + (LH_uKSN*uKSN_1K) + (LH_uKDN*uKDN_1K);
LH_PH = LH_2PH + (LH_uKSH*uKSH_PH) + (LH_uKDH*uKDH_PH) + (LH_uKSN*uKSN_PH) + (LH_uKDN*uKDN_PH);
LH_PN = LH_2PN + (LH_uKSH*uKSH_PN) + (LH_uKDH*uKDH_PN) + (LH_uKSN*uKSN_PN) + (LH_uKDN*uKDN_PN);
LH_2AH = LH_1AH + (LH_uKSH*uKSH_1AH) + (LH_uKDH*uKDH_1AH) + (LH_uKSN*uKSN_1AH) + (LH_uKDN*uKDN_1AH);
LH_2BH = LH_1BH + (LH_uKSH*uKSH_1BH) + (LH_uKDH*uKDH_1BH) + (LH_uKSN*uKSN_1BH) + (LH_uKDN*uKDN_1BH);
LH_2AN = LH_1AN + (LH_uKSH*uKSH_1AN) + (LH_uKDH*uKDH_1AN) + (LH_uKSN*uKSN_1AN) + (LH_uKDN*uKDN_1AN);
LH_2BN = LH_1BN + (LH_uKSH*uKSH_1BN) + (LH_uKDH*uKDH_1BN) + (LH_uKSN*uKSN_1BN) + (LH_uKDN*uKDN_1BN);
LH_2lambda = LH_1lambda + (LH_uKSH*uKSH_1lambda) + (LH_uKDH*uKDH_1lambda) + (LH_uKSN*uKSN_1lambda) + (LH_uKDN*uKDN_1lambda);

LN_2K = LN_1K + (LN_uKSH*uKSH_1K) + (LN_uKDH*uKDH_1K) + (LN_uKSN*uKSN_1K) + (LN_uKDN*uKDN_1K);
LN_PH = LN_2PH + (LN_uKSH*uKSH_PH) + (LN_uKDH*uKDH_PH) + (LN_uKSN*uKSN_PH) + (LN_uKDN*uKDN_PH);
LN_PN = LN_2PN + (LN_uKSH*uKSH_PN) + (LN_uKDH*uKDH_PN) + (LN_uKSN*uKSN_PN) + (LN_uKDN*uKDN_PN);
LN_2AH = LN_1AH + (LN_uKSH*uKSH_1AH) + (LN_uKDH*uKDH_1AH) + (LN_uKSN*uKSN_1AH) + (LN_uKDN*uKDN_1AH);
LN_2BH = LN_1BH + (LN_uKSH*uKSH_1BH) + (LN_uKDH*uKDH_1BH) + (LN_uKSN*uKSN_1BH) + (LN_uKDN*uKDN_1BH);
LN_2AN = LN_1AN + (LN_uKSH*uKSH_1AN) + (LN_uKDH*uKDH_1AN) + (LN_uKSN*uKSN_1AN) + (LN_uKDN*uKDN_1AN);
LN_2BN = LN_1BN + (LN_uKSH*uKSH_1BN) + (LN_uKDH*uKDH_1BN) + (LN_uKSN*uKSN_1BN) + (LN_uKDN*uKDN_1BN);
LN_2lambda = LN_1lambda + (LN_uKSH*uKSH_1lambda) + (LN_uKDH*uKDH_1lambda) + (LN_uKSN*uKSN_1lambda) + (LN_uKDN*uKDN_1lambda);

KH_3K = KH_2K + (KH_uKSH*uKSH_1K) + (KH_uKDH*uKDH_1K) + (KH_uKSN*uKSN_1K) + (KH_uKDN*uKDN_1K);
KH_PH = KH_1PH + (KH_uKSH*uKSH_PH) + (KH_uKDH*uKDH_PH) + (KH_uKSN*uKSN_PH) + (KH_uKDN*uKDN_PH);
KH_PN = KH_1PN + (KH_uKSH*uKSH_PN) + (KH_uKDH*uKDH_PN) + (KH_uKSN*uKSN_PN) + (KH_uKDN*uKDN_PN);
KH_2AH = KH_1AH + (KH_uKSH*uKSH_1AH) + (KH_uKDH*uKDH_1AH) + (KH_uKSN*uKSN_1AH) + (KH_uKDN*uKDN_1AH);
KH_2BH = KH_1BH + (KH_uKSH*uKSH_1BH) + (KH_uKDH*uKDH_1BH) + (KH_uKSN*uKSN_1BH) + (KH_uKDN*uKDN_1BH);
KH_2AN = KH_1AN + (KH_uKSH*uKSH_1AN) + (KH_uKDH*uKDH_1AN) + (KH_uKSN*uKSN_1AN) + (KH_uKDN*uKDN_1AN);
KH_2BN = KH_1BN + (KH_uKSH*uKSH_1BN) + (KH_uKDH*uKDH_1BN) + (KH_uKSN*uKSN_1BN) + (KH_uKDN*uKDN_1BN);
KH_2lambda = KH_1lambda + (KH_uKSH*uKSH_1lambda) + (KH_uKDH*uKDH_1lambda) + (KH_uKSN*uKSN_1lambda) + (KH_uKDN*uKDN_1lambda);

KN_3K = KN_2K + (KN_uKSH*uKSH_1K) + (KN_uKDH*uKDH_1K) + (KN_uKSN*uKSN_1K) + (KN_uKDN*uKDN_1K);
KN_PH = KN_1PH + (KN_uKSH*uKSH_PH) + (KN_uKDH*uKDH_PH) + (KN_uKSN*uKSN_PH) + (KN_uKDN*uKDN_PH);
KN_PN = KN_1PN + (KN_uKSH*uKSH_PN) + (KN_uKDH*uKDH_PN) + (KN_uKSN*uKSN_PN) + (KN_uKDN*uKDN_PN);
KN_2AH = KN_1AH + (KN_uKSH*uKSH_1AH) + (KN_uKDH*uKDH_1AH) + (KN_uKSN*uKSN_1AH) + (KN_uKDN*uKDN_1AH);
KN_2BH = KN_1BH + (KN_uKSH*uKSH_1BH) + (KN_uKDH*uKDH_1BH) + (KN_uKSN*uKSN_1BH) + (KN_uKDN*uKDN_1BH);
KN_2AN = KN_1AN + (KN_uKSH*uKSH_1AN) + (KN_uKDH*uKDH_1AN) + (KN_uKSN*uKSN_1AN) + (KN_uKDN*uKDN_1AN);
KN_2BN = KN_1BN + (KN_uKSH*uKSH_1BN) + (KN_uKDH*uKDH_1BN) + (KN_uKSN*uKSN_1BN) + (KN_uKDN*uKDN_1BN);
KN_2lambda = KN_1lambda + (KN_uKSH*uKSH_1lambda) + (KN_uKDH*uKDH_1lambda) + (KN_uKSN*uKSN_1lambda) + (KN_uKDN*uKDN_1lambda);

YH_2K  = YH_1K + (YH_uKSH*uKSH_1K) + (YH_uKDH*uKDH_1K) + (YH_uKSN*uKSN_1K) + (YH_uKDN*uKDN_1K);
YH_PH  = YH_1PH + (YH_uKSH*uKSH_PH) + (YH_uKDH*uKDH_PH) + (YH_uKSN*uKSN_PH) + (YH_uKDN*uKDN_PH);
YH_PN  = YH_1PN + (YH_uKSH*uKSH_PN) + (YH_uKDH*uKDH_PN) + (YH_uKSN*uKSN_PN) + (YH_uKDN*uKDN_PN);
YH_2AH = YH_1AH + (YH_uKSH*uKSH_1AH) + (YH_uKDH*uKDH_1AH) + (YH_uKSN*uKSN_1AH) + (YH_uKDN*uKDN_1AH);
YH_2BH = YH_1BH + (YH_uKSH*uKSH_1BH) + (YH_uKDH*uKDH_1BH) + (YH_uKSN*uKSN_1BH) + (YH_uKDN*uKDN_1BH);
YH_2AN = YH_1AN + (YH_uKSH*uKSH_1AN) + (YH_uKDH*uKDH_1AN) + (YH_uKSN*uKSN_1AN) + (YH_uKDN*uKDN_1AN);
YH_2BN = YH_1BN + (YH_uKSH*uKSH_1BN) + (YH_uKDH*uKDH_1BN) + (YH_uKSN*uKSN_1BN) + (YH_uKDN*uKDN_1BN);
YH_2lambda = YH_1lambda + (YH_uKSH*uKSH_1lambda) + (YH_uKDH*uKDH_1lambda) + (YH_uKSN*uKSN_1lambda) + (YH_uKDN*uKDN_1lambda);

YN_2K  = YN_1K + (YN_uKSH*uKSH_1K) + (YN_uKDH*uKDH_1K) + (YN_uKSN*uKSN_1K) + (YN_uKDN*uKDN_1K);
YN_PH  = YN_1PH + (YN_uKSH*uKSH_PH) + (YN_uKDH*uKDH_PH) + (YN_uKSN*uKSN_PH) + (YN_uKDN*uKDN_PH);
YN_PN  = YN_1PN + (YN_uKSH*uKSH_PN) + (YN_uKDH*uKDH_PN) + (YN_uKSN*uKSN_PN) + (YN_uKDN*uKDN_PN);
YN_2AH = YN_1AH + (YN_uKSH*uKSH_1AH) + (YN_uKDH*uKDH_1AH) + (YN_uKSN*uKSN_1AH) + (YN_uKDN*uKDN_1AH);
YN_2BH = YN_1BH + (YN_uKSH*uKSH_1BH) + (YN_uKDH*uKDH_1BH) + (YN_uKSN*uKSN_1BH) + (YN_uKDN*uKDN_1BH);
YN_2AN = YN_1AN + (YN_uKSH*uKSH_1AN) + (YN_uKDH*uKDH_1AN) + (YN_uKSN*uKSN_1AN) + (YN_uKDN*uKDN_1AN);
YN_2BN = YN_1BN + (YN_uKSH*uKSH_1BN) + (YN_uKDH*uKDH_1BN) + (YN_uKSN*uKSN_1BN) + (YN_uKDN*uKDN_1BN);
YN_2lambda = YN_1lambda + (YN_uKSH*uKSH_1lambda) + (YN_uKDH*uKDH_1lambda) + (YN_uKSN*uKSN_1lambda) + (YN_uKDN*uKDN_1lambda);

CH_2K = CH_1K + (CH_uKSH*uKSH_1K) + (CH_uKDH*uKDH_1K) + (CH_uKSN*uKSN_1K) + (CH_uKDN*uKDN_1K);
CH_PH = CH_2PH + (CH_uKSH*uKSH_PH) + (CH_uKDH*uKDH_PH) + (CH_uKSN*uKSN_PH) + (CH_uKDN*uKDN_PH);
CH_PN = CH_2PN + (CH_uKSH*uKSH_PN) + (CH_uKDH*uKDH_PN) + (CH_uKSN*uKSN_PN) + (CH_uKDN*uKDN_PN);
CH_2AH = CH_1AH + (CH_uKSH*uKSH_1AH) + (CH_uKDH*uKDH_1AH) + (CH_uKSN*uKSN_1AH) + (CH_uKDN*uKDN_1AH);
CH_2BH = CH_1BH + (CH_uKSH*uKSH_1BH) + (CH_uKDH*uKDH_1BH) + (CH_uKSN*uKSN_1BH) + (CH_uKDN*uKDN_1BH);
CH_2AN = CH_1AN + (CH_uKSH*uKSH_1AN) + (CH_uKDH*uKDH_1AN) + (CH_uKSN*uKSN_1AN) + (CH_uKDN*uKDN_1AN);
CH_2BN = CH_1BN + (CH_uKSH*uKSH_1BN) + (CH_uKDH*uKDH_1BN) + (CH_uKSN*uKSN_1BN) + (CH_uKDN*uKDN_1BN);
CH_2lambda = CH_1lambda + (CH_uKSH*uKSH_1lambda) + (CH_uKDH*uKDH_1lambda) + (CH_uKSN*uKSN_1lambda) + (CH_uKDN*uKDN_1lambda);

CN_2K = CN_1K + (CN_uKSH*uKSH_1K) + (CN_uKDH*uKDH_1K) + (CN_uKSN*uKSN_1K) + (CN_uKDN*uKDN_1K);
CN_PH = CN_2PH + (CN_uKSH*uKSH_PH) + (CN_uKDH*uKDH_PH) + (CN_uKSN*uKSN_PH) + (CN_uKDN*uKDN_PH);
CN_PN = CN_2PN + (CN_uKSH*uKSH_PN) + (CN_uKDH*uKDH_PN) + (CN_uKSN*uKSN_PN) + (CN_uKDN*uKDN_PN);
CN_2AH = CN_1AH + (CN_uKSH*uKSH_1AH) + (CN_uKDH*uKDH_1AH) + (CN_uKSN*uKSN_1AH) + (CN_uKDN*uKDN_1AH);
CN_2BH = CN_1BH + (CN_uKSH*uKSH_1BH) + (CN_uKDH*uKDH_1BH) + (CN_uKSN*uKSN_1BH) + (CN_uKDN*uKDN_1BH);
CN_2AN = CN_1AN + (CN_uKSH*uKSH_1AN) + (CN_uKDH*uKDH_1AN) + (CN_uKSN*uKSN_1AN) + (CN_uKDN*uKDN_1AN);
CN_2BN = CN_1BN + (CN_uKSH*uKSH_1BN) + (CN_uKDH*uKDH_1BN) + (CN_uKSN*uKSN_1BN) + (CN_uKDN*uKDN_1BN);
CN_2lambda = CN_1lambda + (CN_uKSH*uKSH_1lambda) + (CN_uKDH*uKDH_1lambda) + (CN_uKSN*uKSN_1lambda) + (CN_uKDN*uKDN_1lambda);

CF_2K = CF_1K + (CF_uKSH*uKSH_1K) + (CF_uKDH*uKDH_1K) + (CF_uKSN*uKSN_1K) + (CF_uKDN*uKDN_1K);
CF_PH = CF_2PH + (CF_uKSH*uKSH_PH) + (CF_uKDH*uKDH_PH) + (CF_uKSN*uKSN_PH) + (CF_uKDN*uKDN_PH);
CF_PN = CF_2PN + (CF_uKSH*uKSH_PN) + (CF_uKDH*uKDH_PN) + (CF_uKSN*uKSN_PN) + (CF_uKDN*uKDN_PN);
CF_2AH = CF_1AH + (CF_uKSH*uKSH_1AH) + (CF_uKDH*uKDH_1AH) + (CF_uKSN*uKSN_1AH) + (CF_uKDN*uKDN_1AH);
CF_2BH = CF_1BH + (CF_uKSH*uKSH_1BH) + (CF_uKDH*uKDH_1BH) + (CF_uKSN*uKSN_1BH) + (CF_uKDN*uKDN_1BH);
CF_2AN = CF_1AN + (CF_uKSH*uKSH_1AN) + (CF_uKDH*uKDH_1AN) + (CF_uKSN*uKSN_1AN) + (CF_uKDN*uKDN_1AN);
CF_2BN = CF_1BN + (CF_uKSH*uKSH_1BN) + (CF_uKDH*uKDH_1BN) + (CF_uKSN*uKSN_1BN) + (CF_uKDN*uKDN_1BN);
CF_2lambda = CF_1lambda + (CF_uKSH*uKSH_1lambda) + (CF_uKDH*uKDH_1lambda) + (CF_uKSN*uKSN_1lambda) + (CF_uKDN*uKDN_1lambda);  

% Partial Derivatives Gj=Gj(G) 
GN_G   = omegaGN/PN; 
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,lambda)                                                                              
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1SN*uKSN_PH) - (KN*xi1DN*uKDN_PH); % PH                                                                            
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1SN*uKSN_PN) - (KN*xi1DN*uKDN_PN); % PN                                                                            
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1SH*uKSH_PH) - (KH*xi1DH*uKDH_PH); % PH                                                                    
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1SH*uKSH_PN) - (KH*xi1DH*uKDH_PN); % PN                                                                            
                                                                                                                                                         
% K,Q,G,AH,BH,AN,BN,lambda                                                                                                                               
k11 = -(YN_2K - CN_2K - JN_1K - (KN*xi1SN*uKSN_1K) - (KN*xi1DN*uKDN_1K));                                                                                
k12 = JN_1Q;                                                                                                                                             
k13 = GN_G;                                                                                                                                              
k14 = -(YN_2AH - CN_2AH - (KN*xi1SN*uKSN_1AH) - (KN*xi1DN*uKDN_1AH));                                                                                    
k15 = -(YN_2BH - CN_2BH - (KN*xi1SN*uKSN_1BH) - (KN*xi1DN*uKDN_1BH));                                                                                    
k16 = -(YN_2AN - CN_2AN - (KN*xi1SN*uKSN_1AN) - (KN*xi1DN*uKDN_1AN));                                                                                    
k17 = -(YN_2BN - CN_2BN - (KN*xi1SN*uKSN_1BN) - (KN*xi1DN*uKDN_1BN));                                                                                    
k18 = -((YN_2lambda - CN_1lambda) - (KN*xi1SN*uKSN_1lambda) - (KN*xi1DN*uKDN_1lambda));                                                                  
                                                                                                                                                         
k21 = -(YH_2K - CH_2K - JH_1K - (KH*xi1SH*uKSH_1K) - (KH*xi1DH*uKDH_1K));                                                                                
k22 = JH_1Q;                                                                                                                                             
k23 = GH_G;                                                                                                                                              
k24 = -(YH_2AH - CH_2AH - (KH*xi1SH*uKSH_1AH) - (KH*xi1DH*uKDH_1AH));                                                                                    
k25 = -(YH_2BH - CH_2BH - (KH*xi1SH*uKSH_1BH) - (KH*xi1DH*uKDH_1BH));                                                                                    
k26 = -(YH_2AN - CH_2AN - (KH*xi1SH*uKSH_1AN) - (KH*xi1DH*uKDH_1AN));                                                                                    
k27 = -(YH_2BN - CH_2BN - (KH*xi1SH*uKSH_1BN) - (KH*xi1DH*uKDH_1BN));                                                                                    
k28 = -((YH_2lambda - CH_1lambda) - (KH*xi1SH*uKSH_1lambda) - (KH*xi1DH*uKDH_1lambda));                                                                  
                                                                                                                                                         
M4 = [h11 h12; h21 h22];                                                                                                                                 
X4 = [k11 k12 k13 k14 k15 k16 k17 k18; k21 k22 k23 k24 k25 k26 k27 k28];                                                                                 
JST4 = inv(M4);                                                                                                                                          
MST4 = JST4*X4;                                                                                                                                          
                                                                                                                                                         
PH_K = MST4(1,1); PH_Q = MST4(1,2); PH_G = MST4(1,3); PH_AH = MST4(1,4); PH_BH = MST4(1,5); PH_AN = MST4(1,6); PH_BN = MST4(1,7); PH_lambda = MST4(1,8); 
PN_K = MST4(2,1); PN_Q = MST4(2,2); PN_G = MST4(2,3); PN_AH = MST4(2,4); PN_BH = MST4(2,5); PN_AN = MST4(2,6); PN_BN = MST4(2,7); PN_lambda = MST4(2,8);                          

% Solving for Lj,Kj,Wj,Rj,Yj,uKj(K,Q,G,Aj,Bj) - 
LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);
LH_AH = LH_2AH + (LH_PH*PH_AH) + (LH_PN*PN_AH); 
LH_BH = LH_2BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_2AN + (LH_PH*PH_AN) + (LH_PN*PN_AN); 
LH_BN = LH_2BN + (LH_PH*PH_BN) + (LH_PN*PN_BN);
LH_lambda = LH_2lambda + (LH_PH*PH_lambda) + (LH_PN*PN_lambda); 

LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G); 
LN_AH = LN_2AH + (LN_PH*PH_AH) + (LN_PN*PN_AH); 
LN_BH = LN_2BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_2AN + (LN_PH*PH_AN) + (LN_PN*PN_AN); 
LN_BN = LN_2BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);
LN_lambda = LN_2lambda + (LN_PH*PH_lambda) + (LN_PN*PN_lambda); 

YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);
YH_AH = YH_2AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_2BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_2AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_2BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);
YH_lambda = YH_2lambda + (YH_PH*PH_lambda) + (YH_PN*PN_lambda);  

YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);
YN_AH = YN_2AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_2BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_2AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_2BN + (YN_PH*PH_BN) + (YN_PN*PN_BN);
YN_lambda = YN_2lambda + (YN_PH*PH_lambda) + (YN_PN*PN_lambda); 

KH_K  = KH_3K + (KH_PH*PH_K) + (KH_PN*PN_K);                     
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);                             
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);                             
KH_AH = KH_2AH + (KH_PH*PH_AH) + (KH_PN*PN_AH);                  
KH_BH = KH_2BH + (KH_PH*PH_BH) + (KH_PN*PN_BH);                  
KH_AN = KH_2AN + (KH_PH*PH_AN) + (KH_PN*PN_AN);                  
KH_BN = KH_2BN + (KH_PH*PH_BN) + (KH_PN*PN_BN);                  
KH_lambda = KH_2lambda + (KH_PH*PH_lambda) + (KH_PN*PN_lambda);  
                                                                 
KN_K = KN_3K + (KN_PH*PH_K) + (KN_PN*PN_K);                      
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);                              
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);                              
KN_AH = KN_2AH + (KN_PH*PH_AH) + (KN_PN*PN_AH);                  
KN_BH = KN_2BH + (KN_PH*PH_BH) + (KN_PN*PN_BH);                  
KN_AN = KN_2AN + (KN_PH*PH_AN) + (KN_PN*PN_AN);                  
KN_BN = KN_2BN + (KN_PH*PH_BN) + (KN_PN*PN_BN);                  
KN_lambda = KN_2lambda + (KN_PH*PH_lambda) + (KN_PN*PN_lambda);

uKSH_K  = uKSH_1K + (uKSH_PH*PH_K) + (uKSH_PN*PN_K);                           
uKSH_Q  = (uKSH_PH*PH_Q) + (uKSH_PN*PN_Q);                                     
uKSH_G  = (uKSH_PH*PH_G) + (uKSH_PN*PN_G);                                     
uKSH_AH = uKSH_1AH + (uKSH_PH*PH_AH) + (uKSH_PN*PN_AH);                        
uKSH_BH = uKSH_1BH + (uKSH_PH*PH_BH) + (uKSH_PN*PN_BH);                        
uKSH_AN = uKSH_1AN + (uKSH_PH*PH_AN) + (uKSH_PN*PN_AN);                        
uKSH_BN = uKSH_1BN + (uKSH_PH*PH_BN) + (uKSH_PN*PN_BN);                        
uKSH_lambda = uKSH_1lambda + (uKSH_PH*PH_lambda) + (uKSH_PN*PN_lambda);        
                                                                               
uKDH_K  = uKDH_1K + (uKDH_PH*PH_K) + (uKDH_PN*PN_K);                           
uKDH_Q  = (uKDH_PH*PH_Q) + (uKDH_PN*PN_Q);                                     
uKDH_G  = (uKDH_PH*PH_G) + (uKDH_PN*PN_G);                                     
uKDH_AH = uKDH_1AH + (uKDH_PH*PH_AH) + (uKDH_PN*PN_AH);                        
uKDH_BH = uKDH_1BH + (uKDH_PH*PH_BH) + (uKDH_PN*PN_BH);                        
uKDH_AN = uKDH_1AN + (uKDH_PH*PH_AN) + (uKDH_PN*PN_AN);                        
uKDH_BN = uKDH_1BN + (uKDH_PH*PH_BN) + (uKDH_PN*PN_BN);                        
uKDH_lambda = uKDH_1lambda + (uKDH_PH*PH_lambda) + (uKDH_PN*PN_lambda);        
                                                                               
uKSN_K = uKSN_1K + (uKSN_PH*PH_K) + (uKSN_PN*PN_K);                            
uKSN_Q = (uKSN_PH*PH_Q) + (uKSN_PN*PN_Q);                                      
uKSN_G = (uKSN_PH*PH_G) + (uKSN_PN*PN_G);                                      
uKSN_AH = uKSN_1AH + (uKSN_PH*PH_AH) + (uKSN_PN*PN_AH);                        
uKSN_BH = uKSN_1BH + (uKSN_PH*PH_BH) + (uKSN_PN*PN_BH);                        
uKSN_AN = uKSN_1AN + (uKSN_PH*PH_AN) + (uKSN_PN*PN_AN);                        
uKSN_BN = uKSN_1BN + (uKSN_PH*PH_BN) + (uKSN_PN*PN_BN);                        
uKSN_lambda = uKSN_1lambda + (uKSN_PH*PH_lambda) + (uKSN_PN*PN_lambda);        
                                                                               
uKDN_K = uKDN_1K + (uKDN_PH*PH_K) + (uKDN_PN*PN_K);                            
uKDN_Q = (uKDN_PH*PH_Q) + (uKDN_PN*PN_Q);                                      
uKDN_G = (uKDN_PH*PH_G) + (uKDN_PN*PN_G);                                      
uKDN_AH = uKDN_1AH + (uKDN_PH*PH_AH) + (uKDN_PN*PN_AH);                        
uKDN_BH = uKDN_1BH + (uKDN_PH*PH_BH) + (uKDN_PN*PN_BH);                        
uKDN_AN = uKDN_1AN + (uKDN_PH*PH_AN) + (uKDN_PN*PN_AN);                        
uKDN_BN = uKDN_1BN + (uKDN_PH*PH_BN) + (uKDN_PN*PN_BN);                        
uKDN_lambda = uKDN_1lambda + (uKDN_PH*PH_lambda) + (uKDN_PN*PN_lambda);        

% Solving for consumption Cj=Cj(lambda,K,Q,G,Aj,Bj), investment inputs 
% Jj=Jj(K,Q,GH,GN), imports MF=MF(lambda,K,Q,G,Aj,Bj), exports 
%XH=XH(K,Q,G,Aj,Bj)- Final Solutions
CN_K  = CN_2K + (CN_PH*PH_K) + (CN_PN*PN_K);                          
CN_Q  = (CN_PH*PH_Q) + (CN_PN*PN_Q);                                  
CN_G  = (CN_PH*PH_G) + (CN_PN*PN_G);                                  
CN_AH = CN_2AH + (CN_PH*PH_AH) + (CN_PN*PN_AH);                       
CN_BH = CN_2BH + (CN_PH*PH_BH) + (CN_PN*PN_BH);                       
CN_AN = CN_2AN + (CN_PH*PH_AN) + (CN_PN*PN_AN);                       
CN_BN = CN_2BN + (CN_PH*PH_BN) + (CN_PN*PN_BN);                       
CN_lambda = CN_2lambda + (CN_PH*PH_lambda) + (CN_PN*PN_lambda);       
                                                                      
CH_K  = CH_2K + (CH_PH*PH_K) + (CH_PN*PN_K);                          
CH_Q  = (CH_PH*PH_Q) + (CH_PN*PN_Q);                                  
CH_G  = (CH_PH*PH_G) + (CH_PN*PN_G);                                  
CH_AH = CH_2AH + (CH_PH*PH_AH) + (CH_PN*PN_AH);                       
CH_BH = CH_2BH + (CH_PH*PH_BH) + (CH_PN*PN_BH);                       
CH_AN = CH_2AN + (CH_PH*PH_AN) + (CH_PN*PN_AN);                       
CH_BN = CH_2BN + (CH_PH*PH_BN) + (CH_PN*PN_BN);                       
CH_lambda = CH_2lambda + (CH_PH*PH_lambda) + (CH_PN*PN_lambda);       
                                                                      
CF_K  = CF_2K + (CF_PH*PH_K) + (CF_PN*PN_K);                          
CF_Q  = (CF_PH*PH_Q) + (CF_PN*PN_Q);                                  
CF_G  = (CF_PH*PH_G) + (CF_PN*PN_G);                                  
CF_AH = CF_2AH + (CF_PH*PH_AH) + (CF_PN*PN_AH);                       
CF_BH = CF_2BH + (CF_PH*PH_BH) + (CF_PN*PN_BH);                       
CF_AN = CF_2AN + (CF_PH*PH_AN) + (CF_PN*PN_AN);                       
CF_BN = CF_2BN + (CF_PH*PH_BN) + (CF_PN*PN_BN);                       
CF_lambda = CF_2lambda + (CF_PH*PH_lambda) + (CF_PN*PN_lambda);       

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);
JH_lambda  = (JH_PH*PH_lambda) + (JH_PN*PN_lambda);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_BH      = (JN_PH*PH_BH) + (JN_PN*PN_BH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN);
JN_lambda  = (JN_PH*PH_lambda) + (JN_PN*PN_lambda);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN); 
JF_lambda  = (JF_PH*PH_lambda) + (JF_PN*PN_lambda);

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;
XH_lambda = XH_PH*PH_lambda;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);
MF_lambda = (CF_lambda + JF_lambda);
 
% Solving for sectoral return on capital - Rj(K,Q,G,Aj,Bj)                          
RH_K = RH_2K + (RH_PH*PH_K) + (RH_PN*PN_K);                                
RH_Q = (RH_PH*PH_Q) + (RH_PN*PN_Q);                                        
RH_G = (RH_PH*PH_G) + (RH_PN*PN_G);                                        
RH_AH = RH_2AH + (RH_PH*PH_AH) + (RH_PN*PN_AH);                            
RH_BH = RH_2BH + (RH_PH*PH_BH) + (RH_PN*PN_BH);                            
RH_AN = RH_2AN + (RH_PH*PH_AN) + (RH_PN*PN_AN);                            
RH_BN = RH_2BN + (RH_PH*PH_BN) + (RH_PN*PN_BN);                            
RH_lambda = RH_2lambda + (RH_PH*PH_lambda) + (RH_PN*PN_lambda);            
                                                                           
RN_K = RN_2K + (RN_PH*PH_K) + (RN_PN*PN_K);                                
RN_Q = (RN_PH*PH_Q) + (RN_PN*PN_Q);                                        
RN_G = (RN_PH*PH_G) + (RN_PN*PN_G);                                        
RN_AH = RN_2AH + (RN_PH*PH_AH) + (RN_PN*PN_AH);                            
RN_BH = RN_2BH + (RN_PH*PH_BH) + (RN_PN*PN_BH);                            
RN_AN = RN_2AN + (RN_PH*PH_AN) + (RN_PN*PN_AN);                            
RN_BN = RN_2BN + (RN_PH*PH_BN) + (RN_PN*PN_BN);                            
RN_lambda = RN_2lambda + (RN_PH*PH_lambda) + (RN_PN*PN_lambda);            

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(K,Q,G,Aj,Bj,lambda) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_G  = (v_PN*PN_G) + (v_PH*PH_G); 
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);
v_lambda = (v_PN*PN_lambda) + (v_PH*PH_lambda);
 
% Elements of the Jacobian Matrix                                                                                                                                                                                                                                 
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1SN*uKSN_K)-(KN*xi1DN*uKDN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                                                                                    
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1SN*uKSN_Q)-(KN*xi1DN*uKDN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );                                                                                                                                             
Sigma_K   = -( -(RK/K)+(1/K)*( RH*KH*((eta*uKSH_K)+(1-eta)*uKDH_K)+RN*KN*((eta*uKSN_K)+(1-eta)*uKDN_K)+(RH*KH_K)+(RN*KN_K)+(RH_K*KH)+(RN_K*KN) )-(PH*KH/K)*((xi1SH*uKSH_K)+(xi1DH*uKDH_K))-(PN*KN/K)*((xi1SN*uKSN_K)+(xi1DN*uKDN_K))+(PI*kappa*v_K*deltaK));      
Sigma_Q   = (r+deltaK)-( (1/K)*( (RH*KH*((eta*uKSH_Q)+(1-eta)*uKDH_Q))+(RN*KN*((eta*uKSN_Q)+(1-eta)*uKDN_Q))+(RH*KH_Q)+(RN*KN_Q)+(RH_Q*KH)+(RN_Q*KN) )-(PH*KH/K)*((xi1SH*uKSH_Q)+(xi1DH*uKDH_Q))-(PN*KN/K)*((xi1SN*uKSN_Q)+(xi1DN*uKDN_Q))+(PI*kappa*v_Q*deltaK)); 

x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    

J = [x11 x12; x21 x22];
[V,nu]=eig(J);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1); 
nu2 = nu_sorted(2,2); 
omega11 = V_sorted(1,1)/V_sorted(1,1); 
omega21 = V_sorted(2,1)/V_sorted(1,1); 
omega12 = V_sorted(1,2)/V_sorted(1,2); 
omega22 = V_sorted(2,2)/V_sorted(1,2); 
TrJ = trace(J); 
DetJ = det(J); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q);
% Xi_Q=0
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r); 

% Solving for sectoral wages - Wj=Wj(K,Q,G,Aj,Bj)
WH_K = WH_2K + (WH_PH*PH_K) + (WH_PN*PN_K);                       
WH_Q = (WH_PH*PH_Q) + (WH_PN*PN_Q);                               
WH_G = (WH_PH*PH_G) + (WH_PN*PN_G);                               
WH_AH = WH_2AH + (WH_PH*PH_AH) + (WH_PN*PN_AH);                   
WH_BH = WH_2BH + (WH_PH*PH_BH) + (WH_PN*PN_BH);                   
WH_AN = WH_2AN + (WH_PH*PH_AN) + (WH_PN*PN_AN);                   
WH_BN = WH_2BN + (WH_PH*PH_BN) + (WH_PN*PN_BN);                   
WH_lambda = WH_2lambda + (WH_PH*PH_lambda) + (WH_PN*PN_lambda);   
                                                                  
WN_K = WN_2K + (WN_PH*PH_K) + (WN_PN*PN_K);                       
WN_Q = (WN_PH*PH_Q) + (WN_PN*PN_Q);                               
WN_G = (WN_PH*PH_G) + (WN_PN*PN_G);                               
WN_AH = WN_2AH + (WN_PH*PH_AH) + (WN_PN*PN_AH);                   
WN_BH = WN_2BH + (WN_PH*PH_BH) + (WN_PN*PN_BH);                   
WN_AN = WN_2AN + (WN_PH*PH_AN) + (WN_PN*PN_AN);                   
WN_BN = WN_2BN + (WN_PH*PH_BN) + (WN_PN*PN_BN);                   
WN_lambda = WN_2lambda + (WN_PH*PH_lambda) + (WN_PN*PN_lambda); 

% Solution for W as function W=W(lambda,K,Q,AH,BH,AN,BN)                      
W_K       = (W_WH*WH_K) + (W_WN*WN_K);                                          
W_Q       = (W_WH*WH_Q) + (W_WN*WN_Q);  
W_G       = (W_WH*WH_G) + (W_WN*WN_G); 
W_AH      = (W_WH*WH_AH) + (W_WN*WN_AH);                                        
W_BH      = (W_WH*WH_BH) + (W_WN*WN_BH);                                        
W_AN      = (W_WH*WH_AN) + (W_WN*WN_AN);                                        
W_BN      = (W_WH*WH_BN) + (W_WN*WN_BN);                                        
W_lambda  = (W_WH*WH_lambda) + (W_WN*WN_lambda);                                
                                                                                
% Solution for L as function L=L(lambda,K,Q,Aj,Bj)                            
L_K  = (L_W*W_K) + (L_1PN*PN_K) + (L_1PH*PH_K);                                 
L_Q  = (L_W*W_Q) + (L_1PN*PN_Q) + (L_1PH*PH_Q);    
L_G  = (L_W*W_G) + (L_1PN*PN_G) + (L_1PH*PH_G);
L_AH = (L_W*W_AH) + (L_1PN*PN_AH) + (L_1PH*PH_AH);                              
L_BH = (L_W*W_BH) + (L_1PN*PN_BH) + (L_1PH*PH_BH);                              
L_AN = (L_W*W_AN) + (L_1PN*PN_AN) + (L_1PH*PH_AN);                              
L_BN = (L_W*W_BN) + (L_1PN*PN_BN) + (L_1PH*PH_BN);                              
L_lambda  = L_1lambda + (L_W*W_lambda) + (L_1PN*PN_lambda) + (L_1PH*PH_lambda);         

% solving for the Unit Cost for Producing MN=MN(K,Q,PN,G,Aj,Bj)               
MN_K  = sLN*(MN/WN)*WN_K + (1-sLN)*(MN/RN)*RN_K;                              
MN_Q  = sLN*(MN/WN)*WN_Q + (1-sLN)*(MN/RN)*RN_Q;                              
MN_G  = sLN*(MN/WN)*WN_G + (1-sLN)*(MN/RN)*RN_G;                              
MN_AH = sLN*(MN/WN)*WN_AH + (1-sLN)*(MN/RN)*RN_AH;                            
MN_BH = sLN*(MN/WN)*WN_BH + (1-sLN)*(MN/RN)*RN_BH;                            
MN_AN = sLN*(MN/WN)*WN_AN + (1-sLN)*(MN/RN)*RN_AN - sLN*(MN/AN);              
MN_BN = sLN*(MN/WN)*WN_BN + (1-sLN)*(MN/RN)*RN_BN - (1-sLN)*(MN/BN);          
MN_lambda  = sLN*(MN/WN)*WN_lambda + (1-sLN)*(MN/RN)*RN_lambda;               

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 
omegaGT = GT/G; 
omegaGH = (PH*GH)/GT; 
omegaGF = GF/G; 

% Investment 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF;  
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;
RHPH = RH/PH;
RNPN = RN/PN;

% Labor income and Capital income shares
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% Aggregator function for L=L(LH,LN)
VLAB    = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = VLAB^(epsilon/(epsilon+1)); 
L_LH    = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_LN    = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Aggregator function for K=K(KH,KN)                                                                                                      
VCAP    = ( (varthetaK^(-1/epsilonK))*(KH^((epsilonK+1)/epsilonK)) + ((1-varthetaK)^(-1/epsilonK))*(KN^((epsilonK+1)/epsilonK)) );        
K_check = VCAP^(epsilonK/(epsilonK+1));                                                                                                   
K_KH    = ((varthetaK)^(-1/epsilonK))*(KH/K)^(1/epsilonK);                                                                                
K_KN    = ((1-varthetaK)^(-1/epsilonK))*(KN/K)^(1/epsilonK);                                                                             
                                                                                                                                          
% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH =  IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaXHY  = (PH*XH) / Y; 
omegaXHYH = XH / YH;

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Check the closure of the model                                               
cond1  = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH))-RH;       
cond2  = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN))-RN;      
cond3  = PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH))-WH;                
cond4  = PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN))-WN;                
cond5  = (RH*KH)+(RN*KN)-(RK*K);                                               
cond6  = RK-(deltaK+r)*PI;                                                     
cond7  = YN-CN-GN-IN;                                                          
cond8  = YH-CH-GH-IH-XH;                                                       
cond9  = (B-B0) - H1*(K-K0);                                                   
cond10 = DetJ - (nu1*nu2);                                                     
cond11 = TrJ - (nu1+nu2);                                                      
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);                   
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);                          
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                           
cond15 = (W*L) - ((WH*LH)+(WN*LN));                                            
cond16 = -U_L*L_LH - (lambda*WH);                                              
cond17 = -U_L*L_LN - (lambda*WN);                                              
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                                      
cond19 = Sav;                                                                  
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                        
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);                            
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                          
cond23 = (RK*K) - ((RH*KH)+(RN*KN));                                         
cond24 = 1 - (omegaK + omegaL);                                                
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);                          
cond26 = (PT*CT) - ((PH*CH)+CF);                                               
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);                             
cond28 = (PIT*IT) - ((PH*IH)+IF);                                              
cond29 = r*B + (PH*XH) - MF;                                                   
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I);                                                                           
cond31 = K_KH - (RH/RK);                                                            
cond32 = K_KN - (RN/RK);                                                            
cond33 = (KH/KN) - (varthetaK/(1-varthetaK))*(RH/RN)^(epsilonK);    
cond34 = PN - MN;
cond35 = PH - MH;
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kH > kN');
disp('                           The exomark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (exomark)');
disp(sprintf('sigmaH  : %5.2f   gammaH   : %5.2f',sigmaH,gammaH));
disp(sprintf('sigmaN  : %5.2f   gammaN   : %5.2f',sigmaN,gammaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('phi     : %5.2f   varphi   : %5.2f',phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f sigma   : %5.2f',sigmaL,gammaL,sigma));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('epsilonK: %5.2f   varthetaK: %5.2f',epsilonK,varthetaK));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('AH      : %5.2f   BH       : %5.2f',AH,BH));
disp(sprintf('AN      : %5.2f   BN       : %5.2f',AN,BN));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('TFPH    : %5.2f   TFPN     : %5.2f',TFPH,TFPN));
disp(sprintf('omegaYH : %5.2f   Z        : %5.2f TFP        : %5.2f',omegaYH,Z,TFP));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (exomark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));
disp(sprintf('K        : %9.3f   ',K));
disp(sprintf('K_check  : %9.3f   ',K_check));
disp(sprintf('alphaK   : %9.3f   ',alphaK));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('RN                 : %9.3f',RN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('RH                 : %9.3f',RH));
disp(sprintf('Profit             : %9.10f',PiH));

disp(' ');                                                                                      
disp('Wealth');                                                                                 
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));                                          
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));                                     
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA)); 

disp(' ');
disp('The demand side (exomark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (exomark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f',IH,IN));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp('Export and import (exomark)');
disp(sprintf('XH        :   %7.3f   MF : %9.3f',XH,MF));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));

disp('Price of Non Tradables in terms of Imports');                                                                
disp(sprintf('PN_Q        :   %7.3f  PN_K        : %9.3f',PN_Q,PN_K));                          
disp(sprintf('PN_G        :   %7.3f',PN_G)); 
disp(sprintf('PN_AH       :   %7.3f  PN_BH       : %9.3f',PN_AH,PN_BH));
disp(sprintf('PN_AN       :   %7.3f  PN_BN       : %9.3f',PN_AN,PN_BN));
                                                                                                
disp('Terms of Trade');                                                                                            
disp(sprintf('PH_Q        :   %7.3f  PH_K        : %9.3f',PH_Q,PH_K));                          
disp(sprintf('PH_G        :   %7.3f',PH_G));                        
disp(sprintf('PH_AH       :   %7.3f  PH_BH       : %9.3f',PH_AH,PH_BH));
disp(sprintf('PH_AN       :   %7.3f  PH_BN       : %9.3f',PH_AN,PH_BN));                                                                                                

disp(' ');                                                                                      
disp('Partial derivatives CH and CN');                                                          
disp(sprintf('CN_K        :   %7.3f  CH_K      : %9.3f',CN_K,CH_K));                            
disp(sprintf('CN_Q        :   %7.3f  CH_Q      : %9.3f',CN_Q,CH_Q));                            
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));                  
disp(sprintf('CN_G        :   %7.3f  CH_G      : %9.3f',CN_G,CH_G)); 
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));
disp(sprintf('CN_AH       :   %7.3f  CH_AH     : %9.3f',CN_AH,CH_AH));
disp(sprintf('CN_BH       :   %7.3f  CH_BH     : %9.3f',CN_BH,CH_BH));
disp(sprintf('CN_AN       :   %7.3f  CH_AN     : %9.3f',CN_AN,CH_AN));
disp(sprintf('CN_BN       :   %7.3f  CH_BN     : %9.3f',CN_BN,CH_BN));                          
                                                                                                                                                                                                                                                                                                                     
disp('Partial derivatives KH and KN');                                                      
disp(sprintf('KN_Q       :   %7.6f  KH_Q       : %9.6f',KN_Q,KH_Q));                        
disp(sprintf('KN_K       :   %7.6f  KH_K       : %9.6f',KN_K,KH_K));                        
disp(sprintf('KN_lambda  :   %7.3f  KH_lambda  : %9.3f',KN_lambda,KH_lambda));              
disp(sprintf('KN_G       :   %7.6f  KH_G       : %9.6f',KN_G,KH_G));                        
disp(sprintf('KN_AH      :   %7.6f  KH_AH      : %9.6f',KN_AH,KH_AH));                      
disp(sprintf('KN_BH      :   %7.6f  KH_BH      : %9.6f',KN_BH,KH_BH));                      
disp(sprintf('KN_AN      :   %7.6f  KH_AN      : %9.6f',KN_AN,KH_AN));                      
disp(sprintf('KN_BN      :   %7.6f  KH_BN      : %9.6f',KN_BN,KH_BN));                      
                                                                                            
disp('Partial derivatives WH and WN');                                                      
disp(sprintf('WN_Q       :   %7.6f  WH_Q       : %9.6f',WN_Q,WH_Q));                        
disp(sprintf('WN_K       :   %7.6f  WH_K       : %9.6f',WN_K,WH_K));                        
disp(sprintf('WN_lambda  :   %7.3f  WH_lambda  : %9.3f',WN_lambda,WH_lambda));              
disp(sprintf('WN_G       :   %7.6f  WH_G       : %9.6f',WN_G,WH_G));                        
disp(sprintf('WN_AH      :   %7.6f  WH_AH      : %9.6f',WN_AH,WH_AH));                      
disp(sprintf('WN_BH      :   %7.6f  WH_BH      : %9.6f',WN_BH,WH_BH));                      
disp(sprintf('WN_AN      :   %7.6f  WH_AN      : %9.6f',WN_AN,WH_AN));                      
disp(sprintf('WN_BN      :   %7.6f  WH_BN      : %9.6f',WN_BN,WH_BN));                      
                                                                                            
disp('Partial derivatives RH and RN');                                                      
disp(sprintf('RN_Q       :   %7.6f  RH_Q       : %9.6f',RN_Q,RH_Q));                        
disp(sprintf('RN_K       :   %7.6f  RH_K       : %9.6f',RN_K,RH_K));                        
disp(sprintf('RN_lambda  :   %7.3f  RH_lambda  : %9.3f',RN_lambda,RH_lambda));              
disp(sprintf('RN_G       :   %7.6f  RH_G       : %9.6f',RN_G,RH_G));                        
disp(sprintf('RN_AH      :   %7.6f  RH_AH      : %9.6f',RN_AH,RH_AH));                      
disp(sprintf('RN_BH      :   %7.6f  RH_BH      : %9.6f',RN_BH,RH_BH));                      
disp(sprintf('RN_AN      :   %7.6f  RH_AN      : %9.6f',RN_AN,RH_AN));                      
disp(sprintf('RN_BN      :   %7.6f  RH_BN      : %9.6f',RN_BN,RH_BN));                      
                                                                                                
disp('Partial derivatives LH and LN');                                                          
disp(sprintf('LN_Q       :   %7.6f  LH_Q       : %9.6f',LN_Q,LH_Q));                            
disp(sprintf('LN_K       :   %7.6f  LH_K       : %9.6f',LN_K,LH_K));                            
disp(sprintf('LN_lambda  :   %7.3f  LH_lambda  : %9.3f',LN_lambda,LH_lambda));                  
disp(sprintf('LN_G       :   %7.6f  LH_G       : %9.6f',LN_G,LH_G)); 
disp(sprintf('LN_AH      :   %7.6f  LH_AH      : %9.6f',LN_AH,LH_AH));
disp(sprintf('LN_BH      :   %7.6f  LH_BH      : %9.6f',LN_BH,LH_BH));
disp(sprintf('LN_AN      :   %7.6f  LH_AN      : %9.6f',LN_AN,LH_AN));
disp(sprintf('LN_BN      :   %7.6f  LH_BN      : %9.6f',LN_BN,LH_BN));
                                                                                        
disp('Partial derivatives Yj');  
disp(sprintf('YN_1PN     :   %7.6f  YN_1PH     : %9.6f',YN_1PN,YN_1PH));
disp(sprintf('YN_1K      :   %7.6f  YN_1lambda : %9.6f',YN_1K,YN_1lambda));
disp(sprintf('YN_1AH     :   %7.6f  YN_1BH     : %9.6f',YN_1AH,YN_1BH));
disp(sprintf('YN_1AN     :   %7.6f  YN_1BN     : %9.6f',YN_1AN,YH_1BN));
disp(sprintf('YN_uKH     :   %7.6f  YN_uKN     : %9.6f',YN_uKH,YN_uKN));
disp(' ');
disp(sprintf('YH_1PN     :   %7.6f  YH_1PH     : %9.6f',YH_1PN,YH_1PH));
disp(sprintf('YH_1K      :   %7.6f  YH_1lambda : %9.6f',YH_1K,YH_1lambda));
disp(sprintf('YH_1AH     :   %7.6f  YH_1BH     : %9.6f',YH_1AH,YH_1BH));
disp(sprintf('YH_1AN     :   %7.6f  YH_1BN     : %9.6f',YH_1AN,YH_1BN));
disp(sprintf('YH_uKH     :   %7.6f  YH_uKN     : %9.6f',YH_uKH,YH_uKN));
disp(' ');

disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));                            
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));                            
disp(sprintf('YN_lambda  :   %7.3f  YH_lambda  : %9.3f',YN_lambda,YH_lambda));                  
disp(sprintf('YN_G       :   %7.6f  YH_G       : %9.6f',YN_G,YH_G));
disp(sprintf('YN_AH      :   %7.6f  YH_AH      : %9.6f',YN_AH,YH_AH));
disp(sprintf('YN_BH      :   %7.6f  YH_BH      : %9.6f',YN_BH,YH_BH));
disp(sprintf('YN_AN      :   %7.6f  YH_AN      : %9.6f',YN_AN,YH_AN));
disp(sprintf('YN_BN      :   %7.6f  YH_BN      : %9.6f',YN_BN,YH_BN));
                                                                                                                                                                                                                                                                                                                                                                                                    
disp('Partial derivatives of L');                                                               
disp(sprintf('L_Q        :   %7.3f  L_K        : %9.3f',L_Q,L_K));                              
disp(sprintf('L_G        :   %7.3f ',L_G));      
disp(sprintf('L_AH       :   %7.3f  L_BH       : %9.3f',L_AH,L_BH));
disp(sprintf('L_AN       :   %7.3f  L_BN       : %9.3f',L_AN,L_BN));
disp(sprintf('L_lambda   :   %7.3f',L_lambda));  

disp('Partial derivatives of uKj');  
disp(sprintf('uKN_Q       :   %7.6f  uKH_Q       : %9.6f',uKN_Q,uKH_Q));             
disp(sprintf('uKN_K       :   %7.6f  uKH_K       : %9.6f',uKN_K,uKH_K));             
disp(sprintf('uKN_lambda  :   %7.3f  uKH_lambda  : %9.3f',uKN_lambda,uKH_lambda));   
disp(sprintf('uKN_G       :   %7.6f  uKH_G       : %9.6f',uKN_G,uKH_G));             
disp(sprintf('uKN_AH      :   %7.6f  uKH_AH      : %9.6f',uKN_AH,uKH_AH));           
disp(sprintf('uKN_BH      :   %7.6f  uKH_BH      : %9.6f',uKN_BH,uKH_BH));           
disp(sprintf('uKN_AN      :   %7.6f  uKH_AN      : %9.6f',uKN_AN,uKH_AN));           
disp(sprintf('uKN_BN      :   %7.6f  uKH_BN      : %9.6f',uKN_BN,uKH_BN));  
                                                                                                                                                                                                       
disp(' ');                                                                                      
disp('Relative Prices');  
disp(sprintf('PN_K       : %5.4f   PN_Q       : %5.4f',PN_K,PN_Q));                                 
disp(sprintf('PN_G       :  %5.4f  PN_lambda  : %5.4f',PN_G,PN_lambda));  
disp(sprintf('PH_K       : %5.4f   PH_Q       : %5.4f',PH_K,PH_Q));                                 
disp(sprintf('PH_G       :  %5.4f  PH_lambda  : %5.4f',PH_G,PH_lambda)); 
                                                                                                
disp(' ');                                                                                      
disp('Linearization');                                                                          
disp(sprintf('v_K       :  %5.4f  v_Q       : %5.4f',v_K,v_Q));                                 
disp(sprintf('v_G       :  %5.4f',v_G));          
disp(sprintf('v_AH      :  %5.4f  v_BH      : %5.4f',v_AH,v_BH));
disp(sprintf('v_AN      :  %5.4f  v_BN      : %5.4f',v_AN,v_BN));
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));                     
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));                         
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));  
                                                                                                
disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (exomark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/GT  :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));

disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Capital compensation = RH*KH+RN*KN: %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor supply LH/LN       : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));
disp(sprintf('Traded capital supply             : %9.16f   ',cond31));
disp(sprintf('Non-traded capital supply         : %9.16f   ',cond32));
disp(sprintf('Relative capital supply KH/KN     : %9.16f   ',cond33));
disp(sprintf('Unit Cost for Producing N         : %9.16f   ',cond34));
disp(sprintf('Unit Cost for Producing H         : %9.16f   ',cond35));

kH_0 = kH;  kN_0 = kN; PN_0 = PN; K_0 = K; C_0 = C;  
L_0 = L; W_0 = W; P_0 = P; 
YH_0  = YH; YN_0  = YN; Y_0  = Y; YR_0 = Y_0; G_0 = G;     
PC_0 = PC; CN_0 = CN; CH_0 = CH;  GH_0 = GH; GN_0 = GN; 
LH_0 = LH; LN_0 = LN; KH_0 = KH; KN_0 = KN; WH_0 = WH; WN_0 = WN; 
Omega_0 = Omega; YHYN_0 = YHYN; LHLN_0 = LHLN;
IF_0 = IF; CF_0 = CF; XH_0 = XH; MF_0 = MF; GF_0 = GF; PH_0 = PH; 
PT_0 = PT; PIT_0 = PIT; CT_0 = CT; IT_0 = IT; GT_0 = GT; 

CA_0 = CA; Sav_0 = Sav; NX_0 = NX; I_0 = I; lambda_0  = lambda; A_0 = A; 
B_0 = B; IN_0 = IN; IH_0 = IH; PI_0 = PI; EI_0 = EI; 
WPC_0 = WPC; WHPC_0 = WHPC; WNPC_0 = WNPC; RK_0 = RK; 
yH_0 = yH; yN_0 = yN; 

omegaL_0 = omegaL; omegaK_0 = omegaK; omegaI_0 = omegaI; omegaINYN_0 = omegaINYN;
omegaIHYH_0 = omegaIHYH; omega_IFYH_0 = omegaIFYH; omegaGHYH_0 = omegaGHYH; 
omegaGNYN_0 = omegaGNYN; omegaGN_0 = omegaGN;
omegaYH_0 = omegaYH; omegaYN_0 = omegaYN; omegaLH_0 = omegaLH; omegaLN_0 = omegaLN; 
omegaC_0 =omegaC; omegaNX_0 =omegaNX; omegaG_0 =omegaG; omegaB_0 =omegaB; 
omegaIFYH_0 = omegaIFYH; omegaGFYH_0 = omegaGFYH; 
omegaCH_0 = omegaCH; omegaCF_0 = omegaCF; 
omegaGT_0 = omegaGT; omegaGH_0 = omegaGH; omegaGF_0 = omegaGF; 
omegaKY_0 = omegaKY; omegaIH_0 = omegaIH; omegaIF_0 = omegaIF;
omegaXHY_0 = omegaXHY; omegaXHYH_0 = omegaXHYH; 
alphaL_0 = alphaL; alphaK_0 = alphaK; alphaC_0 = alphaC; 
alphaI_0 = alphaI; alphaH_0 = alphaH; alphaIH_0 = alphaIH; 
sLH_0 = sLH; sLN_0 = sLN; sigmaH_0 = sigmaH; sigmaN_0 = sigmaN;  
sL_0 = sL; k_0 = k; VL_0 = VL; RH_0 = RH; RN_0 = RN; 
RHPH_0 = RHPH; RNPN_0 = RNPN; KHK_0 = KHK; RKPC_0 = RKPC;   

 AH_0 = AH; BH_0 = BH; AN_0 = AN; BN_0 = BN;           
 ZH_0 = ZH; ZN_0 = ZN; ZA_0 = ZA;                      
 TFPH_0 = TFPH; TFPN_0 = TFPN; TFPA_0 = TFPA;  
 ASH_0 = AH_0; BSH_0 = BH_0; ASN_0 = AN_0; BSN_0 = BN_0; 
 ADH_0 = AH_0; BDH_0 = BH_0; ADN_0 = AN_0; BDN_0 = BN_0; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Temporary Fiscal Shock                          %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B0       = B_0;
K0       = K_0; 
GH       = GH_0; 
GN       = GN_0; 
GF       = GF_0;  
%G        = G_0; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Endogenous response of G, Aj, Bj to an exogenous government spending shock 
barg     = 0.0000000000001; 
xi       = 0.0000000000001;                                                                                                                                
chi      = 0.0000000000001;
gG       = 0.0000000000001;
filename = 'Calibration_sym_asym';                                                                                             
sheet    = 8;                                                                                                                                          
xlRange  = 'C3:J6';                                                                                                                                 
datac = xlsread(filename,sheet,xlRange);                                                                                                            
parameters = xlsread(filename,sheet,xlRange);     
                                                                                                                                                                                                                                                                                                                                                                                                                   
baraSH    = parameters(1,1);
barbSH    = parameters(1,2);
baraSN    = parameters(1,3);
barbSN    = parameters(1,4);
                            
baraDH    = parameters(1,5);
barbDH    = parameters(1,6);
baraDN    = parameters(1,7);
barbDN    = parameters(1,8);
                            
gASH      = parameters(2,1); 
gBSH      = parameters(2,2); 
gASN      = parameters(2,3); 
gBSN      = parameters(2,4); 
                             
gADH      = parameters(2,5); 
gBDH      = parameters(2,6); 
gADN      = parameters(2,7); 
gBDN      = parameters(2,8); 
                            
xiASH     = parameters(3,1);
chiASH    = parameters(4,1);
xiBSH     = parameters(3,2);
chiBSH    = parameters(4,2);
xiASN     = parameters(3,3);
chiASN    = parameters(4,3);
xiBSN     = parameters(3,4);
chiBSN    = parameters(4,4);
                            
xiADH     = parameters(3,5);
chiADH    = parameters(4,5);
xiBDH     = parameters(3,6);
chiBDH    = parameters(4,6);
xiADN     = parameters(3,7);
chiADN    = parameters(4,7);
xiBDN     = parameters(3,8);
chiBDN    = parameters(4,8);

ASH      = AH_0*(1+gASH); 
ADH      = AH_0*(1+gADH); 
BSH      = BH_0*(1+gBSH); 
BDH      = BH_0*(1+gBDH); 
ASN      = AN_0*(1+gASN); 
ADN      = AN_0*(1+gADN); 
BSN      = BN_0*(1+gBSN); 
BDN      = BN_0*(1+gBDN);

% TFP
AH = (ASH^eta)*(ADH^(1-eta)); 
BH = (BSH^eta)*(BDH^(1-eta)); 
AN = (ASN^eta)*(ADN^(1-eta)); 
BN = (BSN^eta)*(BDN^(1-eta)); 
%ZH = ((AH)^(sLH_0))*((BH)^(1-sLH_0)); 
%ZN = ((AN)^(sLN_0))*((BN)^(1-sLN_0)); 
%ZA = (ZH^omegaYH_0)*(ZN^(1-omegaYH_0));
G  = G_0*(1+gG);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                                                                                                                                                                                                     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x0 =[C_0 L_0 RH_0 RN_0 WH_0 WN_0 W_0 RK_0 PN_0 K_0 PH_0 B_0 alphaL_0 alphaK_0 PC_0 PT_0 CN_0 CH_0 CF_0 PI_0 PIT_0 IN_0 IH_0 IF_0 LH_0 LN_0 KH_0 KN_0 YH_0 YN_0 XH_0 MF_0 VL_0 lambda_0];
[x,fval,exitflag]=fsolve('IML_IMK_CAC_TOT_CES_NS_perm',x0,optimset('display','off','TolFun',1e-011));
C        = x(1)  ; % Consumption                                                              
L        = x(2)  ; % Labor supply                                                             
RH       = x(3)  ; % Return on traded capital                                                 
RN       = x(4)  ; % Return on non-traded capital                                             
WH       = x(5)  ; % Wage rate in sector H                                                    
WN       = x(6)  ; % Wage rate in sector N                                                    
W        = x(7)  ; % Aggregate wage index                                                     
RK       = x(8)  ; % Aggregate capital rental rate                                            
PN       = x(9)  ; % Relative price of non tradables                                          
K        = x(10)  ; % Stock of capital                                                        
PH       = x(11) ; % Terms of trade : PH/PF with PF = numeraire                               
B        = x(12) ; % Stock of Traded Bonds                                                    
alphaL   = x(13) ; % Labor compensation share of tradables                                    
alphaK   = x(14) ; % Capital compensation share of tradables                                  
PC       = x(15) ; % Aggregate consumption price index                                        
PT       = x(16) ; % Consumption price index for tradables                                    
CN       = x(17) ; % Consumption in non tradables                                             
CH       = x(18) ; % Consumption in tradables                                                 
CF       = x(19) ; % Consumption goods imports                                                
PI       = x(20) ; % Aggregate investment price index                                         
PIT      = x(21) ; % Investment price index for tradables                                     
IN       = x(22) ; % Non tradable investment                                                  
IH       = x(23) ; % Investment in home goods                                                 
IF       = x(24) ; % Investment in foreign goods                                              
LH       = x(25) ; % Labor in sector H                                                        
LN       = x(26) ; % Labor in sector N                                                        
KH       = x(27) ; % Capital stock in sector H                                                
KN       = x(28) ; % Capital stock in sector N                                                
YH       = x(29) ; % Traded value added                                                       
YN       = x(30) ; % Non-traded value added                                                   
XH       = x(31) ; % Exports of home traded goods                                             
MF       = x(32) ; % Imports of foreign goods                                                 
VL       = x(33) ; % Desutility labor                                                         
lambda   = x(34) ; % Marginal Utility of Wealth - Intertemporal Solvency Condition 

% Sectoral outputs and sectoral profits        
PiH = (PH*YH) - (RH*KH) - (WH*LH);             
PiN = (PN*YN) - (RN*KN) - (WN*LN);             

% Shares
I       = deltaK*K;
alphaC  = varphi*(PT/PC)^(1-phi);
alphaH  = varphiH*(PH/PT)^(1-rho);
alphaI  = iota*(PIT/PI)^(1-phiI);
alphaIH = iotaH*(PH/PIT)^(1-rhoI);

% Nominal and Real GDP
Y  = (PH*YH) +(PN*YN);
YR = (PH_0*YH) + (PN_0*YN); 
kH  = KH/LH; 
kN  = KN/LN; 
yH  = YH/LH; 
yN  = YN/LN; 
sLH = gammaH*(AH/yH)^((sigmaH-1)/sigmaH);
sLN = gammaN*(AN/yN)^((sigmaN-1)/sigmaN); 
sL  = W*L/Y; 
k   = K/L; 
P   = PN/PH;  
KHK = KH/K; 

% VA shares in real terms
omegaYHR = (PH_0*YH)/YR; 
omegaYNR = (PN_0*YN)/YR; 
omegaLH   = LH / L;
omegaLN   = LN / L;

% Technology                                                                                                  
ZH  = ((AH)^(sLH))*((BH)^(1-sLH));                                                                             
ZN  = ((AN)^(sLN))*((BN)^(1-sLN));   
ZSH = ((ASH)^(sLH))*((BSH)^(1-sLH));   
ZSN = ((ASN)^(sLN))*((BSN)^(1-sLN));   
ZDH = ((ADH)^(sLH))*((BDH)^(1-sLH));   
ZDN = ((ADN)^(sLN))*((BDN)^(1-sLN));   
ZA   = (ZH^omegaYH)*(ZN^(1-omegaYH));                                                                           
TFPH = YH/(gammaH*(LH^((sigmaH-1)/sigmaH)) + (1-gammaH)*(KH^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1));       
TFPN = YN/(gammaN*(LN^((sigmaN-1)/sigmaN)) + (1-gammaN)*(KN^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1));       
TFPA = (TFPH^omegaYH)*(TFPN^(1-omegaYH));                                                                     

% Unit cost for producting
MN = ((gammaN^sigmaN)*((WN/AN)^(1-sigmaN)) + ((1-gammaN)^sigmaN)*((RN/BN)^(1-sigmaN)))^(1/(1-sigmaN));   
MH = ((gammaH^sigmaH)*((WH/AH)^(1-sigmaH)) + ((1-gammaH)^sigmaH)*((RH/BH)^(1-sigmaH)))^(1/(1-sigmaH));                                                         
                                                                         
% Non Sep preferences Shimer (2009)
%VL        = ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );
V_L       = (sigma-1)*gammaL*L^(1/sigmaL);
V_LL      = (sigma-1)*(gammaL/sigmaL)*(L^((1/sigmaL)-1));
U_C       =  (C^(-sigma))*(VL^sigma);
U_CC      = -sigma*(C^(-sigma-1))*(VL^sigma);
U_L       = ( (C^(1-sigma))*sigma*V_L*(VL^(sigma-1)) )/(1-sigma);
U_LL      = U_L*( (V_LL/V_L) + (sigma-1)*V_L*(VL^(-1)) ); 
U_CL      = (C^(-sigma))*sigma*V_L*(VL^(sigma-1));
U_LC      = U_CL;

% Solutions C=C(lambda,PN,PH,W); L=L(lambda,PN,PH,W)
a11 = (U_CC/U_C);
a12 = (U_CL/U_C);
a21 = (U_LC/U_L);
a22 = (U_LL/U_L);

% PN, PH, W, lambda
b11 = (1-alphaC)/PN;
b12 = alphaC*alphaH/PH;
b13 = 0;
b14 = (1/lambda);

b21 = 0;
b22 = 0;
b23 = (1/W);
b24 = (1/lambda);

A1 = [a11 a12; a21 a22];
B1 = [b11 b12 b13 b14; b21 b22 b23 b24];
JST1 = inv(A1);
MST1 = JST1*B1;
C_1PN = MST1(1,1); C_1PH = MST1(1,2); C_W = MST1(1,3);
L_1PN = MST1(2,1); L_1PH = MST1(2,2); L_W = MST1(2,3);

% Partial derivatives of W=W(WN,WH)           
W_WH     = (W/WH)*alphaL; 
W_WN     = (W/WN)*(1-alphaL);                                                                                                                         
L_WH     = L_W*W_WH;                                                                    
L_WN     = L_W*W_WN;                                                                    
                                                                                        
% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH,WN,WH)                      
CN_1PN = - (CN/PN)*(alphaC*phi) + (CN/C)*C_1PN;                                         
CN_1PH = (CN/PH)*alphaC*alphaH*phi + (CN/C)*C_1PH;                                      
CN_WN  = (CN/C)*C_W*W_WN;                                                               
CN_WH  = (CN/C)*C_W*W_WH;                                                               
                                                                                        
CH_1PN = (CH/PN)*phi*(1-alphaC) + (CH/C)*C_1PN;                                         
CH_1PH = -(CH/PH)*( rho*(1-alphaH) + phi*alphaH*(1-alphaC) ) + (CH/C)*C_1PH;            
CH_WN  = (CH/C)*C_W*W_WN;                                                               
CH_WH  = (CH/C)*C_W*W_WH;                                                               
                                                                                        
CF_1PN = (CF/PN)*(1-alphaC)*phi + (CF/C)*C_1PN;                                         
CF_1PH = (CF/PH)*alphaH*(rho - phi*(1-alphaC) ) + (CF/C)*C_1PH;                         
CF_WN  = (CF/C)*C_W*W_WN;                                                               
CF_WH  = (CF/C)*C_W*W_WH;   

% Solutions LH=LH(lambda,WH,WN,PH,PN), LN=LN(lambda,WH,WN,PH,PN)
LH_WH  = (LH/WH)*epsilon*(1-alphaL) + (LH/L)*L_WH; 
LH_WN  = -(LH/WN)*epsilon*(1-alphaL) + (LH/L)*L_WN; 
LH_1PH = (LH/L)*L_1PH; 
LH_1PN = (LH/L)*L_1PN;

LN_WH  = -(LN/WH)*epsilon*alphaL + (LN/L)*L_WH; 
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN; 
LN_1PH = (LN/L)*L_1PH; 
LN_1PN = (LN/L)*L_1PN;  

% Partial derivatives of RK(RH,RN)               
R_RH  = (RK/RH)*alphaK;                         
R_RN  = (RK/RN)*(1-alphaK);                     
                                                 
% Solutions Kj=Kj(RH,RN,K), j=H,N                
KH_RH  = (KH/RH)*epsilonK*(1-alphaK);            
KH_RN  = -(KH/RN)*epsilonK*(1-alphaK);           
KH_1K  = (KH/K);                                 
                                                 
KN_RH  = -(KN/RH)*epsilonK*alphaK;               
KN_RN  = (KN/RN)*epsilonK*alphaK;                
KN_1K  = (KN/K);                                                         

% Solving for WH,WN,RH,RN(PH,PN,K,uKH,uKN,AH,BH,AN,BN,lambda)
d11 = - ( ((1-sLH)/sigmaH)*(LH_WH/LH) + (1/WH) ); % WH
d12 = - ((1-sLH)/sigmaH)*(LH_WN/LH);  % WN
d13 = ((1-sLH)/sigmaH)*(KH_RH/KH);  % RH
d14 = ((1-sLH)/sigmaH)*(KH_RN/KH); % RN

d21 = - ((1-sLN)/sigmaN)*(LN_WH/LN);  % WH
d22 = - ( ((1-sLN)/sigmaN)*(LN_WN/LN) + (1/WN) ); % WN
d23 = ((1-sLN)/sigmaN)*(KN_RH/KN);  % RH
d24 = ((1-sLN)/sigmaN)*(KN_RN/KN); % RN

d31 = (sLH/sigmaH)*(LH_WH/LH); % WH
d32 = (sLH/sigmaH)*(LH_WN/LH); % WN
d33 = - ( (sLH/sigmaH)*(KH_RH/KH) + (1/RH) ); % RH
d34 = - (sLH/sigmaH)*(KH_RN/KH); % RN

d41 = (sLN/sigmaN)*(LN_WH/LN); % WH
d42 = (sLN/sigmaN)*(LN_WN/LN); % WN
d43 = - (sLN/sigmaN)*(KN_RH/KN); % RH
d44 = - ( (sLN/sigmaN)*(KN_RN/KN) + (1/RN) ); % RN

% PN,PH,K,uKH,uKN,AH,BH,AN,BN,lambda
e11 = ((1-sLH)/sigmaH)*(LH_1PN/LH); % PN
e12 = ((1-sLH)/sigmaH)*(LH_1PH/LH) - (1/PH); % PH
e13 = - ((1-sLH)/sigmaH)*(KH_1K/KH); % K
e14 = - ((1-sLH)/sigmaH); % uKH
e15 = 0; % uKN
e16 = - ( ((sigmaH-1)/sigmaH)+ (sLH/sigmaH) )*(1/AH);  % AH
e17 = - ((1-sLH)/sigmaH)*(1/BH);  % BH
e18 = 0;
e19 = 0;

e21 = ((1-sLN)/sigmaN)*(LN_1PN/LN) - (1/PN); % PN
e22 = ((1-sLN)/sigmaN)*(LN_1PH/LN);  % PH
e23 = - ((1-sLN)/sigmaN)*(KN_1K/KN); % K
e24 = 0; % uKH
e25 = - ((1-sLN)/sigmaN);  % uKN
e26 = 0;
e27 = 0;
e28 = - ( ((sigmaN-1)/sigmaN) + (sLN/sigmaN) )*(1/AN);  % AN
e29 = - ((1-sLN)/sigmaN)*(1/BN);    % BN

e31 = - (sLH/sigmaH)*(LH_1PN/LH); % PN
e32 = - ( (sLH/sigmaH)*(LH_1PH/LH) + (1/PH) ); % PH
e33 = (sLH/sigmaH)*(KH_1K/KH); % K
e34 = (sLH/sigmaH); % uKH
e35 = 0;  % uKN
e36 = - (sLH/sigmaH)*(1/AH); % AH
e37 = - ((sigmaH-sLH)/sigmaH)*(1/BH); % BH
e38 = 0;
e39 = 0;

e41 = - ( (sLN/sigmaN)*(LN_1PN/LN) + (1/PN) ); % PN
e42 = - (sLN/sigmaN)*(LN_1PH/LN); % PH
e43 = (sLN/sigmaN)*(KN_1K/KN); % K
e44 = 0;  % uKH
e45 = (sLN/sigmaN); % uKN
e46 = 0;
e47 = 0;
e48 = - (sLN/sigmaN)*(1/AN); % AN
e49 = - ((sigmaN-sLN)/sigmaN)*(1/BN); % BN

M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X2 = [e11 e12 e13 e14 e15 e16 e17 e18 e19; e21 e22 e23 e24 e25 e26 e27 e28 e29; e31 e32 e33 e34 e35 e36 e37 e38 e39; e41 e42 e43 e44 e45 e46 e47 e48 e49];
JST2 = inv(M2);
MST2 = JST2*X2;
WH_1PN = MST2(1,1); WH_1PH = MST2(1,2); WH_1K = MST2(1,3); WH_uKH = MST2(1,4); WH_uKN = MST2(1,5); WH_1AH = MST2(1,6); WH_1BH = MST2(1,7); WH_1AN = MST2(1,8); WH_1BN = MST2(1,9);
WN_1PN = MST2(2,1); WN_1PH = MST2(2,2); WN_1K = MST2(2,3); WN_uKH = MST2(2,4); WN_uKN = MST2(2,5); WN_1AH = MST2(2,6); WN_1BH = MST2(2,7); WN_1AN = MST2(2,8); WN_1BN = MST2(2,9);
RH_1PN = MST2(3,1); RH_1PH = MST2(3,2); RH_1K = MST2(3,3); RH_uKH = MST2(3,4); RH_uKN = MST2(3,5); RH_1AH = MST2(3,6); RH_1BH = MST2(3,7); RH_1AN = MST2(3,8); RH_1BN = MST2(3,9);
RN_1PN = MST2(4,1); RN_1PH = MST2(4,2); RN_1K = MST2(4,3); RN_uKH = MST2(4,4); RN_uKN = MST2(4,5); RN_1AH = MST2(4,6); RN_1BH = MST2(4,7); RN_1AN = MST2(4,8); RN_1BN = MST2(4,9);

% Solutions uKj(uKSj,uKDj)              
uKH_uKSH = eta;                         
uKH_uKDH = (1-eta);                     
uKN_uKSN = eta;                         
uKN_uKDN = (1-eta);                     
                                        
% Solutions Rj,Wj(PN,PH,K,uKSj,uKDj)    
RH_uKSH = RH_uKH*uKH_uKSH;              
RH_uKDH = RH_uKH*uKH_uKDH;              
RH_uKSN = RH_uKN*uKN_uKSN;              
RH_uKDN = RH_uKN*uKN_uKDN;              
                                        
WH_uKSH = WH_uKH*uKH_uKSH;              
WH_uKDH = WH_uKH*uKH_uKDH;              
WH_uKSN = WH_uKN*uKN_uKSN;              
WH_uKDN = WH_uKN*uKN_uKDN;              
                                        
RN_uKSH = RN_uKH*uKH_uKSH;              
RN_uKDH = RN_uKH*uKH_uKDH;              
RN_uKSN = RN_uKN*uKN_uKSN;              
RN_uKDN = RN_uKN*uKN_uKDN;              
                                        
WN_uKSH = WN_uKH*uKH_uKSH;              
WN_uKDH = WN_uKH*uKH_uKDH;              
WN_uKSN = WN_uKN*uKN_uKSN;              
WN_uKDN = WN_uKN*uKN_uKDN;              

% Solving for sectoral labor and sectoral output - Lj,Kj,Yj(PN,PH,K,uKj,Aj,Bj,lambda)
LH_2PN  = LH_1PN + (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_2PH  = LH_1PH + (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K   = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKSH = (LH_WH*WH_uKSH) + (LH_WN*WN_uKSH);
LH_uKDH = (LH_WH*WH_uKDH) + (LH_WN*WN_uKDH);
LH_uKSN = (LH_WH*WH_uKSN) + (LH_WN*WN_uKSN);
LH_uKDN = (LH_WH*WH_uKDN) + (LH_WN*WN_uKDN);
LH_1AH  = (LH_WH*WH_1AH) + (LH_WN*WN_1AH);
LH_1BH  = (LH_WH*WH_1BH) + (LH_WN*WN_1BH);
LH_1AN  = (LH_WH*WH_1AN) + (LH_WN*WN_1AN);
LH_1BN  = (LH_WH*WH_1BN) + (LH_WN*WN_1BN);

LN_2PN  = LN_1PN + (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_2PH  = LN_1PH + (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K   = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKSH = (LN_WH*WH_uKSH) + (LN_WN*WN_uKSH);
LN_uKDH = (LN_WH*WH_uKDH) + (LN_WN*WN_uKDH);
LN_uKSN = (LN_WH*WH_uKSN) + (LN_WN*WN_uKSN);
LN_uKDN = (LN_WH*WH_uKDN) + (LN_WN*WN_uKDN);
LN_1AH  = (LN_WH*WH_1AH) + (LN_WN*WN_1AH);
LN_1BH  = (LN_WH*WH_1BH) + (LN_WN*WN_1BH);
LN_1AN  = (LN_WH*WH_1AN) + (LN_WN*WN_1AN);
LN_1BN  = (LN_WH*WH_1BN) + (LN_WN*WN_1BN);

KH_1PN  = (KH_RH*RH_1PN) + (KH_RN*RN_1PN);
KH_1PH  = (KH_RH*RH_1PH) + (KH_RN*RN_1PH);
KH_2K   = KH_1K  +(KH_RH*RH_1K)  + (KH_RN*RN_1K);
KH_uKSH = (KH_RH*RH_uKSH) + (KH_RN*RN_uKSH);
KH_uKDH = (KH_RH*RH_uKDH) + (KH_RN*RN_uKDH);
KH_uKSN = (KH_RH*RH_uKSN) + (KH_RN*RN_uKSN);
KH_uKDN = (KH_RH*RH_uKDN) + (KH_RN*RN_uKDN);
KH_1AH  = (KH_RH*RH_1AH) + (KH_RN*RN_1AH);
KH_1BH  = (KH_RH*RH_1BH) + (KH_RN*RN_1BH);
KH_1AN  = (KH_RH*RH_1AN) + (KH_RN*RN_1AN);
KH_1BN  = (KH_RH*RH_1BN) + (KH_RN*RN_1BN);

KN_1PN  = (KN_RH*RH_1PN) + (KN_RN*RN_1PN);
KN_1PH  = (KN_RH*RH_1PH) + (KN_RN*RN_1PH);
KN_2K   = KN_1K + (KN_RH*RH_1K)  + (KN_RN*RN_1K);
KN_uKSH = (KN_RH*RH_uKSH) + (KN_RN*RN_uKSH);
KN_uKDH = (KN_RH*RH_uKDH) + (KN_RN*RN_uKDH);
KN_uKSN = (KN_RH*RH_uKSN) + (KN_RN*RN_uKSN);
KN_uKDN = (KN_RH*RH_uKDN) + (KN_RN*RN_uKDN);
KN_1AH  = (KN_RH*RH_1AH) + (KN_RN*RN_1AH);
KN_1BH  = (KN_RH*RH_1BH) + (KN_RN*RN_1BH);
KN_1AN  = (KN_RH*RH_1AN) + (KN_RN*RN_1AN);
KN_1BN  = (KN_RH*RH_1BN) + (KN_RN*RN_1BN);

YH_1PN  = sLH*YH*(LH_2PN/LH) + (1-sLH)*YH*(KH_1PN/KH);
YH_1PH  = sLH*YH*(LH_2PH/LH) + (1-sLH)*YH*(KH_1PH/KH);
YH_1K   = sLH*YH*(LH_1K/LH) + (1-sLH)*YH*(KH_2K/KH);
YH_uKSH = sLH*YH*(LH_uKSH/LH) + (1-sLH)*YH*( (KH_uKSH/KH) + eta );
YH_uKDH = sLH*YH*(LH_uKDH/LH) + (1-sLH)*YH*( (KH_uKDH/KH) + (1-eta) );
YH_uKSN = sLH*YH*(LH_uKSN/LH) + (1-sLH)*YH*(KH_uKSN/KH);
YH_uKDN = sLH*YH*(LH_uKDN/LH) + (1-sLH)*YH*(KH_uKDN/KH);
YH_1AH  = sLH*YH*( (LH_1AH/LH) + (1/AH) ) + (1-sLH)*YH*(KH_1AH/KH);
YH_1BH  = sLH*YH*(LH_1BH/LH) + (1-sLH)*YH*( (KH_1BH/KH) + (1/BH) );
YH_1AN  = sLH*YH*(LH_1AN/LH) + (1-sLH)*YH*(KH_1AN/KH);
YH_1BN  = sLH*YH*(LH_1BN/LH) + (1-sLH)*YH*(KH_1BN/KH);

YN_1PN  = sLN*YN*(LN_2PN/LN) + (1-sLN)*YN*(KN_1PN/KN);
YN_1PH  = sLN*YN*(LN_2PH/LN) + (1-sLN)*YN*(KN_1PH/KN);
YN_1K   = sLN*YN*(LN_1K/LN) + (1-sLN)*YN*(KN_2K/KN);
YN_uKSH = sLN*YN*(LN_uKSH/LN) + (1-sLN)*YN*(KN_uKSH/KN);
YN_uKDH = sLN*YN*(LN_uKDH/LN) + (1-sLN)*YN*(KN_uKDH/KN);
YN_uKSN = sLN*YN*(LN_uKSN/LN) + (1-sLN)*YN*( (KN_uKSN/KN) + eta);
YN_uKDN = sLN*YN*(LN_uKDN/LN) + (1-sLN)*YN*( (KN_uKDN/KN) + (1-eta) );
YN_1AH  = sLN*YN*(LN_1AH/LN) + (1-sLN)*YN*(KN_1AH/KN);
YN_1BH  = sLN*YN*(LN_1BH/LN) + (1-sLN)*YN*(KN_1BH/KN);
YN_1AN  = sLN*YN*( (LN_1AN/LN) + (1/AN) ) + (1-sLN)*YN*(KN_1AN/KN);
YN_1BN  = sLN*YN*(LN_1BN/LN) + (1-sLN)*YN*( (KN_1BN/KN) + (1/BN) );

% Intermediate solution for CN, CH, CF - Cj=Cj(PN,PH,K,uKSj,uKDj,Aj,Bj)
CN_2PN  = CN_1PN + (CN_WH*WH_1PN) + (CN_WN*WN_1PN);
CN_2PH  = CN_1PH + (CN_WH*WH_1PH) + (CN_WN*WN_1PH);
CN_1K   = (CN_WH*WH_1K) + (CN_WN*WN_1K);
CN_uKSH = (CN_WH*WH_uKSH) + (CN_WN*WN_uKSH);
CN_uKDH = (CN_WH*WH_uKDH) + (CN_WN*WN_uKDH);
CN_uKSN = (CN_WH*WH_uKSN) + (CN_WN*WN_uKSN);
CN_uKDN = (CN_WH*WH_uKDN) + (CN_WN*WN_uKDN);
CN_1AH  = (CN_WH*WH_1AH) + (CN_WN*WN_1AH);
CN_1BH  = (CN_WH*WH_1BH) + (CN_WN*WN_1BH);
CN_1AN  = (CN_WH*WH_1AN) + (CN_WN*WN_1AN);
CN_1BN  = (CN_WH*WH_1BN) + (CN_WN*WN_1BN);

CH_2PN  = CH_1PN + (CH_WH*WH_1PN) + (CH_WN*WN_1PN);
CH_2PH  = CH_1PH + (CH_WH*WH_1PH) + (CH_WN*WN_1PH);
CH_1K   = (CH_WH*WH_1K) + (CH_WN*WN_1K);
CH_uKSH = (CH_WH*WH_uKSH) + (CH_WN*WN_uKSH);
CH_uKDH = (CH_WH*WH_uKDH) + (CH_WN*WN_uKDH);
CH_uKSN = (CH_WH*WH_uKSN) + (CH_WN*WN_uKSN);
CH_uKDN = (CH_WH*WH_uKDN) + (CH_WN*WN_uKDN);
CH_1AH  = (CH_WH*WH_1AH) + (CH_WN*WN_1AH);
CH_1BH  = (CH_WH*WH_1BH) + (CH_WN*WN_1BH);
CH_1AN  = (CH_WH*WH_1AN) + (CH_WN*WN_1AN);
CH_1BN  = (CH_WH*WH_1BN) + (CH_WN*WN_1BN);

CF_2PN  = CF_1PN + (CF_WH*WH_1PN) + (CF_WN*WN_1PN);
CF_2PH  = CF_1PH + (CF_WH*WH_1PH) + (CF_WN*WN_1PH);
CF_1K   = (CF_WH*WH_1K) + (CF_WN*WN_1K);
CF_uKSH = (CF_WH*WH_uKSH) + (CF_WN*WN_uKSH);
CF_uKDH = (CF_WH*WH_uKDH) + (CF_WN*WN_uKDH);
CF_uKSN = (CF_WH*WH_uKSN) + (CF_WN*WN_uKSN);
CF_uKDN = (CF_WH*WH_uKDN) + (CF_WN*WN_uKDN);
CF_1AH  = (CF_WH*WH_1AH) + (CF_WN*WN_1AH);
CF_1BH  = (CF_WH*WH_1BH) + (CF_WN*WN_1BH);
CF_1AN  = (CF_WH*WH_1AN) + (CF_WN*WN_1AN);
CF_1BN  = (CF_WH*WH_1BN) + (CF_WN*WN_1BN);

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_1K  = deltaK; 
J_1Q  = K*v_1Q; 
J_PN  = K*v_PN; 
J_PH  = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I      = deltaK*K; 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_1K; 
JN_1Q  = (IN/I)*J_1Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_1K; 
JH_1Q  = (IH/I)*J_1Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_1K; 
JF_1Q  = (IF/I)*J_1Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKSj,uKDj(PN,PH,K)
f11 = ((xi2SH/xi1SH) + (1-eta) + eta*(sLH/sigmaH)) - (sLH/sigmaH)*(LH_uKSH/LH) + (sLH/sigmaH)*(KH_uKSH/KH); % uKSH
f12 = -((sigmaH-sLH)/sigmaH)*(1-eta) - (sLH/sigmaH)*(LH_uKDH/LH) + (sLH/sigmaH)*(KH_uKDH/KH); % uKDH
f13 = - (sLH/sigmaH)*(LH_uKSN/LH) + (sLH/sigmaH)*(KH_uKSN/KH); % uKSN
f14 = - (sLH/sigmaH)*(LH_uKDN/LH) + (sLH/sigmaH)*(KH_uKDN/KH); % uKDN

f21 = -((sigmaH-sLH)/sigmaH)*eta - (sLH/sigmaH)*(LH_uKSH/LH) + (sLH/sigmaH)*(KH_uKSH/KH); % uKSH
%f22 = ((xi2DH/xi1DH) + eta + (1-eta)*(sLH/sigmaH)) + (sLH/sigmaH)*(KH_uKDH/KH); %uKDH
f22 = ((xi2DH/xi1DH) + eta + (1-eta)*(sLH/sigmaH)) - (sLH/sigmaH)*(LH_uKDH/LH) + (sLH/sigmaH)*(KH_uKDH/KH); %uKDH 
f23 = - (sLH/sigmaH)*(LH_uKSN/LH) + (sLH/sigmaH)*(KH_uKSN/KH); % uKSN
f24 = - (sLH/sigmaH)*(LH_uKDN/LH) + (sLH/sigmaH)*(KH_uKDN/KH); % uKDN

f31 =  - (sLN/sigmaN)*(LN_uKSH/LN) + (sLN/sigmaN)*(KN_uKSH/KN); %uKSH
f32 =  - (sLN/sigmaN)*(LN_uKDH/LN) + (sLN/sigmaN)*(KN_uKDH/KN); %uKDH
f33 = ((xi2SN/xi1SN) + (1-eta) + eta*(sLN/sigmaN))  - (sLN/sigmaN)*(LN_uKSN/LN) + (sLN/sigmaN)*(KN_uKSN/KN); %uKSN
f34 = -((sigmaN-sLN)/sigmaN)*(1-eta)  - (sLN/sigmaN)*(LN_uKDN/LN) + (sLN/sigmaN)*(KN_uKDN/KN); %uKDN

f41 = - (sLN/sigmaN)*(LN_uKSH/LN) + (sLN/sigmaN)*(KN_uKSH/KN); %uKSH
f42 = - (sLN/sigmaN)*(LN_uKDH/LN) + (sLN/sigmaN)*(KN_uKDH/KN); %uKDH
f43 = -((sigmaN-sLN)/sigmaN)*eta  - (sLN/sigmaN)*(LN_uKSN/LN) + (sLN/sigmaN)*(KN_uKSN/KN); %uKSN
f44 = ((xi2DN/xi1DN) + eta + (1-eta)*(sLN/sigmaN)) - (sLN/sigmaN)*(LN_uKDN/LN) + (sLN/sigmaN)*(KN_uKDN/KN); %uKDN

% PN, PH, K, AH, BH, AN, BN, lambda
g11 = (sLH/sigmaH)*(LH_2PN/LH) - (sLH/sigmaH)*(KH_1PN/KH); % PN
g12 = (sLH/sigmaH)*(LH_2PH/LH) - (sLH/sigmaH)*(KH_1PH/KH); % PH
g13 = (sLH/sigmaH)*(LH_1K/LH) - (sLH/sigmaH)*(KH_2K/KH); % K
g14 = (sLH/sigmaH)*( (LH_1AH/LH) + (1/AH) ) - (sLH/sigmaH)*(KH_1AH/KH); % AH
g15 = (sLH/sigmaH)*(LH_1BH/LH) - (sLH/sigmaH)*(KH_1BH/KH) + ((sigmaH-sLH)/sigmaH)*(1/BH); % BH
g16 = (sLH/sigmaH)*(LH_1AN/LH) - (sLH/sigmaH)*(KH_1AN/KH); % AN
g17 = (sLH/sigmaH)*(LH_1BN/LH) - (sLH/sigmaH)*(KH_1BN/KH); % BN

g21 = (sLH/sigmaH)*(LH_2PN/LH) - (sLH/sigmaH)*(KH_1PN/KH); % PN
g22 = (sLH/sigmaH)*(LH_2PH/LH) - (sLH/sigmaH)*(KH_1PH/KH); % PH
g23 = (sLH/sigmaH)*(LH_1K/LH) - (sLH/sigmaH)*(KH_2K/KH); % K
g24 = (sLH/sigmaH)*( (LH_1AH/LH) + (1/AH) ) - (sLH/sigmaH)*(KH_1AH/KH); % AH
g25 = (sLH/sigmaH)*(LH_1BH/LH) - (sLH/sigmaH)*(KH_1BH/KH) + ((sigmaH-sLH)/sigmaH)*(1/BH); % BH
g26 = (sLH/sigmaH)*(LH_1AN/LH) - (sLH/sigmaH)*(KH_1AN/KH); % AN
g27 = (sLH/sigmaH)*(LH_1BN/LH) - (sLH/sigmaH)*(KH_1BN/KH); % BN

g31 = (sLN/sigmaN)*(LN_2PN/LN) - (sLN/sigmaN)*(KN_1PN/KN); % PN
g32 = (sLN/sigmaN)*(LN_2PH/LN) - (sLN/sigmaN)*(KN_1PH/KN); % PH
g33 = (sLN/sigmaN)*(LN_1K/LN) - (sLN/sigmaN)*(KN_2K/KN); % K
g34 = (sLN/sigmaN)*(LN_1AH/LN) - (sLN/sigmaN)*(KN_1AH/KN); % AH
g35 = (sLN/sigmaN)*(LN_1BH/LN) - (sLN/sigmaN)*(KN_1BH/KN); % BH
g36 = (sLN/sigmaN)*( (LN_1AN/LN) + (1/AN) ) - (sLN/sigmaN)*(KN_1AN/KN); % AN
g37 = (sLN/sigmaN)*(LN_1BN/LN) - (sLN/sigmaN)*(KN_1BN/KN) + ((sigmaN-sLN)/sigmaN)*(1/BN); % BN

g41 = (sLN/sigmaN)*(LN_2PN/LN) - (sLN/sigmaN)*(KN_1PN/KN); % PN
g42 = (sLN/sigmaN)*(LN_2PH/LN) - (sLN/sigmaN)*(KN_1PH/KN); % PH
g43 = (sLN/sigmaN)*(LN_1K/LN) - (sLN/sigmaN)*(KN_2K/KN); % K
g44 = (sLN/sigmaN)*(LN_1AH/LN) - (sLN/sigmaN)*(KN_1AH/KN); % AH
g45 = (sLN/sigmaN)*(LN_1BH/LN) - (sLN/sigmaN)*(KN_1BH/KN); % BH
g46 = (sLN/sigmaN)*( (LN_1AN/LN) + (1/AN) ) - (sLN/sigmaN)*(KN_1AN/KN); % AN
g47 = (sLN/sigmaN)*(LN_1BN/LN) - (sLN/sigmaN)*(KN_1BN/KN) + ((sigmaN-sLN)/sigmaN)*(1/BN); % BN

M3 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X3 = [g11 g12 g13 g14 g15 g16 g17; g21 g22 g23 g24 g25 g26 g27; g31 g32 g33 g34 g35 g36 g37; g41 g42 g43 g44 g45 g46 g47];
JST3 = inv(M3);
MST3 = JST3*X3;

uKSH_PN = MST3(1,1); uKSH_PH = MST3(1,2); uKSH_1K = MST3(1,3); uKSH_1AH = MST3(1,4); uKSH_1BH = MST3(1,5); uKSH_1AN = MST3(1,6); uKSH_1BN = MST3(1,7);
uKDH_PN = MST3(2,1); uKDH_PH = MST3(2,2); uKDH_1K = MST3(2,3); uKDH_1AH = MST3(2,4); uKDH_1BH = MST3(2,5); uKDH_1AN = MST3(2,6); uKDH_1BN = MST3(2,7);
uKSN_PN = MST3(3,1); uKSN_PH = MST3(3,2); uKSN_1K = MST3(3,3); uKSN_1AH = MST3(3,4); uKSN_1BH = MST3(3,5); uKSN_1AN = MST3(3,6); uKSN_1BN = MST3(3,7);
uKDN_PN = MST3(4,1); uKDN_PH = MST3(4,2); uKDN_1K = MST3(4,3); uKDN_1AH = MST3(4,4); uKDN_1BH = MST3(4,5); uKDN_1AN = MST3(4,6); uKDN_1BN = MST3(4,7);

% Solving for Wj,Rj,Lj,Kj,Yj,Cg(lambda,K,PH,PN,AH,BH,AN,BN)
WH_2K = WH_1K + (WH_uKSH*uKSH_1K) + (WH_uKDH*uKDH_1K) + (WH_uKSN*uKSN_1K) + (WH_uKDN*uKDN_1K);
WH_PH = WH_1PH + (WH_uKSH*uKSH_PH) +  (WH_uKDH*uKDH_PH) + (WH_uKSN*uKSN_PH) + (WH_uKDN*uKDN_PH);
WH_PN = WH_1PN + (WH_uKSH*uKSH_PN) + (WH_uKDH*uKDH_PN) + (WH_uKSN*uKSN_PN) + (WH_uKDN*uKDN_PN);
WH_2AH = WH_1AH + (WH_uKSH*uKSH_1AH) + (WH_uKDH*uKDH_1AH) + (WH_uKSN*uKSN_1AH) + (WH_uKDN*uKDN_1AH);
WH_2BH = WH_1BH + (WH_uKSH*uKSH_1BH) + (WH_uKDH*uKDH_1BH) + (WH_uKSN*uKSN_1BH) + (WH_uKDN*uKDN_1BH);
WH_2AN = WH_1AN + (WH_uKSH*uKSH_1AN) + (WH_uKDH*uKDH_1AN) + (WH_uKSN*uKSN_1AN) + (WH_uKDN*uKDN_1AN);
WH_2BN = WH_1BN + (WH_uKSH*uKSH_1BN) + (WH_uKDH*uKDH_1BN) + (WH_uKSN*uKSN_1BN) + (WH_uKDN*uKDN_1BN);

WN_2K = WN_1K + (WN_uKSH*uKSH_1K) +  (WN_uKDH*uKDH_1K) + (WN_uKSN*uKSN_1K) + (WN_uKDN*uKDN_1K);
WN_PH = WN_1PH + (WN_uKSH*uKSH_PH) + (WN_uKDH*uKDH_PH) + (WN_uKSN*uKSN_PH) + (WN_uKDN*uKDN_PH);
WN_PN = WN_1PN + (WN_uKSH*uKSH_PN) + (WN_uKDH*uKDH_PN) + (WN_uKSN*uKSN_PN) + (WN_uKDN*uKDN_PN);
WN_2AH = WN_1AH + (WN_uKSH*uKSH_1AH) + (WN_uKDH*uKDH_1AH) + (WN_uKSN*uKSN_1AH) + (WN_uKDN*uKDN_1AH);
WN_2BH = WN_1BH + (WN_uKSH*uKSH_1BH) + (WN_uKDH*uKDH_1BH) + (WN_uKSN*uKSN_1BH) + (WN_uKDN*uKDN_1BH);
WN_2AN = WN_1AN + (WN_uKSH*uKSH_1AN) + (WN_uKDH*uKDH_1AN) + (WN_uKSN*uKSN_1AN) + (WN_uKDN*uKDN_1AN);
WN_2BN = WN_1BN + (WN_uKSH*uKSH_1BN) + (WN_uKDH*uKDH_1BN) + (WN_uKSN*uKSN_1BN) + (WN_uKDN*uKDN_1BN);

RH_2K = RH_1K + (RH_uKSH*uKSH_1K) + (RH_uKDH*uKDH_1K) + (RH_uKSN*uKSN_1K) + (RH_uKDN*uKDN_1K);
RH_PH = RH_1PH + (RH_uKSH*uKSH_PH) +  (RH_uKDH*uKDH_PH) + (RH_uKSN*uKSN_PH) + (RH_uKDN*uKDN_PH);
RH_PN = RH_1PN + (RH_uKSH*uKSH_PN) + (RH_uKDH*uKDH_PN) + (RH_uKSN*uKSN_PN) + (RH_uKDN*uKDN_PN);
RH_2AH = RH_1AH + (RH_uKSH*uKSH_1AH) + (RH_uKDH*uKDH_1AH) + (RH_uKSN*uKSN_1AH) + (RH_uKDN*uKDN_1AH);
RH_2BH = RH_1BH + (RH_uKSH*uKSH_1BH) + (RH_uKDH*uKDH_1BH) + (RH_uKSN*uKSN_1BH) + (RH_uKDN*uKDN_1BH);
RH_2AN = RH_1AN + (RH_uKSH*uKSH_1AN) + (RH_uKDH*uKDH_1AN) + (RH_uKSN*uKSN_1AN) + (RH_uKDN*uKDN_1AN);
RH_2BN = RH_1BN + (RH_uKSH*uKSH_1BN) + (RH_uKDH*uKDH_1BN) + (RH_uKSN*uKSN_1BN) + (RH_uKDN*uKDN_1BN);

RN_2K = RN_1K + (RN_uKSH*uKSH_1K) +  (RN_uKDH*uKDH_1K) + (RN_uKSN*uKSN_1K) + (RN_uKDN*uKDN_1K);
RN_PH = RN_1PH + (RN_uKSH*uKSH_PH) + (RN_uKDH*uKDH_PH) + (RN_uKSN*uKSN_PH) + (RN_uKDN*uKDN_PH);
RN_PN = RN_1PN + (RN_uKSH*uKSH_PN) + (RN_uKDH*uKDH_PN) + (RN_uKSN*uKSN_PN) + (RN_uKDN*uKDN_PN);
RN_2AH = RN_1AH + (RN_uKSH*uKSH_1AH) + (RN_uKDH*uKDH_1AH) + (RN_uKSN*uKSN_1AH) + (RN_uKDN*uKDN_1AH);
RN_2BH = RN_1BH + (RN_uKSH*uKSH_1BH) + (RN_uKDH*uKDH_1BH) + (RN_uKSN*uKSN_1BH) + (RN_uKDN*uKDN_1BH);
RN_2AN = RN_1AN + (RN_uKSH*uKSH_1AN) + (RN_uKDH*uKDH_1AN) + (RN_uKSN*uKSN_1AN) + (RN_uKDN*uKDN_1AN);
RN_2BN = RN_1BN + (RN_uKSH*uKSH_1BN) + (RN_uKDH*uKDH_1BN) + (RN_uKSN*uKSN_1BN) + (RN_uKDN*uKDN_1BN);

LH_2K = LH_1K + (LH_uKSH*uKSH_1K) + (LH_uKDH*uKDH_1K) + (LH_uKSN*uKSN_1K) + (LH_uKDN*uKDN_1K);
LH_PH = LH_2PH + (LH_uKSH*uKSH_PH) + (LH_uKDH*uKDH_PH) + (LH_uKSN*uKSN_PH) + (LH_uKDN*uKDN_PH);
LH_PN = LH_2PN + (LH_uKSH*uKSH_PN) + (LH_uKDH*uKDH_PN) + (LH_uKSN*uKSN_PN) + (LH_uKDN*uKDN_PN);
LH_2AH = LH_1AH + (LH_uKSH*uKSH_1AH) + (LH_uKDH*uKDH_1AH) + (LH_uKSN*uKSN_1AH) + (LH_uKDN*uKDN_1AH);
LH_2BH = LH_1BH + (LH_uKSH*uKSH_1BH) + (LH_uKDH*uKDH_1BH) + (LH_uKSN*uKSN_1BH) + (LH_uKDN*uKDN_1BH);
LH_2AN = LH_1AN + (LH_uKSH*uKSH_1AN) + (LH_uKDH*uKDH_1AN) + (LH_uKSN*uKSN_1AN) + (LH_uKDN*uKDN_1AN);
LH_2BN = LH_1BN + (LH_uKSH*uKSH_1BN) + (LH_uKDH*uKDH_1BN) + (LH_uKSN*uKSN_1BN) + (LH_uKDN*uKDN_1BN);

LN_2K = LN_1K + (LN_uKSH*uKSH_1K) + (LN_uKDH*uKDH_1K) + (LN_uKSN*uKSN_1K) + (LN_uKDN*uKDN_1K);
LN_PH = LN_2PH + (LN_uKSH*uKSH_PH) + (LN_uKDH*uKDH_PH) + (LN_uKSN*uKSN_PH) + (LN_uKDN*uKDN_PH);
LN_PN = LN_2PN + (LN_uKSH*uKSH_PN) + (LN_uKDH*uKDH_PN) + (LN_uKSN*uKSN_PN) + (LN_uKDN*uKDN_PN);
LN_2AH = LN_1AH + (LN_uKSH*uKSH_1AH) + (LN_uKDH*uKDH_1AH) + (LN_uKSN*uKSN_1AH) + (LN_uKDN*uKDN_1AH);
LN_2BH = LN_1BH + (LN_uKSH*uKSH_1BH) + (LN_uKDH*uKDH_1BH) + (LN_uKSN*uKSN_1BH) + (LN_uKDN*uKDN_1BH);
LN_2AN = LN_1AN + (LN_uKSH*uKSH_1AN) + (LN_uKDH*uKDH_1AN) + (LN_uKSN*uKSN_1AN) + (LN_uKDN*uKDN_1AN);
LN_2BN = LN_1BN + (LN_uKSH*uKSH_1BN) + (LN_uKDH*uKDH_1BN) + (LN_uKSN*uKSN_1BN) + (LN_uKDN*uKDN_1BN);

KH_3K = KH_2K + (KH_uKSH*uKSH_1K) + (KH_uKDH*uKDH_1K) + (KH_uKSN*uKSN_1K) + (KH_uKDN*uKDN_1K);
KH_PH = KH_1PH + (KH_uKSH*uKSH_PH) + (KH_uKDH*uKDH_PH) + (KH_uKSN*uKSN_PH) + (KH_uKDN*uKDN_PH);
KH_PN = KH_1PN + (KH_uKSH*uKSH_PN) + (KH_uKDH*uKDH_PN) + (KH_uKSN*uKSN_PN) + (KH_uKDN*uKDN_PN);
KH_2AH = KH_1AH + (KH_uKSH*uKSH_1AH) + (KH_uKDH*uKDH_1AH) + (KH_uKSN*uKSN_1AH) + (KH_uKDN*uKDN_1AH);
KH_2BH = KH_1BH + (KH_uKSH*uKSH_1BH) + (KH_uKDH*uKDH_1BH) + (KH_uKSN*uKSN_1BH) + (KH_uKDN*uKDN_1BH);
KH_2AN = KH_1AN + (KH_uKSH*uKSH_1AN) + (KH_uKDH*uKDH_1AN) + (KH_uKSN*uKSN_1AN) + (KH_uKDN*uKDN_1AN);
KH_2BN = KH_1BN + (KH_uKSH*uKSH_1BN) + (KH_uKDH*uKDH_1BN) + (KH_uKSN*uKSN_1BN) + (KH_uKDN*uKDN_1BN);

KN_3K = KN_2K + (KN_uKSH*uKSH_1K) + (KN_uKDH*uKDH_1K) + (KN_uKSN*uKSN_1K) + (KN_uKDN*uKDN_1K);
KN_PH = KN_1PH + (KN_uKSH*uKSH_PH) + (KN_uKDH*uKDH_PH) + (KN_uKSN*uKSN_PH) + (KN_uKDN*uKDN_PH);
KN_PN = KN_1PN + (KN_uKSH*uKSH_PN) + (KN_uKDH*uKDH_PN) + (KN_uKSN*uKSN_PN) + (KN_uKDN*uKDN_PN);
KN_2AH = KN_1AH + (KN_uKSH*uKSH_1AH) + (KN_uKDH*uKDH_1AH) + (KN_uKSN*uKSN_1AH) + (KN_uKDN*uKDN_1AH);
KN_2BH = KN_1BH + (KN_uKSH*uKSH_1BH) + (KN_uKDH*uKDH_1BH) + (KN_uKSN*uKSN_1BH) + (KN_uKDN*uKDN_1BH);
KN_2AN = KN_1AN + (KN_uKSH*uKSH_1AN) + (KN_uKDH*uKDH_1AN) + (KN_uKSN*uKSN_1AN) + (KN_uKDN*uKDN_1AN);
KN_2BN = KN_1BN + (KN_uKSH*uKSH_1BN) + (KN_uKDH*uKDH_1BN) + (KN_uKSN*uKSN_1BN) + (KN_uKDN*uKDN_1BN);

YH_2K  = YH_1K + (YH_uKSH*uKSH_1K) + (YH_uKDH*uKDH_1K) + (YH_uKSN*uKSN_1K) + (YH_uKDN*uKDN_1K);
YH_PH  = YH_1PH + (YH_uKSH*uKSH_PH) + (YH_uKDH*uKDH_PH) + (YH_uKSN*uKSN_PH) + (YH_uKDN*uKDN_PH);
YH_PN  = YH_1PN + (YH_uKSH*uKSH_PN) + (YH_uKDH*uKDH_PN) + (YH_uKSN*uKSN_PN) + (YH_uKDN*uKDN_PN);
YH_2AH = YH_1AH + (YH_uKSH*uKSH_1AH) + (YH_uKDH*uKDH_1AH) + (YH_uKSN*uKSN_1AH) + (YH_uKDN*uKDN_1AH);
YH_2BH = YH_1BH + (YH_uKSH*uKSH_1BH) + (YH_uKDH*uKDH_1BH) + (YH_uKSN*uKSN_1BH) + (YH_uKDN*uKDN_1BH);
YH_2AN = YH_1AN + (YH_uKSH*uKSH_1AN) + (YH_uKDH*uKDH_1AN) + (YH_uKSN*uKSN_1AN) + (YH_uKDN*uKDN_1AN);
YH_2BN = YH_1BN + (YH_uKSH*uKSH_1BN) + (YH_uKDH*uKDH_1BN) + (YH_uKSN*uKSN_1BN) + (YH_uKDN*uKDN_1BN);

YN_2K  = YN_1K + (YN_uKSH*uKSH_1K) + (YN_uKDH*uKDH_1K) + (YN_uKSN*uKSN_1K) + (YN_uKDN*uKDN_1K);
YN_PH  = YN_1PH + (YN_uKSH*uKSH_PH) + (YN_uKDH*uKDH_PH) + (YN_uKSN*uKSN_PH) + (YN_uKDN*uKDN_PH);
YN_PN  = YN_1PN + (YN_uKSH*uKSH_PN) + (YN_uKDH*uKDH_PN) + (YN_uKSN*uKSN_PN) + (YN_uKDN*uKDN_PN);
YN_2AH = YN_1AH + (YN_uKSH*uKSH_1AH) + (YN_uKDH*uKDH_1AH) + (YN_uKSN*uKSN_1AH) + (YN_uKDN*uKDN_1AH);
YN_2BH = YN_1BH + (YN_uKSH*uKSH_1BH) + (YN_uKDH*uKDH_1BH) + (YN_uKSN*uKSN_1BH) + (YN_uKDN*uKDN_1BH);
YN_2AN = YN_1AN + (YN_uKSH*uKSH_1AN) + (YN_uKDH*uKDH_1AN) + (YN_uKSN*uKSN_1AN) + (YN_uKDN*uKDN_1AN);
YN_2BN = YN_1BN + (YN_uKSH*uKSH_1BN) + (YN_uKDH*uKDH_1BN) + (YN_uKSN*uKSN_1BN) + (YN_uKDN*uKDN_1BN);

CH_2K = CH_1K + (CH_uKSH*uKSH_1K) + (CH_uKDH*uKDH_1K) + (CH_uKSN*uKSN_1K) + (CH_uKDN*uKDN_1K);
CH_PH = CH_2PH + (CH_uKSH*uKSH_PH) + (CH_uKDH*uKDH_PH) + (CH_uKSN*uKSN_PH) + (CH_uKDN*uKDN_PH);
CH_PN = CH_2PN + (CH_uKSH*uKSH_PN) + (CH_uKDH*uKDH_PN) + (CH_uKSN*uKSN_PN) + (CH_uKDN*uKDN_PN);
CH_2AH = CH_1AH + (CH_uKSH*uKSH_1AH) + (CH_uKDH*uKDH_1AH) + (CH_uKSN*uKSN_1AH) + (CH_uKDN*uKDN_1AH);
CH_2BH = CH_1BH + (CH_uKSH*uKSH_1BH) + (CH_uKDH*uKDH_1BH) + (CH_uKSN*uKSN_1BH) + (CH_uKDN*uKDN_1BH);
CH_2AN = CH_1AN + (CH_uKSH*uKSH_1AN) + (CH_uKDH*uKDH_1AN) + (CH_uKSN*uKSN_1AN) + (CH_uKDN*uKDN_1AN);
CH_2BN = CH_1BN + (CH_uKSH*uKSH_1BN) + (CH_uKDH*uKDH_1BN) + (CH_uKSN*uKSN_1BN) + (CH_uKDN*uKDN_1BN);

CN_2K = CN_1K + (CN_uKSH*uKSH_1K) + (CN_uKDH*uKDH_1K) + (CN_uKSN*uKSN_1K) + (CN_uKDN*uKDN_1K);
CN_PH = CN_2PH + (CN_uKSH*uKSH_PH) + (CN_uKDH*uKDH_PH) + (CN_uKSN*uKSN_PH) + (CN_uKDN*uKDN_PH);
CN_PN = CN_2PN + (CN_uKSH*uKSH_PN) + (CN_uKDH*uKDH_PN) + (CN_uKSN*uKSN_PN) + (CN_uKDN*uKDN_PN);
CN_2AH = CN_1AH + (CN_uKSH*uKSH_1AH) + (CN_uKDH*uKDH_1AH) + (CN_uKSN*uKSN_1AH) + (CN_uKDN*uKDN_1AH);
CN_2BH = CN_1BH + (CN_uKSH*uKSH_1BH) + (CN_uKDH*uKDH_1BH) + (CN_uKSN*uKSN_1BH) + (CN_uKDN*uKDN_1BH);
CN_2AN = CN_1AN + (CN_uKSH*uKSH_1AN) + (CN_uKDH*uKDH_1AN) + (CN_uKSN*uKSN_1AN) + (CN_uKDN*uKDN_1AN);
CN_2BN = CN_1BN + (CN_uKSH*uKSH_1BN) + (CN_uKDH*uKDH_1BN) + (CN_uKSN*uKSN_1BN) + (CN_uKDN*uKDN_1BN);

CF_2K = CF_1K + (CF_uKSH*uKSH_1K) + (CF_uKDH*uKDH_1K) + (CF_uKSN*uKSN_1K) + (CF_uKDN*uKDN_1K);
CF_PH = CF_2PH + (CF_uKSH*uKSH_PH) + (CF_uKDH*uKDH_PH) + (CF_uKSN*uKSN_PH) + (CF_uKDN*uKDN_PH);
CF_PN = CF_2PN + (CF_uKSH*uKSH_PN) + (CF_uKDH*uKDH_PN) + (CF_uKSN*uKSN_PN) + (CF_uKDN*uKDN_PN);
CF_2AH = CF_1AH + (CF_uKSH*uKSH_1AH) + (CF_uKDH*uKDH_1AH) + (CF_uKSN*uKSN_1AH) + (CF_uKDN*uKDN_1AH);
CF_2BH = CF_1BH + (CF_uKSH*uKSH_1BH) + (CF_uKDH*uKDH_1BH) + (CF_uKSN*uKSN_1BH) + (CF_uKDN*uKDN_1BH);
CF_2AN = CF_1AN + (CF_uKSH*uKSH_1AN) + (CF_uKDH*uKDH_1AN) + (CF_uKSN*uKSN_1AN) + (CF_uKDN*uKDN_1AN);
CF_2BN = CF_1BN + (CF_uKSH*uKSH_1BN) + (CF_uKDH*uKDH_1BN) + (CF_uKSN*uKSN_1BN) + (CF_uKDN*uKDN_1BN);

% Partial Derivatives Gj=Gj(G) 
GN_G   = omegaGN/PN; 
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,lambda)
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1SN*uKSN_PH) - (KN*xi1DN*uKDN_PH); % PH
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1SN*uKSN_PN) - (KN*xi1DN*uKDN_PN); % PN
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1SH*uKSH_PH) - (KH*xi1DH*uKDH_PH); % PH
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1SH*uKSH_PN) - (KH*xi1DH*uKDH_PN); % PN

% K,Q,G,AH,BH,AN,BN,lambda
k11 = -(YN_2K - CN_2K - JN_1K - (KN*xi1SN*uKSN_1K) - (KN*xi1DN*uKDN_1K));
k12 = JN_1Q;
k13 = GN_G;
k14 = -(YN_2AH - CN_2AH - (KN*xi1SN*uKSN_1AH) - (KN*xi1DN*uKDN_1AH));
k15 = -(YN_2BH - CN_2BH - (KN*xi1SN*uKSN_1BH) - (KN*xi1DN*uKDN_1BH));
k16 = -(YN_2AN - CN_2AN - (KN*xi1SN*uKSN_1AN) - (KN*xi1DN*uKDN_1AN));
k17 = -(YN_2BN - CN_2BN - (KN*xi1SN*uKSN_1BN) - (KN*xi1DN*uKDN_1BN));

k21 = -(YH_2K - CH_2K - JH_1K - (KH*xi1SH*uKSH_1K) - (KH*xi1DH*uKDH_1K));
k22 = JH_1Q;
k23 = GH_G;
k24 = -(YH_2AH - CH_2AH - (KH*xi1SH*uKSH_1AH) - (KH*xi1DH*uKDH_1AH));
k25 = -(YH_2BH - CH_2BH - (KH*xi1SH*uKSH_1BH) - (KH*xi1DH*uKDH_1BH));
k26 = -(YH_2AN - CH_2AN - (KH*xi1SH*uKSH_1AN) - (KH*xi1DH*uKDH_1AN));
k27 = -(YH_2BN - CH_2BN - (KH*xi1SH*uKSH_1BN) - (KH*xi1DH*uKDH_1BN));

M4 = [h11 h12; h21 h22];
X4 = [k11 k12 k13 k14 k15 k16 k17; k21 k22 k23 k24 k25 k26 k27];
JST4 = inv(M4);
MST4 = JST4*X4;

PH_K = MST4(1,1); PH_Q = MST4(1,2); PH_G = MST4(1,3); PH_AH = MST4(1,4); PH_BH = MST4(1,5); PH_AN = MST4(1,6); PH_BN = MST4(1,7);
PN_K = MST4(2,1); PN_Q = MST4(2,2); PN_G = MST4(2,3); PN_AH = MST4(2,4); PN_BH = MST4(2,5); PN_AN = MST4(2,6); PN_BN = MST4(2,7);

% Solving for Lj,Kj,Yj,uKj(K,Q,G,Aj,Bj) - Final Solutions
LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K);
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q);
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);
LH_AH = LH_2AH + (LH_PH*PH_AH) + (LH_PN*PN_AH);
LH_BH = LH_2BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_2AN + (LH_PH*PH_AN) + (LH_PN*PN_AN);
LH_BN = LH_2BN + (LH_PH*PH_BN) + (LH_PN*PN_BN);

LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G);
LN_AH = LN_2AH + (LN_PH*PH_AH) + (LN_PN*PN_AH);
LN_BH = LN_2BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_2AN + (LN_PH*PH_AN) + (LN_PN*PN_AN);
LN_BN = LN_2BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);

YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K);
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q);
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);
YH_AH = YH_2AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_2BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_2AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_2BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);

YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);
YN_AH = YN_2AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_2BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_2AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_2BN + (YN_PH*PH_BN) + (YN_PN*PN_BN);

KH_K  = KH_3K + (KH_PH*PH_K) + (KH_PN*PN_K);
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);
KH_AH = KH_2AH + (KH_PH*PH_AH) + (KH_PN*PN_AH);
KH_BH = KH_2BH + (KH_PH*PH_BH) + (KH_PN*PN_BH);
KH_AN = KH_2AN + (KH_PH*PH_AN) + (KH_PN*PN_AN);
KH_BN = KH_2BN + (KH_PH*PH_BN) + (KH_PN*PN_BN);

KN_K = KN_3K + (KN_PH*PH_K) + (KN_PN*PN_K);
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);
KN_AH = KN_2AH + (KN_PH*PH_AH) + (KN_PN*PN_AH);
KN_BH = KN_2BH + (KN_PH*PH_BH) + (KN_PN*PN_BH);
KN_AN = KN_2AN + (KN_PH*PH_AN) + (KN_PN*PN_AN);
KN_BN = KN_2BN + (KN_PH*PH_BN) + (KN_PN*PN_BN);

uKSH_K  = uKSH_1K + (uKSH_PH*PH_K) + (uKSH_PN*PN_K);      
uKSH_Q  = (uKSH_PH*PH_Q) + (uKSH_PN*PN_Q);                
uKSH_G  = (uKSH_PH*PH_G) + (uKSH_PN*PN_G);                
uKSH_AH = uKSH_1AH + (uKSH_PH*PH_AH) + (uKSH_PN*PN_AH);   
uKSH_BH = uKSH_1BH + (uKSH_PH*PH_BH) + (uKSH_PN*PN_BH);   
uKSH_AN = uKSH_1AN + (uKSH_PH*PH_AN) + (uKSH_PN*PN_AN);   
uKSH_BN = uKSH_1BN + (uKSH_PH*PH_BN) + (uKSH_PN*PN_BN);   
                                                          
uKDH_K  = uKDH_1K + (uKDH_PH*PH_K) + (uKDH_PN*PN_K);      
uKDH_Q  = (uKDH_PH*PH_Q) + (uKDH_PN*PN_Q);                
uKDH_G  = (uKDH_PH*PH_G) + (uKDH_PN*PN_G);                
uKDH_AH = uKDH_1AH + (uKDH_PH*PH_AH) + (uKDH_PN*PN_AH);   
uKDH_BH = uKDH_1BH + (uKDH_PH*PH_BH) + (uKDH_PN*PN_BH);   
uKDH_AN = uKDH_1AN + (uKDH_PH*PH_AN) + (uKDH_PN*PN_AN);   
uKDH_BN = uKDH_1BN + (uKDH_PH*PH_BN) + (uKDH_PN*PN_BN);   
                                                          
uKSN_K = uKSN_1K + (uKSN_PH*PH_K) + (uKSN_PN*PN_K);       
uKSN_Q = (uKSN_PH*PH_Q) + (uKSN_PN*PN_Q);                 
uKSN_G = (uKSN_PH*PH_G) + (uKSN_PN*PN_G);                 
uKSN_AH = uKSN_1AH + (uKSN_PH*PH_AH) + (uKSN_PN*PN_AH);   
uKSN_BH = uKSN_1BH + (uKSN_PH*PH_BH) + (uKSN_PN*PN_BH);   
uKSN_AN = uKSN_1AN + (uKSN_PH*PH_AN) + (uKSN_PN*PN_AN);   
uKSN_BN = uKSN_1BN + (uKSN_PH*PH_BN) + (uKSN_PN*PN_BN);   
                                                          
uKDN_K = uKDN_1K + (uKDN_PH*PH_K) + (uKDN_PN*PN_K);       
uKDN_Q = (uKDN_PH*PH_Q) + (uKDN_PN*PN_Q);                 
uKDN_G = (uKDN_PH*PH_G) + (uKDN_PN*PN_G);                 
uKDN_AH = uKDN_1AH + (uKDN_PH*PH_AH) + (uKDN_PN*PN_AH);   
uKDN_BH = uKDN_1BH + (uKDN_PH*PH_BH) + (uKDN_PN*PN_BH);   
uKDN_AN = uKDN_1AN + (uKDN_PH*PH_AN) + (uKDN_PN*PN_AN);   
uKDN_BN = uKDN_1BN + (uKDN_PH*PH_BN) + (uKDN_PN*PN_BN);                
                                       
% Solving for consumption Cj=Cj(lambda,K,Q,GH,GN), investment inputs 
% Jj=Jj(K,Q,GH,GN), imports MF=MF(lambda,K,Q,GH,GN), exports 
%XH=XH(lambda,K,Q,GH,GN)- Final Solutions
CN_K  = CN_2K + (CN_PH*PH_K) + (CN_PN*PN_K);        
CN_Q  = (CN_PH*PH_Q) + (CN_PN*PN_Q);                
CN_G  = (CN_PH*PH_G) + (CN_PN*PN_G);                
CN_AH = CN_2AH + (CN_PH*PH_AH) + (CN_PN*PN_AH);     
CN_BH = CN_2BH + (CN_PH*PH_BH) + (CN_PN*PN_BH);     
CN_AN = CN_2AN + (CN_PH*PH_AN) + (CN_PN*PN_AN);     
CN_BN = CN_2BN + (CN_PH*PH_BN) + (CN_PN*PN_BN);     
                                                    
CH_K  = CH_2K + (CH_PH*PH_K) + (CH_PN*PN_K);        
CH_Q  = (CH_PH*PH_Q) + (CH_PN*PN_Q);                
CH_G  = (CH_PH*PH_G) + (CH_PN*PN_G);                
CH_AH = CH_2AH + (CH_PH*PH_AH) + (CH_PN*PN_AH);     
CH_BH = CH_2BH + (CH_PH*PH_BH) + (CH_PN*PN_BH);     
CH_AN = CH_2AN + (CH_PH*PH_AN) + (CH_PN*PN_AN);     
CH_BN = CH_2BN + (CH_PH*PH_BN) + (CH_PN*PN_BN);     
                                                    
CF_K  = CF_2K + (CF_PH*PH_K) + (CF_PN*PN_K);        
CF_Q  = (CF_PH*PH_Q) + (CF_PN*PN_Q);                
CF_G  = (CF_PH*PH_G) + (CF_PN*PN_G);                
CF_AH = CF_2AH + (CF_PH*PH_AH) + (CF_PN*PN_AH);     
CF_BH = CF_2BH + (CF_PH*PH_BH) + (CF_PN*PN_BH);     
CF_AN = CF_2AN + (CF_PH*PH_AN) + (CF_PN*PN_AN);     
CF_BN = CF_2BN + (CF_PH*PH_BN) + (CF_PN*PN_BN);  

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_BH      = (JN_PH*PH_BH) + (JN_PN*PN_BH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN); 

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);

% Solving for sectoral return on capital - Rj(K,Q,G,Aj,Bj)                  
RH_K = RH_2K + (RH_PH*PH_K) + (RH_PN*PN_K);                                 
RH_Q = (RH_PH*PH_Q) + (RH_PN*PN_Q);                                         
RH_G = (RH_PH*PH_G) + (RH_PN*PN_G);                                         
RH_AH = RH_2AH + (RH_PH*PH_AH) + (RH_PN*PN_AH);                             
RH_BH = RH_2BH + (RH_PH*PH_BH) + (RH_PN*PN_BH);                             
RH_AN = RH_2AN + (RH_PH*PH_AN) + (RH_PN*PN_AN);                             
RH_BN = RH_2BN + (RH_PH*PH_BN) + (RH_PN*PN_BN);                             
                                                                            
RN_K = RN_2K + (RN_PH*PH_K) + (RN_PN*PN_K);                                 
RN_Q = (RN_PH*PH_Q) + (RN_PN*PN_Q);                                         
RN_G = (RN_PH*PH_G) + (RN_PN*PN_G);                                         
RN_AH = RN_2AH + (RN_PH*PH_AH) + (RN_PN*PN_AH);                             
RN_BH = RN_2BH + (RN_PH*PH_BH) + (RN_PN*PN_BH);                             
RN_AN = RN_2AN + (RN_PH*PH_AN) + (RN_PN*PN_AN);                             
RN_BN = RN_2BN + (RN_PH*PH_BN) + (RN_PN*PN_BN);                             

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(K,Q,G,Aj,Bj,lambda) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_G  = (v_PN*PN_G) + (v_PH*PH_G); 
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);

% Solutions Aj,Bj(AjS,AjD,BjS,BjD)           
AH_ASH = eta*(AH_0/ASH_0);                   
AH_ADH = (1-eta)*(AH_0/ADH_0);               
BH_BSH = eta*(BH_0/BSH_0);                   
BH_BDH = (1-eta)*(BH_0/BDH_0);                
AN_ASN = eta*(AN_0/ASN_0);                   
AN_ADN = (1-eta)*(AN_0/ADN_0);               
BN_BSN = eta*(BN_0/BSN_0);                   
BN_BDN = (1-eta)*(BN_0/BDN_0);  

% Solutions PH,PN(K,Q,ASj,ADj,BSj,BDj)              
PH_ASH = PH_AH*AH_ASH;                              
PH_ADH = PH_AH*AH_ADH;                              
PH_BSH = PH_BH*BH_BSH;                              
PH_BDH = PH_BH*BH_BDH;                              
                                                    
PH_ASN = PH_AN*AN_ASN;                              
PH_ADN = PH_AN*AN_ADN;                              
PH_BSN = PH_BN*BN_BSN;                              
PH_BDN = PH_BN*BN_BDN;                              
                                                    
PN_ASH = PN_AH*AH_ASH;                              
PN_ADH = PN_AH*AH_ADH;                              
PN_BSH = PN_BH*BH_BSH;                              
PN_BDH = PN_BH*BH_BDH;                              
                                                    
PN_ASN = PN_AN*AN_ASN;                              
PN_ADN = PN_AN*AN_ADN;                              
PN_BSN = PN_BN*BN_BSN;                              
PN_BDN = PN_BN*BN_BDN;      

% Solutions RH,RN(K,Q,ASj,ADj,BSj,BDj) 
RH_ASH = RH_AH*AH_ASH;  
RH_ADH = RH_AH*AH_ADH;  
RH_BSH = RH_BH*BH_BSH;  
RH_BDH = RH_BH*BH_BDH;  
                        
RH_ASN = RH_AN*AN_ASN;  
RH_ADN = RH_AN*AN_ADN;  
RH_BSN = RH_BN*BN_BSN;  
RH_BDN = RH_BN*BN_BDN;  
                        
RN_ASH = RN_AH*AH_ASH;  
RN_ADH = RN_AH*AH_ADH;  
RN_BSH = RN_BH*BH_BSH;  
RN_BDH = RN_BH*BH_BDH;  
                        
RN_ASN = RN_AN*AN_ASN;  
RN_ADN = RN_AN*AN_ADN;  
RN_BSN = RN_BN*BN_BSN;  
RN_BDN = RN_BN*BN_BDN; 

% Solving for capital-labor ratios kj=kj(K,Q,ASj,ADj,BSj,BDj) -
% sectoral labor Lj=Lj(K,Q,ASj,ADj,BSj,BDj) - sectoral output
% Yj=Yj(K,Q,ASj,ADj,BSj,BDj) - Final Solutions
KH_ASH = KH_AH*AH_ASH;
KH_ADH = KH_AH*AH_ADH;
KH_BSH = KH_BH*BH_BSH;
KH_BDH = KH_BH*BH_BDH;

KH_ASN = KH_AN*AN_ASN;
KH_ADN = KH_AN*AN_ADN;
KH_BSN = KH_BN*BN_BSN;
KH_BDN = KH_BN*BN_BDN;

KN_ASH = KN_AH*AH_ASH;
KN_ADH = KN_AH*AH_ADH;
KN_BSH = KN_BH*BH_BSH;
KN_BDH = KN_BH*BH_BDH;

KN_ASN = KN_AN*AN_ASN;
KN_ADN = KN_AN*AN_ADN;
KN_BSN = KN_BN*BN_BSN;
KN_BDN = KN_BN*BN_BDN;

LH_ASH = LH_AH*AH_ASH;
LH_ADH = LH_AH*AH_ADH;
LH_BSH = LH_BH*BH_BSH;
LH_BDH = LH_BH*BH_BDH;

LH_ASN = LH_AN*AN_ASN;
LH_ADN = LH_AN*AN_ADN;
LH_BSN = LH_BN*BN_BSN;
LH_BDN = LH_BN*BN_BDN;

LN_ASH = LN_AH*AH_ASH;
LN_ADH = LN_AH*AH_ADH;
LN_BSH = LN_BH*BH_BSH;
LN_BDH = LN_BH*BH_BDH;

LN_ASN = LN_AN*AN_ASN;
LN_ADN = LN_AN*AN_ADN;
LN_BSN = LN_BN*BN_BSN;
LN_BDN = LN_BN*BN_BDN;

YH_ASH = YH_AH*AH_ASH;
YH_ADH = YH_AH*AH_ADH;
YH_BSH = YH_BH*BH_BSH;
YH_BDH = YH_BH*BH_BDH;

YH_ASN = YH_AN*AN_ASN;
YH_ADN = YH_AN*AN_ADN;
YH_BSN = YH_BN*BN_BSN;
YH_BDN = YH_BN*BN_BDN;

YN_ASH = YN_AH*AH_ASH;
YN_ADH = YN_AH*AH_ADH;
YN_BSH = YN_BH*BH_BSH;
YN_BDH = YN_BH*BH_BDH;

YN_ASN = YN_AN*AN_ASN;
YN_ADN = YN_AN*AN_ADN;
YN_BSN = YN_BN*BN_BSN;
YN_BDN = YN_BN*BN_BDN;

uKSH_ASH = uKSH_AH*AH_ASH;
uKSH_ADH = uKSH_AH*AH_ADH;
uKSH_BSH = uKSH_BH*BH_BSH;
uKSH_BDH = uKSH_BH*BH_BDH;

uKSH_ASN = uKSH_AN*AN_ASN;
uKSH_ADN = uKSH_AN*AN_ADN;
uKSH_BSN = uKSH_BN*BN_BSN;
uKSH_BDN = uKSH_BN*BN_BDN;

uKDH_ASH = uKDH_AH*AH_ASH;
uKDH_ADH = uKDH_AH*AH_ADH;
uKDH_BSH = uKDH_BH*BH_BSH;
uKDH_BDH = uKDH_BH*BH_BDH;

uKDH_ASN = uKDH_AN*AN_ASN;
uKDH_ADN = uKDH_AN*AN_ADN;
uKDH_BSN = uKDH_BN*BN_BSN;
uKDH_BDN = uKDH_BN*BN_BDN;

uKSN_ASH = uKSN_AH*AH_ASH;
uKSN_ADH = uKSN_AH*AH_ADH;
uKSN_BSH = uKSN_BH*BH_BSH;
uKSN_BDH = uKSN_BH*BH_BDH;

uKSN_ASN = uKSN_AN*AN_ASN;
uKSN_ADN = uKSN_AN*AN_ADN;
uKSN_BSN = uKSN_BN*BN_BSN;
uKSN_BDN = uKSN_BN*BN_BDN;

uKDN_ASH = uKDN_AH*AH_ASH;
uKDN_ADH = uKDN_AH*AH_ADH;
uKDN_BSH = uKDN_BH*BH_BSH;
uKDN_BDH = uKDN_BH*BH_BDH;

uKDN_ASN = uKDN_AN*AN_ASN;
uKDN_ADN = uKDN_AN*AN_ADN;
uKDN_BSN = uKDN_BN*BN_BSN;
uKDN_BDN = uKDN_BN*BN_BDN;

% Solving for consumption Cj=Cj(K,Q,ASj,ADj,BSj,BDj), investment inputs
% Jj=Jj(K,Q,AH,BH,AN,BN), imports MF=MF(K,Q,ASj,ADj,BSj,BDj), exports
%XH=XH(K,Q,ASj,ADj,BSj,BDj)- Final Solutions
CH_ASH = CH_AH*AH_ASH;
CH_ADH = CH_AH*AH_ADH;
CH_BSH = CH_BH*BH_BSH;
CH_BDH = CH_BH*BH_BDH;

CH_ASN = CH_AN*AN_ASN;
CH_ADN = CH_AN*AN_ADN;
CH_BSN = CH_BN*BN_BSN;
CH_BDN = CH_BN*BN_BDN;

CN_ASH = CN_AH*AH_ASH;
CN_ADH = CN_AH*AH_ADH;
CN_BSH = CN_BH*BH_BSH;
CN_BDH = CN_BH*BH_BDH;

CN_ASN = CN_AN*AN_ASN;
CN_ADN = CN_AN*AN_ADN;
CN_BSN = CN_BN*BN_BSN;
CN_BDN = CN_BN*BN_BDN;

CF_ASH = CF_AH*AH_ASH;
CF_ADH = CF_AH*AH_ADH;
CF_BSH = CF_BH*BH_BSH;
CF_BDH = CF_BH*BH_BDH;

CF_ASN = CF_AN*AN_ASN;
CF_ADN = CF_AN*AN_ADN;
CF_BSN = CF_BN*BN_BSN;
CF_BDN = CF_BN*BN_BDN;

JH_ASH = JH_AH*AH_ASH;
JH_ADH = JH_AH*AH_ADH;
JH_BSH = JH_BH*BH_BSH;
JH_BDH = JH_BH*BH_BDH;

JH_ASN = JH_AN*AN_ASN;
JH_ADN = JH_AN*AN_ADN;
JH_BSN = JH_BN*BN_BSN;
JH_BDN = JH_BN*BN_BDN;

JN_ASH = JN_AH*AH_ASH;
JN_ADH = JN_AH*AH_ADH;
JN_BSH = JN_BH*BH_BSH;
JN_BDH = JN_BH*BH_BDH;

JN_ASN = JN_AN*AN_ASN;
JN_ADN = JN_AN*AN_ADN;
JN_BSN = JN_BN*BN_BSN;
JN_BDN = JN_BN*BN_BDN;

JF_ASH = JF_AH*AH_ASH;
JF_ADH = JF_AH*AH_ADH;
JF_BSH = JF_BH*BH_BSH;
JF_BDH = JF_BH*BH_BDH;

JF_ASN = JF_AN*AN_ASN;
JF_ADN = JF_AN*AN_ADN;
JF_BSN = JF_BN*BN_BSN;
JF_BDN = JF_BN*BN_BDN;

XH_ASH = XH_AH*AH_ASH;
XH_ADH = XH_AH*AH_ADH;
XH_BSH = XH_BH*BH_BSH;
XH_BDH = XH_BH*BH_BDH;

XH_ASN = XH_AN*AN_ASN;
XH_ADN = XH_AN*AN_ADN;
XH_BSN = XH_BN*BN_BSN;
XH_BDN = XH_BN*BN_BDN;

MF_ASH = MF_AH*AH_ASH;
MF_ADH = MF_AH*AH_ADH;
MF_BSH = MF_BH*BH_BSH;
MF_BDH = MF_BH*BH_BDH;

MF_ASN = MF_AN*AN_ASN;
MF_ADN = MF_AN*AN_ADN;
MF_BSN = MF_BN*BN_BSN;
MF_BDN = MF_BN*BN_BDN;

v_ASH = v_AH*AH_ASH;   
v_ADH = v_AH*AH_ADH;   
v_BSH = v_BH*BH_BSH;   
v_BDH = v_BH*BH_BDH;   
                       
v_ASN = v_AN*AN_ASN;   
v_ADN = v_AN*AN_ADN;   
v_BSN = v_BN*BN_BSN;   
v_BDN = v_BN*BN_BDN;   

% Elements of the Jacobian Matrix
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1SN*uKSN_K)-(KN*xi1DN*uKDN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1SN*uKSN_Q)-(KN*xi1DN*uKDN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -( -(RK/K)+(1/K)*( RH*KH*((eta*uKSH_K)+(1-eta)*uKDH_K)+RN*KN*((eta*uKSN_K)+(1-eta)*uKDN_K)+(RH*KH_K)+(RN*KN_K)+(RH_K*KH)+(RN_K*KN) )-(PH*KH/K)*((xi1SH*uKSH_K)+(xi1DH*uKDH_K))-(PN*KN/K)*((xi1SN*uKSN_K)+(xi1DN*uKDN_K))+(PI*kappa*v_K*deltaK));
Sigma_Q   = (r+deltaK)-( (1/K)*( (RH*KH*((eta*uKSH_Q)+(1-eta)*uKDH_Q))+(RN*KN*((eta*uKSN_Q)+(1-eta)*uKDN_Q))+(RH*KH_Q)+(RN*KN_Q)+(RH_Q*KH)+(RN_Q*KN) )-(PH*KH/K)*((xi1SH*uKSH_Q)+(xi1DH*uKDH_Q))-(PN*KN/K)*((xi1SN*uKSN_Q)+(xi1DN*uKDN_Q))+(PI*kappa*v_Q*deltaK));

x11   = Upsilon_K;                                                                         
x12   = Upsilon_Q;     
x21   = Sigma_K;                        
x22   = Sigma_Q;
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
omega_12 = V_sorted(1,2)/V_sorted(1,2); 
omega_22 = V_sorted(2,2)/V_sorted(1,2); 

TrJ = trace(J); 
DetJ = det(J); 

% Elements of general solutions for capital K(t) and the relative price P(t)
% K(t) -K = X1(t)+X2(t); P(t)-P = omega21*X1(t)+omega22*X2(t)
% X1(t) = (K0-K)*exp(nu1*t)+Gamma2*exp(nu1*t) - Gamma1*(exp(nu1*t)-exp(-xi*t));
% X2(t) = -Gamma2*exp(-xi*t);

Upsilon_G   = (I/IN)*(YN_G-CN_G-GN_G-(KN*xi1SN*uKSN_G)-(KN*xi1DN*uKDN_G)) + (alphaI*phiI*I)*( (PN_G/PN) - (alphaIH/PH)*PH_G );
Upsilon_ASH = (I/IN)*(YN_ASH-CN_ASH-(KN*xi1SN*uKSN_ASH)-(KN*xi1DN*uKDN_ASH)) + (alphaI*phiI*I)*( (PN_ASH/PN) - (alphaIH/PH)*PH_ASH );
Upsilon_ADH = (I/IN)*(YN_ADH-CN_ADH-(KN*xi1SN*uKSN_ADH)-(KN*xi1DN*uKDN_ADH)) + (alphaI*phiI*I)*( (PN_ADH/PN) - (alphaIH/PH)*PH_ADH );
Upsilon_BSH = (I/IN)*(YN_BSH-CN_BSH-(KN*xi1SN*uKSN_BSH)-(KN*xi1DN*uKDN_BSH)) + (alphaI*phiI*I)*( (PN_BSH/PN) - (alphaIH/PH)*PH_BSH );
Upsilon_BDH = (I/IN)*(YN_BDH-CN_BDH-(KN*xi1SN*uKSN_BDH)-(KN*xi1DN*uKDN_BDH)) + (alphaI*phiI*I)*( (PN_BDH/PN) - (alphaIH/PH)*PH_BDH );

Upsilon_ASN = (I/IN)*(YN_ASN-CN_ASN-(KN*xi1SN*uKSN_ASN)-(KN*xi1DN*uKDN_ASN)) + (alphaI*phiI*I)*( (PN_ASN/PN) - (alphaIH/PH)*PH_ASN );
Upsilon_ADN = (I/IN)*(YN_ADN-CN_ADN-(KN*xi1SN*uKSN_ADN)-(KN*xi1DN*uKDN_ADN)) + (alphaI*phiI*I)*( (PN_ADN/PN) - (alphaIH/PH)*PH_ADN );
Upsilon_BSN = (I/IN)*(YN_BSN-CN_BSN-(KN*xi1SN*uKSN_BSN)-(KN*xi1DN*uKDN_BSN)) + (alphaI*phiI*I)*( (PN_BSN/PN) - (alphaIH/PH)*PH_BSN );
Upsilon_BDN = (I/IN)*(YN_BDN-CN_BDN-(KN*xi1SN*uKSN_BDN)-(KN*xi1DN*uKDN_BDN)) + (alphaI*phiI*I)*( (PN_BDN/PN) - (alphaIH/PH)*PH_BDN );

Sigma_G   = -( (1/K)*( RH*KH*((eta*uKSH_G)+(1-eta)*uKDH_G)+RN*KN*((eta*uKSN_G)+(1-eta)*uKDN_G)+(RH*KH_G)+(RN*KN_G)+(RH_G*KH)+(RN_G*KN) )-(PH*KH/K)*((xi1SH*uKSH_G)+(xi1DH*uKDH_G))-(PN*KN/K)*((xi1SN*uKSN_G)+(xi1DN*uKDN_G))+(PI*kappa*v_G*deltaK));
Sigma_ASH = -( (1/K)*( RH*KH*((eta*uKSH_ASH)+(1-eta)*uKDH_ASH)+RN*KN*((eta*uKSN_ASH)+(1-eta)*uKDN_ASH)+(RH*KH_ASH)+(RN*KN_ASH)+(RH_ASH*KH)+(RN_ASH*KN) )-(PH*KH/K)*((xi1SH*uKSH_ASH)+(xi1DH*uKDH_ASH))-(PN*KN/K)*((xi1SN*uKSN_ASH)+(xi1DN*uKDN_ASH))+(PI*kappa*v_ASH*deltaK));
Sigma_ADH = -( (1/K)*( RH*KH*((eta*uKSH_ADH)+(1-eta)*uKDH_ADH)+RN*KN*((eta*uKSN_ADH)+(1-eta)*uKDN_ADH)+(RH*KH_ADH)+(RN*KN_ADH)+(RH_ADH*KH)+(RN_ADH*KN) )-(PH*KH/K)*((xi1SH*uKSH_ADH)+(xi1DH*uKDH_ADH))-(PN*KN/K)*((xi1SN*uKSN_ADH)+(xi1DN*uKDN_ADH))+(PI*kappa*v_ADH*deltaK));
Sigma_BSH = -( (1/K)*( RH*KH*((eta*uKSH_BSH)+(1-eta)*uKDH_BSH)+RN*KN*((eta*uKSN_BSH)+(1-eta)*uKDN_BSH)+(RH*KH_BSH)+(RN*KN_BSH)+(RH_BSH*KH)+(RN_BSH*KN) )-(PH*KH/K)*((xi1SH*uKSH_BSH)+(xi1DH*uKDH_BSH))-(PN*KN/K)*((xi1SN*uKSN_BSH)+(xi1DN*uKDN_BSH))+(PI*kappa*v_BSH*deltaK));
Sigma_BDH = -( (1/K)*( RH*KH*((eta*uKSH_BDH)+(1-eta)*uKDH_BDH)+RN*KN*((eta*uKSN_BDH)+(1-eta)*uKDN_BDH)+(RH*KH_BDH)+(RN*KN_BDH)+(RH_BDH*KH)+(RN_BDH*KN) )-(PH*KH/K)*((xi1SH*uKSH_BDH)+(xi1DH*uKDH_BDH))-(PN*KN/K)*((xi1SN*uKSN_BDH)+(xi1DN*uKDN_BDH))+(PI*kappa*v_BDH*deltaK));

Sigma_ASN = -( (1/K)*( RH*KH*((eta*uKSH_ASN)+(1-eta)*uKDH_ASN)+RN*KN*((eta*uKSN_ASN)+(1-eta)*uKDN_ASN)+(RH*KH_ASN)+(RN*KN_ASN)+(RH_ASN*KH)+(RN_ASN*KN) )-(PH*KH/K)*((xi1SH*uKSH_ASN)+(xi1DH*uKDH_ASN))-(PN*KN/K)*((xi1SN*uKSN_ASN)+(xi1DN*uKDN_ASN))+(PI*kappa*v_ASN*deltaK));
Sigma_ADN = -( (1/K)*( RH*KH*((eta*uKSH_ADN)+(1-eta)*uKDH_ADN)+RN*KN*((eta*uKSN_ADN)+(1-eta)*uKDN_ADN)+(RH*KH_ADN)+(RN*KN_ADN)+(RH_ADN*KH)+(RN_ADN*KN) )-(PH*KH/K)*((xi1SH*uKSH_ADN)+(xi1DH*uKDH_ADN))-(PN*KN/K)*((xi1SN*uKSN_ADN)+(xi1DN*uKDN_ADN))+(PI*kappa*v_ADN*deltaK));
Sigma_BSN = -( (1/K)*( RH*KH*((eta*uKSH_BSN)+(1-eta)*uKDH_BSN)+RN*KN*((eta*uKSN_BSN)+(1-eta)*uKDN_BSN)+(RH*KH_BSN)+(RN*KN_BSN)+(RH_BSN*KH)+(RN_BSN*KN) )-(PH*KH/K)*((xi1SH*uKSH_BSN)+(xi1DH*uKDH_BSN))-(PN*KN/K)*((xi1SN*uKSN_BSN)+(xi1DN*uKDN_BSN))+(PI*kappa*v_BSN*deltaK));
Sigma_BDN = -( (1/K)*( RH*KH*((eta*uKSH_BDN)+(1-eta)*uKDH_BDN)+RN*KN*((eta*uKSN_BDN)+(1-eta)*uKDN_BDN)+(RH*KH_BDN)+(RN*KN_BDN)+(RH_BDN*KH)+(RN_BDN*KN) )-(PH*KH/K)*((xi1SH*uKSH_BDN)+(xi1DH*uKDH_BDN))-(PN*KN/K)*((xi1SN*uKSN_BDN)+(xi1DN*uKDN_BDN))+(PI*kappa*v_BDN*deltaK));%%%%%%%%%%%%%%%%%% Solutions for Permanent Shocks %%%%%%%%%%%%%%%%%%%%

% Solutions                                                                                                                                                                                                                                                          
Vnorm = [omega_11 omega_12; omega_21 omega_22];                                                                                                                                                                                                                      
Vinv   = inv(Vnorm);                                                                                                                                                                                                                                                 
u11    = Vinv(1,1);                                                                                                                                                                                                                                                  
u12    = Vinv(1,2);                                                                                                                                                                                                                                                  
u21    = Vinv(2,1);                                                                                                                                                                                                                                                  
u22    = Vinv(2,2);                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                     
s11   = (u11*Upsilon_ASH) + (u12*Sigma_ASH);                                                                                                                                                                                                                         
s12   = (u11*Upsilon_BSH) + (u12*Sigma_BSH);                                                                                                                                                                                                                         
s13   = (u11*Upsilon_ASN) + (u12*Sigma_ASN);                                                                                                                                                                                                                         
s14   = (u11*Upsilon_BSN) + (u12*Sigma_BSN);                                                                                                                                                                                                                         
s15   = (u11*Upsilon_ADH) + (u12*Sigma_ADH);                                                                                                                                                                                                                         
s16   = (u11*Upsilon_BDH) + (u12*Sigma_BDH);                                                                                                                                                                                                                         
s17   = (u11*Upsilon_ADN) + (u12*Sigma_ADN);                                                                                                                                                                                                                         
s18   = (u11*Upsilon_BDN) + (u12*Sigma_BDN);                                                                                                                                                                                                                         
s19   = (u11*Upsilon_G)   + (u12*Sigma_G);                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                     
s21   = (u21*Upsilon_ASH) + (u22*Sigma_ASH);                                                                                                                                                                                                                         
s22   = (u21*Upsilon_BSH) + (u22*Sigma_BSH);                                                                                                                                                                                                                         
s23   = (u21*Upsilon_ASN) + (u22*Sigma_ASN);                                                                                                                                                                                                                         
s24   = (u21*Upsilon_BSN) + (u22*Sigma_BSN);                                                                                                                                                                                                                         
s25   = (u21*Upsilon_ADH) + (u22*Sigma_ADH);                                                                                                                                                                                                                         
s26   = (u21*Upsilon_BDH) + (u22*Sigma_BDH);                                                                                                                                                                                                                         
s27   = (u21*Upsilon_ADN) + (u22*Sigma_ADN);                                                                                                                                                                                                                         
s28   = (u21*Upsilon_BDN) + (u22*Sigma_BDN);                                                                                                                                                                                                                         
s29   = (u21*Upsilon_G)   + (u22*Sigma_G);                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                     
DeltaASH_1 = - s11*ASH_0*(1/(nu_1+xiASH));                                                                                                                                                                                                                           
DeltaBSH_1 = - s12*BSH_0*(1/(nu_1+xiBSH));                                                                                                                                                                                                                           
DeltaASN_1 = - s13*ASN_0*(1/(nu_1+xiASN));                                                                                                                                                                                                                           
DeltaBSN_1 = - s14*BSN_0*(1/(nu_1+xiBSN));                                                                                                                                                                                                                           
DeltaADH_1 = - s15*ADH_0*(1/(nu_1+xiADH));                                                                                                                                                                                                                           
DeltaBDH_1 = - s16*BDH_0*(1/(nu_1+xiBDH));                                                                                                                                                                                                                           
DeltaADN_1 = - s17*ADN_0*(1/(nu_1+xiADN));                                                                                                                                                                                                                           
DeltaBDN_1 = - s18*BDN_0*(1/(nu_1+xiBDN));                                                                                                                                                                                                                           
DeltaG_1   = - s19*Y_0*(1/(nu_1+xi));                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                     
DeltaASH_2  = s21*ASH_0*(1/(nu_2+xiASH));                                                                                                                                                                                                                            
DeltaBSH_2  = s22*BSH_0*(1/(nu_2+xiBSH));                                                                                                                                                                                                                            
DeltaASN_2  = s23*ASN_0*(1/(nu_2+xiASN));                                                                                                                                                                                                                            
DeltaBSN_2  = s24*BSN_0*(1/(nu_2+xiBSN));                                                                                                                                                                                                                            
DeltaADH_2  = s25*ADH_0*(1/(nu_2+xiADH));                                                                                                                                                                                                                            
DeltaBDH_2  = s26*BDH_0*(1/(nu_2+xiBDH));                                                                                                                                                                                                                            
DeltaADN_2  = s27*ADN_0*(1/(nu_2+xiADN));                                                                                                                                                                                                                            
DeltaBDN_2  = s28*BDN_0*(1/(nu_2+xiBDN));                                                                                                                                                                                                                            
DeltaG_2    = s29*Y_0*(1/(nu_2+xi));                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                     
ThetaASH_1   = (1-baraSH)*((nu_1+xiASH)/(nu_1+chiASH));                                                                                                                                                                                                              
ThetaASH_2   = (1-baraSH)*((nu_2+xiASH)/(nu_2+chiASH));                                                                                                                                                                                                              
ThetaBSH_1   = (1-barbSH)*((nu_1+xiBSH)/(nu_1+chiBSH));                                                                                                                                                                                                              
ThetaBSH_2   = (1-barbSH)*((nu_2+xiBSH)/(nu_2+chiBSH));                                                                                                                                                                                                              
ThetaASN_1   = (1-baraSN)*((nu_1+xiASN)/(nu_1+chiASN));                                                                                                                                                                                                              
ThetaASN_2   = (1-baraSN)*((nu_2+xiASN)/(nu_2+chiASN));                                                                                                                                                                                                              
ThetaBSN_1   = (1-barbSN)*((nu_1+xiBSN)/(nu_1+chiBSN));                                                                                                                                                                                                              
ThetaBSN_2   = (1-barbSN)*((nu_2+xiBSN)/(nu_2+chiBSN));                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                     
ThetaADH_1   = (1-baraDH)*((nu_1+xiADH)/(nu_1+chiADH));                                                                                                                                                                                                              
ThetaADH_2   = (1-baraDH)*((nu_2+xiADH)/(nu_2+chiADH));                                                                                                                                                                                                              
ThetaBDH_1   = (1-barbDH)*((nu_1+xiBDH)/(nu_1+chiBDH));                                                                                                                                                                                                              
ThetaBDH_2   = (1-barbDH)*((nu_2+xiBDH)/(nu_2+chiBDH));                                                                                                                                                                                                              
ThetaADN_1   = (1-baraDN)*((nu_1+xiADN)/(nu_1+chiADN));                                                                                                                                                                                                              
ThetaADN_2   = (1-baraDN)*((nu_2+xiADN)/(nu_2+chiADN));                                                                                                                                                                                                              
ThetaBDN_1   = (1-barbDN)*((nu_1+xiBDN)/(nu_1+chiBDN));                                                                                                                                                                                                              
ThetaBDN_2   = (1-barbDN)*((nu_2+xiBDN)/(nu_2+chiBDN));

ThetaG_1    = (1-barg)*((nu_1+xi)/(nu_1+chi));
ThetaG_2    = (1-barg)*((nu_2+xi)/(nu_2+chi));
                                                                                                                                                                                                                                                                     
X20 = - DeltaG_2*(1-ThetaG_2) - DeltaASH_2*(1-ThetaASH_2) - DeltaBSH_2*(1-ThetaBSH_2) - DeltaASN_2*(1-ThetaASN_2) - DeltaBSN_2*(1-ThetaBSN_2) - DeltaADH_2*(1-ThetaADH_2) - DeltaBDH_2*(1-ThetaBDH_2) - DeltaADN_2*(1-ThetaADN_2) - DeltaBDN_2*(1-ThetaBDN_2);       
X10 = (K0-K) - X20;                                                                                                                                                                                                                                                  
X11 = X10 - DeltaG_1*(1-ThetaG_1) - DeltaASH_1*(1-ThetaASH_1) - DeltaBSH_1*(1-ThetaBSH_1) - DeltaASN_1*(1-ThetaASN_1) - DeltaBSN_1*(1-ThetaBSN_1) - DeltaADH_1*(1-ThetaADH_1) - DeltaBDH_1*(1-ThetaBDH_1) - DeltaADN_1*(1-ThetaADN_1) - DeltaBDN_1*(1-ThetaBDN_1);   

% Intertemporal solvency condition - lambda
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K;
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
B_G   = (PH_G*XH) + (PH*XH_G) - MF_G;
B_ASH = (PH_ASH*XH) + (PH*XH_ASH) - MF_ASH;
B_BSH = (PH_BSH*XH) + (PH*XH_BSH) - MF_BSH;
B_ASN = (PH_ASN*XH) + (PH*XH_ASN) - MF_ASN;
B_BSN = (PH_BSN*XH) + (PH*XH_BSN) - MF_BSN;
B_ADH = (PH_ADH*XH) + (PH*XH_ADH) - MF_ADH;
B_BDH = (PH_BDH*XH) + (PH*XH_BDH) - MF_BDH;
B_ADN = (PH_ADN*XH) + (PH*XH_ADN) - MF_ADN;
B_BDN = (PH_BDN*XH) + (PH*XH_BDN) - MF_BDN;

N1    = (B_K + (B_Q*omega_21));
N2    = (B_K + (B_Q*omega_22));
ThetaG_prime   = (1-barg)*((xi+r)/(chi+r));
ThetaG_1prime  = ThetaG_1*((xi+r)/(chi+r));
ThetaG_2prime  = ThetaG_2*((xi+r)/(chi+r));

ThetaASH_prime  = (1-baraSH)*((xiASH+r)/(chiASH+r));       
ThetaASH_1prime = ThetaASH_1*((xiASH+r)/(chiASH+r));       
ThetaASH_2prime = ThetaASH_2*((xiASH+r)/(chiASH+r));       
ThetaBSH_prime  = (1-barbSH)*((xiBSH+r)/(chiBSH+r));       
ThetaBSH_1prime = ThetaBSH_1*((xiBSH+r)/(chiBSH+r));       
ThetaBSH_2prime = ThetaBSH_2*((xiBSH+r)/(chiBSH+r));       
ThetaASN_prime  = (1-baraSN)*((xiASN+r)/(chiASN+r));       
ThetaASN_1prime = ThetaASN_1*((xiASN+r)/(chiASN+r));       
ThetaASN_2prime = ThetaASN_2*((xiASN+r)/(chiASN+r));       
ThetaBSN_prime  = (1-barbSN)*((xiBSN+r)/(chiBSN+r));       
ThetaBSN_1prime = ThetaBSN_1*((xiBSN+r)/(chiBSN+r));       
ThetaBSN_2prime = ThetaBSN_2*((xiBSN+r)/(chiBSN+r));       
                                                           
ThetaADH_prime  = (1-baraDH)*((xiADH+r)/(chiADH+r));       
ThetaADH_1prime = ThetaADH_1*((xiADH+r)/(chiADH+r));       
ThetaADH_2prime = ThetaADH_2*((xiADH+r)/(chiADH+r));       
ThetaBDH_prime  = (1-barbDH)*((xiBDH+r)/(chiBDH+r));       
ThetaBDH_1prime = ThetaBDH_1*((xiBDH+r)/(chiBDH+r));       
ThetaBDH_2prime = ThetaBDH_2*((xiBDH+r)/(chiBDH+r));       
ThetaADN_prime  = (1-baraDN)*((xiADN+r)/(chiADN+r));       
ThetaADN_1prime = ThetaADN_1*((xiADN+r)/(chiADN+r));       
ThetaADN_2prime = ThetaADN_2*((xiADN+r)/(chiADN+r));       
ThetaBDN_prime  = (1-barbDN)*((xiBDN+r)/(chiBDN+r));       
ThetaBDN_1prime = ThetaBDN_1*((xiBDN+r)/(chiBDN+r));       
ThetaBDN_2prime = ThetaBDN_2*((xiBDN+r)/(chiBDN+r));       

wB1    = N1*X11;
wBASH2 = B_ASH*ASH_0*(1-ThetaASH_prime) + N1*DeltaASH_1*(1-ThetaASH_1prime) - N2*DeltaASH_2*(1-ThetaASH_2prime);
wBBSH2 = B_BSH*BSH_0*(1-ThetaBSH_prime) + N1*DeltaBSH_1*(1-ThetaBSH_1prime) - N2*DeltaBSH_2*(1-ThetaBSH_2prime);
wBASN2 = B_ASN*ASN_0*(1-ThetaASN_prime) + N1*DeltaASN_1*(1-ThetaASN_1prime) - N2*DeltaASN_2*(1-ThetaASN_2prime);
wBBSN2 = B_BSN*BSN_0*(1-ThetaBSN_prime) + N1*DeltaBSN_1*(1-ThetaBSN_1prime) - N2*DeltaBSN_2*(1-ThetaBSN_2prime);

wBADH2 = B_ADH*ADH_0*(1-ThetaADH_prime) + N1*DeltaADH_1*(1-ThetaADH_1prime) - N2*DeltaADH_2*(1-ThetaADH_2prime);
wBBDH2 = B_BDH*BDH_0*(1-ThetaBDH_prime) + N1*DeltaBDH_1*(1-ThetaBDH_1prime) - N2*DeltaBDH_2*(1-ThetaBDH_2prime);
wBADN2 = B_ADN*ADN_0*(1-ThetaADN_prime) + N1*DeltaADN_1*(1-ThetaADN_1prime) - N2*DeltaADN_2*(1-ThetaADN_2prime);
wBBDN2 = B_BDN*BDN_0*(1-ThetaBDN_prime) + N1*DeltaBDN_1*(1-ThetaBDN_1prime) - N2*DeltaBDN_2*(1-ThetaBDN_2prime);

wBG2   = B_G*Y_0*(1-ThetaG_prime) + N1*DeltaG_1*(1-ThetaG_1prime) - N2*DeltaG_2*(1-ThetaG_2prime);

% Solving for sectoral wages - Wj=Wj(K,Q,G,Aj,Bj)     
WH_K = WH_2K + (WH_PH*PH_K) + (WH_PN*PN_K);           
WH_Q = (WH_PH*PH_Q) + (WH_PN*PN_Q);                   
WH_G = (WH_PH*PH_G) + (WH_PN*PN_G);                   
WH_AH = WH_2AH + (WH_PH*PH_AH) + (WH_PN*PN_AH);       
WH_BH = WH_2BH + (WH_PH*PH_BH) + (WH_PN*PN_BH);       
WH_AN = WH_2AN + (WH_PH*PH_AN) + (WH_PN*PN_AN);       
WH_BN = WH_2BN + (WH_PH*PH_BN) + (WH_PN*PN_BN);       
                                                      
WN_K = WN_2K + (WN_PH*PH_K) + (WN_PN*PN_K);           
WN_Q = (WN_PH*PH_Q) + (WN_PN*PN_Q);                   
WN_G = (WN_PH*PH_G) + (WN_PN*PN_G);                   
WN_AH = WN_2AH + (WN_PH*PH_AH) + (WN_PN*PN_AH);       
WN_BH = WN_2BH + (WN_PH*PH_BH) + (WN_PN*PN_BH);       
WN_AN = WN_2AN + (WN_PH*PH_AN) + (WN_PN*PN_AN);       
WN_BN = WN_2BN + (WN_PH*PH_BN) + (WN_PN*PN_BN);       

WH_ASH = WH_AH*AH_ASH;   
WH_ADH = WH_AH*AH_ADH;   
WH_BSH = WH_BH*BH_BSH;   
WH_BDH = WH_BH*BH_BDH;   
                         
WH_ASN = WH_AN*AN_ASN;   
WH_ADN = WH_AN*AN_ADN;   
WH_BSN = WH_BN*BN_BSN;   
WH_BDN = WH_BN*BN_BDN;   
                         
WN_ASH = WN_AH*AH_ASH;   
WN_ADH = WN_AH*AH_ADH;   
WN_BSH = WN_BH*BH_BSH;   
WN_BDH = WN_BH*BH_BDH;   
                         
WN_ASN = WN_AN*AN_ASN;   
WN_ADN = WN_AN*AN_ADN;   
WN_BSN = WN_BN*BN_BSN;   
WN_BDN = WN_BN*BN_BDN;   
                         
% Solution for W as function W=W(lambda,K,Q,AH,BH,AN,BN)
W_K   = (W_WH*WH_K) + (W_WN*WN_K);
W_Q   = (W_WH*WH_Q) + (W_WN*WN_Q);
W_G   = (W_WH*WH_G) + (W_WN*WN_G);
W_ASH = (W_WH*WH_ASH) + (W_WN*WN_ASH);
W_BSH = (W_WH*WH_BSH) + (W_WN*WN_BSH);
W_ASN = (W_WH*WH_ASN) + (W_WN*WN_ASN);
W_BSN = (W_WH*WH_BSN) + (W_WN*WN_BSN);
W_ADH = (W_WH*WH_ADH) + (W_WN*WN_ADH);
W_BDH = (W_WH*WH_BDH) + (W_WN*WN_BDH);
W_ADN = (W_WH*WH_ADN) + (W_WN*WN_ADN);
W_BDN = (W_WH*WH_BDN) + (W_WN*WN_BDN);

% Solution for L as function L=L(lambda,K,Q,Aj,Bj)
L_K  = (L_W*W_K) + (L_1PN*PN_K) + (L_1PH*PH_K);
L_Q  = (L_W*W_Q) + (L_1PN*PN_Q) + (L_1PH*PH_Q);
L_G  = (L_W*W_G) + (L_1PN*PN_G) + (L_1PH*PH_G);
L_ASH = (L_W*W_ASH) + (L_1PN*PN_ASH) + (L_1PH*PH_ASH);
L_BSH = (L_W*W_BSH) + (L_1PN*PN_BSH) + (L_1PH*PH_BSH);
L_ASN = (L_W*W_ASN) + (L_1PN*PN_ASN) + (L_1PH*PH_ASN);
L_BSN = (L_W*W_BSN) + (L_1PN*PN_BSN) + (L_1PH*PH_BSN);
L_ADH = (L_W*W_ADH) + (L_1PN*PN_ADH) + (L_1PH*PH_ADH);
L_BDH = (L_W*W_BDH) + (L_1PN*PN_BDH) + (L_1PH*PH_BDH);
L_ADN = (L_W*W_ADN) + (L_1PN*PN_ADN) + (L_1PH*PH_ADN);
L_BDN = (L_W*W_BDN) + (L_1PN*PN_BDN) + (L_1PH*PH_BDN);

% Solution for C as function C=C(lambda,K,Q,Aj,Bj)
C_K     = (C_W*W_K) + (C_1PH*PH_K) + (C_1PN*PN_K);
C_Q     = (C_W*W_Q) + (C_1PH*PH_Q) + (C_1PN*PN_Q);
C_G     = (C_W*W_G) + (C_1PH*PH_G) + (C_1PN*PN_G);
C_ASH   = (C_W*W_ASH) + (C_1PH*PH_ASH) + (C_1PN*PN_ASH);
C_BSH   = (C_W*W_BSH) + (C_1PH*PH_BSH) + (C_1PN*PN_BSH);
C_ASN   = (C_W*W_ASN) + (C_1PH*PH_ASN) + (C_1PN*PN_ASN);
C_BSN   = (C_W*W_BSN) + (C_1PH*PH_BSN) + (C_1PN*PN_BSN);
C_ADH   = (C_W*W_ADH) + (C_1PH*PH_ADH) + (C_1PN*PN_ADH);
C_BDH   = (C_W*W_BDH) + (C_1PH*PH_BDH) + (C_1PN*PN_BDH);
C_ADN   = (C_W*W_ADN) + (C_1PH*PH_ADN) + (C_1PN*PN_ADN);
C_BDN   = (C_W*W_BDN) + (C_1PH*PH_BDN) + (C_1PN*PN_BDN);

% Solution for PC=PC(PH,PN) - PC = PC(K,Q,G,Aj,Bj)
PC_K    = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K;
PC_Q    = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_G    = (PC/PH)*alphaC*alphaH*PH_G + (PC/PN)*(1-alphaC)*PN_G;
PC_ASH  = (PC/PH)*alphaC*alphaH*PH_ASH + (PC/PN)*(1-alphaC)*PN_ASH;
PC_BSH  = (PC/PH)*alphaC*alphaH*PH_BSH + (PC/PN)*(1-alphaC)*PN_BSH;
PC_ASN  = (PC/PH)*alphaC*alphaH*PH_ASN + (PC/PN)*(1-alphaC)*PN_ASN;
PC_BSN  = (PC/PH)*alphaC*alphaH*PH_BSN + (PC/PN)*(1-alphaC)*PN_BSN;
PC_ADH  = (PC/PH)*alphaC*alphaH*PH_ADH + (PC/PN)*(1-alphaC)*PN_ADH;
PC_BDH  = (PC/PH)*alphaC*alphaH*PH_BDH + (PC/PN)*(1-alphaC)*PN_BDH;
PC_ADN  = (PC/PH)*alphaC*alphaH*PH_ADN + (PC/PN)*(1-alphaC)*PN_ADN;
PC_BDN  = (PC/PH)*alphaC*alphaH*PH_BDN + (PC/PN)*(1-alphaC)*PN_BDN;

% Solution for GE=PH*GH + PN*GN + GF - G = G(K,Q,G,Aj,Bj)
G_K    = (PH_K*GH) + (PN_K*GN);
G_Q    = (PH_Q*GH) + (PN_Q*GN);
G_G    = (PH_G*GH) + (PN_G*GN) + (PH*GH_G) + (PN*GN_G); %+ GF_G;
G_ASH  = (PH_ASH*GH) + (PN_ASH*GN);
G_BSH  = (PH_BSH*GH) + (PN_BSH*GN);
G_ASN  = (PH_ASN*GH) + (PN_ASN*GN);
G_BSN  = (PH_BSN*GH) + (PN_BSN*GN);
G_ADH  = (PH_ADH*GH) + (PN_ADH*GN);
G_BDH  = (PH_BDH*GH) + (PN_BDH*GN);
G_ADN  = (PH_ADN*GH) + (PN_ADN*GN);
G_BDN  = (PH_BDN*GH) + (PN_BDN*GN);

% Solution for the stock of financial wealth                                                                                   
A_K   = ((WH_K*LH)+(WN_K*LN))+((WH*LH_K)+(WN*LN_K))-G_K-((PC_K*C)+(PC*C_K));                                                   
A_Q   = ((WH_Q*LH)+(WN_Q*LN))+((WH*LH_Q)+(WN*LN_Q))-G_Q-((PC_Q*C)+(PC*C_Q));                                                   
A_G   = ((WH_G*LH)+(WN_G*LN))+((WH*LH_G)+(WN*LN_G))-G_G-((PC_G*C)+(PC*C_G));                                                   
A_ASH = ((WH_ASH*LH)+(WN_ASH*LN))+((WH*LH_ASH)+(WN*LN_ASH)) - G_ASH - (PC_ASH*C) - (PC*C_ASH);                                 
A_BSH = ((WH_BSH*LH)+(WN_BSH*LN))+((WH*LH_BSH)+(WN*LN_BSH)) - G_BSH - (PC_BSH*C) - (PC*C_BSH);                                 
A_ASN = ((WH_ASN*LH)+(WN_ASN*LN))+((WH*LH_ASN)+(WN*LN_ASN)) - G_ASN - (PC_ASN*C) - (PC*C_ASN);                                 
A_BSN = ((WH_BSN*LH)+(WN_BSN*LN))+((WH*LH_BSN)+(WN*LN_BSN)) - G_BSN - (PC_BSN*C) - (PC*C_BSN);                                 
A_ADH = ((WH_ADH*LH)+(WN_ADH*LN))+((WH*LH_ADH)+(WN*LN_ADH)) - G_ADH - (PC_ADH*C) - (PC*C_ADH);                                 
A_BDH = ((WH_BDH*LH)+(WN_BDH*LN))+((WH*LH_BDH)+(WN*LN_BDH)) - G_BDH - (PC_BDH*C) - (PC*C_BDH);                                 
A_ADN = ((WH_ADN*LH)+(WN_ADN*LN))+((WH*LH_ADN)+(WN*LN_ADN)) - G_ADN - (PC_ADN*C) - (PC*C_ADN);                                 
A_BDN = ((WH_BDN*LH)+(WN_BDN*LN))+((WH*LH_BDN)+(WN*LN_BDN)) - G_BDN - (PC_BDN*C) - (PC*C_BDN);                                 
                                                                                                                               
M1        = A_K + (A_Q*omega_21);                                                                                              
M2        = A_K + (A_Q*omega_22);                                                                                              
                                                                                                                               
wA1    = M1*X11;                                                                                                               
wAASH2 = A_ASH*ASH_0*(1-ThetaASH_prime) + M1*DeltaASH_1*(1-ThetaASH_1prime) - M2*DeltaASH_2*(1-ThetaASH_2prime);               
wABSH2 = A_BSH*BSH_0*(1-ThetaBSH_prime) + M1*DeltaBSH_1*(1-ThetaBSH_1prime) - M2*DeltaBSH_2*(1-ThetaBSH_2prime);               
wAASN2 = A_ASN*ASN_0*(1-ThetaASN_prime) + M1*DeltaASN_1*(1-ThetaASN_1prime) - M2*DeltaASN_2*(1-ThetaASN_2prime);               
wABSN2 = A_BSN*BSN_0*(1-ThetaBSN_prime) + M1*DeltaBSN_1*(1-ThetaBSN_1prime) - M2*DeltaBSN_2*(1-ThetaBSN_2prime);               
                                                                                                                               
wAADH2 = A_ADH*ADH_0*(1-ThetaADH_prime) + M1*DeltaADH_1*(1-ThetaADH_1prime) - M2*DeltaADH_2*(1-ThetaADH_2prime);               
wABDH2 = A_BDH*BDH_0*(1-ThetaBDH_prime) + M1*DeltaBDH_1*(1-ThetaBDH_1prime) - M2*DeltaBDH_2*(1-ThetaBDH_2prime);               
wAADN2 = A_ADN*ADN_0*(1-ThetaADN_prime) + M1*DeltaADN_1*(1-ThetaADN_1prime) - M2*DeltaADN_2*(1-ThetaADN_2prime);               
wABDN2 = A_BDN*BDN_0*(1-ThetaBDN_prime) + M1*DeltaBDN_1*(1-ThetaBDN_1prime) - M2*DeltaBDN_2*(1-ThetaBDN_2prime);               
                                                                                                                               
wAG2   = A_G*Y_0*(1-ThetaG_prime) + M1*DeltaG_1*(1-ThetaG_1prime) - M2*DeltaG_2*(1-ThetaG_2prime);                             

dA_eta0_8402 = (wA1/(r-nu_1)) + (wAG2/(xi+r)) + (wAASH2/(xiASH+r)) + (wABSH2/(xiBSH+r)) + (wAASN2/(xiASN+r)) + (wABSN2/(xiBSN+r)) + (wAADH2/(xiADH+r)) + (wABDH2/(xiBDH+r)) + (wAADN2/(xiADN+r)) + (wABDN2/(xiBDN+r));

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(K,Q,G,Aj,Bj);
P_K   = (P/PN)*PN_K - (P/PH)*PH_K;
P_Q   = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_G   = (P/PN)*PN_G - (P/PH)*PH_G;
P_ASH = (P/PN)*PN_ASH - (P/PH)*PH_ASH;
P_BSH = (P/PN)*PN_BSH - (P/PH)*PH_BSH;
P_ASN = (P/PN)*PN_ASN - (P/PH)*PH_ASN;
P_BSN = (P/PN)*PN_BSN - (P/PH)*PH_BSN;
P_ADH = (P/PN)*PN_ADH - (P/PH)*PH_ADH;
P_BDH = (P/PN)*PN_BDH - (P/PH)*PH_BDH;
P_ADN = (P/PN)*PN_ADN - (P/PH)*PH_ADN;
P_BDN = (P/PN)*PN_BDN - (P/PH)*PH_BDN;

% Solution for Y as function Y=Y(K,Q,lambda,GH,GN)
Y_K   = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K);
Y_Q   = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_G   = (PH_G*YH) + (PH*YH_G) + (PN_G*YN) + (PN*YN_G);
Y_ASH = (PH_ASH*YH) + (PH*YH_ASH) + (PN_ASH*YN) + (PN*YN_ASH);
Y_BSH = (PH_BSH*YH) + (PH*YH_BSH) + (PN_BSH*YN) + (PN*YN_BSH);
Y_ASN = (PH_ASN*YH) + (PH*YH_ASN) + (PN_ASN*YN) + (PN*YN_ASN);
Y_BSN = (PH_BSN*YH) + (PH*YH_BSN) + (PN_BSN*YN) + (PN*YN_BSN);
Y_ADH = (PH_ADH*YH) + (PH*YH_ADH) + (PN_ADH*YN) + (PN*YN_ADH);
Y_BDH = (PH_BDH*YH) + (PH*YH_BDH) + (PN_BDH*YN) + (PN*YN_BDH);
Y_ADN = (PH_ADN*YH) + (PH*YH_ADN) + (PN_ADN*YN) + (PN*YN_ADN);
Y_BDN = (PH_BDN*YH) + (PH*YH_BDN) + (PN_BDN*YN) + (PN*YN_BDN);

% Solution for Real GDP as function YR=YR(K,Q,lambda,GH,GN)
YR_K   = (PH_0*YH_K) + (PN_0*YN_K);
YR_Q   = (PH_0*YH_Q) + (PN_0*YN_Q);
YR_G   = (PH_0*YH_G) + (PN_0*YN_G);
YR_ASH = (PH_0*YH_ASH) + (PN_0*YN_ASH);
YR_BSH = (PH_0*YH_BSH) + (PN_0*YN_BSH);
YR_ASN = (PH_0*YH_ASN) + (PN_0*YN_ASN);
YR_BSN = (PH_0*YH_BSN) + (PN_0*YN_BSN);
YR_ADH = (PH_0*YH_ADH) + (PN_0*YN_ADH);
YR_BDH = (PH_0*YH_BDH) + (PN_0*YN_BDH);
YR_ADN = (PH_0*YH_ADN) + (PN_0*YN_ADN);
YR_BDN = (PH_0*YH_BDN) + (PN_0*YN_BDN);

% Solution for J = J(K,Q,AH,BH,AN,BN)
J_K    = J_1K + (J_PH*PH_K) + (J_PN*PN_K);
J_Q    = J_1Q + (J_PH*PH_Q) + (J_PN*PN_Q);
J_G    = (J_PH*PH_G) + (J_PN*PN_G);
J_ASH  = (J_PH*PH_ASH) + (J_PN*PN_ASH);
J_BSH  = (J_PH*PH_BSH) + (J_PN*PN_BSH);
J_ASN  = (J_PH*PH_ASN) + (J_PN*PN_ASN);
J_BSN  = (J_PH*PH_BSN) + (J_PN*PN_BSN);
J_ADH  = (J_PH*PH_ADH) + (J_PN*PN_ADH);
J_BDH  = (J_PH*PH_BDH) + (J_PN*PN_BDH);
J_ADN  = (J_PH*PH_ADN) + (J_PN*PN_ADN);
J_BDN  = (J_PH*PH_BDN) + (J_PN*PN_BDN);

WHW_K   = (WH/W)*( (WH_K/WH) - (W_K/W) );
WHW_Q   = (WH/W)*( (WH_Q/WH) - (W_Q/W) );
WHW_G   = (WH/W)*( (WH_G/WH) - (W_G/W) );
WHW_ASH = (WH/W)*( (WH_ASH/WH) - (W_ASH/W) );
WHW_BSH = (WH/W)*( (WH_BSH/WH) - (W_BSH/W) );
WHW_ASN = (WH/W)*( (WH_ASN/WH) - (W_ASN/W) );
WHW_BSN = (WH/W)*( (WH_BSN/WH) - (W_BSN/W) );
WHW_ADH = (WH/W)*( (WH_ADH/WH) - (W_ADH/W) );
WHW_BDH = (WH/W)*( (WH_BDH/WH) - (W_BDH/W) );
WHW_ADN = (WH/W)*( (WH_ADN/WH) - (W_ADN/W) );
WHW_BDN = (WH/W)*( (WH_BDN/WH) - (W_BDN/W) );

WNW_K   = (WN/W)*( (WN_K/WN) - (W_K/W) );
WNW_Q   = (WN/W)*( (WN_Q/WN) - (W_Q/W) );
WNW_G   = (WN/W)*( (WN_G/WN) - (W_G/W) );
WNW_ASH = (WN/W)*( (WN_ASH/WN) - (W_ASH/W) );
WNW_BSH = (WN/W)*( (WN_BSH/WN) - (W_BSH/W) );
WNW_ASN = (WN/W)*( (WN_ASN/WN) - (W_ASN/W) );
WNW_BSN = (WN/W)*( (WN_BSN/WN) - (W_BSN/W) );
WNW_ADH = (WN/W)*( (WN_ADH/WN) - (W_ADH/W) );
WNW_BDH = (WN/W)*( (WN_BDH/WN) - (W_BDH/W) );
WNW_ADN = (WN/W)*( (WN_ADN/WN) - (W_ADN/W) );
WNW_BDN = (WN/W)*( (WN_BDN/WN) - (W_BDN/W) );

Omega_K    = Omega*( (WN_K/WN) - (WH_K/WH) );
Omega_Q    = Omega*( (WN_Q/WN) - (WH_Q/WH) );
Omega_G    = Omega*( (WN_G/WN) - (WH_G/WH) );
Omega_ASH  = Omega*( (WN_ASH/WN) - (WH_ASH/WH) );
Omega_BSH  = Omega*( (WN_BSH/WN) - (WH_BSH/WH) );
Omega_ASN  = Omega*( (WN_ASN/WN) - (WH_ASN/WH) );
Omega_BSN  = Omega*( (WN_BSN/WN) - (WH_BSN/WH) );
Omega_ADH  = Omega*( (WN_ADH/WN) - (WH_ADH/WH) );
Omega_BDH  = Omega*( (WN_BDH/WN) - (WH_BDH/WH) );
Omega_ADN  = Omega*( (WN_ADN/WN) - (WH_ADN/WH) );
Omega_BDN  = Omega*( (WN_BDN/WN) - (WH_BDN/WH) );

% Solution for Wj/PC,W/PC(K,Q,G,Aj,Bj)
WHPC_K   = WHPC*( (WH_K/WH) - (PC_K/PC) );
WHPC_Q   = WHPC*( (WH_Q/WH) - (PC_Q/PC) );
WHPC_G   = WHPC*( (WH_G/WH) - (PC_G/PC) );
WHPC_ASH = WHPC*( (WH_ASH/WH) - (PC_ASH/PC) );
WHPC_BSH = WHPC*( (WH_BSH/WH) - (PC_BSH/PC) );
WHPC_ASN = WHPC*( (WH_ASN/WH) - (PC_ASN/PC) );
WHPC_BSN = WHPC*( (WH_BSN/WH) - (PC_BSN/PC) );
WHPC_ADH = WHPC*( (WH_ADH/WH) - (PC_ADH/PC) );
WHPC_BDH = WHPC*( (WH_BDH/WH) - (PC_BDH/PC) );
WHPC_ADN = WHPC*( (WH_ADN/WH) - (PC_ADN/PC) );
WHPC_BDN = WHPC*( (WH_BDN/WH) - (PC_BDN/PC) );

WNPC_K   = WNPC*( (WN_K/WN) - (PC_K/PC) );
WNPC_Q   = WNPC*( (WN_Q/WN) - (PC_Q/PC) );
WNPC_G   = WNPC*( (WN_G/WN) - (PC_G/PC) );
WNPC_ASH = WNPC*( (WN_AH/WN) - (PC_ASH/PC) );
WNPC_BSH = WNPC*( (WN_BH/WN) - (PC_BSH/PC) );
WNPC_ASN = WNPC*( (WN_AN/WN) - (PC_ASN/PC) );
WNPC_BSN = WNPC*( (WN_BN/WN) - (PC_BSN/PC) );
WNPC_ADH = WNPC*( (WN_AH/WN) - (PC_ADH/PC) );
WNPC_BDH = WNPC*( (WN_BH/WN) - (PC_BDH/PC) );
WNPC_ADN = WNPC*( (WN_AN/WN) - (PC_ADN/PC) );
WNPC_BDN = WNPC*( (WN_BN/WN) - (PC_BDN/PC) );

WPC_K   = WPC*( (W_K/W) - (PC_K/PC) );
WPC_Q   = WPC*( (W_Q/W) - (PC_Q/PC) );
WPC_G   = WPC*( (W_G/W) - (PC_G/PC) );
WPC_ASH = WPC*( (W_ASH/W) - (PC_ASH/PC) );
WPC_BSH = WPC*( (W_BSH/W) - (PC_BSH/PC) );
WPC_ASN = WPC*( (W_ASN/W) - (PC_ASN/PC) );
WPC_BSN = WPC*( (W_BSN/W) - (PC_BSN/PC) );
WPC_ADH = WPC*( (W_ADH/W) - (PC_ADH/PC) );
WPC_BDH = WPC*( (W_BDH/W) - (PC_BDH/PC) );
WPC_ADN = WPC*( (W_ADN/W) - (PC_ADN/PC) );
WPC_BDN = WPC*( (W_BDN/W) - (PC_BDN/PC) );

% Solution for PI=PI(PH,PN) - PI = PI(K,Q,G,Aj,Bj)
PI_K   = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K;
PI_Q   = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_G   = (PI/PH)*alphaI*alphaIH*PH_G + (PI/PN)*(1-alphaI)*PN_G;
PI_ASH  = (PI/PH)*alphaI*alphaIH*PH_ASH + (PI/PN)*(1-alphaI)*PN_ASH;
PI_BSH  = (PI/PH)*alphaI*alphaIH*PH_BSH + (PI/PN)*(1-alphaI)*PN_BSH;
PI_ASN  = (PI/PH)*alphaI*alphaIH*PH_ASN + (PI/PN)*(1-alphaI)*PN_ASN;
PI_BSN  = (PI/PH)*alphaI*alphaIH*PH_BSN + (PI/PN)*(1-alphaI)*PN_BSN;
PI_ADH  = (PI/PH)*alphaI*alphaIH*PH_ADH + (PI/PN)*(1-alphaI)*PN_ADH;
PI_BDH  = (PI/PH)*alphaI*alphaIH*PH_BDH + (PI/PN)*(1-alphaI)*PN_BDH;
PI_ADN  = (PI/PH)*alphaI*alphaIH*PH_ADN + (PI/PN)*(1-alphaI)*PN_ADN;
PI_BDN  = (PI/PH)*alphaI*alphaIH*PH_BDN + (PI/PN)*(1-alphaI)*PN_BDN;

% RjPj=Rj/Pj=Rj(K,Q,G,Aj,Bj);
RHPH_K  = (RH/PH)*((RH_K/RK) - (PH_K/PH));
RHPH_Q  = (RH/PH)*((RH_Q/RK) - (PH_Q/PH));
RHPH_G  = (RH/PH)*((RH_G/RK) - (PH_G/PH));
RHPH_ASH = (RH/PH)*((RH_ASH/RK) - (PH_ASH/PH));
RHPH_BSH = (RH/PH)*((RH_BSH/RK) - (PH_BSH/PH));
RHPH_ASN = (RH/PH)*((RH_ASN/RK) - (PH_ASN/PH));
RHPH_BSN = (RH/PH)*((RH_BSN/RK) - (PH_BSN/PH));
RHPH_ADH = (RH/PH)*((RH_ADH/RK) - (PH_ADH/PH));
RHPH_BDH = (RH/PH)*((RH_BDH/RK) - (PH_BDH/PH));
RHPH_ADN = (RH/PH)*((RH_ADN/RK) - (PH_ADN/PH));
RHPH_BDN = (RH/PH)*((RH_BDN/RK) - (PH_BDN/PH));

RNPN_K  = (RN/PN)*((RN_K/RK) - (PN_K/PN));
RNPN_Q  = (RN/PN)*((RN_Q/RK) - (PN_Q/PN));
RNPN_G  = (RN/PN)*((RN_G/RK) - (PN_G/PN));
RNPN_ASH = (RN/PN)*((RN_ASH/RK) - (PN_ASH/PN));
RNPN_BSH = (RN/PN)*((RN_BSH/RK) - (PN_BSH/PN));
RNPN_ASN = (RN/PN)*((RN_ASN/RK) - (PN_ASN/PN));
RNPN_BSN = (RN/PN)*((RN_BSN/RK) - (PN_BSN/PN));
RNPN_ADH = (RN/PN)*((RN_ADH/RK) - (PN_ADH/PN));
RNPN_BDH = (RN/PN)*((RN_BDH/RK) - (PN_BDH/PN));
RNPN_ADN = (RN/PN)*((RN_ADN/RK) - (PN_ADN/PN));
RNPN_BDN = (RN/PN)*((RN_BDN/RK) - (PN_BDN/PN));

% Solution for the labor income share sLj=LISj(K,Q,G,Aj,Bj)=Wj*Lj/Pj*Yj
LISH_K  = sLH*( (WH_K/WH) + (LH_K/LH) - (PH_K/PH) - (YH_K/YH) );
LISH_Q  = sLH*( (WH_Q/WH) + (LH_Q/LH) - (PH_Q/PH) - (YH_Q/YH) );
LISH_G  = sLH*( (WH_G/WH) + (LH_G/LH) - (PH_G/PH) - (YH_G/YH) );
LISH_ASH = sLH*( (WH_ASH/WH) + (LH_ASH/LH) - (PH_ASH/PH) - (YH_ASH/YH) );
LISH_BSH = sLH*( (WH_BSH/WH) + (LH_BSH/LH) - (PH_BSH/PH) - (YH_BSH/YH) );
LISH_ASN = sLH*( (WH_ASN/WH) + (LH_ASN/LH) - (PH_ASN/PH) - (YH_ASN/YH) );
LISH_BSN = sLH*( (WH_BSN/WH) + (LH_BSN/LH) - (PH_BSN/PH) - (YH_BSN/YH) );
LISH_ADH = sLH*( (WH_ADH/WH) + (LH_ADH/LH) - (PH_ADH/PH) - (YH_ADH/YH) );
LISH_BDH = sLH*( (WH_BDH/WH) + (LH_BDH/LH) - (PH_BDH/PH) - (YH_BDH/YH) );
LISH_ADN = sLH*( (WH_ADN/WH) + (LH_ADN/LH) - (PH_ADN/PH) - (YH_ADN/YH) );
LISH_BDN = sLH*( (WH_BDN/WH) + (LH_BDN/LH) - (PH_BDN/PH) - (YH_BDN/YH) );

LISN_K  = sLN*( (WN_K/WN) + (LN_K/LN) - (PN_K/PN) - (YN_K/YN) );
LISN_Q  = sLN*( (WN_Q/WN) + (LN_Q/LN) - (PN_Q/PN) - (YN_Q/YN) );
LISN_G  = sLN*( (WN_G/WN) + (LN_G/LN) - (PN_G/PN) - (YN_G/YN) );
LISN_ASH = sLN*( (WN_ASH/WN) + (LN_ASH/LN) - (PN_ASH/PN) - (YN_ASH/YN) );
LISN_BSH = sLN*( (WN_BSH/WN) + (LN_BSH/LN) - (PN_BSH/PN) - (YN_BSH/YN) );
LISN_ASN = sLN*( (WN_ASN/WN) + (LN_ASN/LN) - (PN_ASN/PN) - (YN_ASN/YN) );
LISN_BSN = sLN*( (WN_BSN/WN) + (LN_BSN/LN) - (PN_BSN/PN) - (YN_BSN/YN) );
LISN_ADH = sLN*( (WN_ADH/WN) + (LN_ADH/LN) - (PN_ADH/PN) - (YN_ADH/YN) );
LISN_BDH = sLN*( (WN_BDH/WN) + (LN_BDH/LN) - (PN_BDH/PN) - (YN_BDH/YN) );
LISN_ADN = sLN*( (WN_ADN/WN) + (LN_ADN/LN) - (PN_ADN/PN) - (YN_ADN/YN) );
LISN_BDN = sLN*( (WN_BDN/WN) + (LN_BDN/LN) - (PN_BDN/PN) - (YN_BDN/YN) );

% Solution for LH(K,Q,G,Aj,Bj)/LN(K,Q,G,Aj,Bj)
LHLN_K = (LH/LN)*( (LH_K/LH) - (LN_K/LN) );
LHLN_Q = (LH/LN)*( (LH_Q/LH) - (LN_Q/LN) );
LHLN_G = (LH/LN)*( (LH_G/LH) - (LN_G/LN) );
LHLN_ASH = (LH/LN)*( (LH_ASH/LH) - (LN_ASH/LN) );
LHLN_BSH = (LH/LN)*( (LH_BSH/LH) - (LN_BSH/LN) );
LHLN_ASN = (LH/LN)*( (LH_ASN/LH) - (LN_ASN/LN) );
LHLN_BSN = (LH/LN)*( (LH_BSN/LH) - (LN_BSN/LN) );
LHLN_ADH = (LH/LN)*( (LH_ADH/LH) - (LN_ADH/LN) );
LHLN_BDH = (LH/LN)*( (LH_BDH/LH) - (LN_BDH/LN) );
LHLN_ADN = (LH/LN)*( (LH_ADN/LH) - (LN_ADN/LN) );
LHLN_BDN = (LH/LN)*( (LH_BDN/LH) - (LN_BDN/LN) );

% Solution for YH(K,Q,G,Aj,Bj)/YN(K,Q,G,Aj,Bj)
YHYN_K = (YH/YN)*( (YH_K/YH) - (YN_K/YN) );
YHYN_Q = (YH/YN)*( (YH_Q/YH) - (YN_Q/YN) );
YHYN_G = (YH/YN)*( (YH_G/YH) - (YN_G/YN) );
YHYN_ASH = (YH/YN)*( (YH_ASH/YH) - (YN_ASH/YN) );
YHYN_BSH = (YH/YN)*( (YH_BSH/YH) - (YN_BSH/YN) );
YHYN_ASN = (YH/YN)*( (YH_ASN/YH) - (YN_ASN/YN) );
YHYN_BSN = (YH/YN)*( (YH_BSN/YH) - (YN_BSN/YN) );
YHYN_ADH = (YH/YN)*( (YH_ADH/YH) - (YN_ADH/YN) );
YHYN_BDH = (YH/YN)*( (YH_BDH/YH) - (YN_BDH/YN) );
YHYN_ADN = (YH/YN)*( (YH_ADN/YH) - (YN_ADN/YN) );
YHYN_BDN = (YH/YN)*( (YH_BDN/YH) - (YN_BDN/YN) );

% Solutions for the employment shares Lj/L=(Lj/L)(K,Q,G,Aj,Bj)
LHS_K  = (LH/L)*((LH_K/LH)-(L_K/L));
LHS_Q  = (LH/L)*((LH_Q/LH)-(L_Q/L));
LHS_G  = (LH/L)*((LH_G/LH)-(L_G/L));
LHS_ASH  = (LH/L)*((LH_ASH/LH)-(L_ASH/L));
LHS_BSH  = (LH/L)*((LH_BSH/LH)-(L_BSH/L));
LHS_ASN  = (LH/L)*((LH_ASN/LH)-(L_ASN/L));
LHS_BSN  = (LH/L)*((LH_BSN/LH)-(L_BSN/L));
LHS_ADH  = (LH/L)*((LH_ADH/LH)-(L_ADH/L));
LHS_BDH  = (LH/L)*((LH_BDH/LH)-(L_BDH/L));
LHS_ADN  = (LH/L)*((LH_ADN/LH)-(L_ADN/L));
LHS_BDN  = (LH/L)*((LH_BDN/LH)-(L_BDN/L));

LNS_K  = (LN/L)*((LN_K/LN)-(L_K/L));
LNS_Q  = (LN/L)*((LN_Q/LN)-(L_Q/L));
LNS_G  = (LN/L)*((LN_G/LN)-(L_G/L));
LNS_ASH  = (LN/L)*((LN_ASH/LN)-(L_ASH/L));
LNS_BSH  = (LN/L)*((LN_BSH/LN)-(L_BSH/L));
LNS_ASN  = (LN/L)*((LN_ASN/LN)-(L_ASN/L));
LNS_BSN  = (LN/L)*((LN_BSN/LN)-(L_BSN/L));
LNS_ADH  = (LN/L)*((LN_ADH/LN)-(L_ADH/L));
LNS_BDH  = (LN/L)*((LN_BDH/LN)-(L_BDH/L));
LNS_ADN  = (LN/L)*((LN_ADN/LN)-(L_ADN/L));
LNS_BDN  = (LN/L)*((LN_BDN/LN)-(L_BDN/L));

% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(K,Q,G,Aj,Bj)
YHS_K  = (YH/YR)*( (YH_K/YH) - (YR_K/YR) );
YHS_Q  = (YH/YR)*( (YH_Q/YH) - (YR_Q/YR) );
YHS_G  = (YH/YR)*( (YH_G/YH) - (YR_G/YR) );
YHS_ASH  = (YH/YR)*( (YH_ASH/YH) - (YR_ASH/YR) );
YHS_BSH  = (YH/YR)*( (YH_BSH/YH) - (YR_BSH/YR) );
YHS_ASN  = (YH/YR)*( (YH_ASN/YH) - (YR_ASN/YR) );
YHS_BSN  = (YH/YR)*( (YH_BSN/YH) - (YR_BSN/YR) );
YHS_ADH  = (YH/YR)*( (YH_ADH/YH) - (YR_ADH/YR) );
YHS_BDH  = (YH/YR)*( (YH_BDH/YH) - (YR_BDH/YR) );
YHS_ADN  = (YH/YR)*( (YH_ADN/YH) - (YR_ADN/YR) );
YHS_BDN  = (YH/YR)*( (YH_BDN/YH) - (YR_BDN/YR) );

YNS_K  = (YN/YR)*( (YN_K/YN) - (YR_K/YR) );
YNS_Q  = (YN/YR)*( (YN_Q/YN) - (YR_Q/YR) );
YNS_G  = (YN/YR)*( (YN_G/YN) - (YR_G/YR) );
YNS_ASH  = (YN/YR)*( (YN_ASH/YN) - (YR_ASH/YR) );
YNS_BSH  = (YN/YR)*( (YN_BSH/YN) - (YR_BSH/YR) );
YNS_ASN  = (YN/YR)*( (YN_ASN/YN) - (YR_ASN/YR) );
YNS_BSN  = (YN/YR)*( (YN_BSN/YN) - (YR_BSN/YR) );
YNS_ADH  = (YN/YR)*( (YN_ADH/YN) - (YR_ADH/YR) );
YNS_BDH  = (YN/YR)*( (YN_BDH/YN) - (YR_BDH/YR) );
YNS_ADN  = (YN/YR)*( (YN_ADN/YN) - (YR_ADN/YR) );
YNS_BDN  = (YN/YR)*( (YN_BDN/YN) - (YR_BDN/YR) );

% Solutions for the Kj/K: Kj/K=Kj/K(lambda,K,Q,AH,BH,AN,BN)
KHK_K  = (KH/K)*( (KH_K/KH) - (1/K) );
KHK_Q  = (KH/K)*(KH_Q/KH);
KHK_G  = (KH/K)*(KH_G/KH);
KHK_ASH = (KH/K)*(KH_ASH/KH);
KHK_BSH = (KH/K)*(KH_BSH/KH);
KHK_ASN = (KH/K)*(KH_ASN/KH);
KHK_BSN = (KH/K)*(KH_BSN/KH);
KHK_ADH = (KH/K)*(KH_ADH/KH);
KHK_BDH = (KH/K)*(KH_BDH/KH);
KHK_ADN = (KH/K)*(KH_ADN/KH);
KHK_BDN = (KH/K)*(KH_BDN/KH);

KNK_K  = (KN/K)*( (KN_K/KN) - (1/K) );
KNK_Q  = (KN/K)*(KN_Q/KN);
KNK_G  = (KN/K)*(KN_G/KN);
KNK_ASH = (KN/K)*(KN_ASH/KN);
KNK_BSH = (KN/K)*(KN_BSH/KN);
KNK_ASN = (KN/K)*(KN_ASN/KN);
KNK_BSN = (KN/K)*(KN_BSN/KN);
KNK_ADH = (KN/K)*(KN_ADH/KN);
KNK_BDH = (KN/K)*(KN_BDH/KN);
KNK_ADN = (KN/K)*(KN_ADN/KN);
KNK_BDN = (KN/K)*(KN_BDN/KN);

% Solution for RK as function RK=R(lambda,K,Q,G,AH,BH,AN,BN)
R_K       = (R_RH*RH_K) + (R_RN*RN_K);
R_Q       = (R_RH*RH_Q) + (R_RN*RN_Q);
R_G       = (R_RH*RH_G) + (R_RN*RN_G);
R_ASH     = (R_RH*RH_ASH) + (R_RN*RN_ASH);
R_BSH     = (R_RH*RH_BSH) + (R_RN*RN_BSH);
R_ASN     = (R_RH*RH_ASN) + (R_RN*RN_ASN);
R_BSN     = (R_RH*RH_BSN) + (R_RN*RN_BSN);
R_ADH     = (R_RH*RH_ADH) + (R_RN*RN_ADH);  
R_BDH     = (R_RH*RH_BDH) + (R_RN*RN_BDH);  
R_ADN     = (R_RH*RH_ADN) + (R_RN*RN_ADN);  
R_BDN     = (R_RH*RH_BDN) + (R_RN*RN_BDN);  

% Solutions for the kj=Kj/Lj(lambda,K,Q,AH,BH,AN,BN)
kH_K   = (KH/LH)*( (KH_K/KH) - (LH_K/LH) );
kH_Q   = (KH/LH)*( (KH_Q/KH) - (LH_Q/LH) );
kH_G   = (KH/LH)*( (KH_G/KH) - (LH_G/LH) );
kH_ASH = (KH/LH)*( (KH_ASH/KH) - (LH_ASH/LH) );
kH_BSH = (KH/LH)*( (KH_BSH/KH) - (LH_BSH/LH) );
kH_ASN = (KH/LH)*( (KH_ASN/KH) - (LH_ASN/LH) );
kH_BSN = (KH/LH)*( (KH_BSN/KH) - (LH_BSN/LH) );
kH_ADH = (KH/LH)*( (KH_ADH/KH) - (LH_ADH/LH) );
kH_BDH = (KH/LH)*( (KH_BDH/KH) - (LH_BDH/LH) );
kH_ADN = (KH/LH)*( (KH_ADN/KH) - (LH_ADN/LH) );
kH_BDN = (KH/LH)*( (KH_BDN/KH) - (LH_BDN/LH) );

kN_K   = (KN/LN)*( (KN_K/KN) - (LN_K/LN) );
kN_Q   = (KN/LN)*( (KN_Q/KN) - (LN_Q/LN) );
kN_G   = (KN/LN)*( (KN_G/KN) - (LN_G/LN) );
kN_ASH = (KN/LN)*( (KN_ASH/KN) - (LN_ASH/LN) );
kN_BSH = (KN/LN)*( (KN_BSH/KN) - (LN_BSH/LN) );
kN_ASN = (KN/LN)*( (KN_ASN/KN) - (LN_ASN/LN) );
kN_BSN = (KN/LN)*( (KN_BSN/KN) - (LN_BSN/LN) );
kN_ADH = (KN/LN)*( (KN_ADH/KN) - (LN_ADH/LN) );
kN_BDH = (KN/LN)*( (KN_BDH/KN) - (LN_BDH/LN) );
kN_ADN = (KN/LN)*( (KN_ADN/KN) - (LN_ADN/LN) );
kN_BDN = (KN/LN)*( (KN_BDN/KN) - (LN_BDN/LN) );

% Solutions for the alphaKj=Rj*Kj/RK*K(lambda,K,Q,G,AH,BH,AN,BN)
alphaKH_K  = alphaK*( (RH_K/RH)  + (KH_K/KH)  - (R_K/RK)  - (1/K) );
alphaKH_Q  = alphaK*( (RH_Q/RH)  + (KH_Q/KH)  - (R_Q/RK)  );
alphaKH_G  = alphaK*( (RH_G/RH)  + (KH_G/KH)  - (R_G/RK)  );
alphaKH_ASH = alphaK*( (RH_ASH/RH) + (KH_ASH/KH) - (R_ASH/RK) );
alphaKH_BSH = alphaK*( (RH_BSH/RH) + (KH_BSH/KH) - (R_BSH/RK) );
alphaKH_ASN = alphaK*( (RH_ASN/RH) + (KH_ASN/KH) - (R_ASN/RK) );
alphaKH_BSN = alphaK*( (RH_BSN/RH) + (KH_BSN/KH) - (R_BSN/RK) );
alphaKH_ADH = alphaK*( (RH_ADH/RH) + (KH_ADH/KH) - (R_ADH/RK) );
alphaKH_BDH = alphaK*( (RH_BDH/RH) + (KH_BDH/KH) - (R_BDH/RK) );
alphaKH_ADN = alphaK*( (RH_ADN/RH) + (KH_ADN/KH) - (R_ADN/RK) );
alphaKH_BDN = alphaK*( (RH_BDN/RH) + (KH_BDN/KH) - (R_BDN/RK) );

alphaKN_K  = (1-alphaK)*( (RN_K/RN)  + (KN_K/KN)  - (R_K/RK)  - (1/K) );
alphaKN_Q  = (1-alphaK)*( (RN_Q/RN)  + (KN_Q/KN)  - (R_Q/RK)  );
alphaKN_G  = (1-alphaK)*( (RN_G/RN)  + (KN_G/KN)  - (R_G/RK)  );
alphaKN_ASH = (1-alphaK)*( (RN_ASH/RN) + (KN_ASH/KN) - (R_ASH/RK) );
alphaKN_BSH = (1-alphaK)*( (RN_BSH/RN) + (KN_BSH/KN) - (R_BSH/RK) );
alphaKN_ASN = (1-alphaK)*( (RN_ASN/RN) + (KN_ASN/KN) - (R_ASN/RK) );
alphaKN_BSN = (1-alphaK)*( (RN_BSN/RN) + (KN_BSN/KN) - (R_BSN/RK) );
alphaKN_ADH = (1-alphaK)*( (RN_ADH/RN) + (KN_ADH/KN) - (R_ADH/RK) );
alphaKN_BDH = (1-alphaK)*( (RN_BDH/RN) + (KN_BDH/KN) - (R_BDH/RK) );
alphaKN_ADN = (1-alphaK)*( (RN_ADN/RN) + (KN_ADN/KN) - (R_ADN/RK) );
alphaKN_BDN = (1-alphaK)*( (RN_BDN/RN) + (KN_BDN/KN) - (R_BDN/RK) );

% uKHj = (uKSj)^eta*(uKDj)^(1-eta)
uKH_K   = (eta*uKSH_K) + (1-eta)*uKDH_K;
uKH_Q   = (eta*uKSH_Q) + (1-eta)*uKDH_Q;
uKH_G   = (eta*uKSH_G) + (1-eta)*uKDH_G;
uKH_ASH = (eta*uKSH_ASH) + (1-eta)*uKDH_ASH;
uKH_BSH = (eta*uKSH_BSH) + (1-eta)*uKDH_BSH;
uKH_ASN = (eta*uKSH_ASN) + (1-eta)*uKDH_ASN;
uKH_BSN = (eta*uKSH_BSN) + (1-eta)*uKDH_BSN;
uKH_ADH = (eta*uKSH_ADH) + (1-eta)*uKDH_ADH;
uKH_BDH = (eta*uKSH_BDH) + (1-eta)*uKDH_BDH;
uKH_ADN = (eta*uKSH_ADN) + (1-eta)*uKDH_ADN;
uKH_BDN = (eta*uKSH_BDN) + (1-eta)*uKDH_BDN;

uKN_K   = (eta*uKSN_K)   + (1-eta)*uKDN_K;
uKN_Q   = (eta*uKSN_Q)   + (1-eta)*uKDN_Q;
uKN_G   = (eta*uKSN_G)   + (1-eta)*uKDN_G;
uKN_ASH = (eta*uKSN_ASH) + (1-eta)*uKDN_ASH;
uKN_BSH = (eta*uKSN_BSH) + (1-eta)*uKDN_BSH;
uKN_ASN = (eta*uKSN_ASN) + (1-eta)*uKDN_ASN;
uKN_BSN = (eta*uKSN_BSN) + (1-eta)*uKDN_BSN;
uKN_ADH = (eta*uKSN_ADH) + (1-eta)*uKDN_ADH;
uKN_BDH = (eta*uKSN_BDH) + (1-eta)*uKDN_BDH;
uKN_ADN = (eta*uKSN_ADN) + (1-eta)*uKDN_ADN;
uKN_BDN = (eta*uKSN_BDN) + (1-eta)*uKDN_BDN;

% Aggregate capital utilization rate uK = (alphaK*uKH) + (1-alphaK)*uKN
uK_K   = alphaKH_K  + alphaKN_K  + (alphaK*uKH_K)  + (1-alphaK)*uKN_K;
uK_Q   = alphaKH_Q  + alphaKN_Q  + (alphaK*uKH_Q)  + (1-alphaK)*uKN_Q;
uK_G   = alphaKH_G  + alphaKN_G  + (alphaK*uKH_G)  + (1-alphaK)*uKN_G;
uK_ASH = alphaKH_ASH + alphaKN_ASH + (alphaK*uKH_ASH) + (1-alphaK)*uKN_ASH;
uK_BSH = alphaKH_BSH + alphaKN_BSH + (alphaK*uKH_BSH) + (1-alphaK)*uKN_BSH;
uK_ASN = alphaKH_ASN + alphaKN_ASN + (alphaK*uKH_ASN) + (1-alphaK)*uKN_ASN;
uK_BSN = alphaKH_BSN + alphaKN_BSN + (alphaK*uKH_BSN) + (1-alphaK)*uKN_BSN;
uK_ADH = alphaKH_ADH + alphaKN_ADH + (alphaK*uKH_ADH) + (1-alphaK)*uKN_ADH;
uK_BDH = alphaKH_BDH + alphaKN_BDH + (alphaK*uKH_BDH) + (1-alphaK)*uKN_BDH;
uK_ADN = alphaKH_ADN + alphaKN_ADN + (alphaK*uKH_ADN) + (1-alphaK)*uKN_ADN;
uK_BDN = alphaKH_BDN + alphaKN_BDN + (alphaK*uKH_BDN) + (1-alphaK)*uKN_BDN;

% Solutions TFPj(K,Q,G,Aj,Bj);
TFPH_K    = (ZH/YH)*YH_K  - sLH*(ZH/LH)*LH_K  - (1-sLH)*(ZH/KH)*KH_K;
TFPH_Q    = (ZH/YH)*YH_Q  - sLH*(ZH/LH)*LH_Q  - (1-sLH)*(ZH/KH)*KH_Q;
TFPH_G    = (ZH/YH)*YH_G  - sLH*(ZH/LH)*LH_G  - (1-sLH)*(ZH/KH)*KH_G;
TFPH_ASH  = (ZH/YH)*YH_ASH - sLH*(ZH/LH)*LH_ASH - (1-sLH)*(ZH/KH)*KH_ASH;
TFPH_BSH  = (ZH/YH)*YH_BSH - sLH*(ZH/LH)*LH_BSH - (1-sLH)*(ZH/KH)*KH_BSH;
TFPH_ASN  = (ZH/YH)*YH_ASN - sLH*(ZH/LH)*LH_ASN - (1-sLH)*(ZH/KH)*KH_ASN;
TFPH_BSN  = (ZH/YH)*YH_BSN - sLH*(ZH/LH)*LH_BSN - (1-sLH)*(ZH/KH)*KH_BSN;
TFPH_ADH  = (ZH/YH)*YH_ADH - sLH*(ZH/LH)*LH_ADH - (1-sLH)*(ZH/KH)*KH_ADH;
TFPH_BDH  = (ZH/YH)*YH_BDH - sLH*(ZH/LH)*LH_BDH - (1-sLH)*(ZH/KH)*KH_BDH;
TFPH_ADN  = (ZH/YH)*YH_ADN - sLH*(ZH/LH)*LH_ADN - (1-sLH)*(ZH/KH)*KH_ADN;
TFPH_BDN  = (ZH/YH)*YH_BDN - sLH*(ZH/LH)*LH_BDN - (1-sLH)*(ZH/KH)*KH_BDN;

TFPN_K    = (ZN/YN)*YN_K  - sLN*(ZN/LN)*LN_K  - (1-sLN)*(ZN/KN)*KN_K;
TFPN_Q    = (ZN/YN)*YN_Q  - sLN*(ZN/LN)*LN_Q  - (1-sLN)*(ZN/KN)*KN_Q;
TFPN_G    = (ZN/YN)*YN_G  - sLN*(ZN/LN)*LN_G  - (1-sLN)*(ZN/KN)*KN_G;
TFPN_ASH  = (ZN/YN)*YN_ASH - sLN*(ZN/LN)*LN_ASH - (1-sLN)*(ZN/KN)*KN_ASH;
TFPN_BSH  = (ZN/YN)*YN_BSH - sLN*(ZN/LN)*LN_BSH - (1-sLN)*(ZN/KN)*KN_BSH;
TFPN_ASN  = (ZN/YN)*YN_ASN - sLN*(ZN/LN)*LN_ASN - (1-sLN)*(ZN/KN)*KN_ASN;
TFPN_BSN  = (ZN/YN)*YN_BSN - sLN*(ZN/LN)*LN_BSN - (1-sLN)*(ZN/KN)*KN_BSN;
TFPN_ADH  = (ZN/YN)*YN_ADH - sLN*(ZN/LN)*LN_ADH - (1-sLN)*(ZN/KN)*KN_ADH;
TFPN_BDH  = (ZN/YN)*YN_BDH - sLN*(ZN/LN)*LN_BDH - (1-sLN)*(ZN/KN)*KN_BDH;
TFPN_ADN  = (ZN/YN)*YN_ADN - sLN*(ZN/LN)*LN_ADN - (1-sLN)*(ZN/KN)*KN_ADN;
TFPN_BDN  = (ZN/YN)*YN_BDN - sLN*(ZN/LN)*LN_BDN - (1-sLN)*(ZN/KN)*KN_BDN;

TFPA_K    =  omegaYH*(Z/ZH)*TFPH_K + (1-omegaYH)*(Z/ZN)*TFPN_K;      
TFPA_Q    =  omegaYH*(Z/ZH)*TFPH_Q + (1-omegaYH)*(Z/ZN)*TFPN_Q;      
TFPA_G    =  omegaYH*(Z/ZH)*TFPH_G + (1-omegaYH)*(Z/ZN)*TFPN_G;      
TFPA_ASH  =  omegaYH*(Z/ZH)*TFPH_ASH + (1-omegaYH)*(Z/ZN)*TFPN_ASH;  
TFPA_BSH  =  omegaYH*(Z/ZH)*TFPH_BSH + (1-omegaYH)*(Z/ZN)*TFPN_BSH;  
TFPA_ASN  =  omegaYH*(Z/ZH)*TFPH_ASN + (1-omegaYH)*(Z/ZN)*TFPN_ASN;  
TFPA_BSN  =  omegaYH*(Z/ZH)*TFPH_BSN + (1-omegaYH)*(Z/ZN)*TFPN_BSN;  
TFPA_ADH  =  omegaYH*(Z/ZH)*TFPH_ADH + (1-omegaYH)*(Z/ZN)*TFPN_ADH;  
TFPA_BDH  =  omegaYH*(Z/ZH)*TFPH_BDH + (1-omegaYH)*(Z/ZN)*TFPN_BDH;  
TFPA_ADN  =  omegaYH*(Z/ZH)*TFPH_ADN + (1-omegaYH)*(Z/ZN)*TFPN_ADN;  
TFPA_BDN  =  omegaYH*(Z/ZH)*TFPH_BDN + (1-omegaYH)*(Z/ZN)*TFPN_BDN;  

TFPH_K_check   = (1-sLH)*ZH*uKH_K;
TFPH_Q_check   = (1-sLH)*ZH*uKH_Q;
TFPH_G_check   = (1-sLH)*ZH*uKH_G;
TFPH_ASH_check = sLH*(ZH/AH)*AH_ASH + (1-sLH)*ZH*uKH_ASH;
TFPH_BSH_check = (1-sLH)*(ZH/BH)*BH_BSH + (1-sLH)*ZH*uKH_BSH;
TFPH_ASN_check = (1-sLH)*ZH*uKH_ASN;
TFPH_BSN_check = (1-sLH)*ZH*uKH_BSN;
TFPH_ADH_check = sLH*(ZH/AH)*AH_ADH + (1-sLH)*ZH*uKH_ADH;
TFPH_BDH_check = (1-sLH)*(ZH/BH)*BH_BDH + (1-sLH)*ZH*uKH_BDH; 
TFPH_ADN_check = (1-sLH)*ZH*uKH_ADN;
TFPH_BDN_check = (1-sLH)*ZH*uKH_BDN;

TFPN_K_check      =  (1-sLN)*ZN*uKN_K;
TFPN_Q_check      =  (1-sLN)*ZN*uKN_Q;
TFPN_G_check      =  (1-sLN)*ZN*uKN_G;
TFPN_ASH_check    =  (1-sLN)*ZN*uKN_ASH;
TFPN_BSH_check    =  (1-sLN)*ZN*uKN_BSH;
TFPN_ASN_check    =  sLN*(ZN/AN)*AN_ASN + (1-sLN)*ZN*uKN_ASN;
TFPN_BSN_check    =  (1-sLN)*(ZN/BN)*BN_BSN + (1-sLN)*ZN*uKN_BSN;
TFPN_ADH_check    =  (1-sLN)*ZN*uKN_ADH;
TFPN_BDH_check    =  (1-sLN)*ZN*uKN_BDH;
TFPN_ADN_check    =  sLN*(ZN/AN)*AN_ADN + (1-sLN)*ZN*uKN_ADN;
TFPN_BDN_check    =  (1-sLN)*(ZN/BN)*BN_BDN + (1-sLN)*ZN*uKN_BDN;

% Ratio of traded to non-traded TFP
TFPR_K  = (ZH/ZN)*( (TFPH_K/ZH) - (TFPN_K/ZN) );
TFPR_Q  = (ZH/ZN)*( (TFPH_Q/ZH) - (TFPN_Q/ZN) );
TFPR_G  = (ZH/ZN)*( (TFPH_G/ZH) - (TFPN_G/ZN) );
TFPR_ASH = (ZH/ZN)*( (TFPH_ASH/ZH) - (TFPN_ASH/ZN) );
TFPR_BSH = (ZH/ZN)*( (TFPH_BSH/ZH) - (TFPN_BSH/ZN) );
TFPR_ASN = (ZH/ZN)*( (TFPH_ASN/ZH) - (TFPN_ASN/ZN) );
TFPR_BSN = (ZH/ZN)*( (TFPH_BSN/ZH) - (TFPN_BSN/ZN) );
TFPR_ADH = (ZH/ZN)*( (TFPH_ADH/ZH) - (TFPN_ADH/ZN) );
TFPR_BDH = (ZH/ZN)*( (TFPH_BDH/ZH) - (TFPN_BDH/ZN) );
TFPR_ADN = (ZH/ZN)*( (TFPH_ADN/ZH) - (TFPN_ADN/ZN) );
TFPR_BDN = (ZH/ZN)*( (TFPH_BDN/ZH) - (TFPN_BDN/ZN) );

% Aggregate capital-labor ratio k = K/L
k_K  =  (K/L)*( (1/K) - (L_K/L) );
k_Q  = -(K/L)*(L_Q/L);
k_G  = -(K/L)*(L_G/L);
k_ASH = -(K/L)*(L_ASH/L);
k_BSH = -(K/L)*(L_BSH/L);
k_ASN = -(K/L)*(L_ASN/L);
k_BSN = -(K/L)*(L_BSN/L);
k_ADH = -(K/L)*(L_ADH/L);
k_BDH = -(K/L)*(L_BDH/L);
k_ADN = -(K/L)*(L_ADN/L);
k_BDN = -(K/L)*(L_BDN/L);

% Aggregate LIS
LIS_K  = sL*( (W_K/W) + (L_K/L)  - (Y_K/Y) );
LIS_Q  = sL*( (W_Q/W) + (L_Q/L)  - (Y_Q/Y) );
LIS_G  = sL*( (W_G/W) + (L_G/L)  - (Y_G/Y) );
LIS_ASH = sL*( (W_ASH/W) + (L_ASH/L) - (Y_ASH/Y) );
LIS_BSH = sL*( (W_BSH/W) + (L_BSH/L) - (Y_BSH/Y) );
LIS_ASN = sL*( (W_ASN/W) + (L_ASN/L) - (Y_ASN/Y) );
LIS_BSN = sL*( (W_BSN/W) + (L_BSN/L) - (Y_BSN/Y) );
LIS_ADH = sL*( (W_ADH/W) + (L_ADH/L) - (Y_ADH/Y) );
LIS_BDH = sL*( (W_BDH/W) + (L_BDH/L) - (Y_BDH/Y) );
LIS_ADN = sL*( (W_ADN/W) + (L_ADN/L) - (Y_ADN/Y) );
LIS_BDN = sL*( (W_BDN/W) + (L_BDN/L) - (Y_BDN/Y) );

% Output share of non-tradables at current prices
omegaYN_K  = omegaYN*( (PN_K/PN) + (YN_K/YN) - (Y_K/Y) );
omegaYN_Q  = omegaYN*( (PN_Q/PN) + (YN_Q/YN) - (Y_Q/Y) );
omegaYN_G  = omegaYN*( (PN_G/PN) + (YN_G/YN) - (Y_G/Y) );
omegaYN_ASH = omegaYN*( (PN_ASH/PN) + (YN_ASH/YN) - (Y_ASH/Y) );
omegaYN_BSH = omegaYN*( (PN_BSH/PN) + (YN_BSH/YN) - (Y_BSH/Y) );
omegaYN_ASN = omegaYN*( (PN_ASN/PN) + (YN_ASN/YN) - (Y_ASN/Y) );
omegaYN_BSN = omegaYN*( (PN_BSN/PN) + (YN_BSN/YN) - (Y_BSN/Y) );
omegaYN_ADH = omegaYN*( (PN_ADH/PN) + (YN_ADH/YN) - (Y_ADH/Y) );
omegaYN_BDH = omegaYN*( (PN_BDH/PN) + (YN_BDH/YN) - (Y_BDH/Y) );
omegaYN_ADN = omegaYN*( (PN_ADN/PN) + (YN_ADN/YN) - (Y_ADN/Y) );
omegaYN_BDN = omegaYN*( (PN_BDN/PN) + (YN_BDN/YN) - (Y_BDN/Y) );

tildeKH_K  = KH_K + (KH*uKH_K);
tildeKH_Q  = KH_Q + (KH*uKH_Q);
tildeKH_G  = KH_G + (KH*uKH_G);
tildeKH_ASH = KH_ASH + (KH*uKH_ASH);
tildeKH_BSH = KH_BSH + (KH*uKH_BSH);
tildeKH_ASN = KH_ASN + (KH*uKH_ASN);
tildeKH_BSN = KH_BSN + (KH*uKH_BSN);
tildeKH_ADH = KH_ADH + (KH*uKH_ADH);
tildeKH_BDH = KH_BDH + (KH*uKH_BDH);
tildeKH_ADN = KH_ADN + (KH*uKH_ADN);
tildeKH_BDN = KH_BDN + (KH*uKH_BDN);

tildeKN_K  = KN_K + (KN*uKN_K);
tildeKN_Q  = KN_Q + (KN*uKN_Q);
tildeKN_G  = KN_G + (KN*uKN_G);
tildeKN_ASH = KN_ASH + (KN*uKN_ASH);
tildeKN_BSH = KN_BSH + (KN*uKN_BSH);
tildeKN_ASN = KN_ASN + (KN*uKN_ASN);
tildeKN_BSN = KN_BSN + (KN*uKN_BSN);
tildeKN_ADH = KN_ADH + (KN*uKN_ADH);
tildeKN_BDH = KN_BDH + (KN*uKN_BDH);
tildeKN_ADN = KN_ADN + (KN*uKN_ADN);
tildeKN_BDN = KN_BDN + (KN*uKN_BDN);

tildekH_K  = kH*( (tildeKH_K/KH) - (LH_K/LH) );
tildekH_Q  = kH*( (tildeKH_Q/KH) - (LH_Q/LH) );
tildekH_G  = kH*( (tildeKH_G/KH) - (LH_G/LH) );
tildekH_ASH = kH*( (tildeKH_ASH/KH) - (LH_ASH/LH) );
tildekH_BSH = kH*( (tildeKH_BSH/KH) - (LH_BSH/LH) );
tildekH_ASN = kH*( (tildeKH_ASN/KH) - (LH_ASN/LH) );
tildekH_BSN = kH*( (tildeKH_BSN/KH) - (LH_BSN/LH) );
tildekH_ADH = kH*( (tildeKH_ADH/KH) - (LH_ADH/LH) );
tildekH_BDH = kH*( (tildeKH_BDH/KH) - (LH_BDH/LH) );
tildekH_ADN = kH*( (tildeKH_ADN/KH) - (LH_ADN/LH) );
tildekH_BDN = kH*( (tildeKH_BDN/KH) - (LH_BDN/LH) );

tildekN_K  = kN*( (tildeKN_K/KN) - (LN_K/LN) );
tildekN_Q  = kN*( (tildeKN_Q/KN) - (LN_Q/LN) );
tildekN_G  = kN*( (tildeKN_G/KN) - (LN_G/LN) );
tildekN_ASH = kN*( (tildeKN_ASH/KN) - (LN_ASH/LN) );
tildekN_BSH = kN*( (tildeKN_BSH/KN) - (LN_BSH/LN) );
tildekN_ASN = kN*( (tildeKN_ASN/KN) - (LN_ASN/LN) );
tildekN_BSN = kN*( (tildeKN_BSN/KN) - (LN_BSN/LN) );
tildekN_ADH = kN*( (tildeKN_ADH/KN) - (LN_ADH/LN) );
tildekN_BDH = kN*( (tildeKN_BDH/KN) - (LN_BDH/LN) );
tildekN_ADN = kN*( (tildeKN_ADN/KN) - (LN_ADN/LN) );
tildekN_BDN = kN*( (tildeKN_BDN/KN) - (LN_BDN/LN) );

% Solution for NX = NX(K,Q,AH,BH,AN,BN)
NX_K    = (PH_K*XH) + (PH*XH_K) - MF_K;
NX_Q    = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
NX_G    = (PH_G*XH) + (PH*XH_G) - MF_G;
NX_ASH  = (PH_ASH*XH) + (PH*XH_ASH) - MF_ASH;
NX_BSH  = (PH_BSH*XH) + (PH*XH_BSH) - MF_BSH;
NX_ASN  = (PH_ASN*XH) + (PH*XH_ASN) - MF_ASN;
NX_BSN  = (PH_BSN*XH) + (PH*XH_BSN) - MF_BSN;
NX_ADH  = (PH_ADH*XH) + (PH*XH_ADH) - MF_ADH;
NX_BDH  = (PH_BDH*XH) + (PH*XH_BDH) - MF_BDH;
NX_ADN  = (PH_ADN*XH) + (PH*XH_ADN) - MF_ADN;
NX_BDN  = (PH_BDN*XH) + (PH*XH_BDN) - MF_BDN;

% Solution for Q/PI(H,PN))
QPI_K  = - (PI_K/PI);
QPI_Q  = (1/PI) - (PI_Q/PI);
QPI_G  = - (PI_G/PI);
QPI_ASH = - (PI_ASH/PI);
QPI_BSH = - (PI_BSH/PI);
QPI_ASN = - (PI_ASN/PI);
QPI_BSN = - (PI_BSN/PI);
QPI_ADH = - (PI_ADH/PI);
QPI_BDH = - (PI_BDH/PI);
QPI_ADN = - (PI_ADN/PI);
QPI_BDN = - (PI_BDN/PI);

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% Aggregator function for L=L(LH,LN)
VLAB    = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = VLAB^(epsilon/(epsilon+1)); 
L_LH    = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_LN    = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Aggregator function for K=K(KH,KN)                                                                                                      
VCAP    = ( (varthetaK^(-1/epsilonK))*(KH^((epsilonK+1)/epsilonK)) + ((1-varthetaK)^(-1/epsilonK))*(KN^((epsilonK+1)/epsilonK)) );        
K_check = VCAP^(epsilonK/(epsilonK+1));                                                                                                   
K_KH    = ((varthetaK)^(-1/epsilonK))*(KH/K)^(1/epsilonK);                                                                                
K_KN    = ((1-varthetaK)^(-1/epsilonK))*(KN/K)^(1/epsilonK);   

% Investment 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));   
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF; 
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real return on inputs 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;
RHPH = RH/PH;
RNPN = RN/PN;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);
                                                                         
% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH = IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    = (GH+PN*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Confirmation
% Check the closure of the model                                                                                                         
cond1  = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH))-RH;                                                                 
cond2  = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN))-RN;                                                                
cond3  = PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH))-WH;                                                                          
cond4  = PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN))-WN;                                                                          
cond5  = (RH*KH)+(RN*KN)-(RK*K);                                                                                                         
cond6  = RK-(deltaK+r)*PI;                                                                                                               
cond7  = YN-CN-GN-IN;                                                                                                                    
cond8  = YH-CH-GH-IH-XH;                                                                                                                 
cond9  = (B-B0)-( (wB1/(r-nu_1)) + (wBG2/(xi+r)) + (wBASH2/(xiASH+r)) + (wBBSH2/(xiBSH+r)) + (wBASN2/(xiASN+r)) + (wBBSN2/(xiBSN+r)) + (wBADH2/(xiADH+r)) + (wBBDH2/(xiBDH+r)) + (wBADN2/(xiADN+r)) + (wBBDN2/(xiBDN+r)) );            
cond10 = DetJ - (nu_1*nu_2);                                                                                                               
cond11 = TrJ - (nu_1+nu_2);                                                                                                                
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);                                                                             
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);                                                                                    
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                                                                                     
cond15 = (W*L) - ((WH*LH)+(WN*LN));                                                                                                      
cond16 = -U_L*L_LH - (lambda*WH);                                                                                                        
cond17 = -U_L*L_LN - (lambda*WN);                                                                                                        
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                                                                                                
cond19 = Sav;                                                                                                                            
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                                                                                  
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);                                                                                      
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                                                                                    
cond23 = (RK*K) - ((RH*KH)+(RN*KN));                                                                                                   
cond24 = 1 - (omegaK + omegaL);                                                                                                          
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);                                                                                    
cond26 = (PT*CT) - ((PH*CH)+CF);                                                                                                         
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);                                                                                       
cond28 = (PIT*IT) - ((PH*IH)+IF);                                                                                                        
cond29 = r*B + (PH*XH) - MF;                                                                                                             
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I);                                                                                     
cond31 = K_KH - (RH/RK);                                                            
cond32 = K_KN - (RN/RK);                                                            
cond33 = (KH/KN) - (varthetaK/(1-varthetaK))*(RH/RN)^(epsilonK);    
cond34 = PN - MN;
cond35 = PH - MH;
                                                                                                                                          
% Define New steady-state values
kH_eta0_8402 = kH; kN_eta0_8402 = kN; PN_eta0_8402 = PN; K_eta0_8402 = K; C_eta0_8402 = C;  
L_eta0_8402  = L; W_eta0_8402 = W; P_eta0_8402 = P; 
YH_eta0_8402 = YH; YN_eta0_8402 = YN; Y_eta0_8402 = Y; G_eta0_8402 = G;     
PC_eta0_8402 = PC; CN_eta0_8402 = CN; CH_eta0_8402 = CH;  
GH_eta0_8402 = GH; GN_eta0_8402 = GN; ZH_eta0_8402 = ZH; ZN_eta0_8402 = ZN; Z_eta0_8402 = Z; 
AH_eta0_8402 = AH; BH_eta0_8402 = BH; AN_eta0_8402 = AN; BN_eta0_8402 = BN;
LH_eta0_8402 = LH; LN_eta0_8402 = LN; KH_eta0_8402 = KH; KN_eta0_8402 = KN; WH_eta0_8402 = WH; WN_eta0_8402 = WN; 
Omega_eta0_8402 = Omega; WPC_eta0_8402 = WPC; WHPC_eta0_8402 = WHPC; WNPC_eta0_8402 = WNPC;
IF_eta0_8402 = IF; CF_eta0_8402 = CF; XH_eta0_8402 = XH; MF_eta0_8402 = MF; GF_eta0_8402 = GF; PH_eta0_8402 = PH; 
PT_eta0_8402 = PT; PIT_eta0_8402 = PIT; CT_eta0_8402 = CT; IT_eta0_8402 = IT; GT_eta0_8402 = GT; 

YHYN_eta0_8402 = YHYN; LHLN_eta0_8402 = LHLN; IH_eta0_8402 = IH; IN_eta0_8402 = IN; PI_eta0_8402 = PI; 
EI_eta0_8402 = EI; CA_eta0_8402 = CA; Sav_eta0_8402 = Sav; NX_eta0_8402 = NX; I_eta0_8402 = I; A_eta0_8402 = A; 
B_eta0_8402 = B; lambda_eta0_8402  = lambda; RK_eta0_8402 = RK; YR_eta0_8402 = YR; 
yH_eta0_8402 = yH; yN_eta0_8402 = yN; 

omegaL_eta0_8402 = omegaL; omegaK_eta0_8402 = omegaK; omegaI_eta0_8402 = omegaI; omegaINYN_eta0_8402 = omegaINYN;
omegaIHYH_eta0_8402 = omegaIHYH; omega_IFYH_eta0_8402 = omegaIFYH; omegaGHYH_eta0_8402 = omegaGHYH; 
omegaGFYH_eta0_8402 = omegaGFYH; omegaGNYN_eta0_8402 = omegaGNYN; omegaGN_eta0_8402 = omegaGN;
omegaYH_eta0_8402 = omegaYH; omegaYN_eta0_8402 = omegaYN; omegaLH_eta0_8402 = omegaLH; omegaLN_eta0_8402 = omegaLN; 
omegaC_eta0_8402 =omegaC; omegaNX_eta0_8402 =omegaNX; omegaG_eta0_8402 =omegaG; omegaB_eta0_8402 =omegaB; 
omegaKY_eta0_8402 = omegaKY; omegaIH_eta0_8402 = omegaIH; omegaIF_eta0_8402 = omegaIF; 
omegaGT_eta0_8402 = omegaGT; omegaGH_eta0_8402 = omegaGH; omegaGF_eta0_8402 = omegaGF;
alphaL_eta0_8402 = alphaL; alphaK_eta0_8402 = alphaK; alphaC_eta0_8402 = alphaC; 
alphaI_eta0_8402 = alphaI; alphaH_eta0_8402 = alphaH; alphaIH_eta0_8402 = alphaIH;
omegaYHR_eta0_8402 = omegaYHR; omegaYNR_eta0_8402 = omegaYNR;
sLH_eta0_8402 = sLH; sLN_eta0_8402 = sLN; sL_eta0_8402 = sL; k_eta0_8402 = k; VL_eta0_8402 = VL; 
RH_eta0_8402 = RH; RN_eta0_8402 = RN; KHK_eta0_8402 = KHK; RHPH_eta0_8402 =RHPH; 
RNPN_eta0_8402 = RNPN; 

ASH_eta0_8402 = ASH; BSH_eta0_8402 = BSH; ASN_eta0_8402 = ASN; BSN_eta0_8402 = BSN;
ADH_eta0_8402 = ADH; BDH_eta0_8402 = BDH; ADN_eta0_8402 = ADN; BDN_eta0_8402 = BDN;
ZSH_eta0_8402 = ZSH; ZSN_eta0_8402 = ZSN; ZDH_eta0_8402 = ZDH; ZDN_eta0_8402 = ZDN;
AH_eta0_8402 = AH; BH_eta0_8402 = BH; AN_eta0_8402 = AN; BN_eta0_8402 = BN;        
ZH_eta0_8402 = ZH; ZN_eta0_8402 = ZN; ZA_eta0_8402 = ZA;                      
TFPH_eta0_8402 = TFPH; TFPN_eta0_8402 = TFPN; TFPA_eta0_8402 = TFPA;          

% Steady-State Changes
dC       = C_eta0_8402 - C_0; % Steady-state change of real consumption 
dK       = K_eta0_8402 - K_0; % Steady-state change of real capital 
dL       = L_eta0_8402 - L_0; % Steady-state change of employment 
dPN      = PN_eta0_8402 - PN_0; % Steady-state change of non traded good prices
dPH      = PH_eta0_8402 - PH_0; % Steady-state change of terms of trade (price of exports in terms if imports)
dP       = P_eta0_8402 - P_0; % Steady-state change of non traded goods prices relative to tradable home goods prices
dB       = B_eta0_8402 - B_0; % Steady-state change of traded bonds holding 
dlambda  = lambda_eta0_8402 - lambda_0; % Steady-state change of marginal utility of wealth 
dY       = Y_eta0_8402 - Y_0; % Steady-state change of GDP 
dYR      = YR_eta0_8402 - Y_0; % Steady-state change of real GDP 
dA       = A_eta0_8402 - A_0; % Steady-state change of financial wealth 
dW       = W_eta0_8402 - W_0; % Steady-state change of the wage rate 
dWPC     = WPC_eta0_8402 - WPC_0; % Steady-state change of the real aggregate wage W/PC 
dOmega   = Omega_eta0_8402 - Omega_0; % Steady-state change of the sector wage ratio

dCH   = CH_eta0_8402 - CH_0; % Steady-state change of CH
dCN   = CN_eta0_8402 - CN_0; % Steady-state change of CN
dLH   = LH_eta0_8402 - LH_0; % Steady-state change of real capital 
dLN   = LN_eta0_8402 - LN_0; % Steady-state change of employment 
dKH   = KH_eta0_8402 - KH_0; % Steady-state change of real capital 
dKN   = KN_eta0_8402 - KN_0; % Steady-state change of employment 
dYH   = YH_eta0_8402 - YH_0; % Steady-state change of YH
dYN   = YN_eta0_8402 - YN_0; % Steady-state change of YN
dWH   = WH_eta0_8402 - WH_0; % Steady-state change of WH
dWN   = WN_eta0_8402 - WN_0; % Steady-state change of WN
dRH   = RH_eta0_8402 - RH_0; % Steady-state change of RH  
dRN   = RN_eta0_8402 - RN_0; % Steady-state change of RN  
dWHPC = WHPC_eta0_8402 - WHPC_0; % Steady-state change of WH/PC
dWNPC = WNPC_eta0_8402 - WNPC_0; % Steady-state change of WN/PC
dkH   = kH_eta0_8402 - kH_0; % Steady-state change of kH 
dkN   = kN_eta0_8402 - kN_0; % Steady-state change of kN
dLHLN = LHLN_eta0_8402 - LHLN_0; % Steady-state change of LH/LN
dYHYN = YHYN_eta0_8402 - YHYN_0; % Steady-state change of LH/LN
dsLH  = sLH_eta0_8402 - sLH_0; % Steady-state change of labor income share in the home traded good sector
dsLN  = sLN_eta0_8402 - sLN_0; % Steady-state change of labor income share in the non traded good sector

dGH   = GH_eta0_8402 - GH_0; 
dGN   = GN_eta0_8402 - GN_0; 
dGF   = GF_eta0_8402 - GF_0; 
dG    = G_eta0_8402 - G_0;
dTFPH = TFPH_eta0_8402 - TFPH_0; 
dTFPN = TFPN_eta0_8402 - TFPN_0; 
dTFPA = TFPA_eta0_8402 - TFPA_0;
dZH   = ZH_eta0_8402 - ZH_0;
dZN   = ZN_eta0_8402 - ZN_0;
dZA   = ZA_eta0_8402 - ZA_0; 

dASH = ASH_eta0_8402 - AH_0;  
dBSH = BSH_eta0_8402 - BH_0;  
dASN = ASN_eta0_8402 - AN_0;  
dBSN = BSN_eta0_8402 - BN_0;  
dADH = ADH_eta0_8402 - AH_0;  
dBDH = BDH_eta0_8402 - BH_0;  
dADN = ADN_eta0_8402 - AN_0;  
dBDN = BDN_eta0_8402 - BN_0;  
                         
dZSH = ZSH_eta0_8402 - ZH_0;  
dZSN = ZSN_eta0_8402 - ZN_0;  
dZDH = ZDH_eta0_8402 - ZH_0;  
dZDN = ZDN_eta0_8402 - ZN_0;  
                         
dAH = AH_eta0_8402 - AH_0;    
dBH = BH_eta0_8402 - BH_0;    
dAN = AN_eta0_8402 - AN_0;    
dBN = BN_eta0_8402 - BN_0;    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solution for investment PI*K, 
EK1   = PI + (K*omega_21); % Q(t)*K(t) - Q*K = EK1*X1(t) + EK2*X2(t)
EK2   = PI + (K*omega_22);
 
% Solution for the Relative Price of Non tradables P=P(K,Q,G,Aj,Bj)
wP_1   = P_K + (P_Q*omega_21); 
wP_2   = P_K + (P_Q*omega_22); 

% Solution for the Price of Non tradables PN=PN(K,Q,G,Aj,Bj);                                
wPN_1  =  PN_K + (PN_Q*omega_21);                                                                    
wPN_2  =  PN_K + (PN_Q*omega_22);  

% Solution for the TOT PH=PH(K,Q,G,Aj,Bj)
wPH_1  = PH_K + (PH_Q*omega_21); 
wPH_2  = PH_K + (PH_Q*omega_22);
                                                                                                  
% Solution for the Consumption Price index PC=PC(K,Q,G,Aj,Bj)                                         
wPC_1  =  PC_K + (PC_Q*omega_21);                                                                     
wPC_2  =  PC_K + (PC_Q*omega_22); 

% Solution for the Investment Price index PI=PI(K,Q,G,Aj,Bj)                                          
wPI_1  =  PI_K + (PI_Q*omega_21);                                                                     
wPI_2  =  PI_K + (PI_Q*omega_22); 

% Solution for capital and technology utilization rates uKj,uZj(K,Q,G,Aj,Bj)
wuKSH_1 =  uKSH_K + (uKSH_Q*omega_21);   
wuKSH_2 =  uKSH_K + (uKSH_Q*omega_22);   
wuKSN_1 =  uKSN_K + (uKSN_Q*omega_21);   
wuKSN_2 =  uKSN_K + (uKSN_Q*omega_22);   
                                         
wuKDH_1 =  uKDH_K + (uKDH_Q*omega_21);   
wuKDH_2 =  uKDH_K + (uKDH_Q*omega_22);   
wuKDN_1 =  uKDN_K + (uKDN_Q*omega_21);   
wuKDN_2 =  uKDN_K + (uKDN_Q*omega_22);   

wuKH_1  =  uKH_K + (uKH_Q*omega_21);
wuKH_2  =  uKH_K + (uKH_Q*omega_22);
wuKN_1  =  uKN_K + (uKN_Q*omega_21);
wuKN_2  =  uKN_K + (uKN_Q*omega_22);

wuK_1   =  uK_K + (uK_Q*omega_21);  
wuK_2   =  uK_K + (uK_Q*omega_22);  
                                                                                                                                                                                                                                                                                                               
% Solution for Q(t)/PI(P(t))                                                                           
wQPI_1  = QPI_K + (QPI_Q*omega_21);                                                                  
wQPI_2  = QPI_K + (QPI_Q*omega_22); 
                                                                                                       
% Solution for Consumption C=C(K,Q,G,Aj,Bj)                                                               
wC_1   = C_K + (C_Q*omega_21);                                                                          
wC_2   = C_K + (C_Q*omega_22);     

% Solution for Consumption J=J(K,Q,G,Aj,Bj)                                                               
wJ_1   = J_K + (J_Q*omega_21);                                                                          
wJ_2   = J_K + (J_Q*omega_22); 

% Solution for Consumption J=J(K,Q,G,Aj,Bj)                                                               
wNX_1   = NX_K + (NX_Q*omega_21);                                                                          
wNX_2   = NX_K + (NX_Q*omega_22); 
                                                                                                      
% Solution for the Aggregate Wage Index W=W(K,Q,G,Aj,Bj)                                           
wW_1  =  W_K + (W_Q*omega_21);                                                                         
wW_2  =  W_K + (W_Q*omega_22);   
                                                                                                    
% Solution for the Capital Rental Rate RK=R(K,Q,G,Aj,Bj)                                           
wR_1  =  R_K + (R_Q*omega_21);                                                                         
wR_2  =  R_K + (R_Q*omega_22);         
                                                                                                      
% Solution for the Real Consumption Wage W(K,Q,G,Aj,Bj)/PC(P)                                      
wWPC_1  = WPC_K + (WPC_Q*omega_21);                                                               
wWPC_2  = WPC_K + (WPC_Q*omega_22);    
                                                                                                         
% Solution for Labor L=L(lambda,W)=L(K,Q,G,Aj,Bj)                                                     
wL_1  =  L_K + (L_Q*omega_21);                                                                         
wL_2  =  L_K + (L_Q*omega_22);      
                                                                                                     
% Solutions for the Sectoral Labor kj,K(K,Q,G,Aj,Bj)                                                 
wkH_1  =  kH_K + (kH_Q*omega_21);                                                                     
wkH_2  =  kH_K + (kH_Q*omega_22);                                                                                                                                                             
wkN_1  =  kN_K + (kN_Q*omega_21);                                                                     
wkN_2  =  kN_K + (kN_Q*omega_22);  

wtildekH_1  =  tildekH_K + (tildekH_Q*omega_21);  
wtildekH_2  =  tildekH_K + (tildekH_Q*omega_22);                                             
wtildekN_1  =  tildekN_K + (tildekN_Q*omega_21);  
wtildekN_2  =  tildekN_K + (tildekN_Q*omega_22);  
                                                                                                   
% Solutions for the Sectoral Labor Lj=Lj(K,Q,G,Aj,Bj)                                                 
wLH_1  =  LH_K + (LH_Q*omega_21);                                                                     
wLH_2  =  LH_K + (LH_Q*omega_22);                                                     
                                                                                                       
wLN_1  =  LN_K + (LN_Q*omega_21);                                                                     
wLN_2  =  LN_K + (LN_Q*omega_22);                                                     
                                                                                                       
% Solution for Real GDP YR=YR(K,Q,G,Aj,Bj)                                                                                                                                                                                                                              
wYR_1  = YR_K + (YR_Q*omega_21);                            
wYR_2  = YR_K + (YR_Q*omega_22);

% Solutions for the Sectoral Output Yj=Yj(K,Q,G,Aj,Bj)                                                
wYH_1  = YH_K + (YH_Q*omega_21);                                                                      
wYH_2  = YH_K + (YH_Q*omega_22);                                                                                                                                                        
wYN_1  = YN_K + (YN_Q*omega_21);                                                                      
wYN_2  = YN_K + (YN_Q*omega_22);

% Solutions for YH/YN,LH/LN(K,Q,G,Aj,Bj)
wLHLN_1  = LHLN_K + (LHLN_Q*omega_21);
wLHLN_2  = LHLN_K + (LHLN_Q*omega_22);
wYHYN_1  = YHYN_K + (YHYN_Q*omega_21);
wYHYN_2  = YHYN_K + (YHYN_Q*omega_22);

% Solutions for the Sectoral Wages Wj=Wj(K,Q,G,Aj,Bj)                                              
wWH_1  = WH_K + (WH_Q*omega_21);                                                                      
wWH_2  = WH_K + (WH_Q*omega_22);  
wWN_1  = WN_K + (WN_Q*omega_21);                                                                      
wWN_2  = WN_K + (WN_Q*omega_22);

% Solutions for the Real Sectoral Wages Wj(K,Q,G,Aj,Bj)/PC(K,Q,G,Aj,Bj)     
wWHPC_1  = WHPC_K + (WHPC_Q*omega_21);                 
wWHPC_2  = WHPC_K + (WHPC_Q*omega_22);                 
wWNPC_1  = WNPC_K + (WNPC_Q*omega_21);                 
wWNPC_2  = WNPC_K + (WNPC_Q*omega_22);                 
                                                       
% Solutions for the relative wages Wj/W: WjW=WjW(K,Q,G,Aj,Bj) -     
% Solution for Omega = WN(K,Q,G,Aj,Bj)/WH(K,Q,G,Aj,Bj) 
wWHW_1  = WHW_K + (WHW_Q*omega_21);                
wWHW_2  = WHW_K + (WHW_Q*omega_22);                
wWNW_1  = WNW_K + (WNW_Q*omega_21);                
wWNW_2  = WNW_K + (WNW_Q*omega_22);                
                                                                                                                                                                     
wOmega_1  =  Omega_K + (Omega_Q*omega_21);                       
wOmega_2  =  Omega_K + (Omega_Q*omega_22);     
                                                                                                                                              
% Solution for YH(K,Q,G,Aj,Bj)/YN(K,Q,G,Aj,Bj), Solution for LH(K,Q,G,Aj,Bj)/LN(K,Q,G,Aj,Bj)                               
% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(K,Q,G,Aj,Bj)          
% Solutions for the employment shares Lj/L=(Lj/L)(K,Q,G,Aj,Bj)               
% Solutions for the employment shares sLj=LISj(K,Q,G,Aj,Bj) -  
                                   
wLHS_1  = LHS_K + (LHS_Q*omega_21);   
wLHS_2  = LHS_K + (LHS_Q*omega_22);   
wLNS_1  = LNS_K + (LNS_Q*omega_21);   
wLNS_2  = LNS_K + (LNS_Q*omega_22);   
                                      
wYHS_1  = YHS_K + (YHS_Q*omega_21);   
wYHS_2  = YHS_K + (YHS_Q*omega_22);   
wYNS_1  = YNS_K + (YNS_Q*omega_21);   
wYNS_2  = YNS_K + (YNS_Q*omega_22);   

% sLj = Wj*Lj/(Pj*Yj) -                                                                                
wLISH_1  = LISH_K + (LISH_Q*omega_21);                                    
wLISH_2  = LISH_K + (LISH_Q*omega_22);                                                                                                                                                                
wLISN_1  = LISN_K + (LISN_Q*omega_21); 
wLISN_2  = LISN_K + (LISN_Q*omega_22);                                                      
                                                                                                 
% Solutions for the Kj/K: Kj/K=Kj/K(lambda,K,Q,AH,BH,AN,BN) -                                    
wKHK_1  = KHK_K + (KHK_Q*omega_21);  
wKHK_2  = KHK_K + (KHK_Q*omega_22);  
wKNK_1  = KNK_K + (KNK_Q*omega_21);  
wKNK_2  = KNK_K + (KNK_Q*omega_22); 

% Solutions for TFPj,TFP(lambda,K,Q,AH,BH,AN,BN) -
wTFPH_1  = TFPH_K + (TFPH_Q*omega_21);
wTFPH_2  = TFPH_K + (TFPH_Q*omega_22);
wTFPN_1  = TFPN_K + (TFPN_Q*omega_21);
wTFPN_2  = TFPN_K + (TFPN_Q*omega_22);

wTFPH_1_check  = TFPH_K_check + (TFPH_Q_check*omega_21);
wTFPH_2_check  = TFPH_K_check + (TFPH_Q_check*omega_22);
wTFPN_1_check  = TFPN_K_check + (TFPN_Q_check*omega_21);
wTFPN_2_check  = TFPN_K_check + (TFPN_Q_check*omega_22);

wTFPA_1   = TFPA_K + (TFPA_Q*omega_21);
wTFPA_2   = TFPA_K + (TFPA_Q*omega_22);

wTFPR_1  = TFPR_K + (TFPR_Q*omega_21);  
wTFPR_2  = TFPR_K + (TFPR_Q*omega_22);  
     
% Solutions for the relative return on capital Rj,Rj/Pj(K,Q,G,Aj,Bj) -     
wRH_1  = RH_K + (RH_Q*omega_21);                                           
wRH_2  = RH_K + (RH_Q*omega_22);                                           
wRN_1  = RN_K + (RN_Q*omega_21);                                           
wRN_2  = RN_K + (RN_Q*omega_22);                                           
                                                                           
wRHPH_1  = RHPH_K + (RHPH_Q*omega_21);                                     
wRHPH_2  = RHPH_K + (RHPH_Q*omega_22);                                     
wRNPN_1  = RNPN_K + (RNPN_Q*omega_21);                                     
wRNPN_2  = RNPN_K + (RNPN_Q*omega_22);                                     

% Solutions for aggregate capital-labor ratio k, aggregate LIS sL, output
% share of non-tradables at current prices omegaYN
wk_1   =  k_K + (k_Q*omega_21);                                                                     
wk_2   =  k_K + (k_Q*omega_22); 

wLIS_1   =  LIS_K + (LIS_Q*omega_21); 
wLIS_2   =  LIS_K + (LIS_Q*omega_22); 

womegaYN_1   =  omegaYN_K + (omegaYN_Q*omega_21); 
womegaYN_2   =  omegaYN_K + (omegaYN_Q*omega_22); 
                                                                                                                                                                                                                                                                                           
% Transitional Paths 
time0 = [Tm:Tu:0]; % Span of time t= [-20..0[ 
pathdGY0    = (omegaG_0 - omegaG_0) + 0*time0;
pathCY0     = (C_0 - C_0) + 0*time0;
pathdP0     = (P_0 - P_0) + 0*time0;
pathdPH0    = (PH_0 - PH_0) + 0*time0;
pathdPN0    = (PN_0 - PN_0) + 0*time0;
pathdZA0    = (ZA_0 - ZA_0) + 0*time0;
pathdZH0    = (ZH_0 - ZH_0) + 0*time0;
pathdZN0    = (ZN_0 - ZN_0) + 0*time0;
pathCAY0    = CA_0 + 0*time0;
pathdL0     = (L_0 - L_0) + 0*time0;
pathdK0     = (K_0 - K_0) + 0*time0;
pathdLH0    = (LH_0 - LH_0) + 0*time0;
pathdLN0    = (LN_0 - LN_0) + 0*time0;
pathdkH0    = (kH_0 - kH_0) + 0*time0;
pathdkN0    = (kN_0 - kN_0) + 0*time0;
pathdYH0    = (YH_0 - YH_0) + 0*time0;
pathdYN0    = (YN_0 - YN_0) + 0*time0;
pathIY0     = (I_0 - I_0) + 0*time0;
pathSY0     = CA_0 + 0*time0;
pathdW0     = (W_0 - W_0) + 0*time0;
pathdY0     = (Y_0 - Y_0) + 0*time0;
pathdWH0    = (WH_0 - WH_0) + 0*time0;
pathdWN0    = (WN_0 - WN_0) + 0*time0;
pathdOmega0 = (Omega_0 - Omega_0) + 0*time0;
pathdYHYN0  = (YHYN_0 - YHYN_0) + 0*time0;
pathdLHLN0  = (LHLN_0 - LHLN_0) + 0*time0;
pathdWPC0   = (WPC_0 - WPC_0) + 0*time0;
pathdQ0     = (PI_0 - PI_0) + 0*time0;  
pathdR0     = (RK_0 - RK_0) + 0*time0; 
pathdLISH0  = (sLH_0 - sLH_0) + 0*time0;
pathdLISN0  = (sLN_0 - sLN_0) + 0*time0;

time1    = [0:Tu:Tg]; % span of time t = [0..100]
VG       = exp(-xi*time1) - (1-barg)*exp(-chi*time1);
VG1      = exp(-xi*time1) - ThetaG_1*exp(-chi*time1);
VG2      = exp(-xi*time1) - ThetaG_2*exp(-chi*time1);

VASH     = exp(-xiASH*time1) - (1-baraSH)*exp(-chiASH*time1);
VBSH     = exp(-xiBSH*time1) - (1-barbSH)*exp(-chiBSH*time1);
VASN     = exp(-xiASN*time1) - (1-baraSN)*exp(-chiASN*time1);
VBSN     = exp(-xiBSN*time1) - (1-barbSN)*exp(-chiBSN*time1);
VADH     = exp(-xiADH*time1) - (1-baraDH)*exp(-chiADH*time1);
VBDH     = exp(-xiBDH*time1) - (1-barbDH)*exp(-chiBDH*time1);
VADN     = exp(-xiADN*time1) - (1-baraDN)*exp(-chiADN*time1);
VBDN     = exp(-xiBDN*time1) - (1-barbDN)*exp(-chiBDN*time1);

VAH      = (eta*VASH) + (1-eta)*VADH;
VBH      = (eta*VBSH) + (1-eta)*VBDH;
VAN      = (eta*VASN) + (1-eta)*VADN;
VBN      = (eta*VBSN) + (1-eta)*VBDN;

VASH1    = exp(-xiASH*time1) - ThetaASH_1*exp(-chiASH*time1);
VASH2    = exp(-xiASH*time1) - ThetaASH_2*exp(-chiASH*time1);
VADH1    = exp(-xiADH*time1) - ThetaADH_1*exp(-chiADH*time1);
VADH2    = exp(-xiADH*time1) - ThetaADH_2*exp(-chiADH*time1);

VBSH1    = exp(-xiBSH*time1) - ThetaBSH_1*exp(-chiBSH*time1);
VBSH2    = exp(-xiBSH*time1) - ThetaBSH_2*exp(-chiBSH*time1);
VBDH1    = exp(-xiBDH*time1) - ThetaBDH_1*exp(-chiBDH*time1);
VBDH2    = exp(-xiBDH*time1) - ThetaBDH_2*exp(-chiBDH*time1);

VASN1    = exp(-xiASN*time1) - ThetaASN_1*exp(-chiASN*time1);
VASN2    = exp(-xiASN*time1) - ThetaASN_2*exp(-chiASN*time1);
VADN1    = exp(-xiADN*time1) - ThetaADN_1*exp(-chiADN*time1);
VADN2    = exp(-xiADN*time1) - ThetaADN_2*exp(-chiADN*time1);

VBSN1    = exp(-xiBSN*time1) - ThetaBSN_1*exp(-chiBSN*time1);
VBSN2    = exp(-xiBSN*time1) - ThetaBSN_2*exp(-chiBSN*time1);
VBDN1    = exp(-xiBDN*time1) - ThetaBDN_1*exp(-chiBDN*time1);
VBDN2    = exp(-xiBDN*time1) - ThetaBDN_2*exp(-chiBDN*time1);

VAH1     = (eta*VASH1) + (1-eta)*VADH1;
VBH1     = (eta*VBSH1) + (1-eta)*VBDH1;
VAN1     = (eta*VASN1) + (1-eta)*VADN1;
VBN1     = (eta*VBSN1) + (1-eta)*VBDN1;

VAH2     = (eta*VASH2) + (1-eta)*VADH2;
VBH2     = (eta*VBSH2) + (1-eta)*VBDH2;
VAN2     = (eta*VASN2) + (1-eta)*VADN2;
VBN2     = (eta*VBSN2) + (1-eta)*VBDN2;

VG1prime  = xi*exp(-xi*time1) - chi*ThetaG_1*exp(-chi*time1);
VG2prime  = xi*exp(-xi*time1) - chi*ThetaG_2*exp(-chi*time1);
VGprime   = xi*exp(-xi*time1) - chi*(1-barg)*exp(-chi*time1);
VBG1prime = xi*exp(-xi*time1) - chi*ThetaG_1prime*exp(-chi*time1);
VBG2prime = xi*exp(-xi*time1) - chi*ThetaG_2prime*exp(-chi*time1);
VBGprime  = xi*exp(-xi*time1) - chi*ThetaG_prime*exp(-chi*time1);

VASH1prime    = xiASH*exp(-xiASH*time1) - chiASH*ThetaASH_1*exp(-chiASH*time1);
VASH2prime    = xiASH*exp(-xiASH*time1) - chiASH*ThetaASH_2*exp(-chiASH*time1);
VBSH1prime    = xiBSH*exp(-xiBSH*time1) - chiBSH*ThetaBSH_1*exp(-chiBSH*time1);
VBSH2prime    = xiBSH*exp(-xiBSH*time1) - chiBSH*ThetaBSH_2*exp(-chiBSH*time1);
VASN1prime    = xiASN*exp(-xiASN*time1) - chiASN*ThetaASN_1*exp(-chiASN*time1);
VASN2prime    = xiASN*exp(-xiASN*time1) - chiASN*ThetaASN_2*exp(-chiASN*time1);
VBSN1prime    = xiBSN*exp(-xiBSN*time1) - chiBSN*ThetaBSN_1*exp(-chiBSN*time1);
VBSN2prime    = xiBSN*exp(-xiBSN*time1) - chiBSN*ThetaBSN_2*exp(-chiBSN*time1);

VADH1prime    = xiADH*exp(-xiADH*time1) - chiADH*ThetaADH_1*exp(-chiADH*time1);
VADH2prime    = xiADH*exp(-xiADH*time1) - chiADH*ThetaADH_2*exp(-chiADH*time1);
VBDH1prime    = xiBDH*exp(-xiBDH*time1) - chiBDH*ThetaBDH_1*exp(-chiBDH*time1);
VBDH2prime    = xiBDH*exp(-xiBDH*time1) - chiBDH*ThetaBDH_2*exp(-chiBDH*time1);
VADN1prime    = xiADN*exp(-xiADN*time1) - chiADN*ThetaADN_1*exp(-chiADN*time1);
VADN2prime    = xiADN*exp(-xiADN*time1) - chiADN*ThetaADN_2*exp(-chiADN*time1);
VBDN1prime    = xiBDN*exp(-xiBDN*time1) - chiBDN*ThetaBDN_1*exp(-chiBDN*time1);
VBDN2prime    = xiBDN*exp(-xiBDN*time1) - chiBDN*ThetaBDN_2*exp(-chiBDN*time1);

VBASHprime    = xiASH*exp(-xiASH*time1) - chiASH*ThetaASH_prime*exp(-chiASH*time1);
VBBSHprime    = xiBSH*exp(-xiBSH*time1) - chiBSH*ThetaBSH_prime*exp(-chiBSH*time1);
VBASNprime    = xiASN*exp(-xiASN*time1) - chiASN*ThetaASN_prime*exp(-chiASN*time1);
VBBSNprime    = xiBSN*exp(-xiBSN*time1) - chiBSN*ThetaBSN_prime*exp(-chiBSN*time1);

VBADHprime    = xiADH*exp(-xiADH*time1) - chiADH*ThetaADH_prime*exp(-chiADH*time1);
VBBDHprime    = xiBDH*exp(-xiBDH*time1) - chiBDH*ThetaBDH_prime*exp(-chiBDH*time1);
VBADNprime    = xiADN*exp(-xiADN*time1) - chiADN*ThetaADN_prime*exp(-chiADN*time1);
VBBDNprime    = xiBDN*exp(-xiBDN*time1) - chiBDN*ThetaBDN_prime*exp(-chiBDN*time1);

VBASH1prime   = xiASH*exp(-xiASH*time1) - chiASH*ThetaASH_1prime*exp(-chiASH*time1);
VBASH2prime   = xiASH*exp(-xiASH*time1) - chiASH*ThetaASH_2prime*exp(-chiASH*time1);
VBBSH1prime   = xiBSH*exp(-xiBSH*time1) - chiBSH*ThetaBSH_1prime*exp(-chiBSH*time1);
VBBSH2prime   = xiBSH*exp(-xiBSH*time1) - chiBSH*ThetaBSH_2prime*exp(-chiBSH*time1);
VBASN1prime   = xiASN*exp(-xiASN*time1) - chiASN*ThetaASN_1prime*exp(-chiASN*time1);
VBASN2prime   = xiASN*exp(-xiASN*time1) - chiASN*ThetaASN_2prime*exp(-chiASN*time1);
VBBSN1prime   = xiBSN*exp(-xiBSN*time1) - chiBSN*ThetaBSN_1prime*exp(-chiBSN*time1);
VBBSN2prime   = xiBSN*exp(-xiBSN*time1) - chiBSN*ThetaBSN_2prime*exp(-chiBSN*time1);

VBADH1prime   = xiADH*exp(-xiADH*time1) - chiADH*ThetaADH_1prime*exp(-chiADH*time1);
VBADH2prime   = xiADH*exp(-xiADH*time1) - chiADH*ThetaADH_2prime*exp(-chiADH*time1);
VBBDH1prime   = xiBDH*exp(-xiBDH*time1) - chiBDH*ThetaBDH_1prime*exp(-chiBDH*time1);
VBBDH2prime   = xiBDH*exp(-xiBDH*time1) - chiBDH*ThetaBDH_2prime*exp(-chiBDH*time1);
VBADN1prime   = xiADN*exp(-xiADN*time1) - chiADN*ThetaADN_1prime*exp(-chiADN*time1);
VBADN2prime   = xiADN*exp(-xiADN*time1) - chiADN*ThetaADN_2prime*exp(-chiADN*time1);
VBBDN1prime   = xiBDN*exp(-xiBDN*time1) - chiBDN*ThetaBDN_1prime*exp(-chiBDN*time1);
VBBDN2prime   = xiBDN*exp(-xiBDN*time1) - chiBDN*ThetaBDN_2prime*exp(-chiBDN*time1);

VgG      = gG + exp(-xi*time1) - (1-barg)*exp(-chi*time1);
VgASH    = gASH + exp(-xiASH*time1) - (1-baraSH)*exp(-chiASH*time1);
VgBSH    = gBSH + exp(-xiBSH*time1) - (1-barbSH)*exp(-chiBSH*time1);
VgASN    = gASN + exp(-xiASN*time1) - (1-baraSN)*exp(-chiASN*time1);
VgBSN    = gBSN + exp(-xiBSN*time1) - (1-barbSN)*exp(-chiBSN*time1);
VgADH    = gADH + exp(-xiADH*time1) - (1-baraDH)*exp(-chiADH*time1);
VgBDH    = gBDH + exp(-xiBDH*time1) - (1-barbDH)*exp(-chiBDH*time1);
VgADN    = gADN + exp(-xiADN*time1) - (1-baraDN)*exp(-chiADN*time1);
VgBDN    = gBDN + exp(-xiBDN*time1) - (1-barbDN)*exp(-chiBDN*time1);

X1 = X11*exp(nu_1*time1) + (DeltaG_1*VG1) + (DeltaASH_1*VASH1) + (DeltaBSH_1*VBSH1) + (DeltaASN_1*VASN1) + (DeltaBSN_1*VBSN1) + (DeltaADH_1*VADH1) + (DeltaBDH_1*VBDH1) + (DeltaADN_1*VADN1) + (DeltaBDN_1*VBDN1);
X2 = - (DeltaG_2*VG2) - (DeltaASH_2*VASH2) - (DeltaBSH_2*VBSH2) - (DeltaASN_2*VASN2) - (DeltaBSN_2*VBSN2) - (DeltaADH_2*VADH2) - (DeltaBDH_2*VBDH2) - (DeltaADN_2*VADN2) - (DeltaBDN_2*VBDN2);
                 
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathdGHY1    = omegaGH*(1-omegaGN)*omegaG*VgG*100;              
pathdGNY1    = omegaGH*omegaGN*omegaG*VgG*100;                  
pathdGFY1    = (1-omegaGH)*(1-omegaGN)*omegaG*VgG*100;          
pathdGY1     = omegaG_0*VgG*100;                                
                                                                
pathdASH1    = VgASH*100;                                       
pathdBSH1    = VgBSH*100;                                       
pathdASN1    = VgASN*100;                                       
pathdBSN1    = VgBSN*100;                                       
                                                                
pathdADH1    = VgADH*100;                                       
pathdBDH1    = VgBDH*100;                                       
pathdADN1    = VgADN*100;                                       
pathdBDN1    = VgBDN*100;                                       
                                                        
VgAH         = ((eta*VgASH) + (1-eta)*VgADH);           
VgBH         = ((eta*VgBSH) + (1-eta)*VgBDH);           
VgAN         = ((eta*VgASN) + (1-eta)*VgADN);           
VgBN         = ((eta*VgBSN) + (1-eta)*VgBDN);   
VgZSH        = ((sLH_0*VgASH) + (1-sLH_0)*VgBSH );   
VgZSN        = ((sLN_0*VgASN) + (1-sLN_0)*VgBSN );   
VgZDH        = ((sLH_0*VgADH) + (1-sLH_0)*VgBDH );   
VgZDN        = ((sLN_0*VgADN) + (1-sLN_0)*VgBDN );   
VgZH         = ((sLH_0*VgAH) + (1-sLH_0)*VgBH );        
VgZN         = ((sLN_0*VgAN) + (1-sLN_0)*VgBN );        
VgZA         = (omegaYH_0*VgZH) + (1-omegaYH_0)*VgZN;   
                                                        
pathdAH1     = VgAH*100;                                
pathdBH1     = VgBH*100;                                
pathdAN1     = VgAN*100;                                
pathdBN1     = VgBN*100;  
pathdZSH1    = VgZSH*100;  
pathdZSN1    = VgZSN*100;  
pathdZDH1    = VgZDH*100;  
pathdZDN1    = VgZDN*100;  
pathdZH1     = VgZH*100;                                
pathdZN1     = VgZN*100;                                
pathdZA1     = VgZA*100;                              
pathdFBTCH1  = ((1-sigmaH)/sigmaH)*( VgBH - VgAH )*100; 
pathdFBTCN1  = ((1-sigmaN)/sigmaN)*( VgBN - VgAN )*100; 

pathdK1      = (((K_eta0_8402-K_0) + (X1 + X2) )/K_0)*100;
pathdQ1      = (((PI_eta0_8402-PI_0) + (omega_21*X1) + (omega_22*X2) )/PI_0)*100;
pathdP1      = (((P_eta0_8402-P_0) + (wP_1*X1) + (wP_2*X2) + (P_G*Y_0*VG) + (P_ASH*AH_0*VASH) + (P_BSH*BH_0*VBSH) + (P_ASN*AN_0*VASN) + (P_BSN*BN_0*VBSN) + (P_ADH*AH_0*VADH) + (P_BDH*BH_0*VBDH) + (P_ADN*AN_0*VADN) + (P_BDN*BN_0*VBDN) )/P_0)*100;
pathdPH1     = (((PH_eta0_8402-PH_0) + (wPH_1*X1) + (wPH_2*X2) + (PH_G*Y_0*VG) + (PH_ASH*AH_0*VASH) + (PH_BSH*BH_0*VBSH) + (PH_ASN*AN_0*VASN) + (PH_BSN*BN_0*VBSN) + (PH_ADH*AH_0*VADH) + (PH_BDH*BH_0*VBDH) + (PH_ADN*AN_0*VADN) + (PH_BDN*BN_0*VBDN) )/PH_0)*100;
pathdPN1     = (((PN_eta0_8402-PN_0) + (wPN_1*X1) + (wPN_2*X2) + (PN_G*Y_0*VG) + (PN_ASH*AH_0*VASH) + (PN_BSH*BH_0*VBSH) + (PN_ASN*AN_0*VASN) + (PN_BSN*BN_0*VBSN) + (PN_ADH*AH_0*VADH) + (PN_BDH*BH_0*VBDH) + (PN_ADN*AN_0*VADN) + (PN_BDN*BN_0*VBDN) )/PN_0)*100;
pathdCY1     = ( PC_0*((C_eta0_8402-C_0) + (wC_1*X1) + (wC_2*X2) + (C_G*Y_0*VG) + (C_ASH*AH_0*VASH) + (C_BSH*BH_0*VBSH) + (C_ASN*AN_0*VASN) + (C_BSN*BN_0*VBSN) + (C_ADH*AH_0*VADH) + (C_BDH*BH_0*VBDH) + (C_ADN*AN_0*VADN) + (C_BDN*BN_0*VBDN) )/Y_0 )*100;
pathdJY1     = ( PI_0*((I_eta0_8402-I_0) + (wJ_1*X1) + (wJ_2*X2) + (J_G*Y_0*VG) + (J_ASH*AH_0*VASH) + (J_BSH*BH_0*VBSH) + (J_ASN*AN_0*VASN) + (J_BSN*BN_0*VBSN) + (J_ADH*AH_0*VADH) + (J_BDH*BH_0*VBDH) + (J_ADN*AN_0*VADN) + (J_BDN*BN_0*VBDN) )/Y_0 )*100;
pathdNXY1    = ( ((NX_eta0_8402-NX_0) + (wNX_1*X1) + (wNX_2*X2) + (NX_G*Y_0*VG) + (NX_ASH*AH_0*VASH) + (NX_BSH*BH_0*VBSH) + (NX_ASN*AN_0*VASN) + (NX_BSN*BN_0*VBSN) + (NX_ADH*AH_0*VADH) + (NX_BDH*BH_0*VBDH) + (NX_ADN*AN_0*VADN) + (NX_BDN*BN_0*VBDN) )/Y_0 )*100;

pathdQPI1    = ( (wQPI_1*X1) + (wQPI_2*X2) + (QPI_G*Y_0*VG) + (QPI_ASH*AH_0*VASH) + (QPI_BSH*BH_0*VBSH) + (QPI_ASN*AN_0*VASN) + (QPI_BSN*BN_0*VBSN) + (QPI_ADH*AH_0*VADH) + (QPI_BDH*BH_0*VBDH) + (QPI_ADN*AN_0*VADN) + (QPI_BDN*BN_0*VBDN) )*100;
pathdL1      = (((L_eta0_8402-L_0)  + (wL_1*X1) + (wL_2*X2) + (L_G*Y_0*VG) + (L_ASH*AH_0*VASH) + (L_BSH*BH_0*VBSH) + (L_ASN*AN_0*VASN) + (L_BSN*BN_0*VBSN) + (L_ADH*AH_0*VADH) + (L_BDH*BH_0*VBDH) + (L_ADN*AN_0*VADN) + (L_BDN*BN_0*VBDN) )/L_0)*100;
pathdLH1     = ( (WH_0/W_0)*( (LH_eta0_8402-LH_0) + (wLH_1*X1) + (wLH_2*X2) + (LH_G*Y_0*VG) + (LH_ASH*AH_0*VASH) + (LH_BSH*BH_0*VBSH) + (LH_ASN*AN_0*VASN) + (LH_BSN*BN_0*VBSN) + (LH_ADH*AH_0*VADH) + (LH_BDH*BH_0*VBDH) + (LH_ADN*AN_0*VADN) + (LH_BDN*BN_0*VBDN) )/L_0)*100;
pathdLN1     = ( (WN_0/W_0)*( (LN_eta0_8402-LN_0) + (wLN_1*X1) + (wLN_2*X2) + (LN_G*Y_0*VG) + (LN_ASH*AH_0*VASH) + (LN_BSH*BH_0*VBSH) + (LN_ASN*AN_0*VASN) + (LN_BSN*BN_0*VBSN) + (LN_ADH*AH_0*VADH) + (LN_BDH*BH_0*VBDH) + (LN_ADN*AN_0*VADN) + (LN_BDN*BN_0*VBDN) )/L_0)*100;
pathdW1      = (((W_eta0_8402-W_0) + (wW_1*X1) + (wW_2*X2) + (W_G*Y_0*VG) + (W_ASH*AH_0*VASH) + (W_BSH*BH_0*VBSH) + (W_ASN*AN_0*VASN) + (W_BSN*BN_0*VBSN) + (W_ADH*AH_0*VADH) + (W_BDH*BH_0*VBDH) + (W_ADN*AN_0*VADN) + (W_BDN*BN_0*VBDN) )/W_0)*100;
pathdR1      = (((RK_eta0_8402-RK_0) + (wR_1*X1) + (wR_2*X2) + (R_G*Y_0*VG) + (R_ASH*AH_0*VASH) + (R_BSH*BH_0*VBSH) + (R_ASN*AN_0*VASN) + (R_BSN*BN_0*VBSN) + (R_ADH*AH_0*VADH) + (R_BDH*BH_0*VBDH) + (R_ADN*AN_0*VADN) + (R_BDN*BN_0*VBDN) )/RK_0)*100;
pathdWPC1    = (((WPC_eta0_8402-WPC_0) + (wWPC_1*X1) + (wWPC_2*X2) + (WPC_G*Y_0*VG)  + (WPC_ASH*AH_0*VASH) + (WPC_BSH*BH_0*VBSH) + (WPC_ASN*AN_0*VASN) + (WPC_BSN*BN_0*VBSN) + (WPC_ADH*AH_0*VADH) + (WPC_BDH*BH_0*VBDH) + (WPC_ADN*AN_0*VADN) + (WPC_BDN*BN_0*VBDN) )/WPC_0)*100;
pathdYR1     = (((YR_eta0_8402-Y_0) + (wYR_1*X1) + (wYR_2*X2) + (YR_G*Y_0*VG) + (YR_ASH*AH_0*VASH) + (YR_BSH*BH_0*VBSH) + (YR_ASN*AN_0*VASN) + (YR_BSN*BN_0*VBSN) + (YR_ADH*AH_0*VADH) + (YR_BDH*BH_0*VBDH) + (YR_ADN*AN_0*VADN) + (YR_BDN*BN_0*VBDN) )/Y_0)*100;
pathdYH1     = ( PH_0*((YH_eta0_8402-YH_0) + (wYH_1*X1) + (wYH_2*X2) + (YH_G*Y_0*VG) + (YH_ASH*AH_0*VASH) + (YH_BSH*BH_0*VBSH) + (YH_ASN*AN_0*VASN) + (YH_BSN*BN_0*VBSN) + (YH_ADH*AH_0*VADH) + (YH_BDH*BH_0*VBDH) + (YH_ADN*AN_0*VADN) + (YH_BDN*BN_0*VBDN) )/Y_0)*100;
pathdYN1     = ( PN_0*((YN_eta0_8402-YN_0) + (wYN_1*X1) + (wYN_2*X2) + (YN_G*Y_0*VG) + (YN_ASH*AH_0*VASH) + (YN_BSH*BH_0*VBSH) + (YN_ASN*AN_0*VASN) + (YN_BSN*BN_0*VBSN) + (YN_ADH*AH_0*VADH) + (YN_BDH*BH_0*VBDH) + (YN_ADN*AN_0*VADN) + (YN_BDN*BN_0*VBDN) )/Y_0)*100;
pathdWH1     = (((WH_eta0_8402-WH_0) + (wWH_1*X1) + (wWH_2*X2) + (WH_G*Y_0*VG) + (WH_ASH*AH_0*VASH) + (WH_BSH*BH_0*VBSH) + (WH_ASN*AN_0*VASN) + (WH_BSN*BN_0*VBSN) + (WH_ADH*AH_0*VADH) + (WH_BDH*BH_0*VBDH) + (WH_ADN*AN_0*VADN) + (WH_BDN*BN_0*VBDN) )/WH_0)*100;
pathdWN1     = (((WN_eta0_8402-WN_0) + (wWN_1*X1) + (wWN_2*X2) + (WN_G*Y_0*VG) + (WN_ASH*AH_0*VASH) + (WN_BSH*BH_0*VBSH) + (WN_ASN*AN_0*VASN) + (WN_BSN*BN_0*VBSN) + (WN_ADH*AH_0*VADH) + (WN_BDH*BH_0*VBDH) + (WN_ADN*AN_0*VADN) + (WN_BDN*BN_0*VBDN) )/WN_0)*100;
pathdWHPC1   = (((WHPC_eta0_8402-WHPC_0) + (wWHPC_1*X1) + (wWHPC_2*X2) + (WHPC_G*Y_0*VG)  + (WHPC_ASH*AH_0*VASH) + (WHPC_BSH*BH_0*VBSH) + (WHPC_ASN*AN_0*VASN) + (WHPC_BSN*BN_0*VBSN) + (WHPC_ADH*AH_0*VADH) + (WHPC_BDH*BH_0*VBDH) + (WHPC_ADN*AN_0*VADN) + (WHPC_BDN*BN_0*VBDN) )/WHPC_0)*100;
pathdWNPC1   = (((WNPC_eta0_8402-WNPC_0) + (wWNPC_1*X1) + (wWNPC_2*X2) + (WNPC_G*Y_0*VG)  + (WNPC_ASH*AH_0*VASH) + (WNPC_BSH*BH_0*VBSH) + (WNPC_ASN*AN_0*VASN) + (WNPC_BSN*BN_0*VBSN) + (WNPC_ADH*AH_0*VADH) + (WNPC_BDH*BH_0*VBDH) + (WNPC_ADN*AN_0*VADN) + (WNPC_BDN*BN_0*VBDN) )/WNPC_0)*100;
pathdRHPH1    = ((((RK_eta0_8402/PH_eta0_8402)-(RK_0/PH_0)) + (wRHPH_1*X1) + (wRHPH_2*X2) + (RHPH_G*Y_0*VG) + (RHPH_ASH*AH_0*VASH) + (RHPH_BSH*BH_0*VBSH) + (RHPH_ASN*AN_0*VASN) + (RHPH_BSN*BN_0*VBSN) + (RHPH_ADH*AH_0*VADH) + (RHPH_BDH*BH_0*VBDH) + (RHPH_ADN*AN_0*VADN) + (RHPH_BDN*BN_0*VBDN) )/(RK_0/PH_0))*100; 
pathdRNPN1    = ((((RK_eta0_8402/PN_eta0_8402)-(RK_0/PN_0)) + (wRNPN_1*X1) + (wRNPN_2*X2) + (RNPN_G*Y_0*VG) + (RNPN_ASH*AH_0*VASH) + (RNPN_BSH*BH_0*VBSH) + (RNPN_ASN*AN_0*VASN) + (RNPN_BSN*BN_0*VBSN) + (RNPN_ADH*AH_0*VADH) + (RNPN_BDH*BH_0*VBDH) + (RNPN_ADN*AN_0*VADN) + (RNPN_BDN*BN_0*VBDN) )/(RK_0/PN_0))*100; 

pathdOmega1  = (((Omega_eta0_8402-Omega_0) + (wOmega_1*X1) + (wOmega_2*X2) + (Omega_G*Y_0*VG) + (Omega_ASH*AH_0*VASH) + (Omega_BSH*BH_0*VBSH) + (Omega_ASN*AN_0*VASN) + (Omega_BSN*BN_0*VBSN) + (Omega_ADH*AH_0*VADH) + (Omega_BDH*BH_0*VBDH) + (Omega_ADN*AN_0*VADN) + (Omega_BDN*BN_0*VBDN) )/Omega_0)*100;
pathdYHYN1   = (PH_0/PN_0)*( ((YH_eta0_8402/YN_eta0_8402)-(YH_0/YN_0)) + (wYHYN_1*X1) + (wYHYN_2*X2) + (YHYN_G*Y_0*VG) + (YHYN_ASH*AH_0*VASH) + (YHYN_BSH*BH_0*VBSH) + (YHYN_ASN*AN_0*VASN) + (YHYN_BSN*BN_0*VBSN) + (YHYN_ADH*AH_0*VADH) + (YHYN_BDH*BH_0*VBDH) + (YHYN_ADN*AN_0*VADN) + (YHYN_BDN*BN_0*VBDN) )*100;
pathdLHLN1   = (WH_0/WN_0)*( ((LH_eta0_8402/LN_eta0_8402)-(LH_0/LN_0)) + (wLHLN_1*X1) + (wLHLN_2*X2) + (LHLN_G*Y_0*VG) + (LHLN_ASH*AH_0*VASH) + (LHLN_BSH*BH_0*VBSH) + (LHLN_ASN*AN_0*VASN) + (LHLN_BSN*BN_0*VBSN) + (LHLN_ADH*AH_0*VADH) + (LHLN_BDH*BH_0*VBDH) + (LHLN_ADN*AN_0*VADN) + (LHLN_BDN*BN_0*VBDN) )*100;
pathdLHS1    = (WH_0/W_0)*( ((LH_eta0_8402/L_eta0_8402)- (LH_0/L_0)) + (wLHS_1*X1) + (wLHS_2*X2) + (LHS_G*Y_0*VG) + (LHS_ASH*AH_0*VASH) + (LHS_BSH*BH_0*VBSH) + (LHS_ASN*AN_0*VASN) + (LHS_BSN*BN_0*VBSN) + (LHS_ADH*AH_0*VADH) + (LHS_BDH*BH_0*VBDH) + (LHS_ADN*AN_0*VADN) + (LHS_BDN*BN_0*VBDN) )*100;
pathdLNS1    = (WN_0/W_0)*( ((LN_eta0_8402/L_eta0_8402)- (LN_0/L_0)) + (wLNS_1*X1) + (wLNS_2*X2) + (LNS_G*Y_0*VG) + (LNS_ASH*AH_0*VASH)  + (LNS_BSH*BH_0*VBSH) + (LNS_ASN*AN_0*VASN) + (LNS_BSN*BN_0*VBSN) + (LNS_ADH*AH_0*VADH)  + (LNS_BDH*BH_0*VBDH) + (LNS_ADN*AN_0*VADN) + (LNS_BDN*BN_0*VBDN) )*100;
pathdYHS1    = PH_0*( ((YH_eta0_8402/YR_eta0_8402)- (YH_0/YR_0)) + (wYHS_1*X1) + (wYHS_2*X2) + (YHS_G*Y_0*VG) + (YHS_ASH*AH_0*VASH) + (YHS_BSH*BH_0*VBSH) + (YHS_ASN*AN_0*VASN) + (YHS_BSN*BN_0*VBSN) + (YHS_ADH*AH_0*VADH) + (YHS_BDH*BH_0*VBDH) + (YHS_ADN*AN_0*VADN) + (YHS_BDN*BN_0*VBDN) )*100;
pathdYNS1    = PN_0*( ((YN_eta0_8402/YR_eta0_8402)- (YN_0/YR_0)) + (wYNS_1*X1) + (wYNS_2*X2) + (YNS_G*Y_0*VG) + (YNS_ASH*AH_0*VASH) + (YNS_BSH*BH_0*VBSH) + (YNS_ASN*AN_0*VASN) + (YNS_BSN*BN_0*VBSN) + (YNS_ADH*AH_0*VADH) + (YNS_BDH*BH_0*VBDH) + (YNS_ADN*AN_0*VADN) + (YNS_BDN*BN_0*VBDN) )*100;
pathdWHW1    = (( ((WH_eta0_8402/W_eta0_8402)-(WH_0/W_0)) + (wWHW_1*X1) + (wWHW_2*X2) + (WHW_G*Y_0*VG) + (WHW_ASH*AH_0*VASH) + (WHW_BSH*BH_0*VBSH) + (WHW_ASN*AN_0*VASN) + (WHW_BSN*BN_0*VBSN) + (WHW_ADH*AH_0*VADH) + (WHW_BDH*BH_0*VBDH) + (WHW_ADN*AN_0*VADN) + (WHW_BDN*BN_0*VBDN) )/(WH_0/W_0) )*100;
pathdWNW1    = (( ((WN_eta0_8402/W_eta0_8402)-(WN_0/W_0)) + (wWNW_1*X1) + (wWNW_2*X2) + (WNW_G*Y_0*VG) + (WNW_ASH*AH_0*VASH) + (WNW_BSH*BH_0*VBSH) + (WNW_ASN*AN_0*VASN) + (WNW_BSN*BN_0*VBSN) + (WNW_ADH*AH_0*VADH) + (WNW_BDH*BH_0*VBDH) + (WNW_ADN*AN_0*VADN) + (WNW_BDN*BN_0*VBDN) )/(WN_0/W_0) )*100;
pathdKHK1    =  ( ((KH_eta0_8402/K_eta0_8402)-(KH_0/K_0)) + (wKHK_1*X1) + (wKHK_2*X2) + (KHK_G*Y_0*VG) + (KHK_ASH*AH_0*VASH) + (KHK_BSH*BH_0*VBSH) + (KHK_ASN*AN_0*VASN) + (KHK_BSN*BN_0*VBSN) + (KHK_ADH*AH_0*VADH) + (KHK_BDH*BH_0*VBDH) + (KHK_ADN*AN_0*VADN) + (KHK_BDN*BN_0*VBDN) )*100;
pathdKNK1    =  ( ((KN_eta0_8402/K_eta0_8402)-(KN_0/K_0)) + (wKNK_1*X1) + (wKNK_2*X2) + (KNK_G*Y_0*VG) + (KNK_ASH*AH_0*VASH) + (KNK_BSH*BH_0*VBSH) + (KNK_ASN*AN_0*VASN) + (KNK_BSN*BN_0*VBSN) + (KNK_ADH*AH_0*VADH) + (KNK_BDH*BH_0*VBDH) + (KNK_ADN*AN_0*VADN) + (KNK_BDN*BN_0*VBDN) )*100;

pathdkH1     = ( LH_0*((kH_eta0_8402-kH_0) + (wkH_1*X1) + (wkH_2*X2) + (kH_G*Y_0*VG) + (kH_ASH*AH_0*VASH) + (kH_BSH*BH_0*VBSH) + (kH_ASN*AN_0*VASN) + (kH_BSN*BN_0*VBSN) + (kH_ADH*AH_0*VADH) + (kH_BDH*BH_0*VBDH) + (kH_ADN*AN_0*VADN) + (kH_BDN*BN_0*VBDN) )/K_0)*100;
pathdkN1     = ( LN_0*((kN_eta0_8402-kN_0) + (wkN_1*X1) + (wkN_2*X2) + (kN_G*Y_0*VG) + (kN_ASH*AH_0*VASH) + (kN_BSH*BH_0*VBSH) + (kN_ASN*AN_0*VASN) + (kN_BSN*BN_0*VBSN) + (kN_ADH*AH_0*VADH) + (kN_BDH*BH_0*VBDH) + (kN_ADN*AN_0*VADN) + (kN_BDN*BN_0*VBDN) )/K_0)*100;
pathdLISH1   = ( (sLH_eta0_8402-sLH_0) + (wLISH_1*X1) + (wLISH_2*X2) + (LISH_G*Y_0*VG) + (LISH_ASH*AH_0*VASH) + (LISH_BSH*BH_0*VBSH) + (LISH_ASN*AN_0*VASN) + (LISH_BSN*BN_0*VBSN) + (LISH_ADH*AH_0*VADH) + (LISH_BDH*BH_0*VBDH) + (LISH_ADN*AN_0*VADN) + (LISH_BDN*BN_0*VBDN) )*100;
pathdLISN1   = ( (sLN_eta0_8402-sLN_0) + (wLISN_1*X1) + (wLISN_2*X2) + (LISN_G*Y_0*VG) + (LISN_ASH*AH_0*VASH) + (LISN_BSH*BH_0*VBSH) + (LISN_ASN*AN_0*VASN) + (LISN_BSN*BN_0*VBSN) + (LISN_ADH*AH_0*VADH) + (LISN_BDH*BH_0*VBDH) + (LISN_ADN*AN_0*VADN) + (LISN_BDN*BN_0*VBDN) )*100;

%%%%%%%%% TrASNitional paths - including capital utilization rates ADN TFP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathduKSH1   = ( (wuKSH_1*X1) + (wuKSH_2*X2) + (uKSH_G*Y_0*VG) + (uKSH_ASH*AH_0*VASH) + (uKSH_BSH*BH_0*VBSH) + (uKSH_ASN*AN_0*VASN) + (uKSH_BSN*BN_0*VBSN) + (uKSH_ADH*AH_0*VADH) + (uKSH_BDH*BH_0*VBDH) + (uKSH_ADN*AN_0*VADN) + (uKSH_BDN*BN_0*VBDN) )*100;
pathduKDH1   = ( (wuKDH_1*X1) + (wuKDH_2*X2) + (uKDH_G*Y_0*VG) + (uKDH_ASH*AH_0*VASH) + (uKDH_BSH*BH_0*VBSH) + (uKDH_ASN*AN_0*VASN) + (uKDH_BSN*BN_0*VBSN) + (uKDH_ADH*AH_0*VADH) + (uKDH_BDH*BH_0*VBDH) + (uKDH_ADN*AN_0*VADN) + (uKDH_BDN*BN_0*VBDN) )*100;
pathduKSN1   = ( (wuKSN_1*X1) + (wuKSN_2*X2) + (uKSN_G*Y_0*VG) + (uKSN_ASH*AH_0*VASH) + (uKSN_BSH*BH_0*VBSH) + (uKSN_ASN*AN_0*VASN) + (uKSN_BSN*BN_0*VBSN) + (uKSN_ADH*AH_0*VADH) + (uKSN_BDH*BH_0*VBDH) + (uKSN_ADN*AN_0*VADN) + (uKSN_BDN*BN_0*VBDN) )*100;
pathduKDN1   = ( (wuKDN_1*X1) + (wuKDN_2*X2) + (uKDN_G*Y_0*VG) + (uKDN_ASH*AH_0*VASH) + (uKDN_BSH*BH_0*VBSH) + (uKDN_ASN*AN_0*VASN) + (uKDN_BSN*BN_0*VBSN) + (uKDN_ADH*AH_0*VADH) + (uKDN_BDH*BH_0*VBDH) + (uKDN_ADN*AN_0*VADN) + (uKDN_BDN*BN_0*VBDN) )*100;
pathduKH1    = ( (wuKH_1*X1) + (wuKH_2*X2) + (uKH_G*Y_0*VG) + (uKH_ASH*AH_0*VASH) + (uKH_BSH*BH_0*VBSH) + (uKH_ASN*AN_0*VASN) + (uKH_BSN*BN_0*VBSN) + (uKH_ADH*AH_0*VADH) + (uKH_BDH*BH_0*VBDH) + (uKH_ADN*AN_0*VADN) + (uKH_BDN*BN_0*VBDN) )*100;
pathduKN1    = ( (wuKN_1*X1) + (wuKN_2*X2) + (uKN_G*Y_0*VG) + (uKN_ASH*AH_0*VASH) + (uKN_BSH*BH_0*VBSH) + (uKN_ASN*AN_0*VASN) + (uKN_BSN*BN_0*VBSN) + (uKN_ADH*AH_0*VADH) + (uKN_BDH*BH_0*VBDH) + (uKN_ADN*AN_0*VADN) + (uKN_BDN*BN_0*VBDN) )*100;
pathduK1     = ( (wuK_1*X1) + (wuK_2*X2) + (uK_G*Y_0*VG) + (uK_ASH*AH_0*VASH) + (uK_BSH*BH_0*VBSH) + (uK_ASN*AN_0*VASN) + (uK_BSN*BN_0*VBSN) + (uK_ADH*AH_0*VADH) + (uK_BDH*BH_0*VBDH) + (uK_ADN*AN_0*VADN) + (uK_BDN*BN_0*VBDN) )*100;

%pathdTFPH1   = (( (ZH_eta0_8402-ZH_0) + (wTFPH_1*X1) + (wTFPH_2*X2) + (TFPH_G*Y_0*VG) + (TFPH_ASH*AH_0*VASH) + (TFPH_BSH*BH_0*VBSH) + (TFPH_ASN*AN_0*VASN) + (TFPH_BSN*BN_0*VBSN) + (TFPH_ADH*AH_0*VADH) + (TFPH_BDH*BH_0*VBDH) + (TFPH_ADN*AN_0*VADN) + (TFPH_BDN*BN_0*VBDN) )/ZH_0)*100;
pathdTFPN1   = (( (ZN_eta0_8402-ZN_0) + (wTFPN_1*X1) + (wTFPN_2*X2) + (TFPN_G*Y_0*VG) + (TFPN_ASH*AH_0*VASH) + (TFPN_BSH*BH_0*VBSH) + (TFPN_ASN*AN_0*VASN) + (TFPN_BSN*BN_0*VBSN) + (TFPN_ADH*AH_0*VADH) + (TFPN_BDH*BH_0*VBDH) + (TFPN_ADN*AN_0*VADN) + (TFPN_BDN*BN_0*VBDN) )/ZN_0)*100;
pathdTFPA1   = (( (ZA_eta0_8402-ZA_0) + (wTFPA_1*X1) + (wTFPA_2*X2) + (TFPA_G*Y_0*VG) + (TFPA_ASH*AH_0*VASH) + (TFPA_BSH*BH_0*VBSH) + (TFPA_ASN*AN_0*VASN) + (TFPA_BSN*BN_0*VBSN) + (TFPA_ADH*AH_0*VADH) + (TFPA_BDH*BH_0*VBDH) + (TFPA_ADN*AN_0*VADN) + (TFPA_BDN*BN_0*VBDN) )/ZA_0)*100;   
pathdTFPH1_check   = (( (ZH_eta0_8402-ZH_0) + (wTFPH_1_check*X1) + (wTFPH_2_check*X2) + (TFPH_G_check*Y_0*VG) + (TFPH_ASH_check*AH_0*VASH) + (TFPH_BSH_check*BH_0*VBSH) + (TFPH_ASN_check*AN_0*VASN) + (TFPH_BSN_check*BN_0*VBSN) + (TFPH_ADH_check*AH_0*VADH) + (TFPH_BDH_check*BH_0*VBDH) + (TFPH_ADN_check*AN_0*VADN) + (TFPH_BDN_check*BN_0*VBDN) )/ZH_0)*100;
pathdTFPN1_check   = (( (ZN_eta0_8402-ZN_0) + (wTFPN_1_check*X1) + (wTFPN_2_check*X2) + (TFPN_G_check*Y_0*VG) + (TFPN_ASH_check*AH_0*VASH) + (TFPN_BSH_check*BH_0*VBSH) + (TFPN_ASN_check*AN_0*VASN) + (TFPN_BSN_check*BN_0*VBSN) + (TFPN_ADH_check*AH_0*VADH) + (TFPN_BDH_check*BH_0*VBDH) + (TFPN_ADN_check*AN_0*VADN) + (TFPN_BDN_check*BN_0*VBDN) )/ZN_0)*100;
pathdTFPR1   = (( ((ZH_eta0_8402/ZN_eta0_8402)-(ZH_0/ZN_0)) + (wTFPR_1*X1) + (wTFPR_2*X2) + (TFPR_G*Y_0*VG) + (TFPR_ASH*AH_0*VASH) + (TFPR_BSH*BH_0*VBSH) + (TFPR_ASN*AN_0*VASN) + (TFPR_BSN*BN_0*VBSN)  + (TFPR_ADH*AH_0*VADH) + (TFPR_BDH*BH_0*VBDH) + (TFPR_ADN*AN_0*VADN) + (TFPR_BDN*BN_0*VBDN) )/(ZH_0/ZN_0))*100;

pathdTFPH1    = sLH_0*VgAH*100 + (1-sLH_0)*VgBH*100 + (1-sLH_0)*pathduKH1;
%%%%%%%%%%%%%%% Savings, Investment and Curent Account %%%%%%%%%%%%%%%
CA_ASH = (B_ASH*AH_0/(xiASH+r))*VBASHprime + (N1*DeltaASH_1/(xiASH+r))*VBASH1prime - (N2*DeltaASH_2/(xiASH+r))*VBASH2prime;
CA_BSH = (B_BSH*BH_0/(xiBSH+r))*VBBSHprime + (N1*DeltaBSH_1/(xiBSH+r))*VBBSH1prime - (N2*DeltaBSH_2/(xiBSH+r))*VBBSH2prime;
CA_ASN = (B_ASN*AN_0/(xiASN+r))*VBASNprime + (N1*DeltaASN_1/(xiASN+r))*VBASN1prime - (N2*DeltaASN_2/(xiASN+r))*VBASN2prime;
CA_BSN = (B_BSN*BN_0/(xiBSN+r))*VBBSNprime + (N1*DeltaBSN_1/(xiBSN+r))*VBBSN1prime - (N2*DeltaBSN_2/(xiBSN+r))*VBBSN2prime;

CA_ADH = (B_ADH*AH_0/(xiADH+r))*VBADHprime + (N1*DeltaADH_1/(xiADH+r))*VBADH1prime - (N2*DeltaADH_2/(xiADH+r))*VBADH2prime;
CA_BDH = (B_BDH*BH_0/(xiBDH+r))*VBBDHprime + (N1*DeltaBDH_1/(xiBDH+r))*VBBDH1prime - (N2*DeltaBDH_2/(xiBDH+r))*VBBDH2prime;
CA_ADN = (B_ADN*AN_0/(xiADN+r))*VBADNprime + (N1*DeltaADN_1/(xiADN+r))*VBADN1prime - (N2*DeltaADN_2/(xiADN+r))*VBADN2prime;
CA_BDN = (B_BDN*BN_0/(xiBDN+r))*VBBDNprime + (N1*DeltaBDN_1/(xiBDN+r))*VBBDN1prime - (N2*DeltaBDN_2/(xiBDN+r))*VBBDN2prime;

CA_G  = (B_G*Y_0*omegaG_0/(xi+r))*VBGprime + (N1*DeltaG_1/(xi+r))*VBG1prime - (N2*DeltaG_2/(xi+r))*VBG2prime;

SAV_ASH = (A_ASH*AH_0/(xiASH+r))*VBASHprime + (M1*DeltaASH_1/(xiASH+r))*VBASH1prime - (M2*DeltaASH_2/(xiASH+r))*VBASH2prime;
SAV_BSH = (A_BSH*BH_0/(xiBSH+r))*VBBSHprime + (M1*DeltaBSH_1/(xiBSH+r))*VBBSH1prime - (M2*DeltaBSH_2/(xiBSH+r))*VBBSH2prime;
SAV_ASN = (A_ASN*AN_0/(xiASN+r))*VBASNprime + (M1*DeltaASN_1/(xiASN+r))*VBASN1prime - (M2*DeltaASN_2/(xiASN+r))*VBASN2prime;
SAV_BSN = (A_BSN*BN_0/(xiBSN+r))*VBBSNprime + (M1*DeltaBSN_1/(xiBSN+r))*VBBSN1prime - (M2*DeltaBSN_2/(xiBSN+r))*VBBSN2prime;

SAV_ADH = (A_ADH*AH_0/(xiADH+r))*VBADHprime + (M1*DeltaADH_1/(xiADH+r))*VBADH1prime - (M2*DeltaADH_2/(xiADH+r))*VBADH2prime;
SAV_BDH = (A_BDH*BH_0/(xiBDH+r))*VBBDHprime + (M1*DeltaBDH_1/(xiBDH+r))*VBBDH1prime - (M2*DeltaBDH_2/(xiBDH+r))*VBBDH2prime;
SAV_ADN = (A_ADN*AN_0/(xiADN+r))*VBADNprime + (M1*DeltaADN_1/(xiADN+r))*VBADN1prime - (M2*DeltaADN_2/(xiADN+r))*VBADN2prime;
SAV_BDN = (A_BDN*BN_0/(xiBDN+r))*VBBDNprime + (M1*DeltaBDN_1/(xiBDN+r))*VBBDN1prime - (M2*DeltaBDN_2/(xiBDN+r))*VBBDN2prime;

SAV_G  = (A_G*Y_0*omegaG_0/(xi+r))*VBGprime + (M1*DeltaG_1/(xi+r))*VBG1prime - (M2*DeltaG_2/(xi+r))*VBG2prime;

dotX1 = (nu_1*X11*exp(nu_1*time1)) - (DeltaG_1*VG1prime) - (DeltaASH_1*VASH1prime) - (DeltaBSH_1*VBSH1prime) - (DeltaASN_1*VASN1prime) - (DeltaBSN_1*VBSN1prime) - (DeltaADH_1*VADH1prime) - (DeltaBDH_1*VBDH1prime) - (DeltaADN_1*VADN1prime) - (DeltaBDN_1*VBDN1prime);
dotX2 = (DeltaG_2*VG2prime) + (DeltaASH_2*VASH2prime) + (DeltaBSH_2*VBSH2prime) + (DeltaASN_2*VASN2prime) + (DeltaBSN_2*VBSN2prime) + (DeltaADH_2*VADH2prime) +(DeltaBDH_2*VBDH2prime) + (DeltaADN_2*VADN2prime) + (DeltaBDN_2*VBDN2prime);

pathCAY1 = (( -nu_1*(wB1/(r-nu_1))*exp(nu_1*time1) + CA_ASH + CA_BSH + CA_ASN + CA_BSN + CA_ADH + CA_BDH + CA_ADN + CA_BDN + CA_G )/Y_0 )*100;
pathSY1  = (( -nu_1*(wA1/(r-nu_1))*exp(nu_1*time1) + SAV_ASH + SAV_BSH + SAV_ASN + SAV_BSN + SAV_ADH + SAV_BDH + SAV_ADN + SAV_BDN + SAV_G )/Y_0 )*100;
pathIY1 = (( (EK1*dotX1) + (EK2*dotX2) )/Y_0)*100;

% IRF
timeperm = [time0 time1];
pathdGHY_eta0_8402   = [pathdGY0  pathdGHY1];         
pathdGFY_eta0_8402   = [pathdGY0  pathdGFY1];         
pathdGNY_eta0_8402   = [pathdGY0  pathdGNY1];         
pathdGY_eta0_8402    = [pathdGY0  pathdGY1];          
pathdASH_eta0_8402   = [pathdZH0  pathdASH1];         
pathdBSH_eta0_8402   = [pathdZH0  pathdBSH1];         
pathdASN_eta0_8402   = [pathdZN0  pathdASN1];         
pathdBSN_eta0_8402   = [pathdZN0  pathdBSN1];         
pathdADH_eta0_8402   = [pathdZH0  pathdADH1];         
pathdBDH_eta0_8402   = [pathdZH0  pathdBDH1];         
pathdADN_eta0_8402   = [pathdZN0  pathdADN1];         
pathdBDN_eta0_8402   = [pathdZN0  pathdBDN1];         
                                                 
pathdFBTCH_eta0_8402 = [pathdZH0  pathdFBTCH1];       
pathdFBTCN_eta0_8402 = [pathdZN0  pathdFBTCN1];       
                                                 
pathdZSH_eta0_8402   = [pathdZH0  pathdZSH1];         
pathdZSN_eta0_8402   = [pathdZN0  pathdZSN1];         
pathdZDH_eta0_8402   = [pathdZH0  pathdZDH1];         
pathdZDN_eta0_8402   = [pathdZN0  pathdZDN1];         
pathdZH_eta0_8402    = [pathdZH0  pathdZH1];          
pathdZN_eta0_8402    = [pathdZN0  pathdZN1];          
pathdZA_eta0_8402    = [pathdZA0  pathdZA1];         
                                                 
pathdQ_eta0_8402     = [pathdQ0  pathdQ1];
pathdQPI_eta0_8402   = [pathdQ0  pathdQPI1];
pathdPH_eta0_8402    = [pathdP0  pathdPH1];
pathdPN_eta0_8402    = [pathdP0  pathdPN1];
pathdP_eta0_8402     = [pathdP0  pathdP1]; 
pathdCY_eta0_8402    = [pathCY0  pathdCY1];   
pathdJY_eta0_8402    = [pathIY0  pathdJY1]; 
pathdNXY_eta0_8402   = [pathIY0  pathdNXY1];
pathdL_eta0_8402     = [pathdL0  pathdL1];
pathdK_eta0_8402     = [pathdK0  pathdK1];
pathdLH_eta0_8402    = [pathdLH0 pathdLH1];             
pathdLN_eta0_8402    = [pathdLN0 pathdLN1];  
pathdW_eta0_8402     = [pathdW0 pathdW1]; 
pathdR_eta0_8402     = [pathdR0 pathdR1]; 
pathdWPC_eta0_8402   = [pathdWPC0 pathdWPC1];  
pathdYR_eta0_8402    = [pathdY0 pathdYR1];
pathdYH_eta0_8402    = [pathdY0 pathdYH1];               
pathdYN_eta0_8402    = [pathdY0 pathdYN1];               
pathdWH_eta0_8402    = [pathdWH0  pathdWH1];              
pathdWN_eta0_8402    = [pathdWN0  pathdWN1]; 
pathdWHPC_eta0_8402  = [pathdWH0 pathdWHPC1];
pathdWNPC_eta0_8402  = [pathdWN0 pathdWNPC1];
pathdRHPH_eta0_8402  = [pathdR0 pathdRHPH1];
pathdRNPN_eta0_8402  = [pathdR0 pathdRNPN1];

pathdLHS_eta0_8402   = [pathdLH0 pathdLHS1];             
pathdLNS_eta0_8402   = [pathdLN0 pathdLNS1];
pathdYHS_eta0_8402   = [pathdY0 pathdYHS1];             
pathdYNS_eta0_8402   = [pathdY0 pathdYNS1];
pathdWHW_eta0_8402   = [pathdWH0 pathdWHW1];
pathdWNW_eta0_8402   = [pathdWN0 pathdWNW1];
pathdKHK_eta0_8402   = [pathdkH0 pathdKHK1];             
pathdKNK_eta0_8402   = [pathdkN0 pathdKNK1];

pathdkH_eta0_8402    = [pathdkH0 pathdkH1];             
pathdkN_eta0_8402    = [pathdkN0 pathdkN1];
pathdLISH_eta0_8402  = [pathdLISH0 pathdLISH1];             
pathdLISN_eta0_8402  = [pathdLISN0 pathdLISN1];

pathdOmega_eta0_8402 = [pathdOmega0 pathdOmega1];         
pathdYHYN_eta0_8402  = [pathdYHYN0 pathdYHYN1];           
pathdLHLN_eta0_8402  = [pathdLHLN0 pathdLHLN1];

pathIY_eta0_8402     = [pathIY0  pathIY1];                        
pathCAY_eta0_8402    = [pathCAY0 pathCAY1];               
pathSY_eta0_8402     = [pathSY0  pathSY1];

% IRF including technology and capital utilization rates
pathduKH_eta0_8402   = [pathdkH0 pathduKH1];             
pathduKN_eta0_8402   = [pathdkN0 pathduKN1];
pathduK_eta0_8402    = [pathdkN0 pathduK1];
pathdTFPH_eta0_8402  = [pathdkH0 pathdTFPH1];             
pathdTFPN_eta0_8402  = [pathdkN0 pathdTFPN1];
pathdTFPA_eta0_8402  = [pathdkN0 pathdTFPA1];
pathdTFPH_check_eta0_8402  = [pathdkH0 pathdTFPH1_check];             
pathdTFPN_check_eta0_8402  = [pathdkN0 pathdTFPN1_check];
pathdTFPR_eta0_8402  = [pathdkH0 pathdTFPR1];
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Dynamic and steadty-state effects of a Permanent increase in ZH/ZN %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Impact effects of fiscal shock: dynamic processes 
time1    = [0:Tu:Tg]; % span of time t = [0..100]
VG0       = 1- (1-barg);
VG10      = 1- ThetaG_1;
VG20      = 1- ThetaG_2;

VASH0     = 1 - (1-baraSH);   
VBSH0     = 1 - (1-barbSH);   
VASN0     = 1 - (1-baraSN);   
VBSN0     = 1 - (1-barbSN);   
VADH0     = 1 - (1-baraDH);   
VBDH0     = 1 - (1-barbDH);   
VADN0     = 1 - (1-baraDN);   
VBDN0     = 1 - (1-barbDN);   

VAH0      = (eta*VASH0) + (1-eta)*VADH0;
VBH0      = (eta*VBSH0) + (1-eta)*VBDH0;
VAN0      = (eta*VASN0) + (1-eta)*VADN0;
VBN0      = (eta*VBSN0) + (1-eta)*VBDN0;

VASH10    = 1 - ThetaASH_1;
VASH20    = 1 - ThetaASH_2;
VADH10    = 1 - ThetaADH_1;
VADH20    = 1 - ThetaADH_2;

VBSH10    = 1 - ThetaBSH_1;
VBSH20    = 1 - ThetaBSH_2;
VBDH10    = 1 - ThetaBDH_1;
VBDH20    = 1 - ThetaBDH_2;

VASN10    = 1 - ThetaASN_1;
VASN20    = 1 - ThetaASN_2;
VADN10    = 1 - ThetaADN_1;
VADN20    = 1 - ThetaADN_2;

VBSN10    = 1 - ThetaBSN_1;
VBSN20    = 1 - ThetaBSN_2;
VBDN10    = 1 - ThetaBDN_1;
VBDN20    = 1 - ThetaBDN_2;

VAH10     = (eta*VASH10) + (1-eta)*VADH10;
VBH10     = (eta*VBSH10) + (1-eta)*VBDH10;
VAN10     = (eta*VASN10) + (1-eta)*VADN10;
VBN10     = (eta*VBSN10) + (1-eta)*VBDN10;

VAH20     = (eta*VASH20) + (1-eta)*VADH20;
VBH20     = (eta*VBSH20) + (1-eta)*VBDH20;
VAN20     = (eta*VASN20) + (1-eta)*VADN20;
VBN20     = (eta*VBSN20) + (1-eta)*VBDN20;

VG1prime0  = xi - chi*ThetaG_1;
VG2prime0  = xi - chi*ThetaG_2;
VGprime0   = xi - chi*(1-barg);
VBG1prime0 = xi - chi*ThetaG_1prime;
VBG2prime0 = xi - chi*ThetaG_2prime;
VBGprime0  = xi - chi*ThetaG_prime;

VASH1prime0    = xiASH - chiASH*ThetaASH_1;
VASH2prime0    = xiASH - chiASH*ThetaASH_2;
VBSH1prime0    = xiBSH - chiBSH*ThetaBSH_1;
VBSH2prime0    = xiBSH - chiBSH*ThetaBSH_2;
VASN1prime0    = xiASN - chiASN*ThetaASN_1;
VASN2prime0    = xiASN - chiASN*ThetaASN_2;
VBSN1prime0    = xiBSN - chiBSN*ThetaBSN_1;
VBSN2prime0    = xiBSN - chiBSN*ThetaBSN_2;

VADH1prime0    = xiADH - chiADH*ThetaADH_1;
VADH2prime0    = xiADH - chiADH*ThetaADH_2;
VBDH1prime0    = xiBDH - chiBDH*ThetaBDH_1;
VBDH2prime0    = xiBDH - chiBDH*ThetaBDH_2;
VADN1prime0    = xiADN - chiADN*ThetaADN_1;
VADN2prime0    = xiADN - chiADN*ThetaADN_2;
VBDN1prime0    = xiBDN - chiBDN*ThetaBDN_1;
VBDN2prime0    = xiBDN - chiBDN*ThetaBDN_2;

VBASHprime0    = xiASH - chiASH*ThetaASH_prime;
VBBSHprime0    = xiBSH - chiBSH*ThetaBSH_prime;
VBASNprime0    = xiASN - chiASN*ThetaASN_prime;
VBBSNprime0    = xiBSN - chiBSN*ThetaBSN_prime;

VBADHprime0    = xiADH - chiADH*ThetaADH_prime;
VBBDHprime0    = xiBDH - chiBDH*ThetaBDH_prime;
VBADNprime0    = xiADN - chiADN*ThetaADN_prime;
VBBDNprime0    = xiBDN - chiBDN*ThetaBDN_prime;

VBASH1prime0   = xiASH - chiASH*ThetaASH_1prime;
VBASH2prime0   = xiASH - chiASH*ThetaASH_2prime;
VBBSH1prime0   = xiBSH - chiBSH*ThetaBSH_1prime;
VBBSH2prime0   = xiBSH - chiBSH*ThetaBSH_2prime;
VBASN1prime0   = xiASN - chiASN*ThetaASN_1prime;
VBASN2prime0   = xiASN - chiASN*ThetaASN_2prime;
VBBSN1prime0   = xiBSN - chiBSN*ThetaBSN_1prime;
VBBSN2prime0   = xiBSN - chiBSN*ThetaBSN_2prime;

VBADH1prime0   = xiADH - chiADH*ThetaADH_1prime;
VBADH2prime0   = xiADH - chiADH*ThetaADH_2prime;
VBBDH1prime0   = xiBDH - chiBDH*ThetaBDH_1prime;
VBBDH2prime0   = xiBDH - chiBDH*ThetaBDH_2prime;
VBADN1prime0   = xiADN - chiADN*ThetaADN_1prime;
VBADN2prime0   = xiADN - chiADN*ThetaADN_2prime;
VBBDN1prime0   = xiBDN - chiBDN*ThetaBDN_1prime;
VBBDN2prime0   = xiBDN - chiBDN*ThetaBDN_2prime;

VgG0      = gG + 1 - (1-barg);
VgASH0    = gASH + 1 - (1-baraSH);
VgBSH0    = gBSH + 1 - (1-barbSH);
VgASN0    = gASN + 1 - (1-baraSN);
VgBSN0    = gBSN + 1 - (1-barbSN);
VgADH0    = gADH + 1 - (1-baraDH);
VgBDH0    = gBDH + 1 - (1-barbDH);
VgADN0    = gADN + 1 - (1-baraDN);
VgBDN0    = gBDN + 1 - (1-barbDN);

X10 = X11 + (DeltaG_1*VG10) + (DeltaASH_1*VASH10) + (DeltaBSH_1*VBSH10) + (DeltaASN_1*VASN10) + (DeltaBSN_1*VBSN10) + (DeltaADH_1*VADH10) + (DeltaBDH_1*VBDH10) + (DeltaADN_1*VADN10) + (DeltaBDN_1*VBDN10);
X20 = - (DeltaG_2*VG20) - (DeltaASH_2*VASH20) - (DeltaBSH_2*VBSH20) - (DeltaASN_2*VASN20) - (DeltaBSN_2*VBSN20) - (DeltaADH_2*VADH20) - (DeltaBDH_2*VBDH20) - (DeltaADN_2*VADN20) - (DeltaBDN_2*VBDN20);
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dGHYtime0_eta0_8402    = omegaGH*(1-omegaGN)*omegaG*VgG0*100;                 
dGNYtime0_eta0_8402    = omegaGH*omegaGN*omegaG*VgG0*100;                     
dGFYtime0_eta0_8402    = (1-omegaGH)*(1-omegaGN)*omegaG*VgG0*100;             
dGYtime0_eta0_8402     = omegaG_0*VgG0*100;                                   
                                                                         
dASHtime0_eta0_8402    = VgASH0*100;                                          
dBSHtime0_eta0_8402    = VgBSH0*100;                                          
dASNtime0_eta0_8402    = VgASN0*100;                                          
dBSNtime0_eta0_8402    = VgBSN0*100;                                          
                                                                         
dADHtime0_eta0_8402    = VgADH0*100;                                          
dBDHtime0_eta0_8402    = VgBDH0*100;                                          
dADNtime0_eta0_8402    = VgADN0*100;                                          
dBDNtime0_eta0_8402    = VgBDN0*100;       

VgZSH0  = ((sLH_0*VgASH0) + (1-sLH_0)*VgBSH0);  
VgZSN0  = ((sLN_0*VgASN0) + (1-sLN_0)*VgBSN0);  
VgZDH0  = ((sLH_0*VgADH0) + (1-sLH_0)*VgBDH0);  
VgZDN0  = ((sLN_0*VgADN0) + (1-sLN_0)*VgBDN0);  
                                                                         
VgAH0    = ((eta*VgASH0) + (1-eta)*VgADH0);                              
VgBH0    = ((eta*VgBSH0) + (1-eta)*VgBDH0);                              
VgAN0    = ((eta*VgASN0) + (1-eta)*VgADN0);                              
VgBN0    = ((eta*VgBSN0) + (1-eta)*VgBDN0);                              
VgZH0    = ((sLH_0*VgAH0) + (1-sLH_0)*VgBH0);                            
VgZN0    = ((sLN_0*VgAN0) + (1-sLN_0)*VgBN0);                            
VgZA0    = (omegaYH_0*VgZH0) + (1-omegaYH_0)*VgZN0;                      
                                                                         
dAHtime0_eta0_8402     = VgAH0*100;                                           
dBHtime0_eta0_8402     = VgBH0*100;                                           
dANtime0_eta0_8402     = VgAN0*100;                                           
dBNtime0_eta0_8402     = VgBN0*100;   

dZSHtime0_eta0_8402  = VgZSH0*100;  
dZSNtime0_eta0_8402  = VgZSN0*100;  
dZDHtime0_eta0_8402  = VgZDH0*100;  
dZDNtime0_eta0_8402  = VgZDN0*100;  
                                                                         
dZHtime0_eta0_8402     = VgZH0*100;                                           
dZNtime0_eta0_8402     = VgZN0*100;                                           
dZAtime0_eta0_8402     = VgZA0*100;                                           
dFBTCHtime0_eta0_8402  = ((1-sigmaH)/sigmaH)*( VgBH0 - VgAH0 )*100;           
dFBTCNtime0_eta0_8402  = ((1-sigmaN)/sigmaN)*( VgBN0 - VgAN0 )*100;           

dKtime0_eta0_8402      = (((K_eta0_8402-K_0) + (X10 + X20) )/K_0)*100;
dQtime0_eta0_8402      = (((PI_eta0_8402-PI_0) + (omega_21*X10) + (omega_22*X20) )/PI_0)*100;
dPtime0_eta0_8402      = (((P_eta0_8402-P_0) + (wP_1*X10) + (wP_2*X20) + (P_G*Y_0*VG0) + (P_ASH*AH_0*VASH0) + (P_BSH*BH_0*VBSH0) + (P_ASN*AN_0*VASN0) + (P_BSN*BN_0*VBSN0) + (P_ADH*AH_0*VADH0) + (P_BDH*BH_0*VBDH0) + (P_ADN*AN_0*VADN0) + (P_BDN*BN_0*VBDN0) )/P_0)*100;
dPHtime0_eta0_8402     = (((PH_eta0_8402-PH_0) + (wPH_1*X10) + (wPH_2*X20) + (PH_G*Y_0*VG0) + (PH_ASH*AH_0*VASH0) + (PH_BSH*BH_0*VBSH0) + (PH_ASN*AN_0*VASN0) + (PH_BSN*BN_0*VBSN0) + (PH_ADH*AH_0*VADH0) + (PH_BDH*BH_0*VBDH0) + (PH_ADN*AN_0*VADN0) + (PH_BDN*BN_0*VBDN0) )/PH_0)*100;
dPNtime0_eta0_8402     = (((PN_eta0_8402-PN_0) + (wPN_1*X10) + (wPN_2*X20) + (PN_G*Y_0*VG0) + (PN_ASH*AH_0*VASH0) + (PN_BSH*BH_0*VBSH0) + (PN_ASN*AN_0*VASN0) + (PN_BSN*BN_0*VBSN0) + (PN_ADH*AH_0*VADH0) + (PN_BDH*BH_0*VBDH0) + (PN_ADN*AN_0*VADN0) + (PN_BDN*BN_0*VBDN0) )/PN_0)*100;
dCYtime0_eta0_8402     = ( PC_0*((C_eta0_8402-C_0) + (wC_1*X10) + (wC_2*X20) + (C_G*Y_0*VG0) + (C_ASH*AH_0*VASH0) + (C_BSH*BH_0*VBSH0) + (C_ASN*AN_0*VASN0) + (C_BSN*BN_0*VBSN0) + (C_ADH*AH_0*VADH0) + (C_BDH*BH_0*VBDH0) + (C_ADN*AN_0*VADN0) + (C_BDN*BN_0*VBDN0) )/Y_0 )*100;
dJYtime0_eta0_8402     = ( PI_0*((I_eta0_8402-I_0) + (wJ_1*X10) + (wJ_2*X20) + (J_G*Y_0*VG0) + (J_ASH*AH_0*VASH0) + (J_BSH*BH_0*VBSH0) + (J_ASN*AN_0*VASN0) + (J_BSN*BN_0*VBSN0) + (J_ADH*AH_0*VADH0) + (J_BDH*BH_0*VBDH0) + (J_ADN*AN_0*VADN0) + (J_BDN*BN_0*VBDN0) )/Y_0 )*100;
dNXYtime0_eta0_8402    = ( ((NX_eta0_8402-NX_0) + (wNX_1*X10) + (wNX_2*X20) + (NX_G*Y_0*VG0) + (NX_ASH*AH_0*VASH0) + (NX_BSH*BH_0*VBSH0) + (NX_ASN*AN_0*VASN0) + (NX_BSN*BN_0*VBSN0) + (NX_ADH*AH_0*VADH0) + (NX_BDH*BH_0*VBDH0) + (NX_ADN*AN_0*VADN0) + (NX_BDN*BN_0*VBDN0) )/Y_0 )*100;

dQPItime0_eta0_8402    = ( (wQPI_1*X10) + (wQPI_2*X20) + (QPI_G*Y_0*VG0) + (QPI_ASH*AH_0*VASH0) + (QPI_BSH*BH_0*VBSH0) + (QPI_ASN*AN_0*VASN0) + (QPI_BSN*BN_0*VBSN0) + (QPI_ADH*AH_0*VADH0) + (QPI_BDH*BH_0*VBDH0) + (QPI_ADN*AN_0*VADN0) + (QPI_BDN*BN_0*VBDN0) )*100;
dLtime0_eta0_8402      = (1/dZAtime0_eta0_8402)*(((L_eta0_8402-L_0)  + (wL_1*X10) + (wL_2*X20) + (L_G*Y_0*VG0) + (L_ASH*AH_0*VASH0) + (L_BSH*BH_0*VBSH0) + (L_ASN*AN_0*VASN0) + (L_BSN*BN_0*VBSN0) + (L_ADH*AH_0*VADH0) + (L_BDH*BH_0*VBDH0) + (L_ADN*AN_0*VADN0) + (L_BDN*BN_0*VBDN0) )/L_0)*100;
dLHtime0_eta0_8402     = (1/dZAtime0_eta0_8402)*( (WH_0/W_0)*( (LH_eta0_8402-LH_0) + (wLH_1*X10) + (wLH_2*X20) + (LH_G*Y_0*VG0) + (LH_ASH*AH_0*VASH0) + (LH_BSH*BH_0*VBSH0) + (LH_ASN*AN_0*VASN0) + (LH_BSN*BN_0*VBSN0) + (LH_ADH*AH_0*VADH0) + (LH_BDH*BH_0*VBDH0) + (LH_ADN*AN_0*VADN0) + (LH_BDN*BN_0*VBDN0) )/L_0)*100;
dLNtime0_eta0_8402     = (1/dZAtime0_eta0_8402)*( (WN_0/W_0)*( (LN_eta0_8402-LN_0) + (wLN_1*X10) + (wLN_2*X20) + (LN_G*Y_0*VG0) + (LN_ASH*AH_0*VASH0) + (LN_BSH*BH_0*VBSH0) + (LN_ASN*AN_0*VASN0) + (LN_BSN*BN_0*VBSN0) + (LN_ADH*AH_0*VADH0) + (LN_BDH*BH_0*VBDH0) + (LN_ADN*AN_0*VADN0) + (LN_BDN*BN_0*VBDN0) )/L_0)*100;
dWtime0_eta0_8402      = (((W_eta0_8402-W_0) + (wW_1*X10) + (wW_2*X20) + (W_G*Y_0*VG0) + (W_ASH*AH_0*VASH0) + (W_BSH*BH_0*VBSH0) + (W_ASN*AN_0*VASN0) + (W_BSN*BN_0*VBSN0) + (W_ADH*AH_0*VADH0) + (W_BDH*BH_0*VBDH0) + (W_ADN*AN_0*VADN0) + (W_BDN*BN_0*VBDN0) )/W_0)*100;
dRtime0_eta0_8402      = (((RK_eta0_8402-RK_0) + (wR_1*X10) + (wR_2*X20) + (R_G*Y_0*VG0) + (R_ASH*AH_0*VASH0) + (R_BSH*BH_0*VBSH0) + (R_ASN*AN_0*VASN0) + (R_BSN*BN_0*VBSN0) + (R_ADH*AH_0*VADH0) + (R_BDH*BH_0*VBDH0) + (R_ADN*AN_0*VADN0) + (R_BDN*BN_0*VBDN0) )/RK_0)*100;
dWPCtime0_eta0_8402    = (((WPC_eta0_8402-WPC_0) + (wWPC_1*X10) + (wWPC_2*X20) + (WPC_G*Y_0*VG0)  + (WPC_ASH*AH_0*VASH0) + (WPC_BSH*BH_0*VBSH0) + (WPC_ASN*AN_0*VASN0) + (WPC_BSN*BN_0*VBSN0) + (WPC_ADH*AH_0*VADH0) + (WPC_BDH*BH_0*VBDH0) + (WPC_ADN*AN_0*VADN0) + (WPC_BDN*BN_0*VBDN0) )/WPC_0)*100;
dYRtime0_eta0_8402     = (((YR_eta0_8402-Y_0) + (wYR_1*X10) + (wYR_2*X20) + (YR_G*Y_0*VG0) + (YR_ASH*AH_0*VASH0) + (YR_BSH*BH_0*VBSH0) + (YR_ASN*AN_0*VASN0) + (YR_BSN*BN_0*VBSN0) + (YR_ADH*AH_0*VADH0) + (YR_BDH*BH_0*VBDH0) + (YR_ADN*AN_0*VADN0) + (YR_BDN*BN_0*VBDN0) )/Y_0)*100;
dYHtime0_eta0_8402     = ( PH_0*((YH_eta0_8402-YH_0) + (wYH_1*X10) + (wYH_2*X20) + (YH_G*Y_0*VG0) + (YH_ASH*AH_0*VASH0) + (YH_BSH*BH_0*VBSH0) + (YH_ASN*AN_0*VASN0) + (YH_BSN*BN_0*VBSN0) + (YH_ADH*AH_0*VADH0) + (YH_BDH*BH_0*VBDH0) + (YH_ADN*AN_0*VADN0) + (YH_BDN*BN_0*VBDN0) )/Y_0)*100;
dYNtime0_eta0_8402     = ( PN_0*((YN_eta0_8402-YN_0) + (wYN_1*X10) + (wYN_2*X20) + (YN_G*Y_0*VG0) + (YN_ASH*AH_0*VASH0) + (YN_BSH*BH_0*VBSH0) + (YN_ASN*AN_0*VASN0) + (YN_BSN*BN_0*VBSN0) + (YN_ADH*AH_0*VADH0) + (YN_BDH*BH_0*VBDH0) + (YN_ADN*AN_0*VADN0) + (YN_BDN*BN_0*VBDN0) )/Y_0)*100;
dWHtime0_eta0_8402     = (((WH_eta0_8402-WH_0) + (wWH_1*X10) + (wWH_2*X20) + (WH_G*Y_0*VG0) + (WH_ASH*AH_0*VASH0) + (WH_BSH*BH_0*VBSH0) + (WH_ASN*AN_0*VASN0) + (WH_BSN*BN_0*VBSN0) + (WH_ADH*AH_0*VADH0) + (WH_BDH*BH_0*VBDH0) + (WH_ADN*AN_0*VADN0) + (WH_BDN*BN_0*VBDN0) )/WH_0)*100;
dWNtime0_eta0_8402     = (((WN_eta0_8402-WN_0) + (wWN_1*X10) + (wWN_2*X20) + (WN_G*Y_0*VG0) + (WN_ASH*AH_0*VASH0) + (WN_BSH*BH_0*VBSH0) + (WN_ASN*AN_0*VASN0) + (WN_BSN*BN_0*VBSN0) + (WN_ADH*AH_0*VADH0) + (WN_BDH*BH_0*VBDH0) + (WN_ADN*AN_0*VADN0) + (WN_BDN*BN_0*VBDN0) )/WN_0)*100;
dWHPCtime0_eta0_8402   = (((WHPC_eta0_8402-WHPC_0) + (wWHPC_1*X10) + (wWHPC_2*X20) + (WHPC_G*Y_0*VG0)  + (WHPC_ASH*AH_0*VASH0) + (WHPC_BSH*BH_0*VBSH0) + (WHPC_ASN*AN_0*VASN0) + (WHPC_BSN*BN_0*VBSN0) + (WHPC_ADH*AH_0*VADH0) + (WHPC_BDH*BH_0*VBDH0) + (WHPC_ADN*AN_0*VADN0) + (WHPC_BDN*BN_0*VBDN0) )/WHPC_0)*100;
dWNPCtime0_eta0_8402   = (((WNPC_eta0_8402-WNPC_0) + (wWNPC_1*X10) + (wWNPC_2*X20) + (WNPC_G*Y_0*VG0)  + (WNPC_ASH*AH_0*VASH0) + (WNPC_BSH*BH_0*VBSH0) + (WNPC_ASN*AN_0*VASN0) + (WNPC_BSN*BN_0*VBSN0) + (WNPC_ADH*AH_0*VADH0) + (WNPC_BDH*BH_0*VBDH0) + (WNPC_ADN*AN_0*VADN0) + (WNPC_BDN*BN_0*VBDN0) )/WNPC_0)*100;
dRHPHtime0_eta0_8402    = ((((RK_eta0_8402/PH_eta0_8402)-(RK_0/PH_0)) + (wRHPH_1*X10) + (wRHPH_2*X20) + (RHPH_G*Y_0*VG0) + (RHPH_ASH*AH_0*VASH0) + (RHPH_BSH*BH_0*VBSH0) + (RHPH_ASN*AN_0*VASN0) + (RHPH_BSN*BN_0*VBSN0) + (RHPH_ADH*AH_0*VADH0) + (RHPH_BDH*BH_0*VBDH0) + (RHPH_ADN*AN_0*VADN0) + (RHPH_BDN*BN_0*VBDN0) )/(RK_0/PH_0))*100;
dRNPNtime0_eta0_8402    = ((((RK_eta0_8402/PN_eta0_8402)-(RK_0/PN_0)) + (wRNPN_1*X10) + (wRNPN_2*X20) + (RNPN_G*Y_0*VG0) + (RNPN_ASH*AH_0*VASH0) + (RNPN_BSH*BH_0*VBSH0) + (RNPN_ASN*AN_0*VASN0) + (RNPN_BSN*BN_0*VBSN0) + (RNPN_ADH*AH_0*VADH0) + (RNPN_BDH*BH_0*VBDH0) + (RNPN_ADN*AN_0*VADN0) + (RNPN_BDN*BN_0*VBDN0) )/(RK_0/PN_0))*100;

dOmegatime0_eta0_8402  = (((Omega_eta0_8402-Omega_0) + (wOmega_1*X10) + (wOmega_2*X20) + (Omega_G*Y_0*VG0) + (Omega_ASH*AH_0*VASH0) + (Omega_BSH*BH_0*VBSH0) + (Omega_ASN*AN_0*VASN0) + (Omega_BSN*BN_0*VBSN0) + (Omega_ADH*AH_0*VADH0) + (Omega_BDH*BH_0*VBDH0) + (Omega_ADN*AN_0*VADN0) + (Omega_BDN*BN_0*VBDN0) )/Omega_0)*100;
dYHYNtime0_eta0_8402   = (PH_0/PN_0)*( ((YH_eta0_8402/YN_eta0_8402)-(YH_0/YN_0)) + (wYHYN_1*X10) + (wYHYN_2*X20) + (YHYN_G*Y_0*VG0) + (YHYN_ASH*AH_0*VASH0) + (YHYN_BSH*BH_0*VBSH0) + (YHYN_ASN*AN_0*VASN0) + (YHYN_BSN*BN_0*VBSN0) + (YHYN_ADH*AH_0*VADH0) + (YHYN_BDH*BH_0*VBDH0) + (YHYN_ADN*AN_0*VADN0) + (YHYN_BDN*BN_0*VBDN0) )*100;
dLHLNtime0_eta0_8402   = (WH_0/WN_0)*( ((LH_eta0_8402/LN_eta0_8402)-(LH_0/LN_0)) + (wLHLN_1*X10) + (wLHLN_2*X20) + (LHLN_G*Y_0*VG0) + (LHLN_ASH*AH_0*VASH0) + (LHLN_BSH*BH_0*VBSH0) + (LHLN_ASN*AN_0*VASN0) + (LHLN_BSN*BN_0*VBSN0) + (LHLN_ADH*AH_0*VADH0) + (LHLN_BDH*BH_0*VBDH0) + (LHLN_ADN*AN_0*VADN0) + (LHLN_BDN*BN_0*VBDN0) )*100;
dLHStime0_eta0_8402    = (WH_0/W_0)*( ((LH_eta0_8402/L_eta0_8402)- (LH_0/L_0)) + (wLHS_1*X10) + (wLHS_2*X20) + (LHS_G*Y_0*VG0) + (LHS_ASH*AH_0*VASH0) + (LHS_BSH*BH_0*VBSH0) + (LHS_ASN*AN_0*VASN0) + (LHS_BSN*BN_0*VBSN0) + (LHS_ADH*AH_0*VADH0) + (LHS_BDH*BH_0*VBDH0) + (LHS_ADN*AN_0*VADN0) + (LHS_BDN*BN_0*VBDN0) )*100;
dLNStime0_eta0_8402    = (WN_0/W_0)*( ((LN_eta0_8402/L_eta0_8402)- (LN_0/L_0)) + (wLNS_1*X10) + (wLNS_2*X20) + (LNS_G*Y_0*VG0) + (LNS_ASH*AH_0*VASH0)  + (LNS_BSH*BH_0*VBSH0) + (LNS_ASN*AN_0*VASN0) + (LNS_BSN*BN_0*VBSN0) + (LNS_ADH*AH_0*VADH0)  + (LNS_BDH*BH_0*VBDH0) + (LNS_ADN*AN_0*VADN0) + (LNS_BDN*BN_0*VBDN0) )*100;
dYHStime0_eta0_8402    = PH_0*( ((YH_eta0_8402/YR_eta0_8402)- (YH_0/YR_0)) + (wYHS_1*X10) + (wYHS_2*X20) + (YHS_G*Y_0*VG0) + (YHS_ASH*AH_0*VASH0) + (YHS_BSH*BH_0*VBSH0) + (YHS_ASN*AN_0*VASN0) + (YHS_BSN*BN_0*VBSN0) + (YHS_ADH*AH_0*VADH0) + (YHS_BDH*BH_0*VBDH0) + (YHS_ADN*AN_0*VADN0) + (YHS_BDN*BN_0*VBDN0) )*100;
dYNStime0_eta0_8402    = PN_0*( ((YN_eta0_8402/YR_eta0_8402)- (YN_0/YR_0)) + (wYNS_1*X10) + (wYNS_2*X20) + (YNS_G*Y_0*VG0) + (YNS_ASH*AH_0*VASH0) + (YNS_BSH*BH_0*VBSH0) + (YNS_ASN*AN_0*VASN0) + (YNS_BSN*BN_0*VBSN0) + (YNS_ADH*AH_0*VADH0) + (YNS_BDH*BH_0*VBDH0) + (YNS_ADN*AN_0*VADN0) + (YNS_BDN*BN_0*VBDN0) )*100;
dWHWtime0_eta0_8402    = (( ((WH_eta0_8402/W_eta0_8402)-(WH_0/W_0)) + (wWHW_1*X10) + (wWHW_2*X20) + (WHW_G*Y_0*VG0) + (WHW_ASH*AH_0*VASH0) + (WHW_BSH*BH_0*VBSH0) + (WHW_ASN*AN_0*VASN0) + (WHW_BSN*BN_0*VBSN0) + (WHW_ADH*AH_0*VADH0) + (WHW_BDH*BH_0*VBDH0) + (WHW_ADN*AN_0*VADN0) + (WHW_BDN*BN_0*VBDN0) )/(WH_0/W_0) )*100;
dWNWtime0_eta0_8402    = (( ((WN_eta0_8402/W_eta0_8402)-(WN_0/W_0)) + (wWNW_1*X10) + (wWNW_2*X20) + (WNW_G*Y_0*VG0) + (WNW_ASH*AH_0*VASH0) + (WNW_BSH*BH_0*VBSH0) + (WNW_ASN*AN_0*VASN0) + (WNW_BSN*BN_0*VBSN0) + (WNW_ADH*AH_0*VADH0) + (WNW_BDH*BH_0*VBDH0) + (WNW_ADN*AN_0*VADN0) + (WNW_BDN*BN_0*VBDN0) )/(WN_0/W_0) )*100;
dKHKtime0_eta0_8402    =  ( ((KH_eta0_8402/K_eta0_8402)-(KH_0/K_0)) + (wKHK_1*X10) + (wKHK_2*X20) + (KHK_G*Y_0*VG0) + (KHK_ASH*AH_0*VASH0) + (KHK_BSH*BH_0*VBSH0) + (KHK_ASN*AN_0*VASN0) + (KHK_BSN*BN_0*VBSN0) + (KHK_ADH*AH_0*VADH0) + (KHK_BDH*BH_0*VBDH0) + (KHK_ADN*AN_0*VADN0) + (KHK_BDN*BN_0*VBDN0) )*100;
dKNKtime0_eta0_8402    =  ( ((KN_eta0_8402/K_eta0_8402)-(KN_0/K_0)) + (wKNK_1*X10) + (wKNK_2*X20) + (KNK_G*Y_0*VG0) + (KNK_ASH*AH_0*VASH0) + (KNK_BSH*BH_0*VBSH0) + (KNK_ASN*AN_0*VASN0) + (KNK_BSN*BN_0*VBSN0) + (KNK_ADH*AH_0*VADH0) + (KNK_BDH*BH_0*VBDH0) + (KNK_ADN*AN_0*VADN0) + (KNK_BDN*BN_0*VBDN0) )*100;

dkHtime0_eta0_8402     = ( LH_0*((kH_eta0_8402-kH_0) + (wkH_1*X10) + (wkH_2*X20) + (kH_G*Y_0*VG0) + (kH_ASH*AH_0*VASH0) + (kH_BSH*BH_0*VBSH0) + (kH_ASN*AN_0*VASN0) + (kH_BSN*BN_0*VBSN0) + (kH_ADH*AH_0*VADH0) + (kH_BDH*BH_0*VBDH0) + (kH_ADN*AN_0*VADN0) + (kH_BDN*BN_0*VBDN0) )/K_0)*100;
dkNtime0_eta0_8402     = ( LN_0*((kN_eta0_8402-kN_0) + (wkN_1*X10) + (wkN_2*X20) + (kN_G*Y_0*VG0) + (kN_ASH*AH_0*VASH0) + (kN_BSH*BH_0*VBSH0) + (kN_ASN*AN_0*VASN0) + (kN_BSN*BN_0*VBSN0) + (kN_ADH*AH_0*VADH0) + (kN_BDH*BH_0*VBDH0) + (kN_ADN*AN_0*VADN0) + (kN_BDN*BN_0*VBDN0) )/K_0)*100;
dLISHtime0_eta0_8402   = ( (sLH_eta0_8402-sLH_0) + (wLISH_1*X10) + (wLISH_2*X20) + (LISH_G*Y_0*VG0) + (LISH_ASH*AH_0*VASH0) + (LISH_BSH*BH_0*VBSH0) + (LISH_ASN*AN_0*VASN0) + (LISH_BSN*BN_0*VBSN0) + (LISH_ADH*AH_0*VADH0) + (LISH_BDH*BH_0*VBDH0) + (LISH_ADN*AN_0*VADN0) + (LISH_BDN*BN_0*VBDN0) )*100;
dLISNtime0_eta0_8402   = ( (sLN_eta0_8402-sLN_0) + (wLISN_1*X10) + (wLISN_2*X20) + (LISN_G*Y_0*VG0) + (LISN_ASH*AH_0*VASH0) + (LISN_BSH*BH_0*VBSH0) + (LISN_ASN*AN_0*VASN0) + (LISN_BSN*BN_0*VBSN0) + (LISN_ADH*AH_0*VADH0) + (LISN_BDH*BH_0*VBDH0) + (LISN_ADN*AN_0*VADN0) + (LISN_BDN*BN_0*VBDN0) )*100;

%%%%% TrASNitional paths - including capital utilization rates ADN TFP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
duKSHtime0_eta0_8402   = ( (wuKSH_1*X10) + (wuKSH_2*X20) + (uKSH_G*Y_0*VG0) + (uKSH_ASH*AH_0*VASH0) + (uKSH_BSH*BH_0*VBSH0) + (uKSH_ASN*AN_0*VASN0) + (uKSH_BSN*BN_0*VBSN0) + (uKSH_ADH*AH_0*VADH0) + (uKSH_BDH*BH_0*VBDH0) + (uKSH_ADN*AN_0*VADN0) + (uKSH_BDN*BN_0*VBDN0) )*100;
duKDHtime0_eta0_8402   = ( (wuKDH_1*X10) + (wuKDH_2*X20) + (uKDH_G*Y_0*VG0) + (uKDH_ASH*AH_0*VASH0) + (uKDH_BSH*BH_0*VBSH0) + (uKDH_ASN*AN_0*VASN0) + (uKDH_BSN*BN_0*VBSN0) + (uKDH_ADH*AH_0*VADH0) + (uKDH_BDH*BH_0*VBDH0) + (uKDH_ADN*AN_0*VADN0) + (uKDH_BDN*BN_0*VBDN0) )*100;
duKSNtime0_eta0_8402   = ( (wuKSN_1*X10) + (wuKSN_2*X20) + (uKSN_G*Y_0*VG0) + (uKSN_ASH*AH_0*VASH0) + (uKSN_BSH*BH_0*VBSH0) + (uKSN_ASN*AN_0*VASN0) + (uKSN_BSN*BN_0*VBSN0) + (uKSN_ADH*AH_0*VADH0) + (uKSN_BDH*BH_0*VBDH0) + (uKSN_ADN*AN_0*VADN0) + (uKSN_BDN*BN_0*VBDN0) )*100;
duKDNtime0_eta0_8402   = ( (wuKDN_1*X10) + (wuKDN_2*X20) + (uKDN_G*Y_0*VG0) + (uKDN_ASH*AH_0*VASH0) + (uKDN_BSH*BH_0*VBSH0) + (uKDN_ASN*AN_0*VASN0) + (uKDN_BSN*BN_0*VBSN0) + (uKDN_ADH*AH_0*VADH0) + (uKDN_BDH*BH_0*VBDH0) + (uKDN_ADN*AN_0*VADN0) + (uKDN_BDN*BN_0*VBDN0) )*100;
duKHtime0_eta0_8402    = ( (wuKH_1*X10) + (wuKH_2*X20) + (uKH_G*Y_0*VG0) + (uKH_ASH*AH_0*VASH0) + (uKH_BSH*BH_0*VBSH0) + (uKH_ASN*AN_0*VASN0) + (uKH_BSN*BN_0*VBSN0) + (uKH_ADH*AH_0*VADH0) + (uKH_BDH*BH_0*VBDH0) + (uKH_ADN*AN_0*VADN0) + (uKH_BDN*BN_0*VBDN0) )*100;
duKNtime0_eta0_8402    = ( (wuKN_1*X10) + (wuKN_2*X20) + (uKN_G*Y_0*VG0) + (uKN_ASH*AH_0*VASH0) + (uKN_BSH*BH_0*VBSH0) + (uKN_ASN*AN_0*VASN0) + (uKN_BSN*BN_0*VBSN0) + (uKN_ADH*AH_0*VADH0) + (uKN_BDH*BH_0*VBDH0) + (uKN_ADN*AN_0*VADN0) + (uKN_BDN*BN_0*VBDN0) )*100;
duKtime0_eta0_8402     = ( (wuK_1*X10) + (wuK_2*X20) + (uK_G*Y_0*VG0) + (uK_ASH*AH_0*VASH0) + (uK_BSH*BH_0*VBSH0) + (uK_ASN*AN_0*VASN0) + (uK_BSN*BN_0*VBSN0) + (uK_ADH*AH_0*VADH0) + (uK_BDH*BH_0*VBDH0) + (uK_ADN*AN_0*VADN0) + (uK_BDN*BN_0*VBDN0) )*100;

dTFPHtime0_eta0_8402   = (( (ZH_eta0_8402-ZH_0) + (wTFPH_1*X10) + (wTFPH_2*X20) + (TFPH_G*Y_0*VG0) + (TFPH_ASH*AH_0*VASH0) + (TFPH_BSH*BH_0*VBSH0) + (TFPH_ASN*AN_0*VASN0) + (TFPH_BSN*BN_0*VBSN0) + (TFPH_ADH*AH_0*VADH0) + (TFPH_BDH*BH_0*VBDH0) + (TFPH_ADN*AN_0*VADN0) + (TFPH_BDN*BN_0*VBDN0) )/ZH_0)*100;
dTFPNtime0_eta0_8402   = (( (ZH_eta0_8402-ZN_0) + (wTFPN_1*X10) + (wTFPN_2*X20) + (TFPN_G*Y_0*VG0) + (TFPN_ASH*AH_0*VASH0) + (TFPN_BSH*BH_0*VBSH0) + (TFPN_ASN*AN_0*VASN0) + (TFPN_BSN*BN_0*VBSN0) + (TFPN_ADH*AH_0*VADH0) + (TFPN_BDH*BH_0*VBDH0) + (TFPN_ADN*AN_0*VADN0) + (TFPN_BDN*BN_0*VBDN0) )/ZN_0)*100;
dTFPAtime0_eta0_8402   = (( (ZA_eta0_8402-ZA_0) + (wTFPA_1*X10) + (wTFPA_2*X20) + (TFPA_G*Y_0*VG0) + (TFPA_ASH*AH_0*VASH0) + (TFPA_BSH*BH_0*VBSH0) + (TFPA_ASN*AN_0*VASN0) + (TFPA_BSN*BN_0*VBSN0) + (TFPA_ADH*AH_0*VADH0) + (TFPA_BDH*BH_0*VBDH0) + (TFPA_ADN*AN_0*VADN0) + (TFPA_BDN*BN_0*VBDN0) )/ZA_0)*100;
dTFPHtime0_check_eta0_8402 = (( (ZA_eta0_8402-ZA_0) + (wTFPH_1_check*X10) + (wTFPH_2_check*X20) + (TFPH_G_check*Y_0*VG0) + (TFPH_ASH_check*AH_0*VASH0) + (TFPH_BSH_check*BH_0*VBSH0) + (TFPH_ASN_check*AN_0*VASN0) + (TFPH_BSN_check*BN_0*VBSN0) + (TFPH_ADH_check*AH_0*VADH0) + (TFPH_BDH_check*BH_0*VBDH0) + (TFPH_ADN_check*AN_0*VADN0) + (TFPH_BDN_check*BN_0*VBDN0) )/ZH_0)*100;
dTFPNtime0_check_eta0_8402 = (( (ZA_eta0_8402-ZA_0) + (wTFPN_1_check*X10) + (wTFPN_2_check*X20) + (TFPN_G_check*Y_0*VG0) + (TFPN_ASH_check*AH_0*VASH0) + (TFPN_BSH_check*BH_0*VBSH0) + (TFPN_ASN_check*AN_0*VASN0) + (TFPN_BSN_check*BN_0*VBSN0) + (TFPN_ADH_check*AH_0*VADH0) + (TFPN_BDH_check*BH_0*VBDH0) + (TFPN_ADN_check*AN_0*VADN0) + (TFPN_BDN_check*BN_0*VBDN0) )/ZN_0)*100;
dTFPRtime0_eta0_8402   = (( ((ZH_eta0_8402/ZN_eta0_8402)-(ZH_0/ZN_0)) + (wTFPR_1*X10) + (wTFPR_2*X20) + (TFPR_G*Y_0*VG0) + (TFPR_ASH*AH_0*VASH0) + (TFPR_BSH*BH_0*VBSH0) + (TFPR_ASN*AN_0*VASN0) + (TFPR_BSN*BN_0*VBSN0)  + (TFPR_ADH*AH_0*VADH0) + (TFPR_BDH*BH_0*VBDH0) + (TFPR_ADN*AN_0*VADN0) + (TFPR_BDN*BN_0*VBDN0) )/(ZH_0/ZN_0))*100;

CA_ASH0 = (B_ASH*AH_0/(xiASH+r))*VBASHprime0 + (N1*DeltaASH_1/(xiASH+r))*VBASH1prime0 - (N2*DeltaASH_2/(xiASH+r))*VBASH2prime0;
CA_BSH0 = (B_BSH*BH_0/(xiBSH+r))*VBBSHprime0 + (N1*DeltaBSH_1/(xiBSH+r))*VBBSH1prime0 - (N2*DeltaBSH_2/(xiBSH+r))*VBBSH2prime0;
CA_ASN0 = (B_ASN*AN_0/(xiASN+r))*VBASNprime0 + (N1*DeltaASN_1/(xiASN+r))*VBASN1prime0 - (N2*DeltaASN_2/(xiASN+r))*VBASN2prime0;
CA_BSN0 = (B_BSN*BN_0/(xiBSN+r))*VBBSNprime0 + (N1*DeltaBSN_1/(xiBSN+r))*VBBSN1prime0 - (N2*DeltaBSN_2/(xiBSN+r))*VBBSN2prime0;

CA_ADH0 = (B_ADH*AH_0/(xiADH+r))*VBADHprime0 + (N1*DeltaADH_1/(xiADH+r))*VBADH1prime0 - (N2*DeltaADH_2/(xiADH+r))*VBADH2prime0;
CA_BDH0 = (B_BDH*BH_0/(xiBDH+r))*VBBDHprime0 + (N1*DeltaBDH_1/(xiBDH+r))*VBBDH1prime0 - (N2*DeltaBDH_2/(xiBDH+r))*VBBDH2prime0;
CA_ADN0 = (B_ADN*AN_0/(xiADN+r))*VBADNprime0 + (N1*DeltaADN_1/(xiADN+r))*VBADN1prime0 - (N2*DeltaADN_2/(xiADN+r))*VBADN2prime0;
CA_BDN0 = (B_BDN*BN_0/(xiBDN+r))*VBBDNprime0 + (N1*DeltaBDN_1/(xiBDN+r))*VBBDN1prime0 - (N2*DeltaBDN_2/(xiBDN+r))*VBBDN2prime0;

CA_G0  = (B_G*Y_0*omegaG_0/(xi+r))*VBGprime0 + (N1*DeltaG_1/(xi+r))*VBG1prime0 - (N2*DeltaG_2/(xi+r))*VBG2prime0;

SAV_ASH0 = (A_ASH*AH_0/(xiASH+r))*VBASHprime0 + (M1*DeltaASH_1/(xiASH+r))*VBASH1prime0 - (M2*DeltaASH_2/(xiASH+r))*VBASH2prime0;
SAV_BSH0 = (A_BSH*BH_0/(xiBSH+r))*VBBSHprime0 + (M1*DeltaBSH_1/(xiBSH+r))*VBBSH1prime0 - (M2*DeltaBSH_2/(xiBSH+r))*VBBSH2prime0;
SAV_ASN0 = (A_ASN*AN_0/(xiASN+r))*VBASNprime0 + (M1*DeltaASN_1/(xiASN+r))*VBASN1prime0 - (M2*DeltaASN_2/(xiASN+r))*VBASN2prime0;
SAV_BSN0 = (A_BSN*BN_0/(xiBSN+r))*VBBSNprime0 + (M1*DeltaBSN_1/(xiBSN+r))*VBBSN1prime0 - (M2*DeltaBSN_2/(xiBSN+r))*VBBSN2prime0;

SAV_ADH0 = (A_ADH*AH_0/(xiADH+r))*VBADHprime0 + (M1*DeltaADH_1/(xiADH+r))*VBADH1prime0 - (M2*DeltaADH_2/(xiADH+r))*VBADH2prime0;
SAV_BDH0 = (A_BDH*BH_0/(xiBDH+r))*VBBDHprime0 + (M1*DeltaBDH_1/(xiBDH+r))*VBBDH1prime0 - (M2*DeltaBDH_2/(xiBDH+r))*VBBDH2prime0;
SAV_ADN0 = (A_ADN*AN_0/(xiADN+r))*VBADNprime0 + (M1*DeltaADN_1/(xiADN+r))*VBADN1prime0 - (M2*DeltaADN_2/(xiADN+r))*VBADN2prime0;
SAV_BDN0 = (A_BDN*BN_0/(xiBDN+r))*VBBDNprime0 + (M1*DeltaBDN_1/(xiBDN+r))*VBBDN1prime0 - (M2*DeltaBDN_2/(xiBDN+r))*VBBDN2prime0;

SAV_G0  = (A_G*Y_0*omegaG_0/(xi+r))*VBGprime0 + (M1*DeltaG_1/(xi+r))*VBG1prime0 - (M2*DeltaG_2/(xi+r))*VBG2prime0;

dotX10 = (nu_1*X11) - (DeltaG_1*VG1prime0) - (DeltaASH_1*VASH1prime0) - (DeltaBSH_1*VBSH1prime0) - (DeltaASN_1*VASN1prime0) - (DeltaBSN_1*VBSN1prime0) - (DeltaADH_1*VADH1prime0) - (DeltaBDH_1*VBDH1prime0) - (DeltaADN_1*VADN1prime0) - (DeltaBDN_1*VBDN1prime0);
dotX20 = (DeltaG_2*VG2prime0) + (DeltaASH_2*VASH2prime0) + (DeltaBSH_2*VBSH2prime0) + (DeltaASN_2*VASN2prime0) + (DeltaBSN_2*VBSN2prime0) + (DeltaADH_2*VADH2prime0) +(DeltaBDH_2*VBDH2prime0) + (DeltaADN_2*VADN2prime0) + (DeltaBDN_2*VBDN2prime0);

CAYtime0_eta0_8402 = (( -nu_1*(wB1/(r-nu_1)) + CA_ASH0 + CA_BSH0 + CA_ASN0 + CA_BSN0 + CA_ADH0 + CA_BDH0 + CA_ADN0 + CA_BDN0 + CA_G0 )/Y_0 )*100;
SYtime0_eta0_8402  = (( -nu_1*(wA1/(r-nu_1)) + SAV_ASH0 + SAV_BSH0 + SAV_ASN0 + SAV_BSN0 + SAV_ADH0 + SAV_BDH0 + SAV_ADN0 + SAV_BDN0 + SAV_G0 )/Y_0 )*100;
IYtime0_eta0_8402 = (( (EK1*dotX10) + (EK2*dotX20) )/Y_0)*100;

CAYtime0_eta0_8402_check = SYtime0_eta0_8402 - IYtime0_eta0_8402;

% IRF Hours rescaled so that hatZA(0)=1% on impact

pathdL1_R = (1/dZAtime0_eta0_8402)*(((L_eta0_8402-L_0)  + (wL_1*X1) + (wL_2*X2) + (L_G*Y_0*VG) + (L_ASH*AH_0*VASH) + (L_BSH*BH_0*VBSH) + (L_ASN*AN_0*VASN)  + (L_BSN*BN_0*VBSN) + (L_ADH*AH_0*VADH) + (L_BDH*BH_0*VBDH) + (L_ADN*AN_0*VADN) + (L_BDN*BN_0*VBDN) )/L_0)*100;
pathdL_eta0_8402_R   = [pathdL0  pathdL1_R];
dLtime0_eta0_8402_R  = (1/dZAtime0_eta0_8402)*(((L_eta0_8402-L_0)  + (wL_1*X10) + (wL_2*X20) + (L_G*Y_0*VG0) + (L_ASH*AH_0*VASH0) + (L_BSH*BH_0*VBSH0) + (L_ASN*AN_0*VASN0) + (L_BSN*BN_0*VBSN0) + (L_ADH*AH_0*VADH0) + (L_BDH*BH_0*VBDH0) + (L_ADN*AN_0*VADN0) + (L_BDN*BN_0*VBDN0) )/L_0)*100;

% Steady-state changes - scaled to their initial values                     
dGNY_eta0_8402  = PN_0*(dGN/Y_0)*100; % Change in GN                             
dGHY_eta0_8402  = PH_0*(dGH/Y_0)*100; % Change in GH                             
dGFY_eta0_8402  = (dGF/Y_0)*100; % Change in GH                                  
dGY_eta0_8402   = (dG/Y_0)*100; % Chane in G                                     
% Steady-state changes - scaled to their initial values                     
hatASH_eta0_8402   = (dASH/AH_0)*100; % Change in ASH                            
hatBSH_eta0_8402   = (dBSH/BH_0)*100; % Change in BSH                            
hatASN_eta0_8402   = (dASN/AN_0)*100; % Change in ASN                            
hatBSN_eta0_8402   = (dBSN/BN_0)*100; % Change in BSN                            
                                                                            
hatADH_eta0_8402   = (dADH/AH_0)*100; % Change in ADH                            
hatBDH_eta0_8402   = (dBDH/BH_0)*100; % Change in BDH                            
hatADN_eta0_8402   = (dADN/AN_0)*100; % Change in ADN                            
hatBDN_eta0_8402   = (dBDN/BN_0)*100; % Change in BDN                            
                                                                            
hatZSH_eta0_8402   = (dZSH/ZH_0)*100; % Change in ZSH                            
hatZSN_eta0_8402   = (dZSN/ZN_0)*100; % Change in ZSN                            
hatZDH_eta0_8402   = (dZDH/ZH_0)*100; % Change in ZDH                            
hatZDN_eta0_8402   = (dZDN/ZN_0)*100; % Change in ZDN                            
                                                                            
hatAH_eta0_8402    = (dAH/AH_0)*100; % Change in ADH                             
hatBH_eta0_8402    = (dBH/BH_0)*100; % Change in BDH                             
hatAN_eta0_8402    = (dAN/AN_0)*100; % Change in ADN                             
hatBN_eta0_8402    = (dBN/BN_0)*100; % Change in BDN                             
                                                                            
hatZH_eta0_8402    = (dZH/ZH_0)*100; % Change in ZH                              
hatZN_eta0_8402    = (dZN/ZN_0)*100; % Change in ZN                              
hatZA_eta0_8402    = (dZA/ZA_0)*100; % Change in ZA 

hatTFPH_eta0_8402  = dTFPH/TFPH_0;       
hatTFPN_eta0_8402  = dTFPN/TFPN_0;       
hatTFPA_eta0_8402  = dTFPA/TFPA_0;        
                                                                            
% Steady-state changes and impact effects - scaled to their initial values 
hatlambda_eta0_8402       = (dlambda/lambda_0)*100; 
dCoverY_eta0_8402         = ((PC_0*dC)/Y_0)*100; % Rate of change of the real consumption
hatL_eta0_8402            = (dL/L_0)*100; % Rate of change of employment
hatK_eta0_8402            = (dK/K_0)*100; % Rate of change of the stock of foreign assets
dLHoverL_eta0_8402        = (WH_0/W_0)*(dLH/L_0)*100; % Rate of change of LH
dLNoverL_eta0_8402        = (WN_0/W_0)*(dLN/L_0)*100; % Rate of change of LN
dLHLN_eta0_8402           = (WH_0/WN_0)*((LH/LN)-(LH_0/LN_0))*100; %  Change of LH/LN
hatPH_eta0_8402           = (dPH/PH_0)*100; % Rate of change of PH
hatPN_eta0_8402           = (dPN/PN_0)*100; % Rate of change of PN
hatP_eta0_8402            = (dP/P_0)*100; % Rate of change of PN/PH
dBoverY_eta0_8402         = (dB/Y_0)*100; % Rate of change of the stock of foreign assets
dAoverY_eta0_8402         = (dA/Y_0)*100; % Rate of change of the stock of financial assets
hatW_eta0_8402            = (dW/W_0)*100; % Rate of change of wage
hatWPC_eta0_8402          = (dWPC/WPC_0)*100; % Rate of change of Real Aggregate Wage W/pc
hatY_eta0_8402            = (dY/Y_0)*100; % Rate of change of GDP
hatYR_eta0_8402           = ((YR-Y_0)/Y_0)*100; % Rate of change of Real GDP
dYHoverY_eta0_8402        = (PH_0*dYH/Y_0)*100; % Rate of change of YH
dYNoverY_eta0_8402        = (PN_0*dYN/Y_0)*100; % Rate of change of YN
dYHYN_eta0_8402           = (PH_0/PN_0)*((YH/YN)-(YH_0/YN_0))*100; % Rate of change of YH/YN
hatWH_eta0_8402           = (dWH/WH_0)*100; % Rate of change of WH
hatWN_eta0_8402           = (dWN/WN_0)*100; % Rate of change of WN
hatOmega_eta0_8402        = (dOmega/Omega_0)*100; % Rate of change of omega
hatWHPC_eta0_8402         = (dWHPC/WHPC_0)*100; % Rate of change of WH/PC
hatWNPC_eta0_8402         = (dWNPC/WNPC_0)*100; % Rate of change of WN/PC
dkH_eta0_8402             = LH_0*(dkH/K_0)*100; % Rate of change of kH
dkN_eta0_8402             = LN_0*(dkN/K_0)*100; % Rate of change of kN
dLHS_eta0_8402            = (WH_0/W_0)*((LH/L)-(LH_0/L_0))*100; % change in  the labor share of T
dLNS_eta0_8402            = (WN_0/W_0)*((LN/L)-(LN_0/L_0))*100; % change in the labor share of NT
dYHS_eta0_8402            = PH_0*((YH/YR)-(YH_0/YR_0))*100; % change in the output share of T
dYNS_eta0_8402            = PN_0*((YN/YR)-(YN_0/YR_0))*100; % change in the output share of NT
dLISH_eta0_8402           = (sLH_eta0_8402-sLH_0)*100; % Change in the labor income share H
dLISN_eta0_8402           = (sLN_eta0_8402-sLN_0)*100; % Change in the labor income share N
dWHW_eta0_8402            = (((WH/W)-(WH_0/W_0))/((WH_0/W_0)))*100; % Change in the relative wage H
dWNW_eta0_8402            = (((WN/W)-(WN_0/W_0))/((WH_0/W_0)))*100; % Change in the relative wage N
dKHK_eta0_8402            = ((KH/K)-(KH_0/K_0))*100; % Change in the capital share of H
dKNK_eta0_8402            = ((KN/K)-(KN_0/K_0))*100; % Change in the capital share of N 

disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                    Final Steady State with kH > kN');
disp('                           The exomark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (exomark)');
disp('The structural parameters (exomark)');
disp(sprintf('sigmaH  : %5.2f   gammaH   : %5.2f',sigmaH,gammaH));
disp(sprintf('sigmaN  : %5.2f   gammaN   : %5.2f',sigmaN,gammaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('phi     : %5.2f   varphi   : %5.2f',phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f sigma   : %5.2f',sigmaL,gammaL,sigma));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('AH      : %5.2f   BH       : %5.2f',AH,BH));
disp(sprintf('AN      : %5.2f   BN       : %5.2f',AN,BN));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('TFPH    : %5.2f   TFPN     : %5.2f',TFPH,TFPN));
disp(sprintf('omegaYH : %5.2f   Z        : %5.2f TFP        : %5.2f',omegaYH,Z,TFP));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (exomark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));
disp(sprintf('K        : %9.3f   ',K));
disp(sprintf('K_check  : %9.3f   ',K_check));
disp(sprintf('alphaK   : %9.3f   ',alphaK));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('RN                 : %9.3f',RN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('RH                 : %9.3f',RH));
disp(sprintf('Profit             : %9.10f',PiH));

disp(' ');                                                                                      
disp('Wealth');                                                                                 
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));                                          
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));                                     
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA)); 

disp(' ');
disp('The demand side (exomark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (exomark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f IF     : %9.3f',IH,IN,IF));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp('Linearization');
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('Upsilon_G :  %5.4f  Sigma_G   : %5.4f',Upsilon_G,Sigma_G));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));
disp(sprintf('B_G       :  %5.4f  A_G       : %5.4f',B_G,A_G));
disp(sprintf('A_K       :  %5.4f  A_Q       : %5.4f',A_K,A_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu_1,nu_2));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp('Eigenvectors');
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega_11,omega_12));

disp('Partial derivatives of Yj');                                                          
disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));                        
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));                        
disp(sprintf('YN_G       :   %7.6f  YH_G       : %9.6f',YN_G,YH_G));                        
disp(sprintf('YN_AH      :   %7.6f  YH_AH      : %9.6f',YN_AH,YH_AH));                      
disp(sprintf('YN_BH      :   %7.6f  YH_BH      : %9.6f',YN_BH,YH_BH));                      
disp(sprintf('YN_AN      :   %7.6f  YH_AN      : %9.6f',YN_AN,YH_AN));                      
disp(sprintf('YN_BN      :   %7.6f  YH_BN      : %9.6f',YN_BN,YH_BN));                      
                                                                                              
disp('Partial derivatives of Yj/YR');                                                             
disp(sprintf('YNS_Q       :   %7.6f  YHS_Q       : %9.6f',YNS_Q,YHS_Q));                          
disp(sprintf('YNS_K       :   %7.6f  YHS_K       : %9.6f',YNS_K,YHS_K));                          
disp(sprintf('YNS_G       :   %7.6f  YHS_G       : %9.6f',YNS_G,YHS_G));                          
disp(sprintf('YNS_ASH      :   %7.6f  YHS_ASH     : %9.6f',YNS_ASH,YHS_ASH));    
disp(sprintf('YNS_BSH      :   %7.6f  YHS_BSH     : %9.6f',YNS_BSH,YHS_BSH));    
disp(sprintf('YNS_ASN      :   %7.6f  YHS_ASN     : %9.6f',YNS_ASN,YHS_ASN));    
disp(sprintf('YNS_BSN      :   %7.6f  YHS_BSN     : %9.6f',YNS_BSN,YHS_BSN));    
disp(sprintf('YNS_ADH      :   %7.6f  YHS_ADH     : %9.6f',YNS_ADH,YHS_ADH));    
disp(sprintf('YNS_BDH      :   %7.6f  YHS_BDH     : %9.6f',YNS_BDH,YHS_BDH));    
disp(sprintf('YNS_ADN      :   %7.6f  YHS_ADN     : %9.6f',YNS_ADN,YHS_ADN));    
disp(sprintf('YNS_BDN      :   %7.6f  YHS_BDN     : %9.6f',YNS_BDN,YHS_BDN));                    
                                                                                                  
disp(' ');
disp('Steady State Equilibrium ratios (exomark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WH*LH/W*L   :  %5.3f RH*KH/RK*K  :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));
disp(' ');
disp(' ');
disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LH/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));
disp(sprintf('Traded capital supply             : %9.16f   ',cond31));
disp(sprintf('Non-traded capital supply         : %9.16f   ',cond32));
disp(sprintf('Relative capital supply KH/KN     : %9.16f   ',cond33));
disp(sprintf('Unit Cost for Producing N         : %9.16f   ',cond34));
disp(sprintf('Unit Cost for Producing H         : %9.16f   ',cond35));


disp('-------------------------------------------------------------------------------------------------------- ');
disp('                       Increase in gN : Impact and Steady State Changes (after a rise in gN)     ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('                               |     Temporary   |');
disp('-------------------------------------------------------------------------------------------------------- ');
disp(' ');
disp(sprintf('dGY_eta0_8402              :         |           |%10.3f',dGY_eta0_8402));
disp(sprintf('dGHY_eta0_8402             :         |           |%10.3f',dGHY_eta0_8402));
disp(sprintf('dGNY_eta0_8402             :         |           |%10.3f',dGNY_eta0_8402));
disp(' ');                                                                                   
disp('Technology : long-run');                                                               
disp(sprintf('hatASH_eta0_8402             :         |           |%10.3f',hatASH_eta0_8402));    
disp(sprintf('hatBSH_eta0_8402             :         |           |%10.3f',hatBSH_eta0_8402));    
disp(sprintf('hatASN_eta0_8402             :         |           |%10.3f',hatASN_eta0_8402));    
disp(sprintf('hatBSN_eta0_8402             :         |           |%10.3f',hatBSN_eta0_8402));    
                                                                                       
disp(sprintf('hatADH_eta0_8402             :         |           |%10.3f',hatADH_eta0_8402));    
disp(sprintf('hatBDH_eta0_8402             :         |           |%10.3f',hatBDH_eta0_8402));    
disp(sprintf('hatADN_eta0_8402             :         |           |%10.3f',hatADN_eta0_8402));    
disp(sprintf('hatBDN_eta0_8402             :         |           |%10.3f',hatBDN_eta0_8402));    
                                                                                       
disp(sprintf('hatZSH_eta0_8402             :         |           |%10.3f',hatZSH_eta0_8402));    
disp(sprintf('hatZSN_eta0_8402             :         |           |%10.3f',hatZSN_eta0_8402));    
disp(sprintf('hatZDH_eta0_8402             :         |           |%10.3f',hatZDH_eta0_8402));    
disp(sprintf('hatZDN_eta0_8402             :         |           |%10.3f',hatZDN_eta0_8402));    
                                                                                       
disp(sprintf('hatZH_eta0_8402             :         |           |%10.3f',hatZH_eta0_8402));      
disp(sprintf('hatZN_eta0_8402             :         |           |%10.3f',hatZN_eta0_8402));      
disp(sprintf('hatZA_eta0_8402             :         |           |%10.3f',hatZA_eta0_8402));       
disp(sprintf('hatTFPH_eta0_8402           :         |           |%10.3f',hatTFPH_eta0_8402));    
disp(sprintf('hatTFPN_eta0_8402           :         |           |%10.3f',hatTFPN_eta0_8402));    
disp(sprintf('hatTFPA_eta0_8402           :         |           |%10.3f',hatTFPA_eta0_8402));     

disp(' ');
disp(' Steady State Deviations ( = (x-x0)/x0 where x0 is the value of x at the initial steady state)  ');
disp(sprintf('hatlambda_eta0_8402        :         |           |%10.3f',hatlambda_eta0_8402));
disp(sprintf('dCoverY_eta0_8402          :         |           |%10.3f',dCoverY_eta0_8402));
disp(sprintf('dLoverL_eta0_8402          :         |           |%10.3f',hatL_eta0_8402));
disp(sprintf('dYRoverY_eta0_8402         :         |           |%10.3f',hatYR_eta0_8402));
disp(sprintf('dKoverK_eta0_8402          :         |           |%10.3f',hatK_eta0_8402));
disp(sprintf('dLHoverL_eta0_8402         :         |           |%10.3f',dLHoverL_eta0_8402));
disp(sprintf('dLNover_eta0_8402          :         |           |%10.3f',dLNoverL_eta0_8402));
disp(sprintf('dLHLN_eta0_8402            :         |           |%10.3f',dLHLN_eta0_8402));
disp(sprintf('dYHoverY_eta0_8402         :         |           |%10.3f',dYHoverY_eta0_8402));
disp(sprintf('dYNoverY_eta0_8402         :         |           |%10.3f',dYNoverY_eta0_8402));
disp(sprintf('dYHYN_eta0_8402            :         |           |%10.3f',dYHYN_eta0_8402));
disp(sprintf('hatPH_eta0_8402            :         |           |%10.3f',hatPH_eta0_8402));
disp(sprintf('hatPN_eta0_8402            :         |           |%10.3f',hatPN_eta0_8402));
disp(sprintf('hatP_eta0_8402             :         |           |%10.3f',hatP_eta0_8402));
disp(sprintf('dBoverY_eta0_8402          :         |           |%10.3f',dBoverY_eta0_8402));
disp(sprintf('dAoverY_eta0_8402          :         |           |%10.3f',dAoverY_eta0_8402));
disp(sprintf('dWoverW_eta0_8402          :         |           |%10.3f',hatW_eta0_8402));
disp(sprintf('dWPCoverWPC_eta0_8402      :         |           |%10.3f',hatWPC_eta0_8402));
disp(sprintf('dWHoverWH_eta0_8402        :         |           |%10.3f',hatWH_eta0_8402));
disp(sprintf('dWNoverWN_eta0_8402        :         |           |%10.3f',hatWN_eta0_8402));
disp(sprintf('hatOmega_eta0_8402         :         |           |%10.3f',hatOmega_eta0_8402));
disp(sprintf('dWHPCoverWHPC_eta0_8402    :         |           |%10.3f',hatWHPC_eta0_8402));
disp(sprintf('dWNPCoverWNPC_eta0_8402    :         |           |%10.3f',hatWNPC_eta0_8402));
disp(sprintf('dkHoverK_eta0_8402         :         |           |%10.3f',dkH_eta0_8402));
disp(sprintf('dkNoverK_eta0_8402         :         |           |%10.3f',dkN_eta0_8402));

disp(' ');
disp('Reallocation : long-run');   
disp(sprintf('dLHS_eta0_8402             :         |           |%10.3f',dLHS_eta0_8402));
disp(sprintf('dLNS_eta0_8402             :         |           |%10.3f',dLNS_eta0_8402));
disp(sprintf('dYHS_eta0_8402             :         |           |%10.3f',dYHS_eta0_8402));
disp(sprintf('dYNS_eta0_8402             :         |           |%10.3f',dYNS_eta0_8402));
disp(sprintf('dLISH_eta0_8402            :         |           |%10.3f',dLISH_eta0_8402));
disp(sprintf('dLISN_eta0_8402            :         |           |%10.3f',dLISN_eta0_8402));
disp(sprintf('dWHW_eta0_8402             :         |           |%10.3f',dWHW_eta0_8402));
disp(sprintf('dWNW_eta0_8402             :         |           |%10.3f',dWNW_eta0_8402));

disp(' ');
disp('                                           Initial responses ');
disp(sprintf('dGYtime0_eta0_8402         :                |                 |%10.3f',dGYtime0_eta0_8402));
disp(sprintf('dGHYtime0_eta0_8402        :                |                 |%10.3f',dGHYtime0_eta0_8402));
disp(sprintf('dGNYtime0_eta0_8402        :                |                 |%10.3f',dGNYtime0_eta0_8402));
disp(sprintf('dZSHtime0_eta0_8402        :                |                 |%10.3f',dZSHtime0_eta0_8402));     
disp(sprintf('dZSNtime0_eta0_8402        :                |                 |%10.3f',dZSNtime0_eta0_8402));     
disp(sprintf('dZDHtime0_eta0_8402        :                |                 |%10.3f',dZDHtime0_eta0_8402));     
disp(sprintf('dZDNtime0_eta0_8402        :                |                 |%10.3f',dZDNtime0_eta0_8402));     
disp(sprintf('dZHtime0_eta0_8402         :                |                 |%10.3f',dZHtime0_eta0_8402));
disp(sprintf('dZNtime0_eta0_8402         :                |                 |%10.3f',dZNtime0_eta0_8402));
disp(sprintf('dZAtime0_eta0_8402         :                |                 |%10.3f',dZAtime0_eta0_8402));
disp(sprintf('dASHtime0_eta0_8402        :                |                 |%10.3f',dASHtime0_eta0_8402));  
disp(sprintf('dBSHtime0_eta0_8402        :                |                 |%10.3f',dBSHtime0_eta0_8402));  
disp(sprintf('dASNtime0_eta0_8402        :                |                 |%10.3f',dASNtime0_eta0_8402));  
disp(sprintf('dBSNtime0_eta0_8402        :                |                 |%10.3f',dBSNtime0_eta0_8402));  
disp(sprintf('dADHtime0_eta0_8402        :                |                 |%10.3f',dADHtime0_eta0_8402));  
disp(sprintf('dBDHtime0_eta0_8402        :                |                 |%10.3f',dBDHtime0_eta0_8402));  
disp(sprintf('dADNtime0_eta0_8402        :                |                 |%10.3f',dADNtime0_eta0_8402));  
disp(sprintf('dBDNtime0_eta0_8402        :                |                 |%10.3f',dBDNtime0_eta0_8402));  
disp(sprintf('dFBTCHtime0_eta0_8402      :                |                 |%10.3f',dFBTCHtime0_eta0_8402));
disp(sprintf('dFBTCNtime0_eta0_8402      :                |                 |%10.3f',dFBTCNtime0_eta0_8402));
 
disp('                Initial responses including capital and technology utilization rates');
disp(sprintf('duKHtime0_eta0_8402            :                |                 |%10.3f',duKHtime0_eta0_8402));     
disp(sprintf('duKNtime0_eta0_8402            :                |                 |%10.3f',duKNtime0_eta0_8402));     
disp(sprintf('duKtime0_eta0_8402             :                |                 |%10.3f',duKtime0_eta0_8402));      
disp(sprintf('dTFPHtime0_eta0_8402           :                |                 |%10.3f',dTFPHtime0_eta0_8402));
disp(sprintf('dTFPNtime0_eta0_8402           :                |                 |%10.3f',dTFPNtime0_eta0_8402));
disp(sprintf('dTFPHtime0_check_eta0_8402     :                |                 |%10.3f',dTFPHtime0_check_eta0_8402));
disp(sprintf('dTFPNtime0_check_eta0_8402     :                |                 |%10.3f',dTFPNtime0_check_eta0_8402));
disp(sprintf('dTFPAtime0_eta0_8402           :                |                 |%10.3f',dTFPAtime0_eta0_8402));
disp(sprintf('dTFPRtime0_eta0_8402           :                |                 |%10.3f',dTFPRtime0_eta0_8402));

disp('                                           Initial responses ');
disp(sprintf('dKtime0_eta0_8402         :                |                 |%10.3f',dKtime0_eta0_8402));
disp(' ');
disp(sprintf('dCYtime0_eta0_8402        :                |                 |%10.3f',dCYtime0_eta0_8402));
disp(sprintf('dLtime0_eta0_8402         :                |                 |%10.3f',dLtime0_eta0_8402));
disp(sprintf('dLHtime0_eta0_8402        :                |                 |%10.3f',dLHtime0_eta0_8402));
disp(sprintf('dLNtime0_eta0_8402        :                |                 |%10.3f',dLNtime0_eta0_8402));
disp(sprintf('dLHLNtime0_eta0_8402      :                |                 |%10.3f',dLHLNtime0_eta0_8402));
disp(sprintf('dYRtime0_eta0_8402        :                |                 |%10.3f',dYRtime0_eta0_8402));
disp(sprintf('dYHtime0_eta0_8402        :                |                 |%10.3f',dYHtime0_eta0_8402));
disp(sprintf('dYNtime0_eta0_8402        :                |                 |%10.3f',dYNtime0_eta0_8402));
disp(sprintf('dYHYNtime0_eta0_8402      :                |                 |%10.3f',dYHYNtime0_eta0_8402));
disp(sprintf('dPHtime0_eta0_8402        :                |                 |%10.3f',dPHtime0_eta0_8402));
disp(sprintf('dPNtime0_eta0_8402        :                |                 |%10.3f',dPNtime0_eta0_8402));
disp(sprintf('dPtime0_eta0_8402         :                |                 |%10.3f',dPtime0_eta0_8402));
disp(sprintf('dSYtime0_eta0_8402        :                |                 |%10.3f',SYtime0_eta0_8402));
disp(sprintf('dIYtime0_eta0_8402        :                |                 |%10.3f',IYtime0_eta0_8402));
disp(sprintf('dCAYtime0_eta0_8402       :                |                 |%10.5f',CAYtime0_eta0_8402)); 
disp(sprintf('dCAYtime0_eta0_8402_check :                |                 |%10.5f',CAYtime0_eta0_8402_check)); 
disp(sprintf('dWtime0_eta0_8402         :                |                 |%10.3f',dWtime0_eta0_8402));
disp(sprintf('dWPCtime0_eta0_8402       :                |                 |%10.3f',dWPCtime0_eta0_8402));
disp(sprintf('dWHtime0_eta0_8402        :                |                 |%10.3f',dWHtime0_eta0_8402));
disp(sprintf('dWNtime0_eta0_8402        :                |                 |%10.3f',dWNtime0_eta0_8402));
disp(sprintf('dOmegatime0_eta0_8402     :                |                 |%10.3f',dOmegatime0_eta0_8402));
disp(sprintf('dWHPCtime0_eta0_8402      :                |                 |%10.3f',dWHPCtime0_eta0_8402));
disp(sprintf('dWNPCtime0_eta0_8402      :                |                 |%10.3f',dWNPCtime0_eta0_8402));
disp(sprintf('dkHKtime0_eta0_8402       :                |                 |%10.3f',dkHtime0_eta0_8402));
disp(sprintf('dkNKtime0_eta0_8402       :                |                 |%10.3f',dkNtime0_eta0_8402));
disp(sprintf('dLHStime0_eta0_8402       :                |                 |%10.3f',dLHStime0_eta0_8402));
disp(sprintf('dLNStime0_eta0_8402       :                |                 |%10.3f',dLNStime0_eta0_8402));
disp(sprintf('dYHStime0_eta0_8402       :                |                 |%10.3f',dYHStime0_eta0_8402));
disp(sprintf('dYNStime0_eta0_8402       :                |                 |%10.3f',dYNStime0_eta0_8402));
disp(sprintf('dWHWtime0_eta0_8402       :                |                 |%10.3f',dWHWtime0_eta0_8402));
disp(sprintf('dWNWtime0_eta0_8402       :                |                 |%10.3f',dWNWtime0_eta0_8402));
disp(sprintf('dLISHtime0_eta0_8402      :                |                 |%10.3f',dLISHtime0_eta0_8402));
disp(sprintf('dLISNtime0_eta0_8402      :                |                 |%10.3f',dLISNtime0_eta0_8402));
disp(sprintf('dKHKtime0_eta0_8402       :                |                 |%10.3f',dKHKtime0_eta0_8402));   
disp(sprintf('dKNKtime0_eta0_8402       :                |                 |%10.3f',dKNKtime0_eta0_8402));   
disp(sprintf('dRtime0_eta0_8402         :                |                 |%10.3f',dRtime0_eta0_8402));
disp(sprintf('dRHPHtime0_eta0_8402      :                |                 |%10.3f',dRHPHtime0_eta0_8402));   
disp(sprintf('dRNPNtime0_eta0_8402      :                |                 |%10.3f',dRNPNtime0_eta0_8402));   
                                                                                                                 
disp(' ');
disp('Steady State Equilibrium ratios (exomark)');
disp(sprintf('sigmaH  : %5.2f   sigmaN   : %5.2f',sigmaH_0,sigmaN_0));
disp(sprintf('YH / Y   :  %5.3f     PN*YN / Y  : %5.3f',omegaYH_0,omegaYN_0));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH_0,omegaLN_0));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC_0,omegaNX_0));
disp(sprintf('PI*I / Y  :  %5.3f      G / Y     : %5.3f',omegaI_0,omegaG_0));
disp(' ');
disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH_0,omegaGNYN_0,omegaGN_0));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f    GT/G     : %5.3f',omegaGH_0,omegaGF_0,omegaGT_0));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f',omegaINYN_0,omegaIHYH_0));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH_0,omegaGFYH_0));
disp(sprintf('WH*LH/PH*YH :  %5.3f WN*LN/PN*YN :  %5.3f',sLH_0,sLN_0));
disp(sprintf('WH*LH/W*L   :  %5.3f RH*KH/R*K   :  %5.3f',alphaL_0,alphaK_0));
disp(sprintf('PT*IT/PI*I  :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI_0,alphaC_0));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH_0,alphaH_0));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH_0,omegaCH_0));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF_0,omegaCF_0));
disp(sprintf('PH*XH/Y     :  %5.3f    XH / YH  :  %5.3f',omegaXHY_0,omegaXHYH_0));
disp(sprintf('W*L/P*Y     :  %5.3f R*K/P*Y     :  %5.3f',omegaL_0,omegaK_0));
disp(sprintf('K/Y         :  %5.3f KH/K        :  %5.3f',omegaKY_0,KHK_0));
disp(' ');
disp(sprintf('xi1SH    : %5.5f   xi2SH     : %5.5f',xi1SH,xi2SH));                                
disp(sprintf('xi1SN    : %5.5f   xi2SN     : %5.5f',xi1SN,xi2SN));                                
disp(sprintf('xi1DH    : %5.5f   xi2DH     : %5.5f',xi1DH,xi2DH));                                
disp(sprintf('xi1DN    : %5.5f   xi2DN     : %5.5f',xi1DN,xi2DN));                                
disp(sprintf('xi     : %5.5f  chi       : %5.5f  barg      : %5.5f',xi,chi,barg));                
disp(sprintf('xiASH   : %5.5f  chiASH     : %5.5f  baraSH     : %5.5f',xiASH,chiASH,baraSH));     
disp(sprintf('xiBSH   : %5.5f  chiBSB     : %5.5f  barbSH     : %5.5f',xiBSH,chiBSH,barbSH));     
disp(sprintf('xiASN  : %5.5f   chiASN     : %5.5f  baraSN     : %5.5f',xiASN,chiASN,baraSN));     
disp(sprintf('xiBSN  : %5.5f   chiBSN     : %5.5f  barbSN     : %5.5f',xiBSN,chiBSN,barbSN));     
disp(sprintf('xiADH   : %5.5f  chiADH     : %5.5f  baraDH     : %5.5f',xiADH,chiADH,baraDH));     
disp(sprintf('xiBDH   : %5.5f  chiBDB     : %5.5f  barbDH     : %5.5f',xiBDH,chiBDH,barbDH));     
disp(sprintf('xiADN  : %5.5f   chiADN     : %5.5f  baraDN     : %5.5f',xiADN,chiADN,baraDN));     
disp(sprintf('xiBDN  : %5.5f   chiBDN     : %5.5f  barbDN     : %5.5f',xiBDN,chiBDN,barbDN));             
disp(' ');
disp(sprintf('TFPH       : %5.5f   ZH_0     : %5.5f',TFPH_0,ZH_0));                             
disp(sprintf('TFPH_eta0_8402  : %5.5f   ZH_eta0_8402  : %5.5f',TFPH_eta0_8402,ZH_eta0_8402));
disp(sprintf('TFPN       : %5.5f   ZN_0     : %5.5f',TFPN_0,ZN_0));                             
disp(sprintf('TFPN_eta0_8402  : %5.5f   ZN_eta0_8402  : %5.5f',TFPN_eta0_8402,ZN_eta0_8402));
disp(' ');


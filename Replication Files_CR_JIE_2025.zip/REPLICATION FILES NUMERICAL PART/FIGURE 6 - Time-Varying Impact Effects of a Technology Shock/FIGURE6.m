pathin      = fullfile('C:\Users\Installeur\Documents\FILE',filesep);
pathout     = fullfile('C:\Users\Installeur\Documents\FILE',filesep);
fileinput   = fullfile(pathin,'Time-varying-impact-responses-of-hours.xlsx');
dataLH      = readmatrix(fileinput,'Sheet','Fig6','Range','C03:F21'); 
dataLN      = readmatrix(fileinput,'Sheet','Fig6','Range','H03:K21'); 
dataL       = readmatrix(fileinput,'Sheet','Fig6','Range','M03:P21'); 
data        = [dataLH dataLN dataL];
namevars    = char('LH','LN','L');
maxvalue    = [ 0.050  0.05  0.050];
minvalue    = [-0.175 -0.25 -0.375];
[s1,s2]     = size(dataL);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=01:03
k0          = (i-1)*4+1; 
k1          = k0+3;
datavar     = data(1:s1,k0:k1);
[obs,nbvar] = size(datavar); 
irfemp      = datavar(1:obs,2);  % Empirical response at time t = 0 
lowerb90    = datavar(1:obs,1);  % lower bound of the empirical response (confidence level: 90%) 
upperb90    = datavar(1:obs,3);  % upper bound of the empirical respons (confidence level: 90%) 
irfnum      = datavar(1:obs,4);  % Numerical response at time t = 0 
time        = 1999:2017; 
line_x      = zeros(1,obs);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
hold on;   
area90   = [lowerb90(1:obs)',fliplr(upperb90(1:obs)')];
xpoints  = [time(1:obs),fliplr(time(1:obs))];
p1       = patch(xpoints,area90,[1 1 1]*0.90,'LineStyle','non');   
p2       = plot(time(1:obs)',irfemp(1:obs),'blue','LineWidth',3);
p3       = plot(time(1:obs)',irfnum(1:obs),'black','LineWidth',3);
p4       = plot(time(1:obs)',line_x(1:obs),'LineWidth',0.1,'Color',[0.45 0.45 0.45]);
legend([p2,p3],{'Data','Model'},'Location','best','interpreter','latex','FontSize',12);
hold off;
axis([time(1)-.15 time(obs)+0.15 minvalue(i) maxvalue(i)]);
set(gca,'FontSize',12)
box on;
filename = ['Figure6_' deblank(namevars(i,:)) '.eps']; saveas(gcf,fullfile(pathout,filename),'epsc');
end
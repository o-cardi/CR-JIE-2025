%clc
%clear

global sigma phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global epsilonK varthetaK 
global gammaL sigmaL
global r deltaK kappa
global omegaG omegaGN omegaGH GH GN GF
global BH BN AH AN thetaH thetaN sigmaH sigmaN
global xi1H xi1N 
global xi2H xi2N 
global B0 K0 AH_0 BH_0 AN_0 BN_0 ZH ZN

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% BENCH IML CAC TOT - epsilon =0.98, sigmaL=0.5, kH>kN    %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
AH_0         = 1.00;  
AN_0         = 1.00;
BH_0         = 1.00;  
BN_0         = 1.00;
omegaG       = 0.198; 
omegaGN      = 0.838; 
omegaGH      = 0.65;
thetaH_0     = 0.629; 
thetaN_0     = 0.683; 
sigmaL_0     = 3; 
gammaL       = 1; 
sigma        = 2; 
phi_0        = 0.35;
varphi_0     = 0.508;   
rho_0        = 1.3;  
varphiH_0    = 0.711;
epsilon_0    = 0.80; 
vartheta_0   = 0.383;
epsilonK_0   = 0.15;
varthetaK_0  = 0.388; 
phiI_0       = 1.000001;                    
iota_0       = 0.319; 
rhoI_0       = 1.3;   
iotaH_0      = 0.485; 
kappa        = 17; 
ex           = 1; 
nuX          = 1.3; 

r            = 0.027; 
beta         = r; 
deltaK       = 0.062;

B0           = 4;
K0           = 0;

AH           = AH_0;       
AN           = AN_0;  
BH           = BH_0;       
BN           = BN_0;
thetaH       = thetaH_0;   
thetaN       = thetaN_0;     
sigmaL       = sigmaL_0;   
phi          = phi_0;     
varphi       = varphi_0;  
rho          = rho_0;     
varphiH      = varphiH_0;
phiI         = phiI_0;    
iota         = iota_0; 
rhoI         = rhoI_0;    
iotaH        = iotaH_0;
epsilon      = epsilon_0;  
vartheta     = vartheta_0;  
epsilonK     = epsilonK_0;  
varthetaK    = varthetaK_0;

ZH           = ((AH)^thetaH)*(BH^(1-thetaH)); 
ZN           = ((AN)^thetaN)*(BN^(1-thetaN));  
sigmaH       = 1; 
sigmaN       = 1; 
                                                                                                                                                                                                                                                                                                                                                                     
xi2H     = 0.137972966;                                                                                                                        
xi2N     = 0.557800311;   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.270  ; % Consumption
L_ini        = 0.905  ; % Total hours worked
RH_ini       = 0.220  ; % Capital rental rate in sector H
RN_ini       = 0.220  ; % Capital rental rate in sector N
WH_ini       = 3.763  ; % Wage rate in sector H
WN_ini       = 4.244  ; % Wage rate in sector N
W_ini        = 4.065  ; % Aggregate wage index
RK_ini       = 0.220  ; % Aggregate capital rental rate
PN_ini       = 3.104  ; % Non-traded good prices
K_ini        = 8.447  ; % Stock of capital
PH_ini       = 2.540  ; % Terms of trade
B_ini        = 0.63   ; % Stock of traded Bonds
alphaL_ini   = 0.333  ; % Labor compensation share of tradables
alphaK_ini   = 0.389  ; % Capital compensation share of tradables
PC_ini       = 2.491  ; % Aggregate consumption price index
PT_ini       = 1.898  ; % Consumption price index for tradables
CN_ini       = 0.576  ; % Consumption in non-traded goods
CH_ini       = 0.356  ; % Consumption in home-produced traded goods
CF_ini       = 0.472  ; % Consumption in foreign goods
alphaC_ini   = 0.434  ; % Tradable content of consumption expenditure
alphaH_ini   = 0.657  ; % Home goods content of consumption expenditure on traded goods
PI_ini       = 2.477  ; % Aggregate investment price index
PIT_ini      = 1.531  ; % Investment price index for traded goods
IN_ini       = 0.285  ; % Non traded investment
IH_ini       = 0.069  ; % Home goods investment
IF_ini       = 0.239  ; % Foreign goods investment
alphaI_ini   = 0.319  ; % Tradable content of investment expenditure
alphaIH_ini  = 0.422  ; % Home goods content of investment expenditure on traded goods
LH_ini       = 0.326  ; % Labor in sector H
LN_ini       = 0.578  ; % Labor in sector N
KH_ini       = 3.282  ; % Capital stock in sector H
KN_ini       = 5.165  ; % Capital stock in sector N
GF_ini       = 0.03   ; % Government spending in foreign goods
GH_ini       = 0.05   ; % Government spending in home goods
GN_ini       = 0.30   ; % Government spending in non tradables
YH_ini       = 0.768  ; % Traded value added
YN_ini       = 1.158  ; % Non traded value added
XH_ini       = 0.298  ; % Exports of home traded goods
MF_ini       = 0.773  ; % Imports of foreign goods
xi1H_ini     = 0.09   ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N_ini     = 0.07   ; % Parameter of non-traded capital utilization cost function
VL_ini       = 1.41   ; % Desutility labor
lambda_ini   = 0.494  ; % Intertemporal Solvency Condition  
                                                          
x0 =[C_ini L_ini RH_ini RN_ini WH_ini WN_ini W_ini RK_ini PN_ini K_ini PH_ini B_ini alphaL_ini alphaK_ini PC_ini PT_ini CN_ini CH_ini CF_ini alphaC_ini alphaH_ini PI_ini PIT_ini IN_ini IH_ini IF_ini alphaI_ini alphaIH_ini LH_ini LN_ini KH_ini KN_ini GF_ini GN_ini GH_ini YH_ini YN_ini XH_ini MF_ini xi1H_ini xi1N_ini VL_ini lambda_ini];
[x,fval,exitflag]=fsolve('IML_IMK_CAC_TOT_CD_NS_SS0',x0,optimset('display','off','TolFun',1e-011));

C        = x(1)  ; % Consumption
L        = x(2)  ; % Labor supply
RH       = x(3)  ; % Return on traded capital
RN       = x(4)  ; % Return on non-traded capital
WH       = x(5)  ; % Wage rate in sector H
WN       = x(6)  ; % Wage rate in sector N
W        = x(7)  ; % Aggregate wage index
RK       = x(8)  ; % Aggregate capital rental rate
PN       = x(9)  ; % Relative price of non tradables
K        = x(10)  ; % Stock of capital
PH       = x(11) ; % Terms of trade : PH/PF with PF = numeraire
B        = x(12) ; % Stock of Traded Bonds
alphaL   = x(13) ; % Labor compensation share of tradables
alphaK   = x(14) ; % Capital compensation share of tradables
PC       = x(15) ; % Aggregate consumption price index
PT       = x(16) ; % Consumption price index for tradables
CN       = x(17) ; % Consumption in non tradables
CH       = x(18) ; % Consumption in tradables
CF       = x(19) ; % Consumption goods imports
alphaC   = x(20) ; % Tradable content of consumption expenditure
alphaH   = x(21) ; % Home goods content of consumption expenditure on traded goods
PI       = x(22) ; % Aggregate investment price index
PIT      = x(23) ; % Investment price index for tradables
IN       = x(24) ; % Non tradable investment
IH       = x(25) ; % Investment in home goods
IF       = x(26) ; % Investment in foreign goods
alphaI   = x(27) ; % Tradable content of investment expenditure
alphaIH  = x(28) ; % Home goods content of investment expenditure
LH       = x(29) ; % Labor in sector H
LN       = x(30) ; % Labor in sector N
KH       = x(31) ; % Capital stock in sector H
KN       = x(32) ; % Capital stock in sector N
GF       = x(33) ; % Government spending in foreign goods
GN       = x(34) ; % Government spending in non tradables
GH       = x(35) ; % Government spending in home traded goods
YH       = x(36) ; % Traded value added
YN       = x(37) ; % Non-traded value added
XH       = x(38) ; % Exports of home traded goods
MF       = x(39) ; % Imports of foreign goods
xi1H     = x(40) ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N     = x(41) ; % Parameter of non-traded capital utilization cost function
VL       = x(42) ; % Desutility labor
lambda   = x(43) ; % Marginal Utility of Wealth - Intertemporal Solvency Condition                                                     

% Sectoral outputs and sectoral profits    
PiH = (PH*YH) - (RH*KH) - (WH*LH);  
PiN = (PN*YN) - (RN*KN) - (WN*LN);

% Value added and labor share
Y   = (PH*YH) +(PN*YN);
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L; 

% Labor income share in the home traded good and non traded good sector
kH  = KH/LH; 
kN  = KN/LN; 
yH  = YH/LH; 
yN  = YN/LN; 
sLH = WH*LH/(PH*YH);
sLN = WN*LN/(PN*YN);
sL  = W*L/Y; 
k   = K/L; 
P   = PN/PH; 
KHK = KH/K; 

% Unit cost for producting
MN  = ((WN^thetaN)*(RN^(1-thetaN)))/((thetaN^thetaN)*((1-thetaN)^(1-thetaN)));
MH  = ((WH^thetaH)*(RH^(1-thetaH)))/((thetaH^thetaH)*((1-thetaH)^(1-thetaH)));

% Technology
Z  = (ZH^omegaYH)*(ZN^(1-omegaYH));
TFPH = YH/((LH^thetaH)*(KH^(1-thetaH))); 
TFPN = YN/((LN^thetaN)*(KN^(1-thetaN))); 
TFP  = (TFPH^omegaYH)*(TFPN^(1-omegaYH));

% Non Sep preferences Shimer (2009)
%VL        = ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );
V_L       = (sigma-1)*gammaL*L^(1/sigmaL);
V_LL      = (sigma-1)*(gammaL/sigmaL)*(L^((1/sigmaL)-1)); 
U_C       =  (C^(-sigma))*(VL^sigma); 
U_CC      = -sigma*(C^(-sigma-1))*(VL^sigma); 
U_L       = ( (C^(1-sigma))*sigma*V_L*(VL^(sigma-1)) )/(1-sigma); 
U_LL      = U_L*( (V_LL/V_L) + (sigma-1)*V_L*(VL^(-1)) ); 
U_CL      = (C^(-sigma))*sigma*V_L*(VL^(sigma-1));
U_LC      = U_CL; 

% Solutions C=C(lambda,PN,PH,W); L=L(lambda,PN,PH,W)                      
a11 = (U_CC/U_C);                                                         
a12 = (U_CL/U_C);                                                         
a21 = (U_LC/U_L);                                                         
a22 = (U_LL/U_L);                                                         
                                                                          
% PN, PH, W, lambda                                                            
b11 = (1-alphaC)/PN;                                                      
b12 = alphaC*alphaH/PH;                                                   
b13 = 0; 
b14 = (1/lambda); 
                                                                          
b21 = 0;                                                                  
b22 = 0;                                                                  
b23 = (1/W);   
b24 = (1/lambda); 
                                                                          
A1 = [a11 a12; a21 a22];                                                  
B1 = [b11 b12 b13 b14; b21 b22 b23 b24];                                          
JST1 = inv(A1);                                                           
MST1 = JST1*B1;                                                           
C_1PN = MST1(1,1); C_1PH = MST1(1,2); C_W = MST1(1,3); C_1lambda = MST1(1,4);                  
L_1PN = MST1(2,1); L_1PH = MST1(2,2); L_W = MST1(2,3); L_1lambda = MST1(2,4);

% Partial derivatives of W=W(WN,WH)           
W_WH   = (W/WH)*alphaL; 
W_WN   = (W/WN)*(1-alphaL);                                                                                                                         
L_WH   = L_W*W_WH;                                                                    
L_WN   = L_W*W_WN; 

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH,WN,WH)                      
CN_1PN = - (CN/PN)*(alphaC*phi) + (CN/C)*C_1PN;                                         
CN_1PH = (CN/PH)*alphaC*alphaH*phi + (CN/C)*C_1PH;                                      
CN_WN  = (CN/C)*C_W*W_WN;                                                               
CN_WH  = (CN/C)*C_W*W_WH;                                                               
                                                                                        
CH_1PN = (CH/PN)*phi*(1-alphaC) + (CH/C)*C_1PN;                                         
CH_1PH = -(CH/PH)*( rho*(1-alphaH) + phi*alphaH*(1-alphaC) ) + (CH/C)*C_1PH;            
CH_WN  = (CH/C)*C_W*W_WN;                                                               
CH_WH  = (CH/C)*C_W*W_WH;                                                               
                                                                                        
CF_1PN = (CF/PN)*(1-alphaC)*phi + (CF/C)*C_1PN;                                         
CF_1PH = (CF/PH)*alphaH*(rho - phi*(1-alphaC) ) + (CF/C)*C_1PH;                         
CF_WN  = (CF/C)*C_W*W_WN;                                                               
CF_WH  = (CF/C)*C_W*W_WH;   

CH_1lamb = (CH/C)*C_1lambda; 
CN_1lamb = (CN/C)*C_1lambda;
CF_1lamb = (CF/C)*C_1lambda;

% Solutions LH=LH(lambda,WH,WN,PH,PN), LN=LN(lambda,WH,WN,PH,PN)
LH_WH  = (LH/WH)*epsilon*(1-alphaL) + (LH/L)*L_WH; 
LH_WN  = -(LH/WN)*epsilon*(1-alphaL) + (LH/L)*L_WN; 
LH_1PH = (LH/L)*L_1PH; 
LH_1PN = (LH/L)*L_1PN;

LN_WH  = -(LN/WH)*epsilon*alphaL + (LN/L)*L_WH; 
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN; 
LN_1PH = (LN/L)*L_1PH; 
LN_1PN = (LN/L)*L_1PN;

LH_1lamb   = (LH/L)*L_1lambda;
LN_1lamb   = (LN/L)*L_1lambda;

% Solutions Kj=Kj(RH,RN,K), j=H,N            
KH_RH = (KH/RH)*epsilonK*(1-alphaK);         
KH_RN = -(KH/RN)*epsilonK*(1-alphaK);        
KH_1K  = (KH/K);                              
                                             
KN_RH = -(KN/RH)*epsilonK*alphaK;            
KN_RN = (KN/RN)*epsilonK*alphaK;             
KN_1K  = (KN/K);                              

% Solving for WH,WN,RH,RN(PH,PN,K,uKH,uKN,AH,BH,AN,BN,lambda)                                                                                                                                                                                                                                                                                                                                     
d11 = - ( (1-thetaH)*(LH_WH/LH) + (1/WH) ); % WH                                               
d12 = - (1-thetaH)*(LH_WN/LH);  % WN                                                           
d13 = (1-thetaH)*(KH_RH/KH);  % RH                                                             
d14 = (1-thetaH)*(KH_RN/KH); % RN                                                              
                                                                                                     
d21 = - (1-thetaN)*(LN_WH/LN);  % WH                                                           
d22 = - ( (1-thetaN)*(LN_WN/LN) + (1/WN) ); % WN                                               
d23 = (1-thetaN)*(KN_RH/KN);  % RH                                                             
d24 = (1-thetaN)*(KN_RN/KN); % RN                                                              
                                                                                                     
d31 = thetaH*(LH_WH/LH); % WH                                                                  
d32 = thetaH*(LH_WN/LH); % WN                                                                  
d33 = - ( thetaH*(KH_RH/KH) + (1/RH) ); % RH                                                   
d34 = - thetaH*(KH_RN/KH); % RN                                                                 
                                                                                                     
d41 = thetaN*(LN_WH/LN); % WH                                                                  
d42 = thetaN*(LN_WN/LN); % WN                                                                  
d43 = - thetaN*(KN_RH/KN); % RH                                                                
d44 = - ( thetaN*(KN_RN/KN) + (1/RN) ); % RN                                                                                                                                                                           
                                                                                                                                                                                   
% PN,PH,K,uKH,uKN,AH,BH,AN,BN,lambda                                                                                                                                            
e11 = (1-thetaH)*(LH_1PN/LH); % PN                                                              
e12 = (1-thetaH)*(LH_1PH/LH) - (1/PH); % PH                                                     
e13 = - (1-thetaH)*(KH_1K/KH); % K                                                              
e14 = - (1-thetaH); % uKH                                                                      
e15 = 0; % uKN 
e16  = - (thetaH/AH);    % AH                                                                                                                                                           
e17  = - (1-thetaH)/BH;  % BH                                                                                                                                                          
e18  = 0;             % AN                                                                                                                                                   
e19  = 0;             % BN
e110 = (1-thetaH)*(LH_1lamb/LH); % lambda
                                                                                                                                                                                   
e21 = (1-thetaN)*(LN_1PN/LN) - (1/PN); % PN                                                     
e22 = (1-thetaN)*(LN_1PH/LN);  % PH                                                             
e23 = - (1-thetaN)*(KN_1K/KN); % K                                                              
e24 = 0; % uKH                                                                                       
e25 = - (1-thetaN);  % uKN     
e26  = 0;       % AH                                                                                                                                                         
e27  = 0;           % BH                                                                                                                                                  
e28  = - (thetaN/AN);     % AN                                                                                                                                                                     
e29  = - (1-thetaN)/BN;  %BN
e210 = (1-thetaN)*(LN_1lamb/LN); % lambda 
                                                                                                                                                                                   
e31 = - thetaH*(LH_1PN/LH); % PN                                                                
e32 = - ( thetaH*(LH_1PH/LH) + (1/PH) ); % PH                                                   
e33 = thetaH*(KH_1K/KH); % K                                                                    
e34 = thetaH; % uKH                                                                            
e35 = 0;  % uKN        
e36  = - (thetaH/AH);    % AH                                                                                                                                                           
e37  = - (1-thetaH)/BH;  % BH                                                                                                                                                          
e38  = 0;             % AN                                                                                                                                                   
e39  = 0;             % BN 
e310 = - thetaH*(LH_1lamb/LH); % lambda
                                                                                                                                                                                   
e41 = - ( thetaN*(LN_1PN/LN) + (1/PN) ); % PN                                                   
e42 = - thetaN*(LN_1PH/LN); % PH                                                                
e43 = thetaN*(KN_1K/KN); % K                                                                    
e44 = 0;  % uKH                                                                                      
e45 = thetaN; % uKN 
e46  = 0;       % AH                                                                                                                                                                   
e47  = 0;      % BH                                                                                                                                                                    
e48  = - (thetaN/AN);     % AN                                                                                                                                                                     
e49  = - (1-thetaN)/BN;  %BN
e410 =  - thetaN*(LN_1lamb/LN); % lambda 
                                                                                                                                                                                   
M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X2 = [e11 e12 e13 e14 e15 e16 e17 e18 e19 e110; e21 e22 e23 e24 e25 e26 e27 e28 e29 e210; e31 e32 e33 e34 e35 e36 e37 e38 e39 e310; e41 e42 e43 e44 e45 e46 e47 e48 e49 e410];
JST2 = inv(M2);
MST2 = JST2*X2;
WH_1PN = MST2(1,1); WH_1PH = MST2(1,2); WH_1K = MST2(1,3); WH_uKH = MST2(1,4); WH_uKN = MST2(1,5); WH_1AH = MST2(1,6); WH_1BH = MST2(1,7); WH_1AN = MST2(1,8); WH_1BN = MST2(1,9); WH_1lambda = MST2(1,10);
WN_1PN = MST2(2,1); WN_1PH = MST2(2,2); WN_1K = MST2(2,3); WN_uKH = MST2(2,4); WN_uKN = MST2(2,5); WN_1AH = MST2(2,6); WN_1BH = MST2(2,7); WN_1AN = MST2(2,8); WN_1BN = MST2(2,9); WN_1lambda = MST2(2,10);
RH_1PN = MST2(3,1); RH_1PH = MST2(3,2); RH_1K = MST2(3,3); RH_uKH = MST2(3,4); RH_uKN = MST2(3,5); RH_1AH = MST2(3,6); RH_1BH = MST2(3,7); RH_1AN = MST2(3,8); RH_1BN = MST2(3,9); RH_1lambda = MST2(3,10);
RN_1PN = MST2(4,1); RN_1PH = MST2(4,2); RN_1K = MST2(4,3); RN_uKH = MST2(4,4); RN_uKN = MST2(4,5); RN_1AH = MST2(4,6); RN_1BH = MST2(4,7); RN_1AN = MST2(4,8); RN_1BN = MST2(4,9); RN_1lambda = MST2(4,10);

% Solving for sectoral labor and sectoral output - Lj,yj,Yj,Kj(PN,PH,K,uKj,Aj,Bj)
LH_2PN = LH_1PN + (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_2PH = LH_1PH + (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K  = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKH = (LH_WH*WH_uKH) + (LH_WN*WN_uKH);
LH_uKN = (LH_WH*WH_uKN) + (LH_WN*WN_uKN);
LH_1AH = (LH_WH*WH_1AH) + (LH_WN*WN_1AH);
LH_1BH = (LH_WH*WH_1BH) + (LH_WN*WN_1BH);
LH_1AN = (LH_WH*WH_1AN) + (LH_WN*WN_1AN);
LH_1BN = (LH_WH*WH_1BN) + (LH_WN*WN_1BN);
LH_1lambda = LH_1lamb + (LH_WH*WH_1lambda) + (LH_WN*WN_1lambda);

LN_2PN = LN_1PN + (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_2PH = LN_1PH + (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K  = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKH = (LN_WH*WH_uKH) + (LN_WN*WN_uKH);
LN_uKN = (LN_WH*WH_uKN) + (LN_WN*WN_uKN);
LN_1AH = (LN_WH*WH_1AH) + (LN_WN*WN_1AH);
LN_1BH = (LN_WH*WH_1BH) + (LN_WN*WN_1BH);
LN_1AN = (LN_WH*WH_1AN) + (LN_WN*WN_1AN);
LN_1BN = (LN_WH*WH_1BN) + (LN_WN*WN_1BN);
LN_1lambda = LN_1lamb + (LN_WH*WH_1lambda) + (LN_WN*WN_1lambda);

KH_1PN = (KH_RH*RH_1PN) + (KH_RN*RN_1PN);
KH_1PH = (KH_RH*RH_1PH) + (KH_RN*RN_1PH);
KH_2K  = KH_1K  +(KH_RH*RH_1K)  + (KH_RN*RN_1K);
KH_uKH = (KH_RH*RH_uKH) + (KH_RN*RN_uKH);
KH_uKN = (KH_RH*RH_uKN) + (KH_RN*RN_uKN);
KH_1AH = (KH_RH*RH_1AH) + (KH_RN*RN_1AH);
KH_1BH = (KH_RH*RH_1BH) + (KH_RN*RN_1BH);
KH_1AN = (KH_RH*RH_1AN) + (KH_RN*RN_1AN);
KH_1BN = (KH_RH*RH_1BN) + (KH_RN*RN_1BN);
KH_1lambda = (KH_RH*RH_1lambda) + (KH_RN*RN_1lambda);

KN_1PN = (KN_RH*RH_1PN) + (KN_RN*RN_1PN);
KN_1PH = (KN_RH*RH_1PH) + (KN_RN*RN_1PH);
KN_2K  = KN_1K + (KN_RH*RH_1K)  + (KN_RN*RN_1K);
KN_uKH = (KN_RH*RH_uKH) + (KN_RN*RN_uKH);
KN_uKN = (KN_RH*RH_uKN) + (KN_RN*RN_uKN);
KN_1AH = (KN_RH*RH_1AH) + (KN_RN*RN_1AH);
KN_1BH = (KN_RH*RH_1BH) + (KN_RN*RN_1BH);
KN_1AN = (KN_RH*RH_1AN) + (KN_RN*RN_1AN);
KN_1BN = (KN_RH*RH_1BN) + (KN_RN*RN_1BN);
KN_1lambda = (KN_RH*RH_1lambda) + (KN_RN*RN_1lambda);

YH_1PN = thetaH*YH*(LH_2PN/LH) + (1-thetaH)*YH*(KH_1PN/KH);                    
YH_1PH = thetaH*YH*(LH_2PH/LH) + (1-thetaH)*YH*(KH_1PH/KH);                    
YH_1K  = thetaH*YH*(LH_1K/LH) + (1-thetaH)*YH*(KH_2K/KH);                      
YH_uKH = thetaH*YH*(LH_uKH/LH) + (1-thetaH)*YH*( (KH_uKH/KH) + 1 );            
YH_uKN = thetaH*YH*(LH_uKN/LH) + (1-thetaH)*YH*(KH_uKN/KH);                   
YH_1AH = thetaH*YH*( (LH_1AH/LH) + (1/AH) ) + (1-thetaH)*YH*(KH_1AH/KH);       
YH_1BH = thetaH*YH*(LH_1BH/LH) + (1-thetaH)*YH*( (KH_1BH/KH) + (1/BH) );       
YH_1AN = thetaH*YH*(LH_1AN/LH) + (1-thetaH)*YH*(KH_1AN/KH);                    
YH_1BN = thetaH*YH*(LH_1BN/LH) + (1-thetaH)*YH*(KH_1BN/KH);                    
YH_1lambda =  thetaH*YH*(LH_1lambda/LH) + (1-thetaH)*YH*(KH_1lambda/KH);       
                                                                               
YN_1PN = thetaN*YN*(LN_2PN/LN) + (1-thetaN)*YN*(KN_1PN/KN);                    
YN_1PH = thetaN*YN*(LN_2PH/LN) + (1-thetaN)*YN*(KN_1PH/KN);                    
YN_1K  = thetaN*YN*(LN_1K/LN) + (1-thetaN)*YN*(KN_2K/KN);                      
YN_uKH = thetaN*YN*(LN_uKH/LN) + (1-thetaN)*YN*(KN_uKH/KN);                    
YN_uKN = thetaN*YN*(LN_uKN/LN) + (1-thetaN)*YN*( (KN_uKN/KN) + 1);            
YN_1AH = thetaN*YN*(LN_1AH/LN) + (1-thetaN)*YN*(KN_1AH/KN);                    
YN_1BH = thetaN*YN*(LN_1BH/LN) + (1-thetaN)*YN*(KN_1BH/KN);                    
YN_1AN = thetaN*YN*( (LN_1AN/LN) + (1/AN) ) + (1-thetaN)*YN*(KN_1AN/KN);       
YN_1BN = thetaN*YN*(LN_1BN/LN) + (1-thetaN)*YN*( (KN_1BN/KN) + (1/BN) );       
YN_1lambda = thetaN*YN*(LN_1lambda/LN) + (1-thetaN)*YN*(KN_1lambda/KN);        

% Intermediate solution for CN, CH, CF - Cj=Cj(PN,PH,K,uKj,Aj,Bj)   
CN_2PN     = CN_1PN + (CN_WH*WH_1PN) + (CN_WN*WN_1PN);                 
CN_2PH     = CN_1PH + (CN_WH*WH_1PH) + (CN_WN*WN_1PH);                 
CN_1K      = (CN_WH*WH_1K) + (CN_WN*WN_1K);                            
CN_uKH     = (CN_WH*WH_uKH) + (CN_WN*WN_uKH);                          
CN_uKN     = (CN_WH*WH_uKN) + (CN_WN*WN_uKN);                          
CN_1AH     = (CN_WH*WH_1AH) + (CN_WN*WN_1AH);                          
CN_1BH     = (CN_WH*WH_1BH) + (CN_WN*WN_1BH);                          
CN_1AN     = (CN_WH*WH_1AN) + (CN_WN*WN_1AN);                          
CN_1BN     = (CN_WH*WH_1BN) + (CN_WN*WN_1BN);                          
CN_1lambda = CH_1lamb + (CN_WH*WH_1lambda) + (CN_WN*WN_1lambda);       
                                                                       
CH_2PN     = CH_1PN + (CH_WH*WH_1PN) + (CH_WN*WN_1PN);                 
CH_2PH     = CH_1PH + (CH_WH*WH_1PH) + (CH_WN*WN_1PH);                 
CH_1K      = (CH_WH*WH_1K) + (CH_WN*WN_1K);                            
CH_uKH     = (CH_WH*WH_uKH) + (CH_WN*WN_uKH);                          
CH_uKN     = (CH_WH*WH_uKN) + (CH_WN*WN_uKN);                          
CH_1AH     = (CH_WH*WH_1AH) + (CH_WN*WN_1AH);                          
CH_1BH     = (CH_WH*WH_1BH) + (CH_WN*WN_1BH);                          
CH_1AN     = (CH_WH*WH_1AN) + (CH_WN*WN_1AN);                          
CH_1BN     = (CH_WH*WH_1BN) + (CH_WN*WN_1BN);                          
CH_1lambda = CH_1lamb + (CH_WH*WH_1lambda) + (CH_WN*WN_1lambda);       
                                                                       
CF_2PN     = CF_1PN + (CF_WH*WH_1PN) + (CF_WN*WN_1PN);                 
CF_2PH     = CF_1PH + (CF_WH*WH_1PH) + (CF_WN*WN_1PH);                 
CF_1K      = (CF_WH*WH_1K) + (CF_WN*WN_1K);                            
CF_uKH     = (CF_WH*WH_uKH) + (CF_WN*WN_uKH);                          
CF_uKN     = (CF_WH*WH_uKN) + (CF_WN*WN_uKN);                          
CF_1AH     = (CF_WH*WH_1AH) + (CF_WN*WN_1AH);                          
CF_1BH     = (CF_WH*WH_1BH) + (CF_WN*WN_1BH);                          
CF_1AN     = (CF_WH*WH_1AN) + (CF_WN*WN_1AN);                          
CF_1BN     = (CF_WH*WH_1BN) + (CF_WN*WN_1BN);                          
CF_1lambda = CH_1lamb + (CF_WH*WH_1lambda) + (CF_WN*WN_1lambda);       

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I     = deltaK*K; 
JN_PN = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K = (IN/I)*J_K; 
JN_1Q = (IN/I)*J_Q; 

JH_PN =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKH, uKN; uKj(PN,PH,K)                                 
f11 = ((xi2H/xi1H) + thetaH) - thetaH*(LH_uKH/LH) + thetaH*(KH_uKH/KH); % uKH                
f12 = - thetaH*(LH_uKN/LH) + thetaH*(KH_uKN/KH);  % uKN                                             
f21 = - thetaN*(LN_uKH/LN) + thetaN*(KN_uKH/KN); % uKH                                             
f22 = ((xi2N/xi1N) + thetaN) - thetaN*(LN_uKN/LN) + thetaN*(KN_uKN/KN); % uKN   

% PN, PH, K, AH, BH, AN, BN, lambda                                 
g11 = thetaH*(LH_2PN/LH) - thetaH*(KH_1PN/KH); % PN                 
g12 = thetaH*(LH_2PH/LH) - thetaH*(KH_1PH/KH); % PH                 
g13 = thetaH*(LH_1K/LH) - thetaH*(KH_2K/KH); % K                    
g14 = thetaH*( (LH_1AH/LH) + (1/AH) ) - thetaH*(KH_1AH/KH); % AH    
g15 = thetaH*(LH_1BH/LH) - thetaH*( (KH_1BH/KH) + (1/BH) ); % BH    
g16 = thetaH*(LH_1AN/LH) - thetaH*(KH_1AN/KH); % AN                 
g17 = thetaH*(LH_1BN/LH) - thetaH*(KH_1BN/KH); % BN                 
g18 = thetaH*(LH_1lambda/LH) - thetaH*(KH_1lambda/KH); % lambda     
                                                                    
g21 = thetaN*(LN_2PN/LN) - thetaN*(KN_1PN/KN); % PN                 
g22 = thetaN*(LN_2PH/LN) - thetaN*(KN_1PH/KN); % PH                 
g23 = thetaN*(LN_1K/LN) - thetaN*(KN_2K/KN); % K                    
g24 = thetaN*(LN_1AH/LN) - thetaN*(KN_1AH/KN); % AH                 
g25 = thetaN*(LN_1BH/LN) - thetaN*(KN_1BH/KN); % BH                 
g26 = thetaN*( (LN_1AN/LN) + (1/AN) ) - thetaN*(KN_1AN/KN); % AN    
g27 = thetaN*(LN_1BN/LN) - thetaN*( (KN_1BN/KN) + (1/BN) ); % BN    
g28 = thetaN*(LN_1lambda/LN) - thetaN*(KN_1lambda/KN); % lambda       

M3 = [f11 f12; f21 f22];
X3 = [g11 g12 g13 g14 g15 g16 g17 g18; g21 g22 g23 g24 g25 g26 g27 g28];
JST3 = inv(M3);
MST3 = JST3*X3;

uKH_PN = MST3(1,1); uKH_PH = MST3(1,2); uKH_1K = MST3(1,3); uKH_1AH = MST3(1,4); uKH_1BH = MST3(1,5); uKH_1AN = MST3(1,6); uKH_1BN = MST3(1,7); uKH_1lambda = MST3(1,8);
uKN_PN = MST3(2,1); uKN_PH = MST3(2,2); uKN_1K = MST3(2,3); uKN_1AH = MST3(2,4); uKN_1BH = MST3(2,5); uKN_1AN = MST3(2,6); uKN_1BN = MST3(2,7); uKN_1lambda = MST3(2,8);

% Solving for Wj,Rj,Lj,Kj,Yj(lambda,K,PH,PN,AH,BH,AN,BN)
WH_2K  = WH_1K + (WH_uKH*uKH_1K) + (WH_uKN*uKN_1K);
WH_PH  = WH_1PH + (WH_uKH*uKH_PH) + (WH_uKN*uKN_PH);
WH_PN  = WH_1PN + (WH_uKH*uKH_PN) + (WH_uKN*uKN_PN);
WH_2AH = WH_1AH + (WH_uKH*uKH_1AH) + (WH_uKN*uKN_1AH);
WH_2BH = WH_1BH + (WH_uKH*uKH_1BH) + (WH_uKN*uKN_1BH);
WH_2AN = WH_1AN + (WH_uKH*uKH_1AN) + (WH_uKN*uKN_1AN);
WH_2BN = WH_1BN + (WH_uKH*uKH_1BN) + (WH_uKN*uKN_1BN);
WH_2lambda = WH_1lambda + (WH_uKH*uKH_1lambda) + (WH_uKN*uKN_1lambda);

WN_2K = WN_1K + (WN_uKH*uKH_1K) + (WN_uKN*uKN_1K);
WN_PH = WN_1PH + (WN_uKH*uKH_PH) + (WN_uKN*uKN_PH);
WN_PN = WN_1PN + (WN_uKH*uKH_PN) + (WN_uKN*uKN_PN);
WN_2AH = WN_1AH + (WN_uKH*uKH_1AH) + (WN_uKN*uKN_1AH);
WN_2BH = WN_1BH + (WN_uKH*uKH_1BH) + (WN_uKN*uKN_1BH);
WN_2AN = WN_1AN + (WN_uKH*uKH_1AN) + (WN_uKN*uKN_1AN);
WN_2BN = WN_1BN + (WN_uKH*uKH_1BN) + (WN_uKN*uKN_1BN);
WN_2lambda = WN_1lambda + (WN_uKH*uKH_1lambda) + (WN_uKN*uKN_1lambda);

RH_2K  = RH_1K + (RH_uKH*uKH_1K) + (RH_uKN*uKN_1K);                              
RH_PH  = RH_1PH + (RH_uKH*uKH_PH) + (RH_uKN*uKN_PH);                             
RH_PN  = RH_1PN + (RH_uKH*uKH_PN) + (RH_uKN*uKN_PN);                             
RH_2AH = RH_1AH + (RH_uKH*uKH_1AH) + (RH_uKN*uKN_1AH);                           
RH_2BH = RH_1BH + (RH_uKH*uKH_1BH) + (RH_uKN*uKN_1BH);                           
RH_2AN = RH_1AN + (RH_uKH*uKH_1AN) + (RH_uKN*uKN_1AN);                           
RH_2BN = RH_1BN + (RH_uKH*uKH_1BN) + (RH_uKN*uKN_1BN);                           
RH_2lambda = RH_1lambda + (RH_uKH*uKH_1lambda) + (RH_uKN*uKN_1lambda);           
                                                                                 
RN_2K = RN_1K + (RN_uKH*uKH_1K) + (RN_uKN*uKN_1K);                               
RN_PH = RN_1PH + (RN_uKH*uKH_PH) + (RN_uKN*uKN_PH);                              
RN_PN = RN_1PN + (RN_uKH*uKH_PN) + (RN_uKN*uKN_PN);                              
RN_2AH = RN_1AH + (RN_uKH*uKH_1AH) + (RN_uKN*uKN_1AH);                           
RN_2BH = RN_1BH + (RN_uKH*uKH_1BH) + (RN_uKN*uKN_1BH);                           
RN_2AN = RN_1AN + (RN_uKH*uKH_1AN) + (RN_uKN*uKN_1AN);                           
RN_2BN = RN_1BN + (RN_uKH*uKH_1BN) + (RN_uKN*uKN_1BN);                           
RN_2lambda = RN_1lambda + (RN_uKH*uKH_1lambda) + (RN_uKN*uKN_1lambda);           

LH_2K = LH_1K + (LH_uKH*uKH_1K) + (LH_uKN*uKN_1K);
LH_PH = LH_2PH + (LH_uKH*uKH_PH) + (LH_uKN*uKN_PH);
LH_PN = LH_2PN + (LH_uKH*uKH_PN) + (LH_uKN*uKN_PN);
LH_2AH = LH_1AH + (LH_uKH*uKH_1AH) + (LH_uKN*uKN_1AH);
LH_2BH = LH_1BH + (LH_uKH*uKH_1BH) + (LH_uKN*uKN_1BH);
LH_2AN = LH_1AN + (LH_uKH*uKH_1AN) + (LH_uKN*uKN_1AN);
LH_2BN = LH_1BN + (LH_uKH*uKH_1BN) + (LH_uKN*uKN_1BN);
LH_2lambda = LH_1lambda + (LH_uKH*uKH_1lambda) + (LH_uKN*uKN_1lambda);

LN_2K = LN_1K + (LN_uKH*uKH_1K) + (LN_uKN*uKN_1K);
LN_PH = LN_2PH + (LN_uKH*uKH_PH) + (LN_uKN*uKN_PH);
LN_PN = LN_2PN + (LN_uKH*uKH_PN) + (LN_uKN*uKN_PN);
LN_2AH = LN_1AH + (LN_uKH*uKH_1AH) + (LN_uKN*uKN_1AH);
LN_2BH = LN_1BH + (LN_uKH*uKH_1BH) + (LN_uKN*uKN_1BH);
LN_2AN = LN_1AN + (LN_uKH*uKH_1AN) + (LN_uKN*uKN_1AN);
LN_2BN = LN_1BN + (LN_uKH*uKH_1BN) + (LN_uKN*uKN_1BN);
LN_2lambda = LN_1lambda + (LN_uKH*uKH_1lambda) + (LN_uKN*uKN_1lambda);

KH_3K = KH_2K + (KH_uKH*uKH_1K) + (KH_uKN*uKN_1K);
KH_PH = KH_1PH + (KH_uKH*uKH_PH) + (KH_uKN*uKN_PH);
KH_PN = KH_1PN + (KH_uKH*uKH_PN) + (KH_uKN*uKN_PN);
KH_2AH = KH_1AH + (KH_uKH*uKH_1AH) + (KH_uKN*uKN_1AH);
KH_2BH = KH_1BH + (KH_uKH*uKH_1BH) + (KH_uKN*uKN_1BH);
KH_2AN = KH_1AN + (KH_uKH*uKH_1AN) + (KH_uKN*uKN_1AN);
KH_2BN = KH_1BN + (KH_uKH*uKH_1BN) + (KH_uKN*uKN_1BN);
KH_2lambda = KH_1lambda + (KH_uKH*uKH_1lambda) + (KH_uKN*uKN_1lambda);

KN_3K = KN_2K + (KN_uKH*uKH_1K) + (KN_uKN*uKN_1K);
KN_PH = KN_1PH + (KN_uKH*uKH_PH) + (KN_uKN*uKN_PH);
KN_PN = KN_1PN + (KN_uKH*uKH_PN) + (KN_uKN*uKN_PN);
KN_2AH = KN_1AH + (KN_uKH*uKH_1AH) + (KN_uKN*uKN_1AH);
KN_2BH = KN_1BH + (KN_uKH*uKH_1BH) + (KN_uKN*uKN_1BH);
KN_2AN = KN_1AN + (KN_uKH*uKH_1AN) + (KN_uKN*uKN_1AN);
KN_2BN = KN_1BN + (KN_uKH*uKH_1BN) + (KN_uKN*uKN_1BN);
KN_2lambda = KN_1lambda + (KN_uKH*uKH_1lambda) + (KN_uKN*uKN_1lambda);

YH_2K = YH_1K + (YH_uKH*uKH_1K) + (YH_uKN*uKN_1K);
YH_PH = YH_1PH + (YH_uKH*uKH_PH) + (YH_uKN*uKN_PH);
YH_PN = YH_1PN + (YH_uKH*uKH_PN) + (YH_uKN*uKN_PN);
YH_2AH = YH_1AH + (YH_uKH*uKH_1AH) + (YH_uKN*uKN_1AH);
YH_2BH = YH_1BH + (YH_uKH*uKH_1BH) + (YH_uKN*uKN_1BH);
YH_2AN = YH_1AN + (YH_uKH*uKH_1AN) + (YH_uKN*uKN_1AN);
YH_2BN = YH_1BN + (YH_uKH*uKH_1BN) + (YH_uKN*uKN_1BN);
YH_2lambda = YH_1lambda + (YH_uKH*uKH_1lambda) + (YH_uKN*uKN_1lambda);

YN_2K = YN_1K + (YN_uKH*uKH_1K) + (YN_uKN*uKN_1K);
YN_PH = YN_1PH + (YN_uKH*uKH_PH) + (YN_uKN*uKN_PH);
YN_PN = YN_1PN + (YN_uKH*uKH_PN) + (YN_uKN*uKN_PN);
YN_2AH = YN_1AH + (YN_uKH*uKH_1AH) + (YN_uKN*uKN_1AH);
YN_2BH = YN_1BH + (YN_uKH*uKH_1BH) + (YN_uKN*uKN_1BH);
YN_2AN = YN_1AN + (YN_uKH*uKH_1AN) + (YN_uKN*uKN_1AN);
YN_2BN = YN_1BN + (YN_uKH*uKH_1BN) + (YN_uKN*uKN_1BN);
YN_2lambda = YN_1lambda + (YN_uKH*uKH_1lambda) + (YN_uKN*uKN_1lambda);

CN_2K = CN_1K + (CN_uKH*uKH_1K) + (CN_uKN*uKN_1K);                          
CN_PH = CN_2PH + (CN_uKH*uKH_PH) + (CN_uKN*uKN_PH);                         
CN_PN = CN_2PN + (CN_uKH*uKH_PN) + (CN_uKN*uKN_PN);                         
CN_2AH = CN_1AH + (CN_uKH*uKH_1AH) + (CN_uKN*uKN_1AH);                      
CN_2BH = CN_1BH + (CN_uKH*uKH_1BH) + (CN_uKN*uKN_1BH);                      
CN_2AN = CN_1AN + (CN_uKH*uKH_1AN) + (CN_uKN*uKN_1AN);                      
CN_2BN = CN_1BN + (CN_uKH*uKH_1BN) + (CN_uKN*uKN_1BN);                      
CN_2lambda = CN_1lambda + (CN_uKH*uKH_1lambda) + (CN_uKN*uKN_1lambda);      
                                                                            
CH_2K = CH_1K + (CH_uKH*uKH_1K) + (CH_uKN*uKN_1K);                          
CH_PH = CH_2PH + (CH_uKH*uKH_PH) + (CH_uKN*uKN_PH);                         
CH_PN = CH_2PN + (CH_uKH*uKH_PN) + (CH_uKN*uKN_PN);                         
CH_2AH = CH_1AH + (CH_uKH*uKH_1AH) + (CH_uKN*uKN_1AH);                      
CH_2BH = CH_1BH + (CH_uKH*uKH_1BH) + (CH_uKN*uKN_1BH);                      
CH_2AN = CH_1AN + (CH_uKH*uKH_1AN) + (CH_uKN*uKN_1AN);                      
CH_2BN = CH_1BN + (CH_uKH*uKH_1BN) + (CH_uKN*uKN_1BN);                      
CH_2lambda = CH_1lambda + (CH_uKH*uKH_1lambda) + (CH_uKN*uKN_1lambda);      
                                                                            
CF_2K = CF_1K + (CF_uKH*uKH_1K) + (CF_uKN*uKN_1K);                          
CF_PH = CF_2PH + (CF_uKH*uKH_PH) + (CF_uKN*uKN_PH);                         
CF_PN = CF_2PN + (CF_uKH*uKH_PN) + (CF_uKN*uKN_PN);                         
CF_2AH = CF_1AH + (CF_uKH*uKH_1AH) + (CF_uKN*uKN_1AH);                      
CF_2BH = CF_1BH + (CF_uKH*uKH_1BH) + (CF_uKN*uKN_1BH);                      
CF_2AN = CF_1AN + (CF_uKH*uKH_1AN) + (CF_uKN*uKN_1AN);                      
CF_2BN = CF_1BN + (CF_uKH*uKH_1BN) + (CF_uKN*uKN_1BN);                      
CF_2lambda = CF_1lambda + (CF_uKH*uKH_1lambda) + (CF_uKN*uKN_1lambda);  

% Partial Derivatives Gj=Gj(G)
GN_G   = omegaGN/PN;
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,lambda)     
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1N*uKN_PH);           
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1N*uKN_PN);           
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1H*uKH_PH);   
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1H*uKH_PN);           
                                                            
% K,Q,G,AH,BH,AN,BN,lambda                                                       
k11 = -(YN_2K - CN_2K - JN_1K - (KN*xi1N*uKN_1K));                  
k12 = JN_1Q;    
k13 = GN_G;
k14 = -(YN_2AH - CN_2AH - (KN*xi1N*uKN_1AH));                        
k15 = -(YN_2BH - CN_2BH - (KN*xi1N*uKN_1BH));                        
k16 = -(YN_2AN - CN_2AN - (KN*xi1N*uKN_1AN));                        
k17 = -(YN_2BN - CN_2BN - (KN*xi1N*uKN_1BN));                        
k18 = -((YN_2lambda - CN_2lambda) - (KN*xi1N*uKN_1lambda)); 

k21 = -(YH_2K - CH_2K - JH_1K - (KH*xi1H*uKH_1K));                  
k22 = JH_1Q;  
k23 = GH_G;
k24 = -(YH_2AH - CH_2AH - (KH*xi1H*uKH_1AH));                         
k25 = -(YH_2BH - CH_2BH - (KH*xi1H*uKH_1BH));                         
k26 = -(YH_2AN - CH_2AN - (KH*xi1H*uKH_1AN));                         
k27 = -(YH_2BN - CH_2BN - (KH*xi1H*uKH_1BN));                         
k28 = -((YH_2lambda - CH_2lambda) - (KH*xi1H*uKH_1lambda));  
                                                            
M4 = [h11 h12; h21 h22];                                                                                                                                 
X4 = [k11 k12 k13 k14 k15 k16 k17 k18; k21 k22 k23 k24 k25 k26 k27 k28];                                                                                 
JST4 = inv(M4);                                                                                                                                          
MST4 = JST4*X4;                                                                                                                                          
                                                                                                                                                         
PH_K = MST4(1,1); PH_Q = MST4(1,2); PH_G = MST4(1,3); PH_AH = MST4(1,4); PH_BH = MST4(1,5); PH_AN = MST4(1,6); PH_BN = MST4(1,7); PH_lambda = MST4(1,8); 
PN_K = MST4(2,1); PN_Q = MST4(2,2); PN_G = MST4(2,3); PN_AH = MST4(2,4); PN_BH = MST4(2,5); PN_AN = MST4(2,6); PN_BN = MST4(2,7); PN_lambda = MST4(2,8);                         

% Solving for Lj,Kj,Wj,Rj,Yj,uKj(K,Q,G,Aj,Bj) - 
LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);
LH_AH = LH_2AH + (LH_PH*PH_AH) + (LH_PN*PN_AH); 
LH_BH = LH_2BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_2AN + (LH_PH*PH_AN) + (LH_PN*PN_AN); 
LH_BN = LH_2BN + (LH_PH*PH_BN) + (LH_PN*PN_BN);
LH_lambda = LH_2lambda + (LH_PH*PH_lambda) + (LH_PN*PN_lambda); 

LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G); 
LN_AH = LN_2AH + (LN_PH*PH_AH) + (LN_PN*PN_AH); 
LN_BH = LN_2BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_2AN + (LN_PH*PH_AN) + (LN_PN*PN_AN); 
LN_BN = LN_2BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);
LN_lambda = LN_2lambda + (LN_PH*PH_lambda) + (LN_PN*PN_lambda); 

YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);
YH_AH = YH_2AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_2BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_2AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_2BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);
YH_lambda = YH_2lambda + (YH_PH*PH_lambda) + (YH_PN*PN_lambda);  

YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);
YN_AH = YN_2AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_2BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_2AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_2BN + (YN_PH*PH_BN) + (YN_PN*PN_BN);
YN_lambda = YN_2lambda + (YN_PH*PH_lambda) + (YN_PN*PN_lambda); 

KH_K  = KH_3K + (KH_PH*PH_K) + (KH_PN*PN_K);                     
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);                             
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);                             
KH_AH = KH_2AH + (KH_PH*PH_AH) + (KH_PN*PN_AH);                  
KH_BH = KH_2BH + (KH_PH*PH_BH) + (KH_PN*PN_BH);                  
KH_AN = KH_2AN + (KH_PH*PH_AN) + (KH_PN*PN_AN);                  
KH_BN = KH_2BN + (KH_PH*PH_BN) + (KH_PN*PN_BN);                  
KH_lambda = KH_2lambda + (KH_PH*PH_lambda) + (KH_PN*PN_lambda);  
                                                                 
KN_K = KN_3K + (KN_PH*PH_K) + (KN_PN*PN_K);                      
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);                              
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);                              
KN_AH = KN_2AH + (KN_PH*PH_AH) + (KN_PN*PN_AH);                  
KN_BH = KN_2BH + (KN_PH*PH_BH) + (KN_PN*PN_BH);                  
KN_AN = KN_2AN + (KN_PH*PH_AN) + (KN_PN*PN_AN);                  
KN_BN = KN_2BN + (KN_PH*PH_BN) + (KN_PN*PN_BN);                  
KN_lambda = KN_2lambda + (KN_PH*PH_lambda) + (KN_PN*PN_lambda); 

uKH_K  = uKH_1K + (uKH_PH*PH_K) + (uKH_PN*PN_K);                     
uKH_Q  = (uKH_PH*PH_Q) + (uKH_PN*PN_Q);                              
uKH_G  = (uKH_PH*PH_G) + (uKH_PN*PN_G);                              
uKH_AH = uKH_1AH + (uKH_PH*PH_AH) + (uKH_PN*PN_AH);                  
uKH_BH = uKH_1BH + (uKH_PH*PH_BH) + (uKH_PN*PN_BH);                  
uKH_AN = uKH_1AN + (uKH_PH*PH_AN) + (uKH_PN*PN_AN);                  
uKH_BN = uKH_1BN + (uKH_PH*PH_BN) + (uKH_PN*PN_BN);                  
uKH_lambda = uKH_1lambda + (uKH_PH*PH_lambda) + (uKH_PN*PN_lambda);  
                                                                     
uKN_K = uKN_1K + (uKN_PH*PH_K) + (uKN_PN*PN_K);                      
uKN_Q = (uKN_PH*PH_Q) + (uKN_PN*PN_Q);                               
uKN_G = (uKN_PH*PH_G) + (uKN_PN*PN_G);                               
uKN_AH = uKN_1AH + (uKN_PH*PH_AH) + (uKN_PN*PN_AH);                  
uKN_BH = uKN_1BH + (uKN_PH*PH_BH) + (uKN_PN*PN_BH);                  
uKN_AN = uKN_1AN + (uKN_PH*PH_AN) + (uKN_PN*PN_AN);                  
uKN_BN = uKN_1BN + (uKN_PH*PH_BN) + (uKN_PN*PN_BN);                  
uKN_lambda = uKN_1lambda + (uKN_PH*PH_lambda) + (uKN_PN*PN_lambda);             
                                                                                        
% Solving for consumption Cj=Cj(lambda,K,Q,G,Aj,Bj), investment inputs 
% Jj=Jj(K,Q,GH,GN), imports MF=MF(lambda,K,Q,G,Aj,Bj), exports 
%XH=XH(K,Q,G,Aj,Bj)- Final Solutions
CN_K  = CN_2K + (CN_PH*PH_K) + (CN_PN*PN_K);                          
CN_Q  = (CN_PH*PH_Q) + (CN_PN*PN_Q);                                  
CN_G  = (CN_PH*PH_G) + (CN_PN*PN_G);                                  
CN_AH = CN_2AH + (CN_PH*PH_AH) + (CN_PN*PN_AH);                       
CN_BH = CN_2BH + (CN_PH*PH_BH) + (CN_PN*PN_BH);                       
CN_AN = CN_2AN + (CN_PH*PH_AN) + (CN_PN*PN_AN);                       
CN_BN = CN_2BN + (CN_PH*PH_BN) + (CN_PN*PN_BN);                       
CN_lambda = CN_2lambda + (CN_PH*PH_lambda) + (CN_PN*PN_lambda);       
                                                                      
CH_K  = CH_2K + (CH_PH*PH_K) + (CH_PN*PN_K);                          
CH_Q  = (CH_PH*PH_Q) + (CH_PN*PN_Q);                                  
CH_G  = (CH_PH*PH_G) + (CH_PN*PN_G);                                  
CH_AH = CH_2AH + (CH_PH*PH_AH) + (CH_PN*PN_AH);                       
CH_BH = CH_2BH + (CH_PH*PH_BH) + (CH_PN*PN_BH);                       
CH_AN = CH_2AN + (CH_PH*PH_AN) + (CH_PN*PN_AN);                       
CH_BN = CH_2BN + (CH_PH*PH_BN) + (CH_PN*PN_BN);                       
CH_lambda = CH_2lambda + (CH_PH*PH_lambda) + (CH_PN*PN_lambda);       
                                                                      
CF_K  = CF_2K + (CF_PH*PH_K) + (CF_PN*PN_K);                          
CF_Q  = (CF_PH*PH_Q) + (CF_PN*PN_Q);                                  
CF_G  = (CF_PH*PH_G) + (CF_PN*PN_G);                                  
CF_AH = CF_2AH + (CF_PH*PH_AH) + (CF_PN*PN_AH);                       
CF_BH = CF_2BH + (CF_PH*PH_BH) + (CF_PN*PN_BH);                       
CF_AN = CF_2AN + (CF_PH*PH_AN) + (CF_PN*PN_AN);                       
CF_BN = CF_2BN + (CF_PH*PH_BN) + (CF_PN*PN_BN);                       
CF_lambda = CF_2lambda + (CF_PH*PH_lambda) + (CF_PN*PN_lambda);  

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);
JH_lambda  = (JH_PH*PH_lambda) + (JH_PN*PN_lambda);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_BH      = (JN_PH*PH_BH) + (JN_PN*PN_BH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN);
JN_lambda  = (JN_PH*PH_lambda) + (JN_PN*PN_lambda);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN); 
JF_lambda  = (JF_PH*PH_lambda) + (JF_PN*PN_lambda);

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;
XH_lambda = XH_PH*PH_lambda;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);
MF_lambda = (CF_lambda + JF_lambda);

% Solving for sectoral wages - Wj=Wj(K,Q,G,Aj,Bj)                          
RH_K = RH_2K + (RH_PH*PH_K) + (RH_PN*PN_K);                                
RH_Q = (RH_PH*PH_Q) + (RH_PN*PN_Q);                                        
RH_G = (RH_PH*PH_G) + (RH_PN*PN_G);                                        
RH_AH = RH_2AH + (RH_PH*PH_AH) + (RH_PN*PN_AH);                            
RH_BH = RH_2BH + (RH_PH*PH_BH) + (RH_PN*PN_BH);                            
RH_AN = RH_2AN + (RH_PH*PH_AN) + (RH_PN*PN_AN);                            
RH_BN = RH_2BN + (RH_PH*PH_BN) + (RH_PN*PN_BN);                            
RH_lambda = RH_2lambda + (RH_PH*PH_lambda) + (RH_PN*PN_lambda);            
                                                                           
RN_K = RN_2K + (RN_PH*PH_K) + (RN_PN*PN_K);                                
RN_Q = (RN_PH*PH_Q) + (RN_PN*PN_Q);                                        
RN_G = (RN_PH*PH_G) + (RN_PN*PN_G);                                        
RN_AH = RN_2AH + (RN_PH*PH_AH) + (RN_PN*PN_AH);                            
RN_BH = RN_2BH + (RN_PH*PH_BH) + (RN_PN*PN_BH);                            
RN_AN = RN_2AN + (RN_PH*PH_AN) + (RN_PN*PN_AN);                            
RN_BN = RN_2BN + (RN_PH*PH_BN) + (RN_PN*PN_BN);                            
RN_lambda = RN_2lambda + (RN_PH*PH_lambda) + (RN_PN*PN_lambda);  

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(K,Q,G,Aj,Bj,lambda) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_G  = (v_PN*PN_G) + (v_PH*PH_G); 
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);
v_lambda = (v_PN*PN_lambda) + (v_PH*PH_lambda);

% Elements of the Jacobian Matrix                                                                                                                                           
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                  
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );                                                                           
Sigma_K   = -( -(RK/K)+(1/K)*( (RH*KH*uKH_K)+(RN*KN*uKN_K)+(RH*KH_K)+(RN*KN_K)+(RH_K*KH)+(RN_K*KN) )-(PH*KH/K)*xi1H*uKH_K-(PN*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) );   
Sigma_Q   = (r+deltaK)-( (1/K)*( (RH*KH*uKH_Q)+(RN*KN*uKN_Q)+(RH*KH_Q)+(RN*KN_Q)+(RH_Q*KH)+(RN_Q*KN) )-(PH*KH/K)*xi1H*uKH_Q-(PN*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) ); 

x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    

J = [x11 x12; x21 x22];
[V,nu]=eig(J); 
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1); 
nu2 = nu_sorted(2,2); 
omega11 = V_sorted(1,1)/V_sorted(1,1); 
omega21 = V_sorted(2,1)/V_sorted(1,1); 
omega12 = V_sorted(1,2)/V_sorted(1,2); 
omega22 = V_sorted(2,2)/V_sorted(1,2); 
TrJ = trace(J); 
DetJ = det(J); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q);
% Xi_Q=0
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r); 

% Solving for sectoral wages - Wj=Wj(K,Q,G,Aj,Bj)
WH_K = WH_2K + (WH_PH*PH_K) + (WH_PN*PN_K);                       
WH_Q = (WH_PH*PH_Q) + (WH_PN*PN_Q);                               
WH_G = (WH_PH*PH_G) + (WH_PN*PN_G);                               
WH_AH = WH_2AH + (WH_PH*PH_AH) + (WH_PN*PN_AH);                   
WH_BH = WH_2BH + (WH_PH*PH_BH) + (WH_PN*PN_BH);                   
WH_AN = WH_2AN + (WH_PH*PH_AN) + (WH_PN*PN_AN);                   
WH_BN = WH_2BN + (WH_PH*PH_BN) + (WH_PN*PN_BN);                   
WH_lambda = WH_2lambda + (WH_PH*PH_lambda) + (WH_PN*PN_lambda);   
                                                                  
WN_K = WN_2K + (WN_PH*PH_K) + (WN_PN*PN_K);                       
WN_Q = (WN_PH*PH_Q) + (WN_PN*PN_Q);                               
WN_G = (WN_PH*PH_G) + (WN_PN*PN_G);                               
WN_AH = WN_2AH + (WN_PH*PH_AH) + (WN_PN*PN_AH);                   
WN_BH = WN_2BH + (WN_PH*PH_BH) + (WN_PN*PN_BH);                   
WN_AN = WN_2AN + (WN_PH*PH_AN) + (WN_PN*PN_AN);                   
WN_BN = WN_2BN + (WN_PH*PH_BN) + (WN_PN*PN_BN);                   
WN_lambda = WN_2lambda + (WN_PH*PH_lambda) + (WN_PN*PN_lambda); 

% Solution for W as function W=W(lambda,K,Q,AH,BH,AN,BN)                      
W_K       = (W_WH*WH_K) + (W_WN*WN_K);                                          
W_Q       = (W_WH*WH_Q) + (W_WN*WN_Q);                                          
W_AH      = (W_WH*WH_AH) + (W_WN*WN_AH);                                        
W_BH      = (W_WH*WH_BH) + (W_WN*WN_BH);                                        
W_AN      = (W_WH*WH_AN) + (W_WN*WN_AN);                                        
W_BN      = (W_WH*WH_BN) + (W_WN*WN_BN);                                        
W_lambda  = (W_WH*WH_lambda) + (W_WN*WN_lambda);                                
                                                                                
% Solution for L as function L=L(lambda,K,Q,Aj,Bj)                            
L_K  = (L_W*W_K) + (L_1PN*PN_K) + (L_1PH*PH_K);                                 
L_Q  = (L_W*W_Q) + (L_1PN*PN_Q) + (L_1PH*PH_Q);                                 
L_AH = (L_W*W_AH) + (L_1PN*PN_AH) + (L_1PH*PH_AH);                              
L_BH = (L_W*W_BH) + (L_1PN*PN_BH) + (L_1PH*PH_BH);                              
L_AN = (L_W*W_AN) + (L_1PN*PN_AN) + (L_1PH*PH_AN);                              
L_BN = (L_W*W_BN) + (L_1PN*PN_BN) + (L_1PH*PH_BN);                              
L_lambda  = L_1lambda + (L_W*W_lambda) + (L_1PN*PN_lambda) + (L_1PH*PH_lambda);         

% Solution for C as function C=C(lambda,K,Q,Aj,Bj)                                        
C_K        = (C_W*W_K) + (C_1PH*PH_K) + (C_1PN*PN_K);                                     
C_Q        = (C_W*W_Q) + (C_1PH*PH_Q) + (C_1PN*PN_Q);                                     
C_AH       = (C_W*W_AH) + (C_1PH*PH_AH) + (C_1PN*PN_AH);                                  
C_BH       = (C_W*W_BH) + (C_1PH*PH_BH) + (C_1PN*PN_BH);                                  
C_AN       = (C_W*W_AN) + (C_1PH*PH_AN) + (C_1PN*PN_AN);                                  
C_BN       = (C_W*W_BN) + (C_1PH*PH_BN) + (C_1PN*PN_BN);  
C_lambda   = C_1lambda + (C_1PH*PH_lambda) + (C_1PN*PN_lambda);  

% Solution for GE=PH*GH + PN*GN + GF - G = G(K,Q,G,Aj,Bj)
G_K        = (PH_K*GH) + (PN_K*GN); 
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_G        = (PH_G*GH) + (PN_G*GN) + (PH*GH_G) + (PN*GN_G) + GF_G;   
G_AH       = (PH_AH*GH) + (PN_AH*GN);
G_BH       = (PH_BH*GH) + (PN_BH*GN);
G_AN       = (PH_AN*GH) + (PN_AN*GN);
G_BN       = (PH_BN*GH) + (PN_BN*GN);
G_lambda   = (PH_lambda*GH) + (PN_lambda*GN);

% Unit Cost                                                                          
% solving for the Unit Cost for Producing MN=MN(K,Q,PN,G,Aj,Bj)                      
MN_K  = thetaN*(MN/WN)*WN_K + (1-thetaN)*(MN/RN)*RN_K;                               
MN_Q  = thetaN*(MN/WN)*WN_Q + (1-thetaN)*(MN/RN)*RN_Q;                               
MN_G  = thetaN*(MN/WN)*WN_G + (1-thetaN)*(MN/RN)*RN_G;                               
MN_AH = thetaN*(MN/WN)*WN_AH + (1-thetaN)*(MN/RN)*RN_AH;                             
MN_BH = thetaN*(MN/WN)*WN_BH + (1-thetaN)*(MN/RN)*RN_BH;                             
MN_AN = thetaN*(MN/WN)*WN_AN + (1-thetaN)*(MN/RN)*RN_AN - thetaN*(MN/AN);            
MN_BN = thetaN*(MN/WN)*WN_BN + (1-thetaN)*(MN/RN)*RN_BN - (1-thetaN)*(MN/BN);        
MN_lambda  = thetaN*(MN/WN)*WN_lambda + (1-thetaN)*(MN/RN)*RN_lambda;                

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 
omegaGT = GT/G; 
omegaGH = (PH*GH)/G; 
omegaGF = GF/G; 

% Investment 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF;  
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;
RHPH = RH/PH;
RNPN = RN/PN;

% Labor income and Capital income shares
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% Aggregator function for L=L(LH,LN)
VLAB    = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = VLAB^(epsilon/(epsilon+1)); 
L_LH    = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_LN    = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Aggregator function for K=K(KH,KN)                                                                                                      
VCAP    = ( (varthetaK^(-1/epsilonK))*(KH^((epsilonK+1)/epsilonK)) + ((1-varthetaK)^(-1/epsilonK))*(KN^((epsilonK+1)/epsilonK)) );        
K_check = VCAP^(epsilonK/(epsilonK+1));                                                                                                   
K_KH    = ((varthetaK)^(-1/epsilonK))*(KH/K)^(1/epsilonK);                                                                                
K_KN    = ((1-varthetaK)^(-1/epsilonK))*(KN/K)^(1/epsilonK);  

% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH =  IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaXHY  = (PH*XH) / Y; 
omegaXHYH = XH / YH;

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Check the closure of the model
cond1  = PH*(1-thetaH)*(YH/KH)-RH;                               
cond2  = PN*(1-thetaN)*(YN/KN)-RN;                             
cond3  = PH*thetaH*(YH/LH)-WH;                                   
cond4  = PN*thetaN*(YN/LN)-WN;                                 
cond5  = (RH*KH)+(RN*KN)-(RK*K);                                               
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YH-CH-GH-IH-XH;                                   
cond9  = (B-B0) - H1*(K-K0);                                  
cond10  = DetJ - (nu1*nu2);                                   
cond11 = TrJ - (nu1+nu2);                                     
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);  
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);               
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond15 = (W*L) - ((WH*LH)+(WN*LN));                           
cond16 = -U_L*L_LH - (lambda*WH);               
cond17 = -U_L*L_LN - (lambda*WN);               
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond19 = Sav;                                                 
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);            
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                
cond23 = (RK*K) - ((RH*KH)+(RN*KN));                        
cond24 = 1 - (omegaK + omegaL);    
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);    
cond26 = (PT*CT) - ((PH*CH)+CF); 
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);    
cond28 = (PIT*IT) - ((PH*IH)+IF); 
cond29 = r*B + (PH*XH) - MF; 
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I); 
cond31 = K_KH - (RH/RK);                                                            
cond32 = K_KN - (RN/RK);                                                            
cond33 = (KH/KN) - (varthetaK/(1-varthetaK))*(RH/RN)^(epsilonK);   
cond34 = PN - MN;
cond35 = PH - MH;
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kH > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaH  : %5.2f   thetaN   : %5.2f',thetaH,thetaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('phi     : %5.2f   varphi   : %5.2f',phi,varphi));  
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f ',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f ',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f ',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f sigma   : %5.2f',sigmaL,gammaL,sigma));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('epsilonK: %5.2f   varthetaK: %5.2f',epsilonK,varthetaK));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('TFPH    : %5.2f   TFPN     : %5.2f',TFPH,TFPN));
disp(sprintf('omegaYH : %5.2f   Z        : %5.2f TFP        : %5.2f',omegaYH,Z,TFP));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));
disp(sprintf('L        : %9.3f   ',K));
disp(sprintf('K_check  : %9.3f   ',K_check));
disp(sprintf('alphaK   : %9.3f   ',alphaK));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('RN                 : %9.3f',RN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('RH                 : %9.3f',RH));
disp(sprintf('Profit             : %9.10f',PiH));

disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f',IH,IN));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp('Export and import (benchmark)');
disp(sprintf('XH        :   %7.3f   MF : %9.3f',XH,MF));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));

disp('Unit Cost for Non-Tradables');                                           
disp(sprintf('MN_Q        :   %7.3f  MN_K        : %9.3f',MN_Q,MN_K));         
disp(sprintf('MN_G        :   %7.3f  MN_lambda   : %9.3f',MN_G,MN_lambda));        
disp(sprintf('MN_AH       :   %7.3f  MN_BH       : %9.3f',MN_AH,MN_BH));       
disp(sprintf('MN_AN       :   %7.3f  MN_BN       : %9.3f',MN_AN,MN_BN)); 

disp('Price of Non Tradables in terms of Imports');                                                                
disp(sprintf('PN_Q        :   %7.3f  PN_K        : %9.3f',PN_Q,PN_K));                          
disp(sprintf('PN_G        :   %7.3f',PN_G)); 
disp(sprintf('PN_AH       :   %7.3f  PN_BH       : %9.3f',PN_AH,PN_BH));
disp(sprintf('PN_AN       :   %7.3f  PN_BN       : %9.3f',PN_AN,PN_BN));
                                                                                                
disp('Terms of Trade');                                                                                            
disp(sprintf('PH_Q        :   %7.3f  PH_K        : %9.3f',PH_Q,PH_K));                          
disp(sprintf('PH_G        :   %7.3f',PH_G));                        
disp(sprintf('PH_AH       :   %7.3f  PH_BH       : %9.3f',PH_AH,PH_BH));
disp(sprintf('PH_AN       :   %7.3f  PH_BN       : %9.3f',PH_AN,PH_BN));                                                                                                

disp(' ');                                                                                      
disp('Partial derivatives CH and CN');                                                          
disp(sprintf('CN_K        :   %7.3f  CH_K      : %9.3f',CN_K,CH_K));                            
disp(sprintf('CN_Q        :   %7.3f  CH_Q      : %9.3f',CN_Q,CH_Q));                            
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));                  
disp(sprintf('CN_G        :   %7.3f  CH_G      : %9.3f',CN_G,CH_G)); 
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));
disp(sprintf('CN_AH       :   %7.3f  CH_AH     : %9.3f',CN_AH,CH_AH));
disp(sprintf('CN_BH       :   %7.3f  CH_BH     : %9.3f',CN_BH,CH_BH));
disp(sprintf('CN_AN       :   %7.3f  CH_AN     : %9.3f',CN_AN,CH_AN));
disp(sprintf('CN_BN       :   %7.3f  CH_BN     : %9.3f',CN_BN,CH_BN));                          
                                                                                                
                                                                                                
disp('Partial derivatives KH and KN');                                                      
disp(sprintf('KN_Q       :   %7.6f  KH_Q       : %9.6f',KN_Q,KH_Q));                        
disp(sprintf('KN_K       :   %7.6f  KH_K       : %9.6f',KN_K,KH_K));                        
disp(sprintf('KN_lambda  :   %7.3f  KH_lambda  : %9.3f',KN_lambda,KH_lambda));              
disp(sprintf('KN_G       :   %7.6f  KH_G       : %9.6f',KN_G,KH_G));                        
disp(sprintf('KN_AH      :   %7.6f  KH_AH      : %9.6f',KN_AH,KH_AH));                      
disp(sprintf('KN_BH      :   %7.6f  KH_BH      : %9.6f',KN_BH,KH_BH));                      
disp(sprintf('KN_AN      :   %7.6f  KH_AN      : %9.6f',KN_AN,KH_AN));                      
disp(sprintf('KN_BN      :   %7.6f  KH_BN      : %9.6f',KN_BN,KH_BN));                      
                                                                                            
disp('Partial derivatives WH and WN');                                                      
disp(sprintf('WN_Q       :   %7.6f  WH_Q       : %9.6f',WN_Q,WH_Q));                        
disp(sprintf('WN_K       :   %7.6f  WH_K       : %9.6f',WN_K,WH_K));                        
disp(sprintf('WN_lambda  :   %7.3f  WH_lambda  : %9.3f',WN_lambda,WH_lambda));              
disp(sprintf('WN_G       :   %7.6f  WH_G       : %9.6f',WN_G,WH_G));                        
disp(sprintf('WN_AH      :   %7.6f  WH_AH      : %9.6f',WN_AH,WH_AH));                      
disp(sprintf('WN_BH      :   %7.6f  WH_BH      : %9.6f',WN_BH,WH_BH));                      
disp(sprintf('WN_AN      :   %7.6f  WH_AN      : %9.6f',WN_AN,WH_AN));                      
disp(sprintf('WN_BN      :   %7.6f  WH_BN      : %9.6f',WN_BN,WH_BN));                      
                                                                                            
disp('Partial derivatives RH and RN');                                                      
disp(sprintf('RN_Q       :   %7.6f  RH_Q       : %9.6f',RN_Q,RH_Q));                        
disp(sprintf('RN_K       :   %7.6f  RH_K       : %9.6f',RN_K,RH_K));                        
disp(sprintf('RN_lambda  :   %7.3f  RH_lambda  : %9.3f',RN_lambda,RH_lambda));              
disp(sprintf('RN_G       :   %7.6f  RH_G       : %9.6f',RN_G,RH_G));                        
disp(sprintf('RN_AH      :   %7.6f  RH_AH      : %9.6f',RN_AH,RH_AH));                      
disp(sprintf('RN_BH      :   %7.6f  RH_BH      : %9.6f',RN_BH,RH_BH));                      
disp(sprintf('RN_AN      :   %7.6f  RH_AN      : %9.6f',RN_AN,RH_AN));                      
disp(sprintf('RN_BN      :   %7.6f  RH_BN      : %9.6f',RN_BN,RH_BN));                      
                                                                                                
disp('Partial derivatives LH and LN');                                                          
disp(sprintf('LN_Q       :   %7.6f  LH_Q       : %9.6f',LN_Q,LH_Q));                            
disp(sprintf('LN_K       :   %7.6f  LH_K       : %9.6f',LN_K,LH_K));                            
disp(sprintf('LN_lambda  :   %7.3f  LH_lambda  : %9.3f',LN_lambda,LH_lambda));                  
disp(sprintf('LN_G       :   %7.6f  LH_G       : %9.6f',LN_G,LH_G)); 
disp(sprintf('LN_AH      :   %7.6f  LH_AH      : %9.6f',LN_AH,LH_AH));
disp(sprintf('LN_BH      :   %7.6f  LH_BH      : %9.6f',LN_BH,LH_BH));
disp(sprintf('LN_AN      :   %7.6f  LH_AN      : %9.6f',LN_AN,LH_AN));
disp(sprintf('LN_BN      :   %7.6f  LH_BN      : %9.6f',LN_BN,LH_BN));

                                                                                                
disp('Partial derivatives Yj');  
disp(sprintf('YN_1PN     :   %7.6f  YN_1PH     : %9.6f',YN_1PN,YN_1PH));
disp(sprintf('YN_1K      :   %7.6f  YN_1lambda : %9.6f',YN_1K,YN_1lambda));
disp(sprintf('YN_1AH     :   %7.6f  YN_1BH     : %9.6f',YN_1AH,YN_1BH));
disp(sprintf('YN_1AN     :   %7.6f  YN_1BN     : %9.6f',YN_1AN,YH_1BN));
disp(sprintf('YN_uKH     :   %7.6f  YN_uKN     : %9.6f',YN_uKH,YN_uKN));
disp(' ');
disp(sprintf('YH_1PN     :   %7.6f  YH_1PH     : %9.6f',YH_1PN,YH_1PH));
disp(sprintf('YH_1K      :   %7.6f  YH_1lambda : %9.6f',YH_1K,YH_1lambda));
disp(sprintf('YH_1AH     :   %7.6f  YH_1BH     : %9.6f',YH_1AH,YH_1BH));
disp(sprintf('YH_1AN     :   %7.6f  YH_1BN     : %9.6f',YH_1AN,YH_1BN));
disp(sprintf('YH_uKH     :   %7.6f  YH_uKN     : %9.6f',YH_uKH,YH_uKN));
disp(' ');

disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));                            
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));                            
disp(sprintf('YN_lambda  :   %7.3f  YH_lambda  : %9.3f',YN_lambda,YH_lambda));                  
disp(sprintf('YN_G       :   %7.6f  YH_G       : %9.6f',YN_G,YH_G));
disp(sprintf('YN_AH      :   %7.6f  YH_AH      : %9.6f',YN_AH,YH_AH));
disp(sprintf('YN_BH      :   %7.6f  YH_BH      : %9.6f',YN_BH,YH_BH));
disp(sprintf('YN_AN      :   %7.6f  YH_AN      : %9.6f',YN_AN,YH_AN));
disp(sprintf('YN_BN      :   %7.6f  YH_BN      : %9.6f',YN_BN,YH_BN));
                                                                                                                                                                     
disp('Partial derivatives of L');                                                               
disp(sprintf('L_Q        :   %7.3f  L_K        : %9.3f',L_Q,L_K));                                   
disp(sprintf('L_lambda   :   %7.3f',L_lambda));  

disp('Partial derivatives of uKj');  
disp(sprintf('uKN_Q       :   %7.6f  uKH_Q       : %9.6f',uKN_Q,uKH_Q));             
disp(sprintf('uKN_K       :   %7.6f  uKH_K       : %9.6f',uKN_K,uKH_K));             
disp(sprintf('uKN_lambda  :   %7.3f  uKH_lambda  : %9.3f',uKN_lambda,uKH_lambda));   
disp(sprintf('uKN_G       :   %7.6f  uKH_G       : %9.6f',uKN_G,uKH_G));             
disp(sprintf('uKN_AH      :   %7.6f  uKH_AH      : %9.6f',uKN_AH,uKH_AH));           
disp(sprintf('uKN_BH      :   %7.6f  uKH_BH      : %9.6f',uKN_BH,uKH_BH));           
disp(sprintf('uKN_AN      :   %7.6f  uKH_AN      : %9.6f',uKN_AN,uKH_AN));           
disp(sprintf('uKN_BN      :   %7.6f  uKH_BN      : %9.6f',uKN_BN,uKH_BN));           
                                                                                                                                             
disp(' ');                                                                                      
disp('Linearization');                                                                           
disp(sprintf('v_K       :  %5.4f  v_Q       : %5.4f',v_K,v_Q));                                 
disp(sprintf('v_G       :  %5.4f',v_G));          
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));                     
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));                         
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));  
                                                                                                
disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WH*LH/W*L   :  %5.3f RH*KH/RK*K  :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f  KH/K       :  %5.3f',omegaKY,KHK));

disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LH/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));
disp(sprintf('Traded capital supply             : %9.16f   ',cond31));
disp(sprintf('Non-traded capital supply         : %9.16f   ',cond32));
disp(sprintf('Relative capital supply KH/KN     : %9.16f   ',cond33));
disp(sprintf('Unit Cost for Producing N         : %9.16f   ',cond34));
disp(sprintf('Unit Cost for Producing H         : %9.16f   ',cond35));

kH_0CD = kH;  kN_0CD = kN; PN_0CD = PN; K_0CD = K; C_0CD = C;
L_0CD = L; W_0CD = W; P_0CD = P;
YH_0CD  = YH; YN_0CD  = YN; Y_0CD  = Y; YR_0CD = Y_0CD; G_0CD = G;
PC_0CD = PC; CN_0CD = CN; CH_0CD = CH;
ZH_0CD = ZH; ZN_0CD = ZN; Z_0CD = Z; GH_0CD = GH; GN_0CD = GN;  GF_0CD = GF;
LH_0CD = LH; LN_0CD = LN; KH_0CD = KH; KN_0CD = KN; WH_0CD = WH; WN_0CD = WN;
Omega_0CD = Omega; YHYN_0CD = YHYN; LHLN_0CD = LHLN;
IF_0CD = IF; CF_0CD = CF; XH_0CD = XH; MF_0CD = MF; PH_0CD = PH;
PT_0CD = PT; PIT_0CD = PIT; CT_0CD = CT; IT_0CD = IT; GT_0CD = GT;

CA_0CD = CA; Sav_0CD = Sav; NX_0CD = NX; I_0CD = I; 
lambda_0CD  = lambda; A_0CD = A;
B_0CD = B; IN_0CD = IN; IH_0CD = IH; PI_0CD = PI; EI_0CD = EI;
WPC_0CD = WPC; WHPC_0CD = WHPC; WNPC_0CD = WNPC; RK_0CD = RK;
yH_0CD = yH; yN_0CD = yN;

omegaL_0CD = omegaL; omegaK_0CD = omegaK; omegaI_0CD = omegaI; omegaINYN_0CD = omegaINYN;
omegaIHYH_0CD = omegaIHYH; omega_IFYH_0CD = omegaIFYH; omegaGHYH_0CD = omegaGHYH;
omegaGNYN_0CD = omegaGNYN; omegaGN_0CD = omegaGN;
omegaYH_0CD = omegaYH; omegaYN_0CD = omegaYN; omegaLH_0CD = omegaLH; omegaLN_0CD = omegaLN;
omegaC_0CD =omegaC; omegaNX_0CD =omegaNX; omegaG_0CD =omegaG; omegaB_0CD =omegaB;
omegaIFYH_0CD = omegaIFYH; omegaGFYH_0CD = omegaGFYH; 
omegaCH_0CD = omegaCH; omegaCF_0CD = omegaCF;
omegaGT_0CD = omegaGT; omegaGH_0CD = omegaGH; omegaGF_0CD = omegaGF;
omegaKY_0CD = omegaKY; omegaIH_0CD = omegaIH; omegaIF_0CD = omegaIF;
omegaXHY_0CD = omegaXHY; omegaXHYH_0CD = omegaXHYH;
alphaL_0CD = alphaL; alphaK_0CD = alphaK; alphaC_0CD = alphaC;
alphaI_0CD = alphaI; alphaH_0CD = alphaH; alphaIH_0CD = alphaIH;
sLH_0CD = sLH; sLN_0CD = sLN; 
TFPH_0CD = TFPH; TFPN_0CD = TFPN; TFP_0CD = TFP;
sigmaH_0CD = sigmaH; sigmaN_0CD = sigmaN; H1_0CD = H1; 
VL_0CD = VL; RH_0CD = RH; RN_0CD = RN; RHPH_0CD = RHPH; RNPN_0CD = RNPN; 

clc
clear

% Maximum duration for graphics
Tg = 10;
       
% Minimum duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

eta0_9019_R;        
eta0_8402_R;        
eta0_8595_R;        
eta0_8584_R;      
eta0_8614_R;  
eta0_8501_R;  
eta0_7810_R;  
eta0_8090_R;  
eta0_8095_R;  
eta0_7433_R;  
eta0_6954_R;  
eta0_6594_R;  
eta0_6554_R;  
eta0_6667_R;  
eta0_6809_R;  
eta0_6570_R;  
eta0_6208_R;  
eta0_6233_R;  
eta0_6013_R;

eta0_9019_hntc;   
eta0_8402_hntc;   
eta0_8595_hntc;   
eta0_8584_hntc;   
eta0_8614_hntc;   
eta0_8501_hntc;   
eta0_7810_hntc;   
eta0_8090_hntc;   
eta0_8095_hntc;   
eta0_7433_hntc;   
eta0_6954_hntc;   
eta0_6594_hntc;   
eta0_6554_hntc;   
eta0_6667_hntc;   
eta0_6809_hntc;   
eta0_6570_hntc;   
eta0_6208_hntc;   
eta0_6233_hntc; 
eta0_6013_hntc;  
                  
disp(sprintf('dLtime0,dLHtime0,dLNtime0')); 
disp('Impact Responses of hours worked, hours worked of tradables and non-tradables');                                                             
disp(sprintf('eta0_9019  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_9019,dLHtime0_eta0_9019,dLNtime0_eta0_9019));        
disp(sprintf('eta0_8402  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8402,dLHtime0_eta0_8402,dLNtime0_eta0_8402));        
disp(sprintf('eta0_8595  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8595,dLHtime0_eta0_8595,dLNtime0_eta0_8595));        
disp(sprintf('eta0_8584  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8584,dLHtime0_eta0_8584,dLNtime0_eta0_8584));        
disp(sprintf('eta0_8614  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8614,dLHtime0_eta0_8614,dLNtime0_eta0_8614));        
disp(sprintf('eta0_8501  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8501,dLHtime0_eta0_8501,dLNtime0_eta0_8501));        
disp(sprintf('eta0_7810  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_7810,dLHtime0_eta0_7810,dLNtime0_eta0_7810));        
disp(sprintf('eta0_8090  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8090,dLHtime0_eta0_8090,dLNtime0_eta0_8090));        
disp(sprintf('eta0_8095  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8095,dLHtime0_eta0_8095,dLNtime0_eta0_8095));        
disp(sprintf('eta0_7433  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_7433,dLHtime0_eta0_7433,dLNtime0_eta0_7433));        
disp(sprintf('eta0_6954  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6954,dLHtime0_eta0_6954,dLNtime0_eta0_6954));        
disp(sprintf('eta0_6594  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6594,dLHtime0_eta0_6594,dLNtime0_eta0_6594));        
disp(sprintf('eta0_6554  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6554,dLHtime0_eta0_6554,dLNtime0_eta0_6554));        
disp(sprintf('eta0_6667  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6667,dLHtime0_eta0_6667,dLNtime0_eta0_6667));        
disp(sprintf('eta0_6809  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6809,dLHtime0_eta0_6809,dLNtime0_eta0_6809));        
disp(sprintf('eta0_6570  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6570,dLHtime0_eta0_6570,dLNtime0_eta0_6570));        
disp(sprintf('eta0_6208  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6208,dLHtime0_eta0_6208,dLNtime0_eta0_6208));        
disp(sprintf('eta0_6233  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6233,dLHtime0_eta0_6233,dLNtime0_eta0_6233));        
disp(sprintf('eta0_6013  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6013,dLHtime0_eta0_6013,dLNtime0_eta0_6013));                                                                                                                                                                                                                 
disp(' ');
disp('-------------------------------------------------------------------------------------------------------- ');


disp(sprintf('eta0_9019_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_9019_hntc,dLHtime0_eta0_9019_hntc,dLNtime0_eta0_9019_hntc));      
disp(sprintf('eta0_8402_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8402_hntc,dLHtime0_eta0_8402_hntc,dLNtime0_eta0_8402_hntc));      
disp(sprintf('eta0_8595_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8595_hntc,dLHtime0_eta0_8595_hntc,dLNtime0_eta0_8595_hntc));      
disp(sprintf('eta0_8584_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8584_hntc,dLHtime0_eta0_8584_hntc,dLNtime0_eta0_8584_hntc));      
disp(sprintf('eta0_8614_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8614_hntc,dLHtime0_eta0_8614_hntc,dLNtime0_eta0_8614_hntc));      
disp(sprintf('eta0_8501_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8501_hntc,dLHtime0_eta0_8501_hntc,dLNtime0_eta0_8501_hntc));      
disp(sprintf('eta0_7810_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_7810_hntc,dLHtime0_eta0_7810_hntc,dLNtime0_eta0_7810_hntc));      
disp(sprintf('eta0_8090_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8090_hntc,dLHtime0_eta0_8090_hntc,dLNtime0_eta0_8090_hntc));      
disp(sprintf('eta0_8095_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_8095_hntc,dLHtime0_eta0_8095_hntc,dLNtime0_eta0_8095_hntc));      
disp(sprintf('eta0_7433_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_7433_hntc,dLHtime0_eta0_7433_hntc,dLNtime0_eta0_7433_hntc));      
disp(sprintf('eta0_6954_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6954_hntc,dLHtime0_eta0_6954_hntc,dLNtime0_eta0_6954_hntc));      
disp(sprintf('eta0_6594_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6594_hntc,dLHtime0_eta0_6594_hntc,dLNtime0_eta0_6594_hntc));      
disp(sprintf('eta0_6554_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6554_hntc,dLHtime0_eta0_6554_hntc,dLNtime0_eta0_6554_hntc));      
disp(sprintf('eta0_6667_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6667_hntc,dLHtime0_eta0_6667_hntc,dLNtime0_eta0_6667_hntc));      
disp(sprintf('eta0_6809_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6809_hntc,dLHtime0_eta0_6809_hntc,dLNtime0_eta0_6809_hntc));      
disp(sprintf('eta0_6570_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6570_hntc,dLHtime0_eta0_6570_hntc,dLNtime0_eta0_6570_hntc));      
disp(sprintf('eta0_6208_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6208_hntc,dLHtime0_eta0_6208_hntc,dLNtime0_eta0_6208_hntc));      
disp(sprintf('eta0_6233_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6233_hntc,dLHtime0_eta0_6233_hntc,dLNtime0_eta0_6233_hntc));      
disp(sprintf('eta0_6013_hntc  : |%10.3f | %10.3f | %10.3f ',dLtime0_eta0_6013_hntc,dLHtime0_eta0_6013_hntc,dLNtime0_eta0_6013_hntc));      



clear


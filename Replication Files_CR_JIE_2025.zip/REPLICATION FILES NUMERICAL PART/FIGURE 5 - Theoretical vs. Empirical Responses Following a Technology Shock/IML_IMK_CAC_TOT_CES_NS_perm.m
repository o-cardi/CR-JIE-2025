function g = IML_IMK_CAC_TOT_CES_NS_perm(x)

global sigma phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global gammaL sigmaL
global epsilon vartheta 
global epsilonK varthetaK 
global r deltaK kappa
global omegaGN omegaGH GH GN GF
global BH BN AH AN gammaH gammaN sigmaH sigmaN
global B0 K0 Y_0 AH_0 BH_0 AN_0 BN_0 
global ASH_0 BSH_0 ASN_0 BSN_0 ADH_0 BDH_0 ADN_0 BDN_0 
global barg xi chi 
global xi1SH xi1DH xi1SN xi1DN xi2SH xi2DH xi2SN xi2DN
global xiASH xiADH xiBSH xiBDH xiASN xiADN xiBSN xiBDN   
global chiASH chiADH chiBSH chiBDH chiASN chiADN chiBSN chiBDN 
global baraSH baraDH barbSH barbDH baraSN baraDN barbSN barbDN eta
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
C        = x(1)  ; % Consumption                                                              
L        = x(2)  ; % Labor supply                                                             
RH       = x(3)  ; % Return on traded capital                                                 
RN       = x(4)  ; % Return on non-traded capital                                             
WH       = x(5)  ; % Wage rate in sector H                                                    
WN       = x(6)  ; % Wage rate in sector N                                                    
W        = x(7)  ; % Aggregate wage index                                                     
RK       = x(8)  ; % Aggregate capital rental rate                                            
PN       = x(9)  ; % Relative price of non tradables                                          
K        = x(10)  ; % Stock of capital                                                        
PH       = x(11) ; % Terms of trade : PH/PF with PF = numeraire                               
B        = x(12) ; % Stock of Traded Bonds                                                    
alphaL   = x(13) ; % Labor compensation share of tradables                                    
alphaK   = x(14) ; % Capital compensation share of tradables                                  
PC       = x(15) ; % Aggregate consumption price index                                        
PT       = x(16) ; % Consumption price index for tradables                                    
CN       = x(17) ; % Consumption in non tradables                                             
CH       = x(18) ; % Consumption in tradables                                                 
CF       = x(19) ; % Consumption goods imports                                                
PI       = x(20) ; % Aggregate investment price index                                         
PIT      = x(21) ; % Investment price index for tradables                                     
IN       = x(22) ; % Non tradable investment                                                  
IH       = x(23) ; % Investment in home goods                                                 
IF       = x(24) ; % Investment in foreign goods                                              
LH       = x(25) ; % Labor in sector H                                                        
LN       = x(26) ; % Labor in sector N                                                        
KH       = x(27) ; % Capital stock in sector H                                                
KN       = x(28) ; % Capital stock in sector N                                                
YH       = x(29) ; % Traded value added                                                       
YN       = x(30) ; % Non-traded value added                                                   
XH       = x(31) ; % Exports of home traded goods                                             
MF       = x(32) ; % Imports of foreign goods                                                 
VL       = x(33) ; % Desutility labor                                                         
lambda   = x(34) ; % Marginal Utility of Wealth - Intertemporal Solvency Condition            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
% Aggregate Consumption -  C                                                                                                                     
g(1)= (C^(-sigma))*(VL^sigma) - (PC*lambda);                                                                                                     
                                                                                                                                                 
% Aggregate labor supply - L                                                                                                                     
g(2)= (C^(1-sigma))*sigma*gammaL*(L^(1/sigmaL))*(VL^(sigma-1)) - (lambda*W);                                                                     
                                                                                                                                                 
% MRPKH = RH - RH                                                                                                                                     
g(3)= PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH)) - RH;                                                                          
                                                                                                                                                 
% MRPKN = RN - RN                                                                                                                                     
g(4)= PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN)) - RN;                                                                          
                                                                                                                                                 
% MRPLH = WH - WN                                                                                                                     
g(5)= PH*gammaH*(AH^((sigmaH-1)/sigmaH))*((YH/LH)^(1/sigmaH)) - WH;                                                                              
                                                                                                                                                 
% MRPLN = WN - WN                                                                                                                     
g(6)= PN*gammaN*(AN^((sigmaN-1)/sigmaN))*((YN/LN)^(1/sigmaN)) - WN;                                                                              
                                                                                                                                                 
% Aggregate wage index - W                                                                                                                       
g(7)= W - ((vartheta*(WH)^(epsilon+1)) + ((1-vartheta)*(WN)^(epsilon+1)))^(1/(epsilon+1));                                                       
                                                                                                                                                 
% Aggregate capital rental rate index - RK                                                                                                       
g(8)= RK - ((varthetaK*(RH)^(epsilonK+1)) + ((1-varthetaK)*(RN)^(epsilonK+1)))^(1/(epsilonK+1));                                                 
                                                                                                                                                 
% Return on capital is equal to capital cost dotQ=0 - PN                                                                              
g(9)= RK - (deltaK + r)*PI;                                                                                                                      
                                                                                                                                                 
% Non traded market good market clearing condition - K                                                                                           
g(10)= YN - CN - IN - GN;                                                                                                                        
                                                                                                                                                 
% Homme good market clearing condition - PH                                                                                                      
g(11)= YH - CH - IH - GH - XH;                                                                                                                   
                                                                                                                                                 
% Traded good market clearing condition - B                                                                                                      
g(12)= (r*B) + (PH*XH) - MF;                                                                                                                     
                                                                                                                                                 
% Labor compensation share of tradables WH*LH/W*L - alphaL                                                                                                 
g(13)= alphaL - (vartheta*(WH)^(epsilon+1))/( vartheta*(WH)^(epsilon+1) + (1-vartheta)*(WN)^(epsilon+1) );                                       
                                                                                                                                                 
% Capital compensation share of tradables RH*KH/RK*K- alphaK                                                                                                
g(14)= alphaK - (varthetaK*(RH)^(epsilonK+1))/( varthetaK*(RH)^(epsilonK+1) + (1-varthetaK)*(RN)^(epsilonK+1) );                                 
                                                                                                                                                 
% Consumption price index - PC=PC(PT,PN)                                                                                                         
g(15)= PC - (varphi*(PT^(1-phi))+(1-varphi)*(PN^(1-phi)))^(1/(1-phi));                                                                           
                                                                                                                                                 
% Consumption price index for tradables - PT=PT(PH)                                                                                              
g(16)= PT - (varphiH*(PH^(1-rho))+(1-varphiH))^(1/(1-rho));                                                                                      
                                                                                                                                                 
% Consumption in non tradables - CN                                                                                                              
g(17)= CN - C*(1-varphi)*((PN/PC)^(-phi));                                                                                                       
                                                                                                                                                 
% Consumption in home goods - CH                                                                                                                 
g(18)= CH - C*varphi*((PT/PC)^(-phi))*varphiH*((PH/PT)^(-rho));                                                                                  
                                                                                                                                                 
% Consumption in foreign goods - CF                                                                                                              
g(19)= CF - C*varphi*((PT/PC)^(-phi))*(1-varphiH)*((1/PT)^(-rho));                                                                               
                                                                                                                                                 
% Investment price index - PI=PI(PT,PN)                                                                                                          
g(20)= PI - (iota*(PIT^(1-phiI))+(1-iota)*(PN^(1-phiI)))^(1/(1-phiI));                                                                           
                                                                                                                                                 
% Investment price index for tradables - PIT=PIT(PH)                                                                                             
g(21)= PIT - (iotaH*(PH^(1-rhoI))+(1-iotaH))^(1/(1-rhoI));                                                                                       
                                                                                                                                                 
% Investment in non tradables - IN                                                                                                               
g(22)= IN - (deltaK*K)*(1-iota)*((PN/PI)^(-phiI));                                                                                               
                                                                                                                                                 
% Investment in home goods - IH                                                                                                                  
g(23)= IH - (deltaK*K)*iota*((PIT/PI)^(-phiI))*iotaH*((PH/PIT)^(-rhoI));                                                                         
                                                                                                                                                 
% Investment in foreign goods - IF                                                                                                               
g(24)= IF - (deltaK*K)*iota*((PIT/PI)^(-phiI))*(1-iotaH)*((1/PIT)^(-rhoI));                                                                      
                                                                                                                                                 
% Hours worked in the traded sector - LH                                                                                                          
g(25)= LH - L*(vartheta*(WH/W)^epsilon);                                                                                                         
                                                                                                                                                 
% Hours worked in the non traded sector - LN                                                                                                      
g(26)= LN - L*((1-vartheta)*(WN/W)^epsilon);                                                                                                     
                                                                                                                                                 
% Capital stock in the traded sector - KH                                                                                                        
g(27)= KH - K*(varthetaK*(RH/RK)^epsilonK);                                                                                                      
                                                                                                                                                 
% Capital stock in the non traded sector - KN                                                                                                    
g(28)= KN - K*((1-varthetaK)*(RN/RK)^epsilonK);                                                                                                  
                                                                                                                                                 
% Value added in the home-produced traded goods sector - YH                                                                                      
g(29)= YH - ( gammaH*((AH*LH)^((sigmaH-1)/sigmaH)) + (1-gammaH)*((BH*KH)^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1));                             
                                                                                                                                                 
% Value added in the non-traded sector - YN                                                                                                      
g(30)= YN - ( gammaN*((AN*LN)^((sigmaN-1)/sigmaN)) + (1-gammaN)*((BN*KN)^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1));                             
                                                                                                                                                 
% Export of home goods - XH                                                                                                                      
g(31)= XH - ex*(PH)^(-nuX);                                                                                                                      
                                                                                                                                                 
% Import of foreign goods - MF                                                                                                                   
g(32)= MF - (CF+IF+GF);                                                                                                                          
                                                                                                                                                 
% Desutility from working                                                                                                                        
g(33)= VL - ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) );                                                                  

% Non tradable shares of consumption, investment, labor compensation, labor
% income share
I       = deltaK*K;
alphaC  = varphi*(PT/PC)^(1-phi);
alphaH  = varphiH*(PH/PT)^(1-rho);
alphaI  = iota*(PIT/PI)^(1-phiI);
alphaIH = iotaH*(PH/PIT)^(1-rhoI);
sLH    = (WH*LH)/(PH*YH); 
sLN    = (WN*LN)/(PN*YN);

% Solutions C=C(lambda,PN,PH,W); L=L(lambda,PN,PH,W)
a11 = -(sigma/C); 
a12 = (sigma/L)*((1+sigmaL)/sigmaL)*((VL-1)/VL);
a21 = (1-sigma)/C; 
a22 = (1/L)*( (1/sigmaL) + (sigma-1)*((1+sigmaL)/sigmaL)*((VL-1)/VL) );  

b11 = (1-alphaC)/PN; 
b12 = alphaC*alphaH/PH; 
b13 = 0;
b21 = 0;
b22 = 0; 
b23 = (1/W); 

A1 = [a11 a12; a21 a22];
B1 = [b11 b12 b13; b21 b22 b23];
JST1 = inv(A1);
MST1 = JST1*B1;
C_1PN = MST1(1,1); C_1PH = MST1(1,2); C_W = MST1(1,3); 
L_1PN = MST1(2,1); L_1PH = MST1(2,2); L_W = MST1(2,3); 

% Partial derivatives of W=W(WN,WH)           
W_WH     = (W/WH)*alphaL; 
W_WN     = (W/WN)*(1-alphaL);                                                                                                                         
L_WH     = L_W*W_WH;                                                                    
L_WN     = L_W*W_WN;                                                                    
                                                                                        
% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH,WN,WH)                      
CN_1PN = - (CN/PN)*(alphaC*phi) + (CN/C)*C_1PN;                                         
CN_1PH = (CN/PH)*alphaC*alphaH*phi + (CN/C)*C_1PH;                                      
CN_WN  = (CN/C)*C_W*W_WN;                                                               
CN_WH  = (CN/C)*C_W*W_WH;                                                               
                                                                                        
CH_1PN = (CH/PN)*phi*(1-alphaC) + (CH/C)*C_1PN;                                         
CH_1PH = -(CH/PH)*( rho*(1-alphaH) + phi*alphaH*(1-alphaC) ) + (CH/C)*C_1PH;            
CH_WN  = (CH/C)*C_W*W_WN;                                                               
CH_WH  = (CH/C)*C_W*W_WH;                                                               
                                                                                        
CF_1PN = (CF/PN)*(1-alphaC)*phi + (CF/C)*C_1PN;                                         
CF_1PH = (CF/PH)*alphaH*(rho - phi*(1-alphaC) ) + (CF/C)*C_1PH;                         
CF_WN  = (CF/C)*C_W*W_WN;                                                               
CF_WH  = (CF/C)*C_W*W_WH;   

% Solutions LH=LH(lambda,WH,WN,PH,PN), LN=LN(lambda,WH,WN,PH,PN)
LH_WH  = (LH/WH)*epsilon*(1-alphaL) + (LH/L)*L_WH; 
LH_WN  = -(LH/WN)*epsilon*(1-alphaL) + (LH/L)*L_WN; 
LH_1PH = (LH/L)*L_1PH; 
LH_1PN = (LH/L)*L_1PN;

LN_WH  = -(LN/WH)*epsilon*alphaL + (LN/L)*L_WH; 
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN; 
LN_1PH = (LN/L)*L_1PH; 
LN_1PN = (LN/L)*L_1PN;  

% Solutions Kj=Kj(RH,RN,K), j=H,N            
KH_RH = (KH/RH)*epsilonK*(1-alphaK);         
KH_RN = -(KH/RN)*epsilonK*(1-alphaK);        
KH_1K  = (KH/K);                              
                                             
KN_RH = -(KN/RH)*epsilonK*alphaK;            
KN_RN = (KN/RN)*epsilonK*alphaK;             
KN_1K  = (KN/K);                              

% Solving for WH,WN,RH,RN(PH,PN,K,uKH,uKN,AH,BH,AN,BN,lambda)
d11 = - ( ((1-sLH)/sigmaH)*(LH_WH/LH) + (1/WH) ); % WH
d12 = - ((1-sLH)/sigmaH)*(LH_WN/LH);  % WN
d13 = ((1-sLH)/sigmaH)*(KH_RH/KH);  % RH
d14 = ((1-sLH)/sigmaH)*(KH_RN/KH); % RN

d21 = - ((1-sLN)/sigmaN)*(LN_WH/LN);  % WH
d22 = - ( ((1-sLN)/sigmaN)*(LN_WN/LN) + (1/WN) ); % WN
d23 = ((1-sLN)/sigmaN)*(KN_RH/KN);  % RH
d24 = ((1-sLN)/sigmaN)*(KN_RN/KN); % RN

d31 = (sLH/sigmaH)*(LH_WH/LH); % WH
d32 = (sLH/sigmaH)*(LH_WN/LH); % WN
d33 = - ( (sLH/sigmaH)*(KH_RH/KH) + (1/RH) ); % RH
d34 = - (sLH/sigmaH)*(KH_RN/KH); % RN

d41 = (sLN/sigmaN)*(LN_WH/LN); % WH
d42 = (sLN/sigmaN)*(LN_WN/LN); % WN
d43 = - (sLN/sigmaN)*(KN_RH/KN); % RH
d44 = - ( (sLN/sigmaN)*(KN_RN/KN) + (1/RN) ); % RN

% PN,PH,K,uKH,uKN,AH,BH,AN,BN,lambda
e11 = ((1-sLH)/sigmaH)*(LH_1PN/LH); % PN
e12 = ((1-sLH)/sigmaH)*(LH_1PH/LH) - (1/PH); % PH
e13 = - ((1-sLH)/sigmaH)*(KH_1K/KH); % K
e14 = - ((1-sLH)/sigmaH); % uKH
e15 = 0; % uKN
e16 = - ( ((sigmaH-1)/sigmaH)+ (sLH/sigmaH) )*(1/AH);  % AH
e17 = - ((1-sLH)/sigmaH)*(1/BH);  % BH
e18 = 0;
e19 = 0;

e21 = ((1-sLN)/sigmaN)*(LN_1PN/LN) - (1/PN); % PN
e22 = ((1-sLN)/sigmaN)*(LN_1PH/LN);  % PH
e23 = - ((1-sLN)/sigmaN)*(KN_1K/KN); % K
e24 = 0; % uKH
e25 = - ((1-sLN)/sigmaN);  % uKN
e26 = 0;
e27 = 0;
e28 = - ( ((sigmaN-1)/sigmaN) + (sLN/sigmaN) )*(1/AN);  % AN
e29 = - ((1-sLN)/sigmaN)*(1/BN);    % BN

e31 = - (sLH/sigmaH)*(LH_1PN/LH); % PN
e32 = - ( (sLH/sigmaH)*(LH_1PH/LH) + (1/PH) ); % PH
e33 = (sLH/sigmaH)*(KH_1K/KH); % K
e34 = (sLH/sigmaH); % uKH
e35 = 0;  % uKN
e36 = - (sLH/sigmaH)*(1/AH); % AH
e37 = - ((sigmaH-sLH)/sigmaH)*(1/BH); % BH
e38 = 0;
e39 = 0;

e41 = - ( (sLN/sigmaN)*(LN_1PN/LN) + (1/PN) ); % PN
e42 = - (sLN/sigmaN)*(LN_1PH/LN); % PH
e43 = (sLN/sigmaN)*(KN_1K/KN); % K
e44 = 0;  % uKH
e45 = (sLN/sigmaN); % uKN
e46 = 0;
e47 = 0;
e48 = - (sLN/sigmaN)*(1/AN); % AN
e49 = - ((sigmaN-sLN)/sigmaN)*(1/BN); % BN

M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X2 = [e11 e12 e13 e14 e15 e16 e17 e18 e19; e21 e22 e23 e24 e25 e26 e27 e28 e29; e31 e32 e33 e34 e35 e36 e37 e38 e39; e41 e42 e43 e44 e45 e46 e47 e48 e49];
JST2 = inv(M2);
MST2 = JST2*X2;
WH_1PN = MST2(1,1); WH_1PH = MST2(1,2); WH_1K = MST2(1,3); WH_uKH = MST2(1,4); WH_uKN = MST2(1,5); WH_1AH = MST2(1,6); WH_1BH = MST2(1,7); WH_1AN = MST2(1,8); WH_1BN = MST2(1,9);
WN_1PN = MST2(2,1); WN_1PH = MST2(2,2); WN_1K = MST2(2,3); WN_uKH = MST2(2,4); WN_uKN = MST2(2,5); WN_1AH = MST2(2,6); WN_1BH = MST2(2,7); WN_1AN = MST2(2,8); WN_1BN = MST2(2,9);
RH_1PN = MST2(3,1); RH_1PH = MST2(3,2); RH_1K = MST2(3,3); RH_uKH = MST2(3,4); RH_uKN = MST2(3,5); RH_1AH = MST2(3,6); RH_1BH = MST2(3,7); RH_1AN = MST2(3,8); RH_1BN = MST2(3,9);
RN_1PN = MST2(4,1); RN_1PH = MST2(4,2); RN_1K = MST2(4,3); RN_uKH = MST2(4,4); RN_uKN = MST2(4,5); RN_1AH = MST2(4,6); RN_1BH = MST2(4,7); RN_1AN = MST2(4,8); RN_1BN = MST2(4,9);

% Solutions uKj(uKSj,uKDj)              
uKH_uKSH = eta;                         
uKH_uKDH = (1-eta);                     
uKN_uKSN = eta;                         
uKN_uKDN = (1-eta);                     
                                        
% Solutions Rj,Wj(PN,PH,K,uKSj,uKDj)    
RH_uKSH = RH_uKH*uKH_uKSH;              
RH_uKDH = RH_uKH*uKH_uKDH;              
RH_uKSN = RH_uKN*uKN_uKSN;              
RH_uKDN = RH_uKN*uKN_uKDN;              
                                        
WH_uKSH = WH_uKH*uKH_uKSH;              
WH_uKDH = WH_uKH*uKH_uKDH;              
WH_uKSN = WH_uKN*uKN_uKSN;              
WH_uKDN = WH_uKN*uKN_uKDN;              
                                        
RN_uKSH = RN_uKH*uKH_uKSH;              
RN_uKDH = RN_uKH*uKH_uKDH;              
RN_uKSN = RN_uKN*uKN_uKSN;              
RN_uKDN = RN_uKN*uKN_uKDN;              
                                        
WN_uKSH = WN_uKH*uKH_uKSH;              
WN_uKDH = WN_uKH*uKH_uKDH;              
WN_uKSN = WN_uKN*uKN_uKSN;              
WN_uKDN = WN_uKN*uKN_uKDN;   

% Solving for sectoral labor and sectoral output - Lj,Kj,Yj(PN,PH,K,uKj,Aj,Bj,lambda)
LH_2PN  = LH_1PN + (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_2PH  = LH_1PH + (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K   = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKSH = (LH_WH*WH_uKSH) + (LH_WN*WN_uKSH);
LH_uKDH = (LH_WH*WH_uKDH) + (LH_WN*WN_uKDH);
LH_uKSN = (LH_WH*WH_uKSN) + (LH_WN*WN_uKSN);
LH_uKDN = (LH_WH*WH_uKDN) + (LH_WN*WN_uKDN);
LH_1AH  = (LH_WH*WH_1AH) + (LH_WN*WN_1AH);
LH_1BH  = (LH_WH*WH_1BH) + (LH_WN*WN_1BH);
LH_1AN  = (LH_WH*WH_1AN) + (LH_WN*WN_1AN);
LH_1BN  = (LH_WH*WH_1BN) + (LH_WN*WN_1BN);

LN_2PN  = LN_1PN + (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_2PH  = LN_1PH + (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K   = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKSH = (LN_WH*WH_uKSH) + (LN_WN*WN_uKSH);
LN_uKDH = (LN_WH*WH_uKDH) + (LN_WN*WN_uKDH);
LN_uKSN = (LN_WH*WH_uKSN) + (LN_WN*WN_uKSN);
LN_uKDN = (LN_WH*WH_uKDN) + (LN_WN*WN_uKDN);
LN_1AH  = (LN_WH*WH_1AH) + (LN_WN*WN_1AH);
LN_1BH  = (LN_WH*WH_1BH) + (LN_WN*WN_1BH);
LN_1AN  = (LN_WH*WH_1AN) + (LN_WN*WN_1AN);
LN_1BN  = (LN_WH*WH_1BN) + (LN_WN*WN_1BN);

KH_1PN  = (KH_RH*RH_1PN) + (KH_RN*RN_1PN);
KH_1PH  = (KH_RH*RH_1PH) + (KH_RN*RN_1PH);
KH_2K   = KH_1K  +(KH_RH*RH_1K)  + (KH_RN*RN_1K);
KH_uKSH = (KH_RH*RH_uKSH) + (KH_RN*RN_uKSH);
KH_uKDH = (KH_RH*RH_uKDH) + (KH_RN*RN_uKDH);
KH_uKSN = (KH_RH*RH_uKSN) + (KH_RN*RN_uKSN);
KH_uKDN = (KH_RH*RH_uKDN) + (KH_RN*RN_uKDN);
KH_1AH  = (KH_RH*RH_1AH) + (KH_RN*RN_1AH);
KH_1BH  = (KH_RH*RH_1BH) + (KH_RN*RN_1BH);
KH_1AN  = (KH_RH*RH_1AN) + (KH_RN*RN_1AN);
KH_1BN  = (KH_RH*RH_1BN) + (KH_RN*RN_1BN);

KN_1PN  = (KN_RH*RH_1PN) + (KN_RN*RN_1PN);
KN_1PH  = (KN_RH*RH_1PH) + (KN_RN*RN_1PH);
KN_2K   = KN_1K + (KN_RH*RH_1K)  + (KN_RN*RN_1K);
KN_uKSH = (KN_RH*RH_uKSH) + (KN_RN*RN_uKSH);
KN_uKDH = (KN_RH*RH_uKDH) + (KN_RN*RN_uKDH);
KN_uKSN = (KN_RH*RH_uKSN) + (KN_RN*RN_uKSN);
KN_uKDN = (KN_RH*RH_uKDN) + (KN_RN*RN_uKDN);
KN_1AH  = (KN_RH*RH_1AH) + (KN_RN*RN_1AH);
KN_1BH  = (KN_RH*RH_1BH) + (KN_RN*RN_1BH);
KN_1AN  = (KN_RH*RH_1AN) + (KN_RN*RN_1AN);
KN_1BN  = (KN_RH*RH_1BN) + (KN_RN*RN_1BN);

YH_1PN  = sLH*YH*(LH_2PN/LH) + (1-sLH)*YH*(KH_1PN/KH);
YH_1PH  = sLH*YH*(LH_2PH/LH) + (1-sLH)*YH*(KH_1PH/KH);
YH_1K   = sLH*YH*(LH_1K/LH) + (1-sLH)*YH*(KH_2K/KH);
YH_uKSH = sLH*YH*(LH_uKSH/LH) + (1-sLH)*YH*( (KH_uKSH/KH) + eta );
YH_uKDH = sLH*YH*(LH_uKDH/LH) + (1-sLH)*YH*( (KH_uKDH/KH) + (1-eta) );
YH_uKSN = sLH*YH*(LH_uKSN/LH) + (1-sLH)*YH*(KH_uKSN/KH);
YH_uKDN = sLH*YH*(LH_uKDN/LH) + (1-sLH)*YH*(KH_uKDN/KH);
YH_1AH  = sLH*YH*( (LH_1AH/LH) + (1/AH) ) + (1-sLH)*YH*(KH_1AH/KH);
YH_1BH  = sLH*YH*(LH_1BH/LH) + (1-sLH)*YH*( (KH_1BH/KH) + (1/BH) );
YH_1AN  = sLH*YH*(LH_1AN/LH) + (1-sLH)*YH*(KH_1AN/KH);
YH_1BN  = sLH*YH*(LH_1BN/LH) + (1-sLH)*YH*(KH_1BN/KH);

YN_1PN  = sLN*YN*(LN_2PN/LN) + (1-sLN)*YN*(KN_1PN/KN);
YN_1PH  = sLN*YN*(LN_2PH/LN) + (1-sLN)*YN*(KN_1PH/KN);
YN_1K   = sLN*YN*(LN_1K/LN) + (1-sLN)*YN*(KN_2K/KN);
YN_uKSH = sLN*YN*(LN_uKSH/LN) + (1-sLN)*YN*(KN_uKSH/KN);
YN_uKDH = sLN*YN*(LN_uKDH/LN) + (1-sLN)*YN*(KN_uKDH/KN);
YN_uKSN = sLN*YN*(LN_uKSN/LN) + (1-sLN)*YN*( (KN_uKSN/KN) + eta);
YN_uKDN = sLN*YN*(LN_uKDN/LN) + (1-sLN)*YN*( (KN_uKDN/KN) + (1-eta) );
YN_1AH  = sLN*YN*(LN_1AH/LN) + (1-sLN)*YN*(KN_1AH/KN);
YN_1BH  = sLN*YN*(LN_1BH/LN) + (1-sLN)*YN*(KN_1BH/KN);
YN_1AN  = sLN*YN*( (LN_1AN/LN) + (1/AN) ) + (1-sLN)*YN*(KN_1AN/KN);
YN_1BN  = sLN*YN*(LN_1BN/LN) + (1-sLN)*YN*( (KN_1BN/KN) + (1/BN) );

% Intermediate solution for CN, CH, CF - Cj=Cj(PN,PH,K,uKSj,uKDj,Aj,Bj)
CN_2PN  = CN_1PN + (CN_WH*WH_1PN) + (CN_WN*WN_1PN);
CN_2PH  = CN_1PH + (CN_WH*WH_1PH) + (CN_WN*WN_1PH);
CN_1K   = (CN_WH*WH_1K) + (CN_WN*WN_1K);
CN_uKSH = (CN_WH*WH_uKSH) + (CN_WN*WN_uKSH);
CN_uKDH = (CN_WH*WH_uKDH) + (CN_WN*WN_uKDH);
CN_uKSN = (CN_WH*WH_uKSN) + (CN_WN*WN_uKSN);
CN_uKDN = (CN_WH*WH_uKDN) + (CN_WN*WN_uKDN);
CN_1AH  = (CN_WH*WH_1AH) + (CN_WN*WN_1AH);
CN_1BH  = (CN_WH*WH_1BH) + (CN_WN*WN_1BH);
CN_1AN  = (CN_WH*WH_1AN) + (CN_WN*WN_1AN);
CN_1BN  = (CN_WH*WH_1BN) + (CN_WN*WN_1BN);

CH_2PN  = CH_1PN + (CH_WH*WH_1PN) + (CH_WN*WN_1PN);
CH_2PH  = CH_1PH + (CH_WH*WH_1PH) + (CH_WN*WN_1PH);
CH_1K   = (CH_WH*WH_1K) + (CH_WN*WN_1K);
CH_uKSH = (CH_WH*WH_uKSH) + (CH_WN*WN_uKSH);
CH_uKDH = (CH_WH*WH_uKDH) + (CH_WN*WN_uKDH);
CH_uKSN = (CH_WH*WH_uKSN) + (CH_WN*WN_uKSN);
CH_uKDN = (CH_WH*WH_uKDN) + (CH_WN*WN_uKDN);
CH_1AH  = (CH_WH*WH_1AH) + (CH_WN*WN_1AH);
CH_1BH  = (CH_WH*WH_1BH) + (CH_WN*WN_1BH);
CH_1AN  = (CH_WH*WH_1AN) + (CH_WN*WN_1AN);
CH_1BN  = (CH_WH*WH_1BN) + (CH_WN*WN_1BN);

CF_2PN  = CF_1PN + (CF_WH*WH_1PN) + (CF_WN*WN_1PN);
CF_2PH  = CF_1PH + (CF_WH*WH_1PH) + (CF_WN*WN_1PH);
CF_1K   = (CF_WH*WH_1K) + (CF_WN*WN_1K);
CF_uKSH = (CF_WH*WH_uKSH) + (CF_WN*WN_uKSH);
CF_uKDH = (CF_WH*WH_uKDH) + (CF_WN*WN_uKDH);
CF_uKSN = (CF_WH*WH_uKSN) + (CF_WN*WN_uKSN);
CF_uKDN = (CF_WH*WH_uKDN) + (CF_WN*WN_uKDN);
CF_1AH  = (CF_WH*WH_1AH) + (CF_WN*WN_1AH);
CF_1BH  = (CF_WH*WH_1BH) + (CF_WN*WN_1BH);
CF_1AN  = (CF_WH*WH_1AN) + (CF_WN*WN_1AN);
CF_1BN  = (CF_WH*WH_1BN) + (CF_WN*WN_1BN);

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q) 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKSj,uKDj(PN,PH,K)
f11 = ((xi2SH/xi1SH) + (1-eta) + eta*(sLH/sigmaH)) - (sLH/sigmaH)*(LH_uKSH/LH) + (sLH/sigmaH)*(KH_uKSH/KH); % uKSH
f12 = -((sigmaH-sLH)/sigmaH)*(1-eta) - (sLH/sigmaH)*(LH_uKDH/LH) + (sLH/sigmaH)*(KH_uKDH/KH); % uKDH
f13 = - (sLH/sigmaH)*(LH_uKSN/LH) + (sLH/sigmaH)*(KH_uKSN/KH); % uKSN
f14 = - (sLH/sigmaH)*(LH_uKDN/LH) + (sLH/sigmaH)*(KH_uKDN/KH); % uKDN

f21 = -((sigmaH-sLH)/sigmaH)*eta - (sLH/sigmaH)*(LH_uKSH/LH) + (sLH/sigmaH)*(KH_uKSH/KH); % uKSH
%f22 = ((xi2DH/xi1DH) + eta + (1-eta)*(sLH/sigmaH)) + (sLH/sigmaH)*(KH_uKDH/KH); %uKDH
f22 = ((xi2DH/xi1DH) + eta + (1-eta)*(sLH/sigmaH)) - (sLH/sigmaH)*(LH_uKDH/LH) + (sLH/sigmaH)*(KH_uKDH/KH); %uKDH 
f23 = - (sLH/sigmaH)*(LH_uKSN/LH) + (sLH/sigmaH)*(KH_uKSN/KH); % uKSN
f24 = - (sLH/sigmaH)*(LH_uKDN/LH) + (sLH/sigmaH)*(KH_uKDN/KH); % uKDN

f31 =  - (sLN/sigmaN)*(LN_uKSH/LN) + (sLN/sigmaN)*(KN_uKSH/KN); %uKSH
f32 =  - (sLN/sigmaN)*(LN_uKDH/LN) + (sLN/sigmaN)*(KN_uKDH/KN); %uKDH
f33 = ((xi2SN/xi1SN) + (1-eta) + eta*(sLN/sigmaN))  - (sLN/sigmaN)*(LN_uKSN/LN) + (sLN/sigmaN)*(KN_uKSN/KN); %uKSN
f34 = -((sigmaN-sLN)/sigmaN)*(1-eta)  - (sLN/sigmaN)*(LN_uKDN/LN) + (sLN/sigmaN)*(KN_uKDN/KN); %uKDN

f41 = - (sLN/sigmaN)*(LN_uKSH/LN) + (sLN/sigmaN)*(KN_uKSH/KN); %uKSH
f42 = - (sLN/sigmaN)*(LN_uKDH/LN) + (sLN/sigmaN)*(KN_uKDH/KN); %uKDH
f43 = -((sigmaN-sLN)/sigmaN)*eta  - (sLN/sigmaN)*(LN_uKSN/LN) + (sLN/sigmaN)*(KN_uKSN/KN); %uKSN
f44 = ((xi2DN/xi1DN) + eta + (1-eta)*(sLN/sigmaN)) - (sLN/sigmaN)*(LN_uKDN/LN) + (sLN/sigmaN)*(KN_uKDN/KN); %uKDN

% PN, PH, K, AH, BH, AN, BN, lambda
g11 = (sLH/sigmaH)*(LH_2PN/LH) - (sLH/sigmaH)*(KH_1PN/KH); % PN
g12 = (sLH/sigmaH)*(LH_2PH/LH) - (sLH/sigmaH)*(KH_1PH/KH); % PH
g13 = (sLH/sigmaH)*(LH_1K/LH) - (sLH/sigmaH)*(KH_2K/KH); % K
g14 = (sLH/sigmaH)*( (LH_1AH/LH) + (1/AH) ) - (sLH/sigmaH)*(KH_1AH/KH); % AH
g15 = (sLH/sigmaH)*(LH_1BH/LH) - (sLH/sigmaH)*(KH_1BH/KH) + ((sigmaH-sLH)/sigmaH)*(1/BH); % BH
g16 = (sLH/sigmaH)*(LH_1AN/LH) - (sLH/sigmaH)*(KH_1AN/KH); % AN
g17 = (sLH/sigmaH)*(LH_1BN/LH) - (sLH/sigmaH)*(KH_1BN/KH); % BN

g21 = (sLH/sigmaH)*(LH_2PN/LH) - (sLH/sigmaH)*(KH_1PN/KH); % PN
g22 = (sLH/sigmaH)*(LH_2PH/LH) - (sLH/sigmaH)*(KH_1PH/KH); % PH
g23 = (sLH/sigmaH)*(LH_1K/LH) - (sLH/sigmaH)*(KH_2K/KH); % K
g24 = (sLH/sigmaH)*( (LH_1AH/LH) + (1/AH) ) - (sLH/sigmaH)*(KH_1AH/KH); % AH
g25 = (sLH/sigmaH)*(LH_1BH/LH) - (sLH/sigmaH)*(KH_1BH/KH) + ((sigmaH-sLH)/sigmaH)*(1/BH); % BH
g26 = (sLH/sigmaH)*(LH_1AN/LH) - (sLH/sigmaH)*(KH_1AN/KH); % AN
g27 = (sLH/sigmaH)*(LH_1BN/LH) - (sLH/sigmaH)*(KH_1BN/KH); % BN

g31 = (sLN/sigmaN)*(LN_2PN/LN) - (sLN/sigmaN)*(KN_1PN/KN); % PN
g32 = (sLN/sigmaN)*(LN_2PH/LN) - (sLN/sigmaN)*(KN_1PH/KN); % PH
g33 = (sLN/sigmaN)*(LN_1K/LN) - (sLN/sigmaN)*(KN_2K/KN); % K
g34 = (sLN/sigmaN)*(LN_1AH/LN) - (sLN/sigmaN)*(KN_1AH/KN); % AH
g35 = (sLN/sigmaN)*(LN_1BH/LN) - (sLN/sigmaN)*(KN_1BH/KN); % BH
g36 = (sLN/sigmaN)*( (LN_1AN/LN) + (1/AN) ) - (sLN/sigmaN)*(KN_1AN/KN); % AN
g37 = (sLN/sigmaN)*(LN_1BN/LN) - (sLN/sigmaN)*(KN_1BN/KN) + ((sigmaN-sLN)/sigmaN)*(1/BN); % BN

g41 = (sLN/sigmaN)*(LN_2PN/LN) - (sLN/sigmaN)*(KN_1PN/KN); % PN
g42 = (sLN/sigmaN)*(LN_2PH/LN) - (sLN/sigmaN)*(KN_1PH/KN); % PH
g43 = (sLN/sigmaN)*(LN_1K/LN) - (sLN/sigmaN)*(KN_2K/KN); % K
g44 = (sLN/sigmaN)*(LN_1AH/LN) - (sLN/sigmaN)*(KN_1AH/KN); % AH
g45 = (sLN/sigmaN)*(LN_1BH/LN) - (sLN/sigmaN)*(KN_1BH/KN); % BH
g46 = (sLN/sigmaN)*( (LN_1AN/LN) + (1/AN) ) - (sLN/sigmaN)*(KN_1AN/KN); % AN
g47 = (sLN/sigmaN)*(LN_1BN/LN) - (sLN/sigmaN)*(KN_1BN/KN) + ((sigmaN-sLN)/sigmaN)*(1/BN); % BN

M3 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X3 = [g11 g12 g13 g14 g15 g16 g17; g21 g22 g23 g24 g25 g26 g27; g31 g32 g33 g34 g35 g36 g37; g41 g42 g43 g44 g45 g46 g47];
JST3 = inv(M3);
MST3 = JST3*X3;

uKSH_PN = MST3(1,1); uKSH_PH = MST3(1,2); uKSH_1K = MST3(1,3); uKSH_1AH = MST3(1,4); uKSH_1BH = MST3(1,5); uKSH_1AN = MST3(1,6); uKSH_1BN = MST3(1,7);
uKDH_PN = MST3(2,1); uKDH_PH = MST3(2,2); uKDH_1K = MST3(2,3); uKDH_1AH = MST3(2,4); uKDH_1BH = MST3(2,5); uKDH_1AN = MST3(2,6); uKDH_1BN = MST3(2,7);
uKSN_PN = MST3(3,1); uKSN_PH = MST3(3,2); uKSN_1K = MST3(3,3); uKSN_1AH = MST3(3,4); uKSN_1BH = MST3(3,5); uKSN_1AN = MST3(3,6); uKSN_1BN = MST3(3,7);
uKDN_PN = MST3(4,1); uKDN_PH = MST3(4,2); uKDN_1K = MST3(4,3); uKDN_1AH = MST3(4,4); uKDN_1BH = MST3(4,5); uKDN_1AN = MST3(4,6); uKDN_1BN = MST3(4,7);

% Solving for Wj,Rj,Lj,Kj,Yj,Cg(lambda,K,PH,PN,AH,BH,AN,BN)
WH_2K = WH_1K + (WH_uKSH*uKSH_1K) + (WH_uKDH*uKDH_1K) + (WH_uKSN*uKSN_1K) + (WH_uKDN*uKDN_1K);
WH_PH = WH_1PH + (WH_uKSH*uKSH_PH) +  (WH_uKDH*uKDH_PH) + (WH_uKSN*uKSN_PH) + (WH_uKDN*uKDN_PH);
WH_PN = WH_1PN + (WH_uKSH*uKSH_PN) + (WH_uKDH*uKDH_PN) + (WH_uKSN*uKSN_PN) + (WH_uKDN*uKDN_PN);
WH_2AH = WH_1AH + (WH_uKSH*uKSH_1AH) + (WH_uKDH*uKDH_1AH) + (WH_uKSN*uKSN_1AH) + (WH_uKDN*uKDN_1AH);
WH_2BH = WH_1BH + (WH_uKSH*uKSH_1BH) + (WH_uKDH*uKDH_1BH) + (WH_uKSN*uKSN_1BH) + (WH_uKDN*uKDN_1BH);
WH_2AN = WH_1AN + (WH_uKSH*uKSH_1AN) + (WH_uKDH*uKDH_1AN) + (WH_uKSN*uKSN_1AN) + (WH_uKDN*uKDN_1AN);
WH_2BN = WH_1BN + (WH_uKSH*uKSH_1BN) + (WH_uKDH*uKDH_1BN) + (WH_uKSN*uKSN_1BN) + (WH_uKDN*uKDN_1BN);

WN_2K = WN_1K + (WN_uKSH*uKSH_1K) +  (WN_uKDH*uKDH_1K) + (WN_uKSN*uKSN_1K) + (WN_uKDN*uKDN_1K);
WN_PH = WN_1PH + (WN_uKSH*uKSH_PH) + (WN_uKDH*uKDH_PH) + (WN_uKSN*uKSN_PH) + (WN_uKDN*uKDN_PH);
WN_PN = WN_1PN + (WN_uKSH*uKSH_PN) + (WN_uKDH*uKDH_PN) + (WN_uKSN*uKSN_PN) + (WN_uKDN*uKDN_PN);
WN_2AH = WN_1AH + (WN_uKSH*uKSH_1AH) + (WN_uKDH*uKDH_1AH) + (WN_uKSN*uKSN_1AH) + (WN_uKDN*uKDN_1AH);
WN_2BH = WN_1BH + (WN_uKSH*uKSH_1BH) + (WN_uKDH*uKDH_1BH) + (WN_uKSN*uKSN_1BH) + (WN_uKDN*uKDN_1BH);
WN_2AN = WN_1AN + (WN_uKSH*uKSH_1AN) + (WN_uKDH*uKDH_1AN) + (WN_uKSN*uKSN_1AN) + (WN_uKDN*uKDN_1AN);
WN_2BN = WN_1BN + (WN_uKSH*uKSH_1BN) + (WN_uKDH*uKDH_1BN) + (WN_uKSN*uKSN_1BN) + (WN_uKDN*uKDN_1BN);

RH_2K = RH_1K + (RH_uKSH*uKSH_1K) + (RH_uKDH*uKDH_1K) + (RH_uKSN*uKSN_1K) + (RH_uKDN*uKDN_1K);
RH_PH = RH_1PH + (RH_uKSH*uKSH_PH) +  (RH_uKDH*uKDH_PH) + (RH_uKSN*uKSN_PH) + (RH_uKDN*uKDN_PH);
RH_PN = RH_1PN + (RH_uKSH*uKSH_PN) + (RH_uKDH*uKDH_PN) + (RH_uKSN*uKSN_PN) + (RH_uKDN*uKDN_PN);
RH_2AH = RH_1AH + (RH_uKSH*uKSH_1AH) + (RH_uKDH*uKDH_1AH) + (RH_uKSN*uKSN_1AH) + (RH_uKDN*uKDN_1AH);
RH_2BH = RH_1BH + (RH_uKSH*uKSH_1BH) + (RH_uKDH*uKDH_1BH) + (RH_uKSN*uKSN_1BH) + (RH_uKDN*uKDN_1BH);
RH_2AN = RH_1AN + (RH_uKSH*uKSH_1AN) + (RH_uKDH*uKDH_1AN) + (RH_uKSN*uKSN_1AN) + (RH_uKDN*uKDN_1AN);
RH_2BN = RH_1BN + (RH_uKSH*uKSH_1BN) + (RH_uKDH*uKDH_1BN) + (RH_uKSN*uKSN_1BN) + (RH_uKDN*uKDN_1BN);

RN_2K = RN_1K + (RN_uKSH*uKSH_1K) +  (RN_uKDH*uKDH_1K) + (RN_uKSN*uKSN_1K) + (RN_uKDN*uKDN_1K);
RN_PH = RN_1PH + (RN_uKSH*uKSH_PH) + (RN_uKDH*uKDH_PH) + (RN_uKSN*uKSN_PH) + (RN_uKDN*uKDN_PH);
RN_PN = RN_1PN + (RN_uKSH*uKSH_PN) + (RN_uKDH*uKDH_PN) + (RN_uKSN*uKSN_PN) + (RN_uKDN*uKDN_PN);
RN_2AH = RN_1AH + (RN_uKSH*uKSH_1AH) + (RN_uKDH*uKDH_1AH) + (RN_uKSN*uKSN_1AH) + (RN_uKDN*uKDN_1AH);
RN_2BH = RN_1BH + (RN_uKSH*uKSH_1BH) + (RN_uKDH*uKDH_1BH) + (RN_uKSN*uKSN_1BH) + (RN_uKDN*uKDN_1BH);
RN_2AN = RN_1AN + (RN_uKSH*uKSH_1AN) + (RN_uKDH*uKDH_1AN) + (RN_uKSN*uKSN_1AN) + (RN_uKDN*uKDN_1AN);
RN_2BN = RN_1BN + (RN_uKSH*uKSH_1BN) + (RN_uKDH*uKDH_1BN) + (RN_uKSN*uKSN_1BN) + (RN_uKDN*uKDN_1BN);

LH_2K = LH_1K + (LH_uKSH*uKSH_1K) + (LH_uKDH*uKDH_1K) + (LH_uKSN*uKSN_1K) + (LH_uKDN*uKDN_1K);
LH_PH = LH_2PH + (LH_uKSH*uKSH_PH) + (LH_uKDH*uKDH_PH) + (LH_uKSN*uKSN_PH) + (LH_uKDN*uKDN_PH);
LH_PN = LH_2PN + (LH_uKSH*uKSH_PN) + (LH_uKDH*uKDH_PN) + (LH_uKSN*uKSN_PN) + (LH_uKDN*uKDN_PN);
LH_2AH = LH_1AH + (LH_uKSH*uKSH_1AH) + (LH_uKDH*uKDH_1AH) + (LH_uKSN*uKSN_1AH) + (LH_uKDN*uKDN_1AH);
LH_2BH = LH_1BH + (LH_uKSH*uKSH_1BH) + (LH_uKDH*uKDH_1BH) + (LH_uKSN*uKSN_1BH) + (LH_uKDN*uKDN_1BH);
LH_2AN = LH_1AN + (LH_uKSH*uKSH_1AN) + (LH_uKDH*uKDH_1AN) + (LH_uKSN*uKSN_1AN) + (LH_uKDN*uKDN_1AN);
LH_2BN = LH_1BN + (LH_uKSH*uKSH_1BN) + (LH_uKDH*uKDH_1BN) + (LH_uKSN*uKSN_1BN) + (LH_uKDN*uKDN_1BN);

LN_2K = LN_1K + (LN_uKSH*uKSH_1K) + (LN_uKDH*uKDH_1K) + (LN_uKSN*uKSN_1K) + (LN_uKDN*uKDN_1K);
LN_PH = LN_2PH + (LN_uKSH*uKSH_PH) + (LN_uKDH*uKDH_PH) + (LN_uKSN*uKSN_PH) + (LN_uKDN*uKDN_PH);
LN_PN = LN_2PN + (LN_uKSH*uKSH_PN) + (LN_uKDH*uKDH_PN) + (LN_uKSN*uKSN_PN) + (LN_uKDN*uKDN_PN);
LN_2AH = LN_1AH + (LN_uKSH*uKSH_1AH) + (LN_uKDH*uKDH_1AH) + (LN_uKSN*uKSN_1AH) + (LN_uKDN*uKDN_1AH);
LN_2BH = LN_1BH + (LN_uKSH*uKSH_1BH) + (LN_uKDH*uKDH_1BH) + (LN_uKSN*uKSN_1BH) + (LN_uKDN*uKDN_1BH);
LN_2AN = LN_1AN + (LN_uKSH*uKSH_1AN) + (LN_uKDH*uKDH_1AN) + (LN_uKSN*uKSN_1AN) + (LN_uKDN*uKDN_1AN);
LN_2BN = LN_1BN + (LN_uKSH*uKSH_1BN) + (LN_uKDH*uKDH_1BN) + (LN_uKSN*uKSN_1BN) + (LN_uKDN*uKDN_1BN);

KH_3K = KH_2K + (KH_uKSH*uKSH_1K) + (KH_uKDH*uKDH_1K) + (KH_uKSN*uKSN_1K) + (KH_uKDN*uKDN_1K);
KH_PH = KH_1PH + (KH_uKSH*uKSH_PH) + (KH_uKDH*uKDH_PH) + (KH_uKSN*uKSN_PH) + (KH_uKDN*uKDN_PH);
KH_PN = KH_1PN + (KH_uKSH*uKSH_PN) + (KH_uKDH*uKDH_PN) + (KH_uKSN*uKSN_PN) + (KH_uKDN*uKDN_PN);
KH_2AH = KH_1AH + (KH_uKSH*uKSH_1AH) + (KH_uKDH*uKDH_1AH) + (KH_uKSN*uKSN_1AH) + (KH_uKDN*uKDN_1AH);
KH_2BH = KH_1BH + (KH_uKSH*uKSH_1BH) + (KH_uKDH*uKDH_1BH) + (KH_uKSN*uKSN_1BH) + (KH_uKDN*uKDN_1BH);
KH_2AN = KH_1AN + (KH_uKSH*uKSH_1AN) + (KH_uKDH*uKDH_1AN) + (KH_uKSN*uKSN_1AN) + (KH_uKDN*uKDN_1AN);
KH_2BN = KH_1BN + (KH_uKSH*uKSH_1BN) + (KH_uKDH*uKDH_1BN) + (KH_uKSN*uKSN_1BN) + (KH_uKDN*uKDN_1BN);

KN_3K = KN_2K + (KN_uKSH*uKSH_1K) + (KN_uKDH*uKDH_1K) + (KN_uKSN*uKSN_1K) + (KN_uKDN*uKDN_1K);
KN_PH = KN_1PH + (KN_uKSH*uKSH_PH) + (KN_uKDH*uKDH_PH) + (KN_uKSN*uKSN_PH) + (KN_uKDN*uKDN_PH);
KN_PN = KN_1PN + (KN_uKSH*uKSH_PN) + (KN_uKDH*uKDH_PN) + (KN_uKSN*uKSN_PN) + (KN_uKDN*uKDN_PN);
KN_2AH = KN_1AH + (KN_uKSH*uKSH_1AH) + (KN_uKDH*uKDH_1AH) + (KN_uKSN*uKSN_1AH) + (KN_uKDN*uKDN_1AH);
KN_2BH = KN_1BH + (KN_uKSH*uKSH_1BH) + (KN_uKDH*uKDH_1BH) + (KN_uKSN*uKSN_1BH) + (KN_uKDN*uKDN_1BH);
KN_2AN = KN_1AN + (KN_uKSH*uKSH_1AN) + (KN_uKDH*uKDH_1AN) + (KN_uKSN*uKSN_1AN) + (KN_uKDN*uKDN_1AN);
KN_2BN = KN_1BN + (KN_uKSH*uKSH_1BN) + (KN_uKDH*uKDH_1BN) + (KN_uKSN*uKSN_1BN) + (KN_uKDN*uKDN_1BN);

YH_2K  = YH_1K + (YH_uKSH*uKSH_1K) + (YH_uKDH*uKDH_1K) + (YH_uKSN*uKSN_1K) + (YH_uKDN*uKDN_1K);
YH_PH  = YH_1PH + (YH_uKSH*uKSH_PH) + (YH_uKDH*uKDH_PH) + (YH_uKSN*uKSN_PH) + (YH_uKDN*uKDN_PH);
YH_PN  = YH_1PN + (YH_uKSH*uKSH_PN) + (YH_uKDH*uKDH_PN) + (YH_uKSN*uKSN_PN) + (YH_uKDN*uKDN_PN);
YH_2AH = YH_1AH + (YH_uKSH*uKSH_1AH) + (YH_uKDH*uKDH_1AH) + (YH_uKSN*uKSN_1AH) + (YH_uKDN*uKDN_1AH);
YH_2BH = YH_1BH + (YH_uKSH*uKSH_1BH) + (YH_uKDH*uKDH_1BH) + (YH_uKSN*uKSN_1BH) + (YH_uKDN*uKDN_1BH);
YH_2AN = YH_1AN + (YH_uKSH*uKSH_1AN) + (YH_uKDH*uKDH_1AN) + (YH_uKSN*uKSN_1AN) + (YH_uKDN*uKDN_1AN);
YH_2BN = YH_1BN + (YH_uKSH*uKSH_1BN) + (YH_uKDH*uKDH_1BN) + (YH_uKSN*uKSN_1BN) + (YH_uKDN*uKDN_1BN);

YN_2K  = YN_1K + (YN_uKSH*uKSH_1K) + (YN_uKDH*uKDH_1K) + (YN_uKSN*uKSN_1K) + (YN_uKDN*uKDN_1K);
YN_PH  = YN_1PH + (YN_uKSH*uKSH_PH) + (YN_uKDH*uKDH_PH) + (YN_uKSN*uKSN_PH) + (YN_uKDN*uKDN_PH);
YN_PN  = YN_1PN + (YN_uKSH*uKSH_PN) + (YN_uKDH*uKDH_PN) + (YN_uKSN*uKSN_PN) + (YN_uKDN*uKDN_PN);
YN_2AH = YN_1AH + (YN_uKSH*uKSH_1AH) + (YN_uKDH*uKDH_1AH) + (YN_uKSN*uKSN_1AH) + (YN_uKDN*uKDN_1AH);
YN_2BH = YN_1BH + (YN_uKSH*uKSH_1BH) + (YN_uKDH*uKDH_1BH) + (YN_uKSN*uKSN_1BH) + (YN_uKDN*uKDN_1BH);
YN_2AN = YN_1AN + (YN_uKSH*uKSH_1AN) + (YN_uKDH*uKDH_1AN) + (YN_uKSN*uKSN_1AN) + (YN_uKDN*uKDN_1AN);
YN_2BN = YN_1BN + (YN_uKSH*uKSH_1BN) + (YN_uKDH*uKDH_1BN) + (YN_uKSN*uKSN_1BN) + (YN_uKDN*uKDN_1BN);

CH_2K = CH_1K + (CH_uKSH*uKSH_1K) + (CH_uKDH*uKDH_1K) + (CH_uKSN*uKSN_1K) + (CH_uKDN*uKDN_1K);
CH_PH = CH_2PH + (CH_uKSH*uKSH_PH) + (CH_uKDH*uKDH_PH) + (CH_uKSN*uKSN_PH) + (CH_uKDN*uKDN_PH);
CH_PN = CH_2PN + (CH_uKSH*uKSH_PN) + (CH_uKDH*uKDH_PN) + (CH_uKSN*uKSN_PN) + (CH_uKDN*uKDN_PN);
CH_2AH = CH_1AH + (CH_uKSH*uKSH_1AH) + (CH_uKDH*uKDH_1AH) + (CH_uKSN*uKSN_1AH) + (CH_uKDN*uKDN_1AH);
CH_2BH = CH_1BH + (CH_uKSH*uKSH_1BH) + (CH_uKDH*uKDH_1BH) + (CH_uKSN*uKSN_1BH) + (CH_uKDN*uKDN_1BH);
CH_2AN = CH_1AN + (CH_uKSH*uKSH_1AN) + (CH_uKDH*uKDH_1AN) + (CH_uKSN*uKSN_1AN) + (CH_uKDN*uKDN_1AN);
CH_2BN = CH_1BN + (CH_uKSH*uKSH_1BN) + (CH_uKDH*uKDH_1BN) + (CH_uKSN*uKSN_1BN) + (CH_uKDN*uKDN_1BN);

CN_2K = CN_1K + (CN_uKSH*uKSH_1K) + (CN_uKDH*uKDH_1K) + (CN_uKSN*uKSN_1K) + (CN_uKDN*uKDN_1K);
CN_PH = CN_2PH + (CN_uKSH*uKSH_PH) + (CN_uKDH*uKDH_PH) + (CN_uKSN*uKSN_PH) + (CN_uKDN*uKDN_PH);
CN_PN = CN_2PN + (CN_uKSH*uKSH_PN) + (CN_uKDH*uKDH_PN) + (CN_uKSN*uKSN_PN) + (CN_uKDN*uKDN_PN);
CN_2AH = CN_1AH + (CN_uKSH*uKSH_1AH) + (CN_uKDH*uKDH_1AH) + (CN_uKSN*uKSN_1AH) + (CN_uKDN*uKDN_1AH);
CN_2BH = CN_1BH + (CN_uKSH*uKSH_1BH) + (CN_uKDH*uKDH_1BH) + (CN_uKSN*uKSN_1BH) + (CN_uKDN*uKDN_1BH);
CN_2AN = CN_1AN + (CN_uKSH*uKSH_1AN) + (CN_uKDH*uKDH_1AN) + (CN_uKSN*uKSN_1AN) + (CN_uKDN*uKDN_1AN);
CN_2BN = CN_1BN + (CN_uKSH*uKSH_1BN) + (CN_uKDH*uKDH_1BN) + (CN_uKSN*uKSN_1BN) + (CN_uKDN*uKDN_1BN);

CF_2K = CF_1K + (CF_uKSH*uKSH_1K) + (CF_uKDH*uKDH_1K) + (CF_uKSN*uKSN_1K) + (CF_uKDN*uKDN_1K);
CF_PH = CF_2PH + (CF_uKSH*uKSH_PH) + (CF_uKDH*uKDH_PH) + (CF_uKSN*uKSN_PH) + (CF_uKDN*uKDN_PH);
CF_PN = CF_2PN + (CF_uKSH*uKSH_PN) + (CF_uKDH*uKDH_PN) + (CF_uKSN*uKSN_PN) + (CF_uKDN*uKDN_PN);
CF_2AH = CF_1AH + (CF_uKSH*uKSH_1AH) + (CF_uKDH*uKDH_1AH) + (CF_uKSN*uKSN_1AH) + (CF_uKDN*uKDN_1AH);
CF_2BH = CF_1BH + (CF_uKSH*uKSH_1BH) + (CF_uKDH*uKDH_1BH) + (CF_uKSN*uKSN_1BH) + (CF_uKDN*uKDN_1BH);
CF_2AN = CF_1AN + (CF_uKSH*uKSH_1AN) + (CF_uKDH*uKDH_1AN) + (CF_uKSN*uKSN_1AN) + (CF_uKDN*uKDN_1AN);
CF_2BN = CF_1BN + (CF_uKSH*uKSH_1BN) + (CF_uKDH*uKDH_1BN) + (CF_uKSN*uKSN_1BN) + (CF_uKDN*uKDN_1BN);

% Partial Derivatives Gj=Gj(G) 
GN_G   = omegaGN/PN; 
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,lambda)
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1SN*uKSN_PH) - (KN*xi1DN*uKDN_PH); % PH
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1SN*uKSN_PN) - (KN*xi1DN*uKDN_PN); % PN
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1SH*uKSH_PH) - (KH*xi1DH*uKDH_PH); % PH
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1SH*uKSH_PN) - (KH*xi1DH*uKDH_PN); % PN

% K,Q,G,AH,BH,AN,BN,lambda
k11 = -(YN_2K - CN_2K - JN_1K - (KN*xi1SN*uKSN_1K) - (KN*xi1DN*uKDN_1K));
k12 = JN_1Q;
k13 = GN_G;
k14 = -(YN_2AH - CN_2AH - (KN*xi1SN*uKSN_1AH) - (KN*xi1DN*uKDN_1AH));
k15 = -(YN_2BH - CN_2BH - (KN*xi1SN*uKSN_1BH) - (KN*xi1DN*uKDN_1BH));
k16 = -(YN_2AN - CN_2AN - (KN*xi1SN*uKSN_1AN) - (KN*xi1DN*uKDN_1AN));
k17 = -(YN_2BN - CN_2BN - (KN*xi1SN*uKSN_1BN) - (KN*xi1DN*uKDN_1BN));

k21 = -(YH_2K - CH_2K - JH_1K - (KH*xi1SH*uKSH_1K) - (KH*xi1DH*uKDH_1K));
k22 = JH_1Q;
k23 = GH_G;
k24 = -(YH_2AH - CH_2AH - (KH*xi1SH*uKSH_1AH) - (KH*xi1DH*uKDH_1AH));
k25 = -(YH_2BH - CH_2BH - (KH*xi1SH*uKSH_1BH) - (KH*xi1DH*uKDH_1BH));
k26 = -(YH_2AN - CH_2AN - (KH*xi1SH*uKSH_1AN) - (KH*xi1DH*uKDH_1AN));
k27 = -(YH_2BN - CH_2BN - (KH*xi1SH*uKSH_1BN) - (KH*xi1DH*uKDH_1BN));

M4 = [h11 h12; h21 h22];
X4 = [k11 k12 k13 k14 k15 k16 k17; k21 k22 k23 k24 k25 k26 k27];
JST4 = inv(M4);
MST4 = JST4*X4;

PH_K = MST4(1,1); PH_Q = MST4(1,2); PH_G = MST4(1,3); PH_AH = MST4(1,4); PH_BH = MST4(1,5); PH_AN = MST4(1,6); PH_BN = MST4(1,7);
PN_K = MST4(2,1); PN_Q = MST4(2,2); PN_G = MST4(2,3); PN_AH = MST4(2,4); PN_BH = MST4(2,5); PN_AN = MST4(2,6); PN_BN = MST4(2,7);

% Solving for Lj,Kj,Yj,uKj(K,Q,G,Aj,Bj) - Final Solutions
LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K);
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q);
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);
LH_AH = LH_2AH + (LH_PH*PH_AH) + (LH_PN*PN_AH);
LH_BH = LH_2BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_2AN + (LH_PH*PH_AN) + (LH_PN*PN_AN);
LH_BN = LH_2BN + (LH_PH*PH_BN) + (LH_PN*PN_BN);

LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G);
LN_AH = LN_2AH + (LN_PH*PH_AH) + (LN_PN*PN_AH);
LN_BH = LN_2BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_2AN + (LN_PH*PH_AN) + (LN_PN*PN_AN);
LN_BN = LN_2BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);

YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K);
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q);
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);
YH_AH = YH_2AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_2BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_2AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_2BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);

YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);
YN_AH = YN_2AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_2BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_2AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_2BN + (YN_PH*PH_BN) + (YN_PN*PN_BN);

KH_K  = KH_3K + (KH_PH*PH_K) + (KH_PN*PN_K);
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);
KH_AH = KH_2AH + (KH_PH*PH_AH) + (KH_PN*PN_AH);
KH_BH = KH_2BH + (KH_PH*PH_BH) + (KH_PN*PN_BH);
KH_AN = KH_2AN + (KH_PH*PH_AN) + (KH_PN*PN_AN);
KH_BN = KH_2BN + (KH_PH*PH_BN) + (KH_PN*PN_BN);

KN_K = KN_3K + (KN_PH*PH_K) + (KN_PN*PN_K);
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);
KN_AH = KN_2AH + (KN_PH*PH_AH) + (KN_PN*PN_AH);
KN_BH = KN_2BH + (KN_PH*PH_BH) + (KN_PN*PN_BH);
KN_AN = KN_2AN + (KN_PH*PH_AN) + (KN_PN*PN_AN);
KN_BN = KN_2BN + (KN_PH*PH_BN) + (KN_PN*PN_BN);

uKSH_K  = uKSH_1K + (uKSH_PH*PH_K) + (uKSH_PN*PN_K);      
uKSH_Q  = (uKSH_PH*PH_Q) + (uKSH_PN*PN_Q);                
uKSH_G  = (uKSH_PH*PH_G) + (uKSH_PN*PN_G);                
uKSH_AH = uKSH_1AH + (uKSH_PH*PH_AH) + (uKSH_PN*PN_AH);   
uKSH_BH = uKSH_1BH + (uKSH_PH*PH_BH) + (uKSH_PN*PN_BH);   
uKSH_AN = uKSH_1AN + (uKSH_PH*PH_AN) + (uKSH_PN*PN_AN);   
uKSH_BN = uKSH_1BN + (uKSH_PH*PH_BN) + (uKSH_PN*PN_BN);   
                                                          
uKDH_K  = uKDH_1K + (uKDH_PH*PH_K) + (uKDH_PN*PN_K);      
uKDH_Q  = (uKDH_PH*PH_Q) + (uKDH_PN*PN_Q);                
uKDH_G  = (uKDH_PH*PH_G) + (uKDH_PN*PN_G);                
uKDH_AH = uKDH_1AH + (uKDH_PH*PH_AH) + (uKDH_PN*PN_AH);   
uKDH_BH = uKDH_1BH + (uKDH_PH*PH_BH) + (uKDH_PN*PN_BH);   
uKDH_AN = uKDH_1AN + (uKDH_PH*PH_AN) + (uKDH_PN*PN_AN);   
uKDH_BN = uKDH_1BN + (uKDH_PH*PH_BN) + (uKDH_PN*PN_BN);   
                                                          
uKSN_K = uKSN_1K + (uKSN_PH*PH_K) + (uKSN_PN*PN_K);       
uKSN_Q = (uKSN_PH*PH_Q) + (uKSN_PN*PN_Q);                 
uKSN_G = (uKSN_PH*PH_G) + (uKSN_PN*PN_G);                 
uKSN_AH = uKSN_1AH + (uKSN_PH*PH_AH) + (uKSN_PN*PN_AH);   
uKSN_BH = uKSN_1BH + (uKSN_PH*PH_BH) + (uKSN_PN*PN_BH);   
uKSN_AN = uKSN_1AN + (uKSN_PH*PH_AN) + (uKSN_PN*PN_AN);   
uKSN_BN = uKSN_1BN + (uKSN_PH*PH_BN) + (uKSN_PN*PN_BN);   
                                                          
uKDN_K = uKDN_1K + (uKDN_PH*PH_K) + (uKDN_PN*PN_K);       
uKDN_Q = (uKDN_PH*PH_Q) + (uKDN_PN*PN_Q);                 
uKDN_G = (uKDN_PH*PH_G) + (uKDN_PN*PN_G);                 
uKDN_AH = uKDN_1AH + (uKDN_PH*PH_AH) + (uKDN_PN*PN_AH);   
uKDN_BH = uKDN_1BH + (uKDN_PH*PH_BH) + (uKDN_PN*PN_BH);   
uKDN_AN = uKDN_1AN + (uKDN_PH*PH_AN) + (uKDN_PN*PN_AN);   
uKDN_BN = uKDN_1BN + (uKDN_PH*PH_BN) + (uKDN_PN*PN_BN);                   
                          
% Solving for consumption Cj=Cj(lambda,K,Q,GH,GN), investment inputs 
% Jj=Jj(K,Q,GH,GN), imports MF=MF(lambda,K,Q,GH,GN), exports 
%XH=XH(lambda,K,Q,GH,GN)- Final Solutions
CN_K  = CN_2K + (CN_PH*PH_K) + (CN_PN*PN_K);        
CN_Q  = (CN_PH*PH_Q) + (CN_PN*PN_Q);                
CN_G  = (CN_PH*PH_G) + (CN_PN*PN_G);                
CN_AH = CN_2AH + (CN_PH*PH_AH) + (CN_PN*PN_AH);     
CN_BH = CN_2BH + (CN_PH*PH_BH) + (CN_PN*PN_BH);     
CN_AN = CN_2AN + (CN_PH*PH_AN) + (CN_PN*PN_AN);     
CN_BN = CN_2BN + (CN_PH*PH_BN) + (CN_PN*PN_BN);     
                                                    
CH_K  = CH_2K + (CH_PH*PH_K) + (CH_PN*PN_K);        
CH_Q  = (CH_PH*PH_Q) + (CH_PN*PN_Q);                
CH_G  = (CH_PH*PH_G) + (CH_PN*PN_G);                
CH_AH = CH_2AH + (CH_PH*PH_AH) + (CH_PN*PN_AH);     
CH_BH = CH_2BH + (CH_PH*PH_BH) + (CH_PN*PN_BH);     
CH_AN = CH_2AN + (CH_PH*PH_AN) + (CH_PN*PN_AN);     
CH_BN = CH_2BN + (CH_PH*PH_BN) + (CH_PN*PN_BN);     
                                                    
CF_K  = CF_2K + (CF_PH*PH_K) + (CF_PN*PN_K);        
CF_Q  = (CF_PH*PH_Q) + (CF_PN*PN_Q);                
CF_G  = (CF_PH*PH_G) + (CF_PN*PN_G);                
CF_AH = CF_2AH + (CF_PH*PH_AH) + (CF_PN*PN_AH);     
CF_BH = CF_2BH + (CF_PH*PH_BH) + (CF_PN*PN_BH);     
CF_AN = CF_2AN + (CF_PH*PH_AN) + (CF_PN*PN_AN);     
CF_BN = CF_2BN + (CF_PH*PH_BN) + (CF_PN*PN_BN);     

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_BH      = (JN_PH*PH_BH) + (JN_PN*PN_BH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN); 

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);

% Solving for sectoral return on capital - Rj(K,Q,G,Aj,Bj)                  
RH_K = RH_2K + (RH_PH*PH_K) + (RH_PN*PN_K);                                 
RH_Q = (RH_PH*PH_Q) + (RH_PN*PN_Q);                                         
RH_G = (RH_PH*PH_G) + (RH_PN*PN_G);                                         
RH_AH = RH_2AH + (RH_PH*PH_AH) + (RH_PN*PN_AH);                             
RH_BH = RH_2BH + (RH_PH*PH_BH) + (RH_PN*PN_BH);                             
RH_AN = RH_2AN + (RH_PH*PH_AN) + (RH_PN*PN_AN);                             
RH_BN = RH_2BN + (RH_PH*PH_BN) + (RH_PN*PN_BN);                             
                                                                            
RN_K = RN_2K + (RN_PH*PH_K) + (RN_PN*PN_K);                                 
RN_Q = (RN_PH*PH_Q) + (RN_PN*PN_Q);                                         
RN_G = (RN_PH*PH_G) + (RN_PN*PN_G);                                         
RN_AH = RN_2AH + (RN_PH*PH_AH) + (RN_PN*PN_AH);                             
RN_BH = RN_2BH + (RN_PH*PH_BH) + (RN_PN*PN_BH);                             
RN_AN = RN_2AN + (RN_PH*PH_AN) + (RN_PN*PN_AN);                             
RN_BN = RN_2BN + (RN_PH*PH_BN) + (RN_PN*PN_BN);                             
                  
% Solving for investment function I/K = v(Q/PI)+delta_K -     
% v=v(lambda,K,Q,G) final solution                  
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q);                      
v_K  = (v_PN*PN_K) + (v_PH*PH_K);                             
v_G  = (v_PN*PN_G) + (v_PH*PH_G);   
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);

% Solutions Aj,Bj(AjS,AjD,BjS,BjD)           
AH_ASH = eta*(AH_0/ASH_0);                   
AH_ADH = (1-eta)*(AH_0/ADH_0);               
BH_BSH = eta*(BH_0/BSH_0);                   
BH_BDH = (1-eta)*(BH_0/BDH_0);                
AN_ASN = eta*(AN_0/ASN_0);                   
AN_ADN = (1-eta)*(AN_0/ADN_0);               
BN_BSN = eta*(BN_0/BSN_0);                   
BN_BDN = (1-eta)*(BN_0/BDN_0);  

% Solutions PH,PN(K,Q,ASj,ADj,BSj,BDj)              
PH_ASH = PH_AH*AH_ASH;                              
PH_ADH = PH_AH*AH_ADH;                              
PH_BSH = PH_BH*BH_BSH;                              
PH_BDH = PH_BH*BH_BDH;                              
                                                    
PH_ASN = PH_AN*AN_ASN;                              
PH_ADN = PH_AN*AN_ADN;                              
PH_BSN = PH_BN*BN_BSN;                              
PH_BDN = PH_BN*BN_BDN;                              
                                                    
PN_ASH = PN_AH*AH_ASH;                              
PN_ADH = PN_AH*AH_ADH;                              
PN_BSH = PN_BH*BH_BSH;                              
PN_BDH = PN_BH*BH_BDH;                              
                                                    
PN_ASN = PN_AN*AN_ASN;                              
PN_ADN = PN_AN*AN_ADN;                              
PN_BSN = PN_BN*BN_BSN;                              
PN_BDN = PN_BN*BN_BDN;      

% Solutions RH,RN(K,Q,ASj,ADj,BSj,BDj) 
RH_ASH = RH_AH*AH_ASH;  
RH_ADH = RH_AH*AH_ADH;  
RH_BSH = RH_BH*BH_BSH;  
RH_BDH = RH_BH*BH_BDH;  
                        
RH_ASN = RH_AN*AN_ASN;  
RH_ADN = RH_AN*AN_ADN;  
RH_BSN = RH_BN*BN_BSN;  
RH_BDN = RH_BN*BN_BDN;  
                        
RN_ASH = RN_AH*AH_ASH;  
RN_ADH = RN_AH*AH_ADH;  
RN_BSH = RN_BH*BH_BSH;  
RN_BDH = RN_BH*BH_BDH;  
                        
RN_ASN = RN_AN*AN_ASN;  
RN_ADN = RN_AN*AN_ADN;  
RN_BSN = RN_BN*BN_BSN;  
RN_BDN = RN_BN*BN_BDN; 

% Solving for capital-labor ratios kj=kj(K,Q,ASj,ADj,BSj,BDj) -
% sectoral labor Lj=Lj(K,Q,ASj,ADj,BSj,BDj) - sectoral output
% Yj=Yj(K,Q,ASj,ADj,BSj,BDj) - Final Solutions
KH_ASH = KH_AH*AH_ASH;
KH_ADH = KH_AH*AH_ADH;
KH_BSH = KH_BH*BH_BSH;
KH_BDH = KH_BH*BH_BDH;

KH_ASN = KH_AN*AN_ASN;
KH_ADN = KH_AN*AN_ADN;
KH_BSN = KH_BN*BN_BSN;
KH_BDN = KH_BN*BN_BDN;

KN_ASH = KN_AH*AH_ASH;
KN_ADH = KN_AH*AH_ADH;
KN_BSH = KN_BH*BH_BSH;
KN_BDH = KN_BH*BH_BDH;

KN_ASN = KN_AN*AN_ASN;
KN_ADN = KN_AN*AN_ADN;
KN_BSN = KN_BN*BN_BSN;
KN_BDN = KN_BN*BN_BDN;

LH_ASH = LH_AH*AH_ASH;
LH_ADH = LH_AH*AH_ADH;
LH_BSH = LH_BH*BH_BSH;
LH_BDH = LH_BH*BH_BDH;

LH_ASN = LH_AN*AN_ASN;
LH_ADN = LH_AN*AN_ADN;
LH_BSN = LH_BN*BN_BSN;
LH_BDN = LH_BN*BN_BDN;

LN_ASH = LN_AH*AH_ASH;
LN_ADH = LN_AH*AH_ADH;
LN_BSH = LN_BH*BH_BSH;
LN_BDH = LN_BH*BH_BDH;

LN_ASN = LN_AN*AN_ASN;
LN_ADN = LN_AN*AN_ADN;
LN_BSN = LN_BN*BN_BSN;
LN_BDN = LN_BN*BN_BDN;

YH_ASH = YH_AH*AH_ASH;
YH_ADH = YH_AH*AH_ADH;
YH_BSH = YH_BH*BH_BSH;
YH_BDH = YH_BH*BH_BDH;

YH_ASN = YH_AN*AN_ASN;
YH_ADN = YH_AN*AN_ADN;
YH_BSN = YH_BN*BN_BSN;
YH_BDN = YH_BN*BN_BDN;

YN_ASH = YN_AH*AH_ASH;
YN_ADH = YN_AH*AH_ADH;
YN_BSH = YN_BH*BH_BSH;
YN_BDH = YN_BH*BH_BDH;

YN_ASN = YN_AN*AN_ASN;
YN_ADN = YN_AN*AN_ADN;
YN_BSN = YN_BN*BN_BSN;
YN_BDN = YN_BN*BN_BDN;

uKSH_ASH = uKSH_AH*AH_ASH;
uKSH_ADH = uKSH_AH*AH_ADH;
uKSH_BSH = uKSH_BH*BH_BSH;
uKSH_BDH = uKSH_BH*BH_BDH;

uKSH_ASN = uKSH_AN*AN_ASN;
uKSH_ADN = uKSH_AN*AN_ADN;
uKSH_BSN = uKSH_BN*BN_BSN;
uKSH_BDN = uKSH_BN*BN_BDN;

uKDH_ASH = uKDH_AH*AH_ASH;
uKDH_ADH = uKDH_AH*AH_ADH;
uKDH_BSH = uKDH_BH*BH_BSH;
uKDH_BDH = uKDH_BH*BH_BDH;

uKDH_ASN = uKDH_AN*AN_ASN;
uKDH_ADN = uKDH_AN*AN_ADN;
uKDH_BSN = uKDH_BN*BN_BSN;
uKDH_BDN = uKDH_BN*BN_BDN;

uKSN_ASH = uKSN_AH*AH_ASH;
uKSN_ADH = uKSN_AH*AH_ADH;
uKSN_BSH = uKSN_BH*BH_BSH;
uKSN_BDH = uKSN_BH*BH_BDH;

uKSN_ASN = uKSN_AN*AN_ASN;
uKSN_ADN = uKSN_AN*AN_ADN;
uKSN_BSN = uKSN_BN*BN_BSN;
uKSN_BDN = uKSN_BN*BN_BDN;

uKDN_ASH = uKDN_AH*AH_ASH;
uKDN_ADH = uKDN_AH*AH_ADH;
uKDN_BSH = uKDN_BH*BH_BSH;
uKDN_BDH = uKDN_BH*BH_BDH;

uKDN_ASN = uKDN_AN*AN_ASN;
uKDN_ADN = uKDN_AN*AN_ADN;
uKDN_BSN = uKDN_BN*BN_BSN;
uKDN_BDN = uKDN_BN*BN_BDN;

% Solving for consumption Cj=Cj(K,Q,ASj,ADj,BSj,BDj), investment inputs
% Jj=Jj(K,Q,AH,BH,AN,BN), imports MF=MF(K,Q,ASj,ADj,BSj,BDj), exports
%XH=XH(K,Q,ASj,ADj,BSj,BDj)- Final Solutions
CH_ASH = CH_AH*AH_ASH;
CH_ADH = CH_AH*AH_ADH;
CH_BSH = CH_BH*BH_BSH;
CH_BDH = CH_BH*BH_BDH;

CH_ASN = CH_AN*AN_ASN;
CH_ADN = CH_AN*AN_ADN;
CH_BSN = CH_BN*BN_BSN;
CH_BDN = CH_BN*BN_BDN;

CN_ASH = CN_AH*AH_ASH;
CN_ADH = CN_AH*AH_ADH;
CN_BSH = CN_BH*BH_BSH;
CN_BDH = CN_BH*BH_BDH;

CN_ASN = CN_AN*AN_ASN;
CN_ADN = CN_AN*AN_ADN;
CN_BSN = CN_BN*BN_BSN;
CN_BDN = CN_BN*BN_BDN;

CF_ASH = CF_AH*AH_ASH;
CF_ADH = CF_AH*AH_ADH;
CF_BSH = CF_BH*BH_BSH;
CF_BDH = CF_BH*BH_BDH;

CF_ASN = CF_AN*AN_ASN;
CF_ADN = CF_AN*AN_ADN;
CF_BSN = CF_BN*BN_BSN;
CF_BDN = CF_BN*BN_BDN;

JH_ASH = JH_AH*AH_ASH;
JH_ADH = JH_AH*AH_ADH;
JH_BSH = JH_BH*BH_BSH;
JH_BDH = JH_BH*BH_BDH;

JH_ASN = JH_AN*AN_ASN;
JH_ADN = JH_AN*AN_ADN;
JH_BSN = JH_BN*BN_BSN;
JH_BDN = JH_BN*BN_BDN;

JN_ASH = JN_AH*AH_ASH;
JN_ADH = JN_AH*AH_ADH;
JN_BSH = JN_BH*BH_BSH;
JN_BDH = JN_BH*BH_BDH;

JN_ASN = JN_AN*AN_ASN;
JN_ADN = JN_AN*AN_ADN;
JN_BSN = JN_BN*BN_BSN;
JN_BDN = JN_BN*BN_BDN;

JF_ASH = JF_AH*AH_ASH;
JF_ADH = JF_AH*AH_ADH;
JF_BSH = JF_BH*BH_BSH;
JF_BDH = JF_BH*BH_BDH;

JF_ASN = JF_AN*AN_ASN;
JF_ADN = JF_AN*AN_ADN;
JF_BSN = JF_BN*BN_BSN;
JF_BDN = JF_BN*BN_BDN;

XH_ASH = XH_AH*AH_ASH;
XH_ADH = XH_AH*AH_ADH;
XH_BSH = XH_BH*BH_BSH;
XH_BDH = XH_BH*BH_BDH;

XH_ASN = XH_AN*AN_ASN;
XH_ADN = XH_AN*AN_ADN;
XH_BSN = XH_BN*BN_BSN;
XH_BDN = XH_BN*BN_BDN;

MF_ASH = MF_AH*AH_ASH;
MF_ADH = MF_AH*AH_ADH;
MF_BSH = MF_BH*BH_BSH;
MF_BDH = MF_BH*BH_BDH;

MF_ASN = MF_AN*AN_ASN;
MF_ADN = MF_AN*AN_ADN;
MF_BSN = MF_BN*BN_BSN;
MF_BDN = MF_BN*BN_BDN;

v_ASH = v_AH*AH_ASH; 
v_ADH = v_AH*AH_ADH; 
v_BSH = v_BH*BH_BSH; 
v_BDH = v_BH*BH_BDH; 
                     
v_ASN = v_AN*AN_ASN; 
v_ADN = v_AN*AN_ADN; 
v_BSN = v_BN*BN_BSN; 
v_BDN = v_BN*BN_BDN;   

% Elements of the Jacobian Matrix
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1SN*uKSN_K)-(KN*xi1DN*uKDN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1SN*uKSN_Q)-(KN*xi1DN*uKDN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -( -(RK/K)+(1/K)*( RH*KH*((eta*uKSH_K)+(1-eta)*uKDH_K)+RN*KN*((eta*uKSN_K)+(1-eta)*uKDN_K)+(RH*KH_K)+(RN*KN_K)+(RH_K*KH)+(RN_K*KN) )-(PH*KH/K)*((xi1SH*uKSH_K)+(xi1DH*uKDH_K))-(PN*KN/K)*((xi1SN*uKSN_K)+(xi1DN*uKDN_K))+(PI*kappa*v_K*deltaK));
Sigma_Q   = (r+deltaK)-( (1/K)*( (RH*KH*((eta*uKSH_Q)+(1-eta)*uKDH_Q))+(RN*KN*((eta*uKSN_Q)+(1-eta)*uKDN_Q))+(RH*KH_Q)+(RN*KN_Q)+(RH_Q*KH)+(RN_Q*KN) )-(PH*KH/K)*((xi1SH*uKSH_Q)+(xi1DH*uKDH_Q))-(PN*KN/K)*((xi1SN*uKSN_Q)+(xi1DN*uKDN_Q))+(PI*kappa*v_Q*deltaK));

x11   = Upsilon_K;                                                                         
x12   = Upsilon_Q;     
x21   = Sigma_K;                        
x22   = Sigma_Q;
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
omega_12 = V_sorted(1,2)/V_sorted(1,2); 
omega_22 = V_sorted(2,2)/V_sorted(1,2); 

% Solutions
Upsilon_G   = (I/IN)*(YN_G-CN_G-GN_G-(KN*xi1SN*uKSN_G)-(KN*xi1DN*uKDN_G)) + (alphaI*phiI*I)*( (PN_G/PN) - (alphaIH/PH)*PH_G );
Upsilon_ASH = (I/IN)*(YN_ASH-CN_ASH-(KN*xi1SN*uKSN_ASH)-(KN*xi1DN*uKDN_ASH)) + (alphaI*phiI*I)*( (PN_ASH/PN) - (alphaIH/PH)*PH_ASH );
Upsilon_ADH = (I/IN)*(YN_ADH-CN_ADH-(KN*xi1SN*uKSN_ADH)-(KN*xi1DN*uKDN_ADH)) + (alphaI*phiI*I)*( (PN_ADH/PN) - (alphaIH/PH)*PH_ADH );
Upsilon_BSH = (I/IN)*(YN_BSH-CN_BSH-(KN*xi1SN*uKSN_BSH)-(KN*xi1DN*uKDN_BSH)) + (alphaI*phiI*I)*( (PN_BSH/PN) - (alphaIH/PH)*PH_BSH );
Upsilon_BDH = (I/IN)*(YN_BDH-CN_BDH-(KN*xi1SN*uKSN_BDH)-(KN*xi1DN*uKDN_BDH)) + (alphaI*phiI*I)*( (PN_BDH/PN) - (alphaIH/PH)*PH_BDH );

Upsilon_ASN = (I/IN)*(YN_ASN-CN_ASN-(KN*xi1SN*uKSN_ASN)-(KN*xi1DN*uKDN_ASN)) + (alphaI*phiI*I)*( (PN_ASN/PN) - (alphaIH/PH)*PH_ASN );
Upsilon_ADN = (I/IN)*(YN_ADN-CN_ADN-(KN*xi1SN*uKSN_ADN)-(KN*xi1DN*uKDN_ADN)) + (alphaI*phiI*I)*( (PN_ADN/PN) - (alphaIH/PH)*PH_ADN );
Upsilon_BSN = (I/IN)*(YN_BSN-CN_BSN-(KN*xi1SN*uKSN_BSN)-(KN*xi1DN*uKDN_BSN)) + (alphaI*phiI*I)*( (PN_BSN/PN) - (alphaIH/PH)*PH_BSN );
Upsilon_BDN = (I/IN)*(YN_BDN-CN_BDN-(KN*xi1SN*uKSN_BDN)-(KN*xi1DN*uKDN_BDN)) + (alphaI*phiI*I)*( (PN_BDN/PN) - (alphaIH/PH)*PH_BDN );

Sigma_G   = -( (1/K)*( RH*KH*((eta*uKSH_G)+(1-eta)*uKDH_G)+RN*KN*((eta*uKSN_G)+(1-eta)*uKDN_G)+(RH*KH_G)+(RN*KN_G)+(RH_G*KH)+(RN_G*KN) )-(PH*KH/K)*((xi1SH*uKSH_G)+(xi1DH*uKDH_G))-(PN*KN/K)*((xi1SN*uKSN_G)+(xi1DN*uKDN_G))+(PI*kappa*v_G*deltaK));
Sigma_ASH = -( (1/K)*( RH*KH*((eta*uKSH_ASH)+(1-eta)*uKDH_ASH)+RN*KN*((eta*uKSN_ASH)+(1-eta)*uKDN_ASH)+(RH*KH_ASH)+(RN*KN_ASH)+(RH_ASH*KH)+(RN_ASH*KN) )-(PH*KH/K)*((xi1SH*uKSH_ASH)+(xi1DH*uKDH_ASH))-(PN*KN/K)*((xi1SN*uKSN_ASH)+(xi1DN*uKDN_ASH))+(PI*kappa*v_ASH*deltaK));
Sigma_ADH = -( (1/K)*( RH*KH*((eta*uKSH_ADH)+(1-eta)*uKDH_ADH)+RN*KN*((eta*uKSN_ADH)+(1-eta)*uKDN_ADH)+(RH*KH_ADH)+(RN*KN_ADH)+(RH_ADH*KH)+(RN_ADH*KN) )-(PH*KH/K)*((xi1SH*uKSH_ADH)+(xi1DH*uKDH_ADH))-(PN*KN/K)*((xi1SN*uKSN_ADH)+(xi1DN*uKDN_ADH))+(PI*kappa*v_ADH*deltaK));
Sigma_BSH = -( (1/K)*( RH*KH*((eta*uKSH_BSH)+(1-eta)*uKDH_BSH)+RN*KN*((eta*uKSN_BSH)+(1-eta)*uKDN_BSH)+(RH*KH_BSH)+(RN*KN_BSH)+(RH_BSH*KH)+(RN_BSH*KN) )-(PH*KH/K)*((xi1SH*uKSH_BSH)+(xi1DH*uKDH_BSH))-(PN*KN/K)*((xi1SN*uKSN_BSH)+(xi1DN*uKDN_BSH))+(PI*kappa*v_BSH*deltaK));
Sigma_BDH = -( (1/K)*( RH*KH*((eta*uKSH_BDH)+(1-eta)*uKDH_BDH)+RN*KN*((eta*uKSN_BDH)+(1-eta)*uKDN_BDH)+(RH*KH_BDH)+(RN*KN_BDH)+(RH_BDH*KH)+(RN_BDH*KN) )-(PH*KH/K)*((xi1SH*uKSH_BDH)+(xi1DH*uKDH_BDH))-(PN*KN/K)*((xi1SN*uKSN_BDH)+(xi1DN*uKDN_BDH))+(PI*kappa*v_BDH*deltaK));

Sigma_ASN = -( (1/K)*( RH*KH*((eta*uKSH_ASN)+(1-eta)*uKDH_ASN)+RN*KN*((eta*uKSN_ASN)+(1-eta)*uKDN_ASN)+(RH*KH_ASN)+(RN*KN_ASN)+(RH_ASN*KH)+(RN_ASN*KN) )-(PH*KH/K)*((xi1SH*uKSH_ASN)+(xi1DH*uKDH_ASN))-(PN*KN/K)*((xi1SN*uKSN_ASN)+(xi1DN*uKDN_ASN))+(PI*kappa*v_ASN*deltaK));
Sigma_ADN = -( (1/K)*( RH*KH*((eta*uKSH_ADN)+(1-eta)*uKDH_ADN)+RN*KN*((eta*uKSN_ADN)+(1-eta)*uKDN_ADN)+(RH*KH_ADN)+(RN*KN_ADN)+(RH_ADN*KH)+(RN_ADN*KN) )-(PH*KH/K)*((xi1SH*uKSH_ADN)+(xi1DH*uKDH_ADN))-(PN*KN/K)*((xi1SN*uKSN_ADN)+(xi1DN*uKDN_ADN))+(PI*kappa*v_ADN*deltaK));
Sigma_BSN = -( (1/K)*( RH*KH*((eta*uKSH_BSN)+(1-eta)*uKDH_BSN)+RN*KN*((eta*uKSN_BSN)+(1-eta)*uKDN_BSN)+(RH*KH_BSN)+(RN*KN_BSN)+(RH_BSN*KH)+(RN_BSN*KN) )-(PH*KH/K)*((xi1SH*uKSH_BSN)+(xi1DH*uKDH_BSN))-(PN*KN/K)*((xi1SN*uKSN_BSN)+(xi1DN*uKDN_BSN))+(PI*kappa*v_BSN*deltaK));
Sigma_BDN = -( (1/K)*( RH*KH*((eta*uKSH_BDN)+(1-eta)*uKDH_BDN)+RN*KN*((eta*uKSN_BDN)+(1-eta)*uKDN_BDN)+(RH*KH_BDN)+(RN*KN_BDN)+(RH_BDN*KH)+(RN_BDN*KN) )-(PH*KH/K)*((xi1SH*uKSH_BDN)+(xi1DH*uKDH_BDN))-(PN*KN/K)*((xi1SN*uKSN_BDN)+(xi1DN*uKDN_BDN))+(PI*kappa*v_BDN*deltaK));%%%%%%%%%%%%%%%%%% Solutions for Permanent Shocks %%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%% Solutions for Permanent Shocks %%%%%%%%%%%%%%%%%%%%
Vnorm = [omega_11 omega_12; omega_21 omega_22];
Vinv   = inv(Vnorm);
u11    = Vinv(1,1);
u12    = Vinv(1,2);
u21    = Vinv(2,1);
u22    = Vinv(2,2);

s11   = (u11*Upsilon_ASH) + (u12*Sigma_ASH);                                                                                                                                                                                                                         
s12   = (u11*Upsilon_BSH) + (u12*Sigma_BSH);                                                                                                                                                                                                                         
s13   = (u11*Upsilon_ASN) + (u12*Sigma_ASN);                                                                                                                                                                                                                         
s14   = (u11*Upsilon_BSN) + (u12*Sigma_BSN);                                                                                                                                                                                                                         
s15   = (u11*Upsilon_ADH) + (u12*Sigma_ADH);                                                                                                                                                                                                                         
s16   = (u11*Upsilon_BDH) + (u12*Sigma_BDH);                                                                                                                                                                                                                         
s17   = (u11*Upsilon_ADN) + (u12*Sigma_ADN);                                                                                                                                                                                                                         
s18   = (u11*Upsilon_BDN) + (u12*Sigma_BDN);                                                                                                                                                                                                                         
s19   = (u11*Upsilon_G)   + (u12*Sigma_G);                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                     
s21   = (u21*Upsilon_ASH) + (u22*Sigma_ASH);                                                                                                                                                                                                                         
s22   = (u21*Upsilon_BSH) + (u22*Sigma_BSH);                                                                                                                                                                                                                         
s23   = (u21*Upsilon_ASN) + (u22*Sigma_ASN);                                                                                                                                                                                                                         
s24   = (u21*Upsilon_BSN) + (u22*Sigma_BSN);                                                                                                                                                                                                                         
s25   = (u21*Upsilon_ADH) + (u22*Sigma_ADH);                                                                                                                                                                                                                         
s26   = (u21*Upsilon_BDH) + (u22*Sigma_BDH);                                                                                                                                                                                                                         
s27   = (u21*Upsilon_ADN) + (u22*Sigma_ADN);                                                                                                                                                                                                                         
s28   = (u21*Upsilon_BDN) + (u22*Sigma_BDN);                                                                                                                                                                                                                         
s29   = (u21*Upsilon_G)   + (u22*Sigma_G);                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                     
DeltaASH_1 = - s11*ASH_0*(1/(nu_1+xiASH));                                                                                                                                                                                                                           
DeltaBSH_1 = - s12*BSH_0*(1/(nu_1+xiBSH));                                                                                                                                                                                                                           
DeltaASN_1 = - s13*ASN_0*(1/(nu_1+xiASN));                                                                                                                                                                                                                           
DeltaBSN_1 = - s14*BSN_0*(1/(nu_1+xiBSN));                                                                                                                                                                                                                           
DeltaADH_1 = - s15*ADH_0*(1/(nu_1+xiADH));                                                                                                                                                                                                                           
DeltaBDH_1 = - s16*BDH_0*(1/(nu_1+xiBDH));                                                                                                                                                                                                                           
DeltaADN_1 = - s17*ADN_0*(1/(nu_1+xiADN));                                                                                                                                                                                                                           
DeltaBDN_1 = - s18*BDN_0*(1/(nu_1+xiBDN));                                                                                                                                                                                                                           
DeltaG_1   = - s19*Y_0*(1/(nu_1+xi));                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                     
DeltaASH_2  = s21*ASH_0*(1/(nu_2+xiASH));                                                                                                                                                                                                                            
DeltaBSH_2  = s22*BSH_0*(1/(nu_2+xiBSH));                                                                                                                                                                                                                            
DeltaASN_2  = s23*ASN_0*(1/(nu_2+xiASN));                                                                                                                                                                                                                            
DeltaBSN_2  = s24*BSN_0*(1/(nu_2+xiBSN));                                                                                                                                                                                                                            
DeltaADH_2  = s25*ADH_0*(1/(nu_2+xiADH));                                                                                                                                                                                                                            
DeltaBDH_2  = s26*BDH_0*(1/(nu_2+xiBDH));                                                                                                                                                                                                                            
DeltaADN_2  = s27*ADN_0*(1/(nu_2+xiADN));                                                                                                                                                                                                                            
DeltaBDN_2  = s28*BDN_0*(1/(nu_2+xiBDN));                                                                                                                                                                                                                            
DeltaG_2    = s29*Y_0*(1/(nu_2+xi));                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                     
ThetaASH_1   = (1-baraSH)*((nu_1+xiASH)/(nu_1+chiASH));                                                                                                                                                                                                              
ThetaASH_2   = (1-baraSH)*((nu_2+xiASH)/(nu_2+chiASH));                                                                                                                                                                                                              
ThetaBSH_1   = (1-barbSH)*((nu_1+xiBSH)/(nu_1+chiBSH));                                                                                                                                                                                                              
ThetaBSH_2   = (1-barbSH)*((nu_2+xiBSH)/(nu_2+chiBSH));                                                                                                                                                                                                              
ThetaASN_1   = (1-baraSN)*((nu_1+xiASN)/(nu_1+chiASN));                                                                                                                                                                                                              
ThetaASN_2   = (1-baraSN)*((nu_2+xiASN)/(nu_2+chiASN));                                                                                                                                                                                                              
ThetaBSN_1   = (1-barbSN)*((nu_1+xiBSN)/(nu_1+chiBSN));                                                                                                                                                                                                              
ThetaBSN_2   = (1-barbSN)*((nu_2+xiBSN)/(nu_2+chiBSN));                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                     
ThetaADH_1   = (1-baraDH)*((nu_1+xiADH)/(nu_1+chiADH));                                                                                                                                                                                                              
ThetaADH_2   = (1-baraDH)*((nu_2+xiADH)/(nu_2+chiADH));                                                                                                                                                                                                              
ThetaBDH_1   = (1-barbDH)*((nu_1+xiBDH)/(nu_1+chiBDH));                                                                                                                                                                                                              
ThetaBDH_2   = (1-barbDH)*((nu_2+xiBDH)/(nu_2+chiBDH));                                                                                                                                                                                                              
ThetaADN_1   = (1-baraDN)*((nu_1+xiADN)/(nu_1+chiADN));                                                                                                                                                                                                              
ThetaADN_2   = (1-baraDN)*((nu_2+xiADN)/(nu_2+chiADN));                                                                                                                                                                                                              
ThetaBDN_1   = (1-barbDN)*((nu_1+xiBDN)/(nu_1+chiBDN));                                                                                                                                                                                                              
ThetaBDN_2   = (1-barbDN)*((nu_2+xiBDN)/(nu_2+chiBDN));     

ThetaG_1    = (1-barg)*((nu_1+xi)/(nu_1+chi));
ThetaG_2    = (1-barg)*((nu_2+xi)/(nu_2+chi));
                                                                                                                                                                                                                                                                     
X20 = - DeltaG_2*(1-ThetaG_2) - DeltaASH_2*(1-ThetaASH_2) - DeltaBSH_2*(1-ThetaBSH_2) - DeltaASN_2*(1-ThetaASN_2) - DeltaBSN_2*(1-ThetaBSN_2) - DeltaADH_2*(1-ThetaADH_2) - DeltaBDH_2*(1-ThetaBDH_2) - DeltaADN_2*(1-ThetaADN_2) - DeltaBDN_2*(1-ThetaBDN_2);       
X10 = (K0-K) - X20;                                                                                                                                                                                                                                                  
X11 = X10 - DeltaG_1*(1-ThetaG_1) - DeltaASH_1*(1-ThetaASH_1) - DeltaBSH_1*(1-ThetaBSH_1) - DeltaASN_1*(1-ThetaASN_1) - DeltaBSN_1*(1-ThetaBSN_1) - DeltaADH_1*(1-ThetaADH_1) - DeltaBDH_1*(1-ThetaBDH_1) - DeltaADN_1*(1-ThetaADN_1) - DeltaBDN_1*(1-ThetaBDN_1);   

% Intertemporal solvency condition - lambda
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K;
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
B_G   = (PH_G*XH) + (PH*XH_G) - MF_G;
B_ASH = (PH_ASH*XH) + (PH*XH_ASH) - MF_ASH;
B_BSH = (PH_BSH*XH) + (PH*XH_BSH) - MF_BSH;
B_ASN = (PH_ASN*XH) + (PH*XH_ASN) - MF_ASN;
B_BSN = (PH_BSN*XH) + (PH*XH_BSN) - MF_BSN;
B_ADH = (PH_ADH*XH) + (PH*XH_ADH) - MF_ADH;
B_BDH = (PH_BDH*XH) + (PH*XH_BDH) - MF_BDH;
B_ADN = (PH_ADN*XH) + (PH*XH_ADN) - MF_ADN;
B_BDN = (PH_BDN*XH) + (PH*XH_BDN) - MF_BDN;

N1    = (B_K + (B_Q*omega_21));
N2    = (B_K + (B_Q*omega_22));
ThetaG_prime   = (1-barg)*((xi+r)/(chi+r));
ThetaG_1prime  = ThetaG_1*((xi+r)/(chi+r));
ThetaG_2prime  = ThetaG_2*((xi+r)/(chi+r));

ThetaASH_prime  = (1-baraSH)*((xiASH+r)/(chiASH+r));       
ThetaASH_1prime = ThetaASH_1*((xiASH+r)/(chiASH+r));       
ThetaASH_2prime = ThetaASH_2*((xiASH+r)/(chiASH+r));       
ThetaBSH_prime  = (1-barbSH)*((xiBSH+r)/(chiBSH+r));       
ThetaBSH_1prime = ThetaBSH_1*((xiBSH+r)/(chiBSH+r));       
ThetaBSH_2prime = ThetaBSH_2*((xiBSH+r)/(chiBSH+r));       
ThetaASN_prime  = (1-baraSN)*((xiASN+r)/(chiASN+r));       
ThetaASN_1prime = ThetaASN_1*((xiASN+r)/(chiASN+r));       
ThetaASN_2prime = ThetaASN_2*((xiASN+r)/(chiASN+r));       
ThetaBSN_prime  = (1-barbSN)*((xiBSN+r)/(chiBSN+r));       
ThetaBSN_1prime = ThetaBSN_1*((xiBSN+r)/(chiBSN+r));       
ThetaBSN_2prime = ThetaBSN_2*((xiBSN+r)/(chiBSN+r));       
                                                           
ThetaADH_prime  = (1-baraDH)*((xiADH+r)/(chiADH+r));       
ThetaADH_1prime = ThetaADH_1*((xiADH+r)/(chiADH+r));       
ThetaADH_2prime = ThetaADH_2*((xiADH+r)/(chiADH+r));       
ThetaBDH_prime  = (1-barbDH)*((xiBDH+r)/(chiBDH+r));       
ThetaBDH_1prime = ThetaBDH_1*((xiBDH+r)/(chiBDH+r));       
ThetaBDH_2prime = ThetaBDH_2*((xiBDH+r)/(chiBDH+r));       
ThetaADN_prime  = (1-baraDN)*((xiADN+r)/(chiADN+r));       
ThetaADN_1prime = ThetaADN_1*((xiADN+r)/(chiADN+r));       
ThetaADN_2prime = ThetaADN_2*((xiADN+r)/(chiADN+r));       
ThetaBDN_prime  = (1-barbDN)*((xiBDN+r)/(chiBDN+r));       
ThetaBDN_1prime = ThetaBDN_1*((xiBDN+r)/(chiBDN+r));       
ThetaBDN_2prime = ThetaBDN_2*((xiBDN+r)/(chiBDN+r));       

wB1    = N1*X11;
wBASH2 = B_ASH*ASH_0*(1-ThetaASH_prime) + N1*DeltaASH_1*(1-ThetaASH_1prime) - N2*DeltaASH_2*(1-ThetaASH_2prime);
wBBSH2 = B_BSH*BSH_0*(1-ThetaBSH_prime) + N1*DeltaBSH_1*(1-ThetaBSH_1prime) - N2*DeltaBSH_2*(1-ThetaBSH_2prime);
wBASN2 = B_ASN*ASN_0*(1-ThetaASN_prime) + N1*DeltaASN_1*(1-ThetaASN_1prime) - N2*DeltaASN_2*(1-ThetaASN_2prime);
wBBSN2 = B_BSN*BSN_0*(1-ThetaBSN_prime) + N1*DeltaBSN_1*(1-ThetaBSN_1prime) - N2*DeltaBSN_2*(1-ThetaBSN_2prime);

wBADH2 = B_ADH*ADH_0*(1-ThetaADH_prime) + N1*DeltaADH_1*(1-ThetaADH_1prime) - N2*DeltaADH_2*(1-ThetaADH_2prime);
wBBDH2 = B_BDH*BDH_0*(1-ThetaBDH_prime) + N1*DeltaBDH_1*(1-ThetaBDH_1prime) - N2*DeltaBDH_2*(1-ThetaBDH_2prime);
wBADN2 = B_ADN*ADN_0*(1-ThetaADN_prime) + N1*DeltaADN_1*(1-ThetaADN_1prime) - N2*DeltaADN_2*(1-ThetaADN_2prime);
wBBDN2 = B_BDN*BDN_0*(1-ThetaBDN_prime) + N1*DeltaBDN_1*(1-ThetaBDN_1prime) - N2*DeltaBDN_2*(1-ThetaBDN_2prime);

wBG2   = B_G*Y_0*(1-ThetaG_prime) + N1*DeltaG_1*(1-ThetaG_1prime) - N2*DeltaG_2*(1-ThetaG_2prime);

g(34) = (B-B0)-( (wB1/(r-nu_1)) + (wBG2/(xi+r)) + (wBASH2/(xiASH+r)) + (wBBSH2/(xiBSH+r)) + (wBASN2/(xiASN+r)) + (wBBSN2/(xiBSN+r)) + (wBADH2/(xiADH+r)) + (wBBDH2/(xiBDH+r)) + (wBADN2/(xiADN+r)) + (wBBDN2/(xiBDN+r)) );   

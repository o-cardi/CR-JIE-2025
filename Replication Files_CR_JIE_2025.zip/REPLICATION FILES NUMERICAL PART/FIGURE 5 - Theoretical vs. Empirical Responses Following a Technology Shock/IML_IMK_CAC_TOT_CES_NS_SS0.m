function g = IML_IMK_CAC_TOT_CES_NS_SS0(x)

global sigma phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global epsilonK varthetaK 
global gammaL sigmaL 
global r deltaK kappa
global omegaG omegaGN omegaGH 
global BH BN AH AN gammaH gammaN sigmaH sigmaN
global xi2SH xi2SN xi2DH xi2DN
global B0 K0 
global eta
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    VARAIABLES of the MODEL                      %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C        = x(1)  ; % Consumption
L        = x(2)  ; % Labor supply
RH       = x(3)  ; % Return on traded capital
RN       = x(4)  ; % Return on non-traded capital
WH       = x(5)  ; % Wage rate in sector H
WN       = x(6)  ; % Wage rate in sector N
W        = x(7)  ; % Aggregate wage index
RK       = x(8)  ; % Aggregate capital rental rate
PN       = x(9)  ; % Relative price of non tradables
K        = x(10)  ; % Stock of capital
PH       = x(11) ; % Terms of trade : PH/PF with PF = numeraire
B        = x(12) ; % Stock of Traded Bonds
alphaL   = x(13) ; % Labor compensation share of tradables
alphaK   = x(14) ; % Capital compensation share of tradables
PC       = x(15) ; % Aggregate consumption price index
PT       = x(16) ; % Consumption price index for tradables
CN       = x(17) ; % Consumption in non tradables
CH       = x(18) ; % Consumption in tradables
CF       = x(19) ; % Consumption goods imports
alphaC   = x(20) ; % Tradable content of consumption expenditure
alphaH   = x(21) ; % Home goods content of consumption expenditure on traded goods
PI       = x(22) ; % Aggregate investment price index
PIT      = x(23) ; % Investment price index for tradables
IN       = x(24) ; % Non tradable investment
IH       = x(25) ; % Investment in home goods
IF       = x(26) ; % Investment in foreign goods
alphaI   = x(27) ; % Tradable content of investment expenditure
alphaIH  = x(28) ; % Home goods content of investment expenditure
LH       = x(29) ; % Labor in sector H
LN       = x(30) ; % Labor in sector N
KH       = x(31) ; % Capital stock in sector H
KN       = x(32) ; % Capital stock in sector N
GF       = x(33) ; % Government spending in foreign goods
GN       = x(34) ; % Government spending in non tradables
GH       = x(35) ; % Government spending in home traded goods
YH       = x(36) ; % Traded value added
YN       = x(37) ; % Non-traded value added
XH       = x(38) ; % Exports of home traded goods
MF       = x(39) ; % Imports of foreign goods
xi1SH    = x(40) ; % Parameter of traded capital utilization cost function associated with symmetric technology uKSH
xi1DH    = x(41) ; % Parameter of traded capital utilization cost function associated with asymmetric technology uKDH
xi1SN    = x(42) ; % Parameter of non-traded capital utilization cost function associated with symmetric technology uKSN
xi1DN    = x(43) ; % Parameter of traded capital utilization cost function associated with asymmetric technology uKDN
VL       = x(44) ; % Desutility labor
lambda   = x(45) ; % Marginal Utility of Wealth - Intertemporal Solvency Condition                                                    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    STEADY STATE of the MODEL                    %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
% Aggregate Consumption -  C
g(1)= (C^(-sigma))*(VL^sigma) - (PC*lambda);

% Aggregate labor supply - L
g(2)= (C^(1-sigma))*sigma*gammaL*(L^(1/sigmaL))*(VL^(sigma-1)) - (lambda*W);

% MRPKH = RH - RH
g(3)= PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH)) - RH; 

% MRPKN = RN - RN
g(4)= PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN)) - RN;  

% MRPLH = WH - WH
g(5)= PH*gammaH*(AH^((sigmaH-1)/sigmaH))*((YH/LH)^(1/sigmaH)) - WH;

% MRPLN = WN - WN
g(6)= PN*gammaN*(AN^((sigmaN-1)/sigmaN))*((YN/LN)^(1/sigmaN)) - WN;

% Aggregate wage index - W
g(7)= W - ((vartheta*(WH)^(epsilon+1)) + ((1-vartheta)*(WN)^(epsilon+1)))^(1/(epsilon+1));

% Aggregate capital rental rate index - RK
g(8)= RK - ((varthetaK*(RH)^(epsilonK+1)) + ((1-varthetaK)*(RN)^(epsilonK+1)))^(1/(epsilonK+1));

% Return on capital is equal to capital cost dotQ=0 - PN 
g(9)= RK - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(10)= YN - CN - IN - GN;

% Homme good market clearing condition - PH
g(11)= YH - CH - IH - GH - XH;

% Traded good market clearing condition - B
g(12)= (r*B) + (PH*XH) - MF;

% Labor compensation share of tradables WH*LH/W*L - alphaL 
g(13)= alphaL - (vartheta*(WH)^(epsilon+1))/( vartheta*(WH)^(epsilon+1) + (1-vartheta)*(WN)^(epsilon+1) ); 

% Capital compensation share of tradables RH*KH/RK*K- alphaK 
g(14)= alphaK - (varthetaK*(RH)^(epsilonK+1))/( varthetaK*(RH)^(epsilonK+1) + (1-varthetaK)*(RN)^(epsilonK+1) ); 

% Consumption price index - PC=PC(PT,PN)
g(15)= PC - (varphi*(PT^(1-phi))+(1-varphi)*(PN^(1-phi)))^(1/(1-phi));

% Consumption price index for tradables - PT=PT(PH)
g(16)= PT - (varphiH*(PH^(1-rho))+(1-varphiH))^(1/(1-rho));

% Consumption in non tradables - CN
g(17)= CN - C*(1-varphi)*((PN/PC)^(-phi));

% Consumption in home goods - CH
g(18)= CH - C*varphi*((PT/PC)^(-phi))*varphiH*((PH/PT)^(-rho));

% Consumption in foreign goods - CF
g(19)= CF - C*varphi*((PT/PC)^(-phi))*(1-varphiH)*((1/PT)^(-rho));

% Tradable content of consumption expenditure - alphaC
g(20)= alphaC - varphi*(PT/PC)^(1-phi);

% Home goods content of consumption expenditure - alphaH
g(21)= alphaH - varphiH*(PH/PT)^(1-rho);

% Investment price index - PI=PI(PT,PN)
g(22)= PI - (iota*(PIT^(1-phiI))+(1-iota)*(PN^(1-phiI)))^(1/(1-phiI));

% Investment price index for tradables - PIT=PIT(PH)
g(23)= PIT - (iotaH*(PH^(1-rhoI))+(1-iotaH))^(1/(1-rhoI));

% Investment in non tradables - IN
g(24)= IN - (deltaK*K)*(1-iota)*((PN/PI)^(-phiI));

% Investment in home goods - IH
g(25)= IH - (deltaK*K)*iota*((PIT/PI)^(-phiI))*iotaH*((PH/PIT)^(-rhoI));

% Investment in foreign goods - IF
g(26)= IF - (deltaK*K)*iota*((PIT/PI)^(-phiI))*(1-iotaH)*((1/PIT)^(-rhoI));

% Tradable of investment expenditure - alphaI
g(27)= alphaI - iota*(PIT/PI)^(1-phiI);

% Home goods content of investment expenditure - alphaIH
g(28)= alphaIH - iotaH*(PH/PIT)^(1-rhoI);

% Hours worked in the traded sector - LH
g(29)= LH - L*(vartheta*(WH/W)^epsilon); 

% Hours worked in the non traded sector - LN
g(30)= LN - L*((1-vartheta)*(WN/W)^epsilon); 

% Capital stock in the traded sector - KH
g(31)= KH - K*(varthetaK*(RH/RK)^epsilonK); 

% Capital stock in the non traded sector - KN
g(32)= KN - K*((1-varthetaK)*(RN/RK)^epsilonK); 

% Total government spending - G
g(33)= ((PH*GH) + GF + (PN*GN)) - omegaG*( (PH*YH) + (PN*YN) ); 

% Non tradable share of government spending  - GN
g(34)= (PN*GN) - omegaGN*( (PH*GH) + GF + (PN*GN) ); 

% Home goods content of government spending  - GH
g(35)= (PH*GH) - omegaGH*( (PH*GH) + GF ); 

% Value added in the home-produced traded goods sector - YH
g(36)= YH - ( gammaH*((AH*LH)^((sigmaH-1)/sigmaH)) + (1-gammaH)*((BH*KH)^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1));  
 
% Value added in the non-traded sector - YN
g(37)= YN - ( gammaN*((AN*LN)^((sigmaN-1)/sigmaN)) + (1-gammaN)*((BN*KN)^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1)); 

% Export of home goods - XH
g(38)= XH - ex*(PH)^(-nuX);

% Import of foreign goods - MF
g(39)= MF - (CF+IF+GF); 
                                                                                                    
% Capital and technology utilzation rates parameters - xi1j, chi1j                                  
g(40)= xi1SH - eta*(RK/PH);                                                                         
g(41)= xi1DH - (1-eta)*(RK/PH);                                                                     
g(42)= xi1SN - eta*(RK/PN);                                                                         
g(43)= xi1DN - (1-eta)*(RK/PN);                                                                     
                                                                                                    
% Desutility from labor                                                                             
g(44)= VL - ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) ); % Desutility labor  

% Labor income share in the home traded good and non traded good sector
sLH    = (WH*LH)/(PH*YH); 
sLN    = (WN*LN)/(PN*YN);

% Non Sep Preferences Shimer [2009]
% Solutions C=C(lambda,PN,PH,W); L=L(lambda,PN,PH,W)
a11 = -(sigma/C); 
a12 = (sigma/L)*((1+sigmaL)/sigmaL)*((VL-1)/VL);
a21 = (1-sigma)/C; 
a22 = (1/L)*( (1/sigmaL) + (sigma-1)*((1+sigmaL)/sigmaL)*((VL-1)/VL) );  

b11 = (1-alphaC)/PN; 
b12 = alphaC*alphaH/PH; 
b13 = 0;
b21 = 0;
b22 = 0; 
b23 = (1/W); 

A1 = [a11 a12; a21 a22];
B1 = [b11 b12 b13; b21 b22 b23];
JST1 = inv(A1);
MST1 = JST1*B1;
C_1PN = MST1(1,1); C_1PH = MST1(1,2); C_W = MST1(1,3); 
L_1PN = MST1(2,1); L_1PH = MST1(2,2); L_W = MST1(2,3);

% Partial derivatives of W=W(WN,WH)           
W_WH   = (W/WH)*alphaL; 
W_WN   = (W/WN)*(1-alphaL);                                                                                                                         
L_WH   = L_W*W_WH;                                                                    
L_WN   = L_W*W_WN;                                                                  
                                                                                        
% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH,WN,WH)                      
CN_1PN = -(CN/PN)*(alphaC*phi) + (CN/C)*C_1PN;                                         
CN_1PH = (CN/PH)*alphaC*alphaH*phi + (CN/C)*C_1PH;                                      
CN_WN  = (CN/C)*C_W*W_WN;                                                               
CN_WH  = (CN/C)*C_W*W_WH;                                                               
                                                                                        
CH_1PN = (CH/PN)*phi*(1-alphaC) + (CH/C)*C_1PN;                                         
CH_1PH = -(CH/PH)*( rho*(1-alphaH) + phi*alphaH*(1-alphaC) ) + (CH/C)*C_1PH;            
CH_WN  = (CH/C)*C_W*W_WN;                                                               
CH_WH  = (CH/C)*C_W*W_WH;                                                               
                                                                                        
CF_1PN = (CF/PN)*(1-alphaC)*phi + (CF/C)*C_1PN;                                         
CF_1PH = (CF/PH)*alphaH*(rho - phi*(1-alphaC) ) + (CF/C)*C_1PH;                         
CF_WN  = (CF/C)*C_W*W_WN;                                                               
CF_WH  = (CF/C)*C_W*W_WH;   

% Solutions Lj=Lj(lambda,WH,WN,PH,PN)
LH_WH  = (LH/WH)*epsilon*(1-alphaL) + (LH/L)*L_WH; 
LH_WN  = -(LH/WN)*epsilon*(1-alphaL) + (LH/L)*L_WN; 
LH_1PH = (LH/L)*L_1PH; 
LH_1PN = (LH/L)*L_1PN;

LN_WH  = -(LN/WH)*epsilon*alphaL + (LN/L)*L_WH; 
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN; 
LN_1PH = (LN/L)*L_1PH; 
LN_1PN = (LN/L)*L_1PN;  

% Solutions Kj=Kj(RH,RN,K), j=H,N            
KH_RH = (KH/RH)*epsilonK*(1-alphaK);         
KH_RN = -(KH/RN)*epsilonK*(1-alphaK);        
KH_1K  = (KH/K);                              
                                             
KN_RH = -(KN/RH)*epsilonK*alphaK;            
KN_RN = (KN/RN)*epsilonK*alphaK;             
KN_1K  = (KN/K);                              

% Solutions for Wj,Rj(PN,PH,uKH,uKN,Aj,Bj,lambda),                                                                                                                                                      
d11 = - ( ((1-sLH)/sigmaH)*(LH_WH/LH) + (1/WH) ); % WH                                               
d12 = - ((1-sLH)/sigmaH)*(LH_WN/LH);  % WN                                                           
d13 = ((1-sLH)/sigmaH)*(KH_RH/KH);  % RH                                                             
d14 = ((1-sLH)/sigmaH)*(KH_RN/KH); % RN                                                              
                                                                                                     
d21 = - ((1-sLN)/sigmaN)*(LN_WH/LN);  % WH                                                           
d22 = - ( ((1-sLN)/sigmaN)*(LN_WN/LN) + (1/WN) ); % WN                                               
d23 = ((1-sLN)/sigmaN)*(KN_RH/KN);  % RH                                                             
d24 = ((1-sLN)/sigmaN)*(KN_RN/KN); % RN                                                              
                                                                                                     
d31 = (sLH/sigmaH)*(LH_WH/LH); % WH                                                                  
d32 = (sLH/sigmaH)*(LH_WN/LH); % WN                                                                  
d33 = - ( (sLH/sigmaH)*(KH_RH/KH) + (1/RH) ); % RH                                                   
d34 = - (sLH/sigmaH)*(KH_RN/KH); % RN                                                                 
                                                                                                     
d41 = (sLN/sigmaN)*(LN_WH/LN); % WH                                                                  
d42 = (sLN/sigmaN)*(LN_WN/LN); % WN                                                                  
d43 = - (sLN/sigmaN)*(KN_RH/KN); % RH                                                                
d44 = - ( (sLN/sigmaN)*(KN_RN/KN) + (1/RN) ); % RN                                                   
                                                                                                     
% PN, PH, K, uKH, uKN                                                                                
e11 = ((1-sLH)/sigmaH)*(LH_1PN/LH); % PN                                                              
e12 = ((1-sLH)/sigmaH)*(LH_1PH/LH) - (1/PH); % PH                                                     
e13 = - ((1-sLH)/sigmaH)*(KH_1K/KH); % K                                                              
e14 = - ((1-sLH)/sigmaH); % uKH                                                                      
e15 = 0; % uKN                                                                                       
                                                                                                     
e21 = ((1-sLN)/sigmaN)*(LN_1PN/LN) - (1/PN); % PN                                                     
e22 = ((1-sLN)/sigmaN)*(LN_1PH/LN);  % PH                                                             
e23 = - ((1-sLN)/sigmaN)*(KN_1K/KN); % K                                                              
e24 = 0; % uKH                                                                                       
e25 = - ((1-sLN)/sigmaN);  % uKN                                                                     
                                                                                                     
e31 = - (sLH/sigmaH)*(LH_1PN/LH); % PN                                                                
e32 = - ( (sLH/sigmaH)*(LH_1PH/LH) + (1/PH) ); % PH                                                   
e33 = (sLH/sigmaH)*(KH_1K/KH); % K                                                                    
e34 = (sLH/sigmaH); % uKH                                                                            
e35 = 0;  % uKN                                                                                      
                                                                                                     
e41 = - ( (sLN/sigmaN)*(LN_1PN/LN) + (1/PN) ); % PN                                                   
e42 = - (sLN/sigmaN)*(LN_1PH/LN); % PH                                                                
e43 = (sLN/sigmaN)*(KN_1K/KN); % K                                                                    
e44 = 0;  % uKH                                                                                      
e45 = (sLN/sigmaN); % uKN                                                                            
                                                                                                     
M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];                           
X2 = [e11 e12 e13 e14 e15; e21 e22 e23 e24 e25; e31 e32 e33 e34 e35; e41 e42 e43 e44 e45];           
JST2 = inv(M2);                                                                                      
MST2 = JST2*X2;                                                                                      
                                                                                                     
WH_1PN = MST2(1,1); WH_1PH = MST2(1,2); WH_1K = MST2(1,3); WH_uKH = MST2(1,4); WH_uKN = MST2(1,5);   
WN_1PN = MST2(2,1); WN_1PH = MST2(2,2); WN_1K = MST2(2,3); WN_uKH = MST2(2,4); WN_uKN = MST2(2,5);   
RH_1PN = MST2(3,1); RH_1PH = MST2(3,2); RH_1K = MST2(3,3); RH_uKH = MST2(3,4); RH_uKN = MST2(3,5);   
RN_1PN = MST2(4,1); RN_1PH = MST2(4,2); RN_1K = MST2(4,3); RN_uKH = MST2(4,4); RN_uKN = MST2(4,5); 

% Solutions uKj(uKSj,uKDj)     
uKH_uKSH = eta;        
uKH_uKDH = (1-eta);    
uKN_uKSN = eta;        
uKN_uKDN = (1-eta); 

% Solutions Rj,Wj(PN,PH,K,uKSj,uKDj)                                                          
RH_uKSH = RH_uKH*uKH_uKSH;                                                                    
RH_uKDH = RH_uKH*uKH_uKDH;                                                                    
RH_uKSN = RH_uKN*uKN_uKSN;                                                                    
RH_uKDN = RH_uKN*uKN_uKDN;                                                                    
                                                                                              
WH_uKSH = WH_uKH*uKH_uKSH;                                                                    
WH_uKDH = WH_uKH*uKH_uKDH;                                                                    
WH_uKSN = WH_uKN*uKN_uKSN;                                                                    
WH_uKDN = WH_uKN*uKN_uKDN;                                                                    
                                                                                              
RN_uKSH = RN_uKH*uKH_uKSH;                                                                    
RN_uKDH = RN_uKH*uKH_uKDH;                                                                    
RN_uKSN = RN_uKN*uKN_uKSN;                                                                    
RN_uKDN = RN_uKN*uKN_uKDN;                                                                    
                                                                                              
WN_uKSH = WN_uKH*uKH_uKSH;                                                                    
WN_uKDH = WN_uKH*uKH_uKDH;                                                                    
WN_uKSN = WN_uKN*uKN_uKSN;                                                                    
WN_uKDN = WN_uKN*uKN_uKDN;  

% Solving for sectoral labor and sectoral output - Lj,Kj,Yj(PN,PH,K,uKj,Aj,Bj,lambda)                                     
LH_2PN  = LH_1PN + (LH_WH*WH_1PN) + (LH_WN*WN_1PN);                                                                       
LH_2PH  = LH_1PH + (LH_WH*WH_1PH) + (LH_WN*WN_1PH);                                                                       
LH_1K   = (LH_WH*WH_1K)  + (LH_WN*WN_1K);                                                                                 
LH_uKSH = (LH_WH*WH_uKSH) + (LH_WN*WN_uKSH);                                                                              
LH_uKDH = (LH_WH*WH_uKDH) + (LH_WN*WN_uKDH);                                                                              
LH_uKSN = (LH_WH*WH_uKSN) + (LH_WN*WN_uKSN);                                                                              
LH_uKDN = (LH_WH*WH_uKDN) + (LH_WN*WN_uKDN);                                                      
                                                                                              
LN_2PN  = LN_1PN + (LN_WH*WH_1PN) + (LN_WN*WN_1PN);                                                                       
LN_2PH  = LN_1PH + (LN_WH*WH_1PH) + (LN_WN*WN_1PH);                                                                       
LN_1K   = (LN_WH*WH_1K)  + (LN_WN*WN_1K);                                                                                 
LN_uKSH = (LN_WH*WH_uKSH) + (LN_WN*WN_uKSH);                                                                              
LN_uKDH = (LN_WH*WH_uKDH) + (LN_WN*WN_uKDH);                                                                              
LN_uKSN = (LN_WH*WH_uKSN) + (LN_WN*WN_uKSN);                                                                              
LN_uKDN = (LN_WH*WH_uKDN) + (LN_WN*WN_uKDN);                                                        
                                                                                              
KH_1PN  = (KH_RH*RH_1PN) + (KH_RN*RN_1PN);                                                                                
KH_1PH  = (KH_RH*RH_1PH) + (KH_RN*RN_1PH);                                                                                
KH_2K   = KH_1K  +(KH_RH*RH_1K)  + (KH_RN*RN_1K);                                                                         
KH_uKSH = (KH_RH*RH_uKSH) + (KH_RN*RN_uKSH);                                                                              
KH_uKDH = (KH_RH*RH_uKDH) + (KH_RN*RN_uKDH);                                                                              
KH_uKSN = (KH_RH*RH_uKSN) + (KH_RN*RN_uKSN);                                                                              
KH_uKDN = (KH_RH*RH_uKDN) + (KH_RN*RN_uKDN);                                                     
                                                                                              
KN_1PN  = (KN_RH*RH_1PN) + (KN_RN*RN_1PN);                                                                                
KN_1PH  = (KN_RH*RH_1PH) + (KN_RN*RN_1PH);                                                                                
KN_2K   = KN_1K + (KN_RH*RH_1K)  + (KN_RN*RN_1K);                                                                         
KN_uKSH = (KN_RH*RH_uKSH) + (KN_RN*RN_uKSH);                                                                              
KN_uKDH = (KN_RH*RH_uKDH) + (KN_RN*RN_uKDH);                                                                              
KN_uKSN = (KN_RH*RH_uKSN) + (KN_RN*RN_uKSN);                                                                              
KN_uKDN = (KN_RH*RH_uKDN) + (KN_RN*RN_uKDN);                                                    
                                                                                              
YH_1PN  = sLH*YH*(LH_2PN/LH) + (1-sLH)*YH*(KH_1PN/KH);                                                                    
YH_1PH  = sLH*YH*(LH_2PH/LH) + (1-sLH)*YH*(KH_1PH/KH);                                                                    
YH_1K   = sLH*YH*(LH_1K/LH) + (1-sLH)*YH*(KH_2K/KH);                                                                      
YH_uKSH = sLH*YH*(LH_uKSH/LH) + (1-sLH)*YH*( (KH_uKSH/KH) + eta );                                                        
YH_uKDH = sLH*YH*(LH_uKDH/LH) + (1-sLH)*YH*( (KH_uKDH/KH) + (1-eta) );                                                    
YH_uKSN = sLH*YH*(LH_uKSN/LH) + (1-sLH)*YH*(KH_uKSN/KH);                                                                  
YH_uKDN = sLH*YH*(LH_uKDN/LH) + (1-sLH)*YH*(KH_uKDN/KH);                                          
                                                                                              
YN_1PN  = sLN*YN*(LN_2PN/LN) + (1-sLN)*YN*(KN_1PN/KN);                                                                    
YN_1PH  = sLN*YN*(LN_2PH/LN) + (1-sLN)*YN*(KN_1PH/KN);                                                                    
YN_1K   = sLN*YN*(LN_1K/LN) + (1-sLN)*YN*(KN_2K/KN);                                                                      
YN_uKSH = sLN*YN*(LN_uKSH/LN) + (1-sLN)*YN*(KN_uKSH/KN);                                                                  
YN_uKDH = sLN*YN*(LN_uKDH/LN) + (1-sLN)*YN*(KN_uKDH/KN);                                                                  
YN_uKSN = sLN*YN*(LN_uKSN/LN) + (1-sLN)*YN*( (KN_uKSN/KN) + eta);                                                         
YN_uKDN = sLN*YN*(LN_uKDN/LN) + (1-sLN)*YN*( (KN_uKDN/KN) + (1-eta) );                                  

% Intermediate solution for CN, CH, CF - Cj=Cj(PN,PH,K,uKSj,uKDj,Aj,Bj)                                                   
CN_2PN     = CN_1PN + (CN_WH*WH_1PN) + (CN_WN*WN_1PN);                                                                    
CN_2PH     = CN_1PH + (CN_WH*WH_1PH) + (CN_WN*WN_1PH);                                                                    
CN_1K      = (CN_WH*WH_1K) + (CN_WN*WN_1K);                                                                               
CN_uKSH    = (CN_WH*WH_uKSH) + (CN_WN*WN_uKSH);                                                                           
CN_uKDH    = (CN_WH*WH_uKDH) + (CN_WN*WN_uKDH);                                                                           
CN_uKSN    = (CN_WH*WH_uKSN) + (CN_WN*WN_uKSN);                                                                           
CN_uKDN    = (CN_WH*WH_uKDN) + (CN_WN*WN_uKDN);                                        
                                                                                    
CH_2PN     = CH_1PN + (CH_WH*WH_1PN) + (CH_WN*WN_1PN);                                                                    
CH_2PH     = CH_1PH + (CH_WH*WH_1PH) + (CH_WN*WN_1PH);                                                                    
CH_1K      = (CH_WH*WH_1K) + (CH_WN*WN_1K);                                                                               
CH_uKSH    = (CH_WH*WH_uKSH) + (CH_WN*WN_uKSH);                                                                           
CH_uKDH    = (CH_WH*WH_uKDH) + (CH_WN*WN_uKDH);                                                                           
CH_uKSN    = (CH_WH*WH_uKSN) + (CH_WN*WN_uKSN);                                                                           
CH_uKDN    = (CH_WH*WH_uKDN) + (CH_WN*WN_uKDN);                                         
                                                                                    
CF_2PN     = CF_1PN + (CF_WH*WH_1PN) + (CF_WN*WN_1PN);                                                                    
CF_2PH     = CF_1PH + (CF_WH*WH_1PH) + (CF_WN*WN_1PH);                                                                    
CF_1K      = (CF_WH*WH_1K) + (CF_WN*WN_1K);                                                                               
CF_uKSH    = (CF_WH*WH_uKSH) + (CF_WN*WN_uKSH);                                                                           
CF_uKDH    = (CF_WH*WH_uKDH) + (CF_WN*WN_uKDH);                                                                           
CF_uKSN    = (CF_WH*WH_uKSN) + (CF_WN*WN_uKSN);                                                                           
CF_uKDN    = (CF_WH*WH_uKDN) + (CF_WN*WN_uKDN);                                          

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I     = deltaK*K; 
JN_PN = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K = (IN/I)*J_K; 
JN_1Q = (IN/I)*J_Q; 

JH_PN =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKSj,uKDj(PN,PH,K)                                                                       
f11 = ((xi2SH/xi1SH) + (1-eta) + eta*(sLH/sigmaH)) - (sLH/sigmaH)*(LH_uKSH/LH) + (sLH/sigmaH)*(KH_uKSH/KH); % uKSH                               
f12 = -((sigmaH-sLH)/sigmaH)*(1-eta) - (sLH/sigmaH)*(LH_uKDH/LH) + (sLH/sigmaH)*(KH_uKDH/KH); % uKDH                                             
f13 = - (sLH/sigmaH)*(LH_uKSN/LH) + (sLH/sigmaH)*(KH_uKSN/KH); % uKSN                                                                            
f14 = - (sLH/sigmaH)*(LH_uKDN/LH) + (sLH/sigmaH)*(KH_uKDN/KH); % uKDN                                                                            
                                                                                                                                                 
f21 = -((sigmaH-sLH)/sigmaH)*eta - (sLH/sigmaH)*(LH_uKSH/LH) + (sLH/sigmaH)*(KH_uKSH/KH); % uKSH                                                 
%f22 = ((xi2DH/xi1DH) + eta + (1-eta)*(sLH/sigmaH)) + (sLH/sigmaH)*(KH_uKDH/KH); %uKDH     
f22 = ((xi2DH/xi1DH) + eta + (1-eta)*(sLH/sigmaH)) - (sLH/sigmaH)*(LH_uKDH/LH) + (sLH/sigmaH)*(KH_uKDH/KH); %uKDH 
f23 = - (sLH/sigmaH)*(LH_uKSN/LH) + (sLH/sigmaH)*(KH_uKSN/KH); % uKSN                                                                            
f24 = - (sLH/sigmaH)*(LH_uKDN/LH) + (sLH/sigmaH)*(KH_uKDN/KH); % uKDN                                                                            
                                                                                                                                                 
f31 =  - (sLN/sigmaN)*(LN_uKSH/LN) + (sLN/sigmaN)*(KN_uKSH/KN); %uKSH                                                                            
f32 =  - (sLN/sigmaN)*(LN_uKDH/LN) + (sLN/sigmaN)*(KN_uKDH/KN); %uKDH                                                                            
f33 = ((xi2SN/xi1SN) + (1-eta) + eta*(sLN/sigmaN))  - (sLN/sigmaN)*(LN_uKSN/LN) + (sLN/sigmaN)*(KN_uKSN/KN); %uKSN                               
f34 = -((sigmaN-sLN)/sigmaN)*(1-eta)  - (sLN/sigmaN)*(LN_uKDN/LN) + (sLN/sigmaN)*(KN_uKDN/KN); %uKDN                                             
                                                                                                                                                 
f41 = - (sLN/sigmaN)*(LN_uKSH/LN) + (sLN/sigmaN)*(KN_uKSH/KN); %uKSH                                                                             
f42 = - (sLN/sigmaN)*(LN_uKDH/LN) + (sLN/sigmaN)*(KN_uKDH/KN); %uKDH                                                                             
f43 = -((sigmaN-sLN)/sigmaN)*eta  - (sLN/sigmaN)*(LN_uKSN/LN) + (sLN/sigmaN)*(KN_uKSN/KN); %uKSN                                                 
f44 = ((xi2DN/xi1DN) + eta + (1-eta)*(sLN/sigmaN)) - (sLN/sigmaN)*(LN_uKDN/LN) + (sLN/sigmaN)*(KN_uKDN/KN); %uKDN                                
                                                                                                                                                 
% PN, PH, K, AH, BH, AN, BN, lambda                                                                                                              
g11 = (sLH/sigmaH)*(LH_2PN/LH) - (sLH/sigmaH)*(KH_1PN/KH); % PN                                                                                  
g12 = (sLH/sigmaH)*(LH_2PH/LH) - (sLH/sigmaH)*(KH_1PH/KH); % PH                                                                                  
g13 = (sLH/sigmaH)*(LH_1K/LH) - (sLH/sigmaH)*(KH_2K/KH); % K                                              
                                                                                                               
g21 = (sLH/sigmaH)*(LH_2PN/LH) - (sLH/sigmaH)*(KH_1PN/KH); % PN                                                                                  
g22 = (sLH/sigmaH)*(LH_2PH/LH) - (sLH/sigmaH)*(KH_1PH/KH); % PH                                                                                  
g23 = (sLH/sigmaH)*(LH_1K/LH) - (sLH/sigmaH)*(KH_2K/KH); % K    

g31 = (sLN/sigmaN)*(LN_2PN/LN) - (sLN/sigmaN)*(KN_1PN/KN); % PN                                                                                  
g32 = (sLN/sigmaN)*(LN_2PH/LN) - (sLN/sigmaN)*(KN_1PH/KN); % PH                                                                                  
g33 = (sLN/sigmaN)*(LN_1K/LN) - (sLN/sigmaN)*(KN_2K/KN); % K  

g41 = (sLN/sigmaN)*(LN_2PN/LN) - (sLN/sigmaN)*(KN_1PN/KN); % PN                                                                                  
g42 = (sLN/sigmaN)*(LN_2PH/LN) - (sLN/sigmaN)*(KN_1PH/KN); % PH                                                                                  
g43 = (sLN/sigmaN)*(LN_1K/LN) - (sLN/sigmaN)*(KN_2K/KN); % K  
                                                                                                                                                                            
M3 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];    
X3 = [g11 g12 g13; g21 g22 g23; g31 g32 g33; g41 g42 g43];                    
JST3 = inv(M3);                                                               
MST3 = JST3*X3;                                                               
                                                                              
uKSH_PN = MST3(1,1); uKSH_PH = MST3(1,2); uKSH_1K = MST3(1,3);                
uKDH_PN = MST3(2,1); uKDH_PH = MST3(2,2); uKDH_1K = MST3(2,3);                
uKSN_PN = MST3(3,1); uKSN_PH = MST3(3,2); uKSN_1K = MST3(3,3);                
uKDN_PN = MST3(4,1); uKDN_PH = MST3(4,2); uKDN_1K = MST3(4,3);                                                                    

% Solving for Wj,Rj,Lj,Kj,Yj,Cg(lambda,K,PH,PN,AH,BH,AN,BN)
WH_2K = WH_1K + (WH_uKSH*uKSH_1K) + (WH_uKDH*uKDH_1K) + (WH_uKSN*uKSN_1K) + (WH_uKDN*uKDN_1K);
WH_PH = WH_1PH + (WH_uKSH*uKSH_PH) +  (WH_uKDH*uKDH_PH) + (WH_uKSN*uKSN_PH) + (WH_uKDN*uKDN_PH);
WH_PN = WH_1PN + (WH_uKSH*uKSH_PN) + (WH_uKDH*uKDH_PN) + (WH_uKSN*uKSN_PN) + (WH_uKDN*uKDN_PN);

WN_2K = WN_1K + (WN_uKSH*uKSH_1K) +  (WN_uKDH*uKDH_1K) + (WN_uKSN*uKSN_1K) + (WN_uKDN*uKDN_1K);
WN_PH = WN_1PH + (WN_uKSH*uKSH_PH) + (WN_uKDH*uKDH_PH) + (WN_uKSN*uKSN_PH) + (WN_uKDN*uKDN_PH);
WN_PN = WN_1PN + (WN_uKSH*uKSH_PN) + (WN_uKDH*uKDH_PN) + (WN_uKSN*uKSN_PN) + (WN_uKDN*uKDN_PN);

RH_2K = RH_1K + (RH_uKSH*uKSH_1K) + (RH_uKDH*uKDH_1K) + (RH_uKSN*uKSN_1K) + (RH_uKDN*uKDN_1K);
RH_PH = RH_1PH + (RH_uKSH*uKSH_PH) +  (RH_uKDH*uKDH_PH) + (RH_uKSN*uKSN_PH) + (RH_uKDN*uKDN_PH);
RH_PN = RH_1PN + (RH_uKSH*uKSH_PN) + (RH_uKDH*uKDH_PN) + (RH_uKSN*uKSN_PN) + (RH_uKDN*uKDN_PN);

RN_2K = RN_1K + (RN_uKSH*uKSH_1K) +  (RN_uKDH*uKDH_1K) + (RN_uKSN*uKSN_1K) + (RN_uKDN*uKDN_1K);
RN_PH = RN_1PH + (RN_uKSH*uKSH_PH) + (RN_uKDH*uKDH_PH) + (RN_uKSN*uKSN_PH) + (RN_uKDN*uKDN_PH);
RN_PN = RN_1PN + (RN_uKSH*uKSH_PN) + (RN_uKDH*uKDH_PN) + (RN_uKSN*uKSN_PN) + (RN_uKDN*uKDN_PN);
                                                                                               
LH_2K = LH_1K + (LH_uKSH*uKSH_1K) + (LH_uKDH*uKDH_1K) + (LH_uKSN*uKSN_1K) + (LH_uKDN*uKDN_1K);
LH_PH = LH_2PH + (LH_uKSH*uKSH_PH) + (LH_uKDH*uKDH_PH) + (LH_uKSN*uKSN_PH) + (LH_uKDN*uKDN_PH);
LH_PN = LH_2PN + (LH_uKSH*uKSH_PN) + (LH_uKDH*uKDH_PN) + (LH_uKSN*uKSN_PN) + (LH_uKDN*uKDN_PN);

LN_2K = LN_1K + (LN_uKSH*uKSH_1K) + (LN_uKDH*uKDH_1K) + (LN_uKSN*uKSN_1K) + (LN_uKDN*uKDN_1K);
LN_PH = LN_2PH + (LN_uKSH*uKSH_PH) + (LN_uKDH*uKDH_PH) + (LN_uKSN*uKSN_PH) + (LN_uKDN*uKDN_PH);
LN_PN = LN_2PN + (LN_uKSH*uKSH_PN) + (LN_uKDH*uKDH_PN) + (LN_uKSN*uKSN_PN) + (LN_uKDN*uKDN_PN);

KH_3K = KH_2K + (KH_uKSH*uKSH_1K) + (KH_uKDH*uKDH_1K) + (KH_uKSN*uKSN_1K) + (KH_uKDN*uKDN_1K);
KH_PH = KH_1PH + (KH_uKSH*uKSH_PH) + (KH_uKDH*uKDH_PH) + (KH_uKSN*uKSN_PH) + (KH_uKDN*uKDN_PH);
KH_PN = KH_1PN + (KH_uKSH*uKSH_PN) + (KH_uKDH*uKDH_PN) + (KH_uKSN*uKSN_PN) + (KH_uKDN*uKDN_PN);                                          
                                                                                               
KN_3K = KN_2K + (KN_uKSH*uKSH_1K) + (KN_uKDH*uKDH_1K) + (KN_uKSN*uKSN_1K) + (KN_uKDN*uKDN_1K);
KN_PH = KN_1PH + (KN_uKSH*uKSH_PH) + (KN_uKDH*uKDH_PH) + (KN_uKSN*uKSN_PH) + (KN_uKDN*uKDN_PH);
KN_PN = KN_1PN + (KN_uKSH*uKSH_PN) + (KN_uKDH*uKDH_PN) + (KN_uKSN*uKSN_PN) + (KN_uKDN*uKDN_PN);                                           
                                                                                                                                                                                                                                      
YH_2K  = YH_1K + (YH_uKSH*uKSH_1K) + (YH_uKDH*uKDH_1K) + (YH_uKSN*uKSN_1K) + (YH_uKDN*uKDN_1K);
YH_PH  = YH_1PH + (YH_uKSH*uKSH_PH) + (YH_uKDH*uKDH_PH) + (YH_uKSN*uKSN_PH) + (YH_uKDN*uKDN_PH);
YH_PN  = YH_1PN + (YH_uKSH*uKSH_PN) + (YH_uKDH*uKDH_PN) + (YH_uKSN*uKSN_PN) + (YH_uKDN*uKDN_PN);                                          
                                                                                               
YN_2K  = YN_1K + (YN_uKSH*uKSH_1K) + (YN_uKDH*uKDH_1K) + (YN_uKSN*uKSN_1K) + (YN_uKDN*uKDN_1K);
YN_PH  = YN_1PH + (YN_uKSH*uKSH_PH) + (YN_uKDH*uKDH_PH) + (YN_uKSN*uKSN_PH) + (YN_uKDN*uKDN_PH);
YN_PN  = YN_1PN + (YN_uKSH*uKSH_PN) + (YN_uKDH*uKDH_PN) + (YN_uKSN*uKSN_PN) + (YN_uKDN*uKDN_PN);

CH_2K = CH_1K + (CH_uKSH*uKSH_1K) + (CH_uKDH*uKDH_1K) + (CH_uKSN*uKSN_1K) + (CH_uKDN*uKDN_1K);
CH_PH = CH_2PH + (CH_uKSH*uKSH_PH) + (CH_uKDH*uKDH_PH) + (CH_uKSN*uKSN_PH) + (CH_uKDN*uKDN_PH);
CH_PN = CH_2PN + (CH_uKSH*uKSH_PN) + (CH_uKDH*uKDH_PN) + (CH_uKSN*uKSN_PN) + (CH_uKDN*uKDN_PN); 
                                                     
CN_2K = CN_1K + (CN_uKSH*uKSH_1K) + (CN_uKDH*uKDH_1K) + (CN_uKSN*uKSN_1K) + (CN_uKDN*uKDN_1K);
CN_PH = CN_2PH + (CN_uKSH*uKSH_PH) + (CN_uKDH*uKDH_PH) + (CN_uKSN*uKSN_PH) + (CN_uKDN*uKDN_PH);
CN_PN = CN_2PN + (CN_uKSH*uKSH_PN) + (CN_uKDH*uKDH_PN) + (CN_uKSN*uKSN_PN) + (CN_uKDN*uKDN_PN);  
                                                     
CF_2K = CF_1K + (CF_uKSH*uKSH_1K) + (CF_uKDH*uKDH_1K) + (CF_uKSN*uKSN_1K) + (CF_uKDN*uKDN_1K);
CF_PH = CF_2PH + (CF_uKSH*uKSH_PH) + (CF_uKDH*uKDH_PH) + (CF_uKSN*uKSN_PH) + (CF_uKDN*uKDN_PH);
CF_PN = CF_2PN + (CF_uKSH*uKSH_PN) + (CF_uKDH*uKDH_PN) + (CF_uKSN*uKSN_PN) + (CF_uKDN*uKDN_PN); 

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,lambda)                                                                              
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1SN*uKSN_PH) - (KN*xi1DN*uKDN_PH); % PH                                                                            
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1SN*uKSN_PN) - (KN*xi1DN*uKDN_PN); % PN                                                                            
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1SH*uKSH_PH) - (KH*xi1DH*uKDH_PH); % PH                                                                    
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1SH*uKSH_PN) - (KH*xi1DH*uKDH_PN); % PN                                                                            
                                                                                                                                                         
% K,Q,G,AH,BH,AN,BN,lambda                                                                                                                               
k11 = -(YN_2K - CN_2K - JN_1K - (KN*xi1SN*uKSN_1K) - (KN*xi1DN*uKDN_1K));                                                                                
k12 = JN_1Q;                                              
k21 = -(YH_2K - CH_2K - JH_1K - (KH*xi1SH*uKSH_1K) - (KH*xi1DH*uKDH_1K));                                                                                
k22 = JH_1Q;                                                 
                                                            
M4 = [h11 h12; h21 h22];              
X4 = [k11 k12; k21 k22];              
JST4 = inv(M4);                       
MST4 = JST4*X4;                       
                                      
PH_K = MST4(1,1); PH_Q = MST4(1,2);   
PN_K = MST4(2,1); PN_Q = MST4(2,2);                           

% Solving for Lj,Kj,Wj,Rj,Yj,uKj(K,Q,G,Aj,Bj) - 
LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q);                  
LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);               
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);                       
                                                          
KH_K = KH_3K + (KH_PH*PH_K) + (KH_PN*PN_K);               
KH_Q = (KH_PH*PH_Q) + (KH_PN*PN_Q);                       
KN_K = KN_3K + (KN_PH*PH_K) + (KN_PN*PN_K);               
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);                       
                                                                                                                                   
RH_K = RH_2K + (RH_PH*PH_K) + (RH_PN*PN_K);               
RH_Q = (RH_PH*PH_Q) + (RH_PN*PN_Q);                       
RN_K = RN_2K + (RN_PH*PH_K) + (RN_PN*PN_K);               
RN_Q = (RN_PH*PH_Q) + (RN_PN*PN_Q);                       
                                                          
YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K);               
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q);                       
YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);               
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);                       
                                                          
uKSH_K  = uKSH_1K + (uKSH_PH*PH_K) + (uKSH_PN*PN_K);                           
uKSH_Q  = (uKSH_PH*PH_Q) + (uKSH_PN*PN_Q);      
uKDH_K  = uKDH_1K + (uKDH_PH*PH_K) + (uKDH_PN*PN_K);                           
uKDH_Q  = (uKDH_PH*PH_Q) + (uKDH_PN*PN_Q);

uKSN_K = uKSN_1K + (uKSN_PH*PH_K) + (uKSN_PN*PN_K);                            
uKSN_Q = (uKSN_PH*PH_Q) + (uKSN_PN*PN_Q); 
uKDN_K = uKDN_1K + (uKDN_PH*PH_K) + (uKDN_PN*PN_K);                            
uKDN_Q = (uKDN_PH*PH_Q) + (uKDN_PN*PN_Q);
                                                      
% Solving for consumption Cj=Cj(lambda,K,Q,G,Aj,Bj), investment inputs 
% Jj=Jj(K,Q,GH,GN), imports MF=MF(lambda,K,Q,G,Aj,Bj), exports 
%XH=XH(K,Q,G,Aj,Bj)- Final Solutions
CN_K  = CN_2K + (CN_PH*PH_K) + (CN_PN*PN_K);                          
CN_Q  = (CN_PH*PH_Q) + (CN_PN*PN_Q);                                        
                                                        
CH_K  = CH_2K + (CH_PH*PH_K) + (CH_PN*PN_K);            
CH_Q  = (CH_PH*PH_Q) + (CH_PN*PN_Q);                    
                   
CF_K  = CF_2K + (CF_PH*PH_K) + (CF_PN*PN_K);            
CF_Q  = (CF_PH*PH_Q) + (CF_PN*PN_Q);                                      

JH_K  = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q  = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q); 
JN_K  = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q  = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JF_K  = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q  = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 

XH_K = XH_PH*PH_K; 
XH_Q = XH_PH*PH_Q; 
MF_K = (CF_K + JF_K); 
MF_Q = (CF_Q + JF_Q);  

% Solving for investment function I/K = v(Q/PI)+delta_K - final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 

% Elements of the Jacobian Matrix                                                                                                                                                                                                                                 
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1SN*uKSN_K)-(KN*xi1DN*uKDN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                                                                                    
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1SN*uKSN_Q)-(KN*xi1DN*uKDN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );                                                                                                                                             
Sigma_K   = -( -(RK/K)+(1/K)*( RH*KH*((eta*uKSH_K)+(1-eta)*uKDH_K)+RN*KN*((eta*uKSN_K)+(1-eta)*uKDN_K)+(RH*KH_K)+(RN*KN_K)+(RH_K*KH)+(RN_K*KN) )-(PH*KH/K)*((xi1SH*uKSH_K)+(xi1DH*uKDH_K))-(PN*KN/K)*((xi1SN*uKSN_K)+(xi1DN*uKDN_K))+(PI*kappa*v_K*deltaK));      
Sigma_Q   = (r+deltaK)-( (1/K)*( (RH*KH*((eta*uKSH_Q)+(1-eta)*uKDH_Q))+(RN*KN*((eta*uKSN_Q)+(1-eta)*uKDN_Q))+(RH*KH_Q)+(RN*KN_Q)+(RH_Q*KH)+(RN_Q*KN) )-(PH*KH/K)*((xi1SH*uKSH_Q)+(xi1DH*uKDH_Q))-(PN*KN/K)*((xi1SN*uKSN_Q)+(xi1DN*uKDN_Q))+(PI*kappa*v_Q*deltaK)); 

x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    
                                                                      
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
 
% Intertemporal solvency condition - lambda 
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega_21));
H1    = N1/(nu_1-r); 
g(45) = (B - B0) - H1*(K-K0);




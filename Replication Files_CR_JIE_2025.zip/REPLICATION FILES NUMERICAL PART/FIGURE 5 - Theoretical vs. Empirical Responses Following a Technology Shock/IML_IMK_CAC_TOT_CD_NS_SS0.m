function g = IML_IMK_CAC_TOT_CD_NS_SS0(x)

global sigma phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global epsilonK varthetaK 
global gammaL sigmaL 
global r deltaK kappa
global thetaH thetaN ZH ZN
global omegaG omegaGN omegaGH 
global xi2H xi2N 
global B0 K0 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    VARAIABLES of the MODEL                      %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C        = x(1)  ; % Consumption
L        = x(2)  ; % Labor supply
RH       = x(3)  ; % Return on traded capital
RN       = x(4)  ; % Return on non-traded capital
WH       = x(5)  ; % Wage rate in sector H
WN       = x(6)  ; % Wage rate in sector N
W        = x(7)  ; % Aggregate wage index
RK       = x(8)  ; % Aggregate capital rental rate
PN       = x(9)  ; % Relative price of non tradables
K        = x(10)  ; % Stock of capital
PH       = x(11) ; % Terms of trade : PH/PF with PF = numeraire
B        = x(12) ; % Stock of Traded Bonds
alphaL   = x(13) ; % Labor compensation share of tradables
alphaK   = x(14) ; % Capital compensation share of tradables
PC       = x(15) ; % Aggregate consumption price index
PT       = x(16) ; % Consumption price index for tradables
CN       = x(17) ; % Consumption in non tradables
CH       = x(18) ; % Consumption in tradables
CF       = x(19) ; % Consumption goods imports
alphaC   = x(20) ; % Tradable content of consumption expenditure
alphaH   = x(21) ; % Home goods content of consumption expenditure on traded goods
PI       = x(22) ; % Aggregate investment price index
PIT      = x(23) ; % Investment price index for tradables
IN       = x(24) ; % Non tradable investment
IH       = x(25) ; % Investment in home goods
IF       = x(26) ; % Investment in foreign goods
alphaI   = x(27) ; % Tradable content of investment expenditure
alphaIH  = x(28) ; % Home goods content of investment expenditure
LH       = x(29) ; % Labor in sector H
LN       = x(30) ; % Labor in sector N
KH       = x(31) ; % Capital stock in sector H
KN       = x(32) ; % Capital stock in sector N
GF       = x(33) ; % Government spending in foreign goods
GN       = x(34) ; % Government spending in non tradables
GH       = x(35) ; % Government spending in home traded goods
YH       = x(36) ; % Traded value added
YN       = x(37) ; % Non-traded value added
XH       = x(38) ; % Exports of home traded goods
MF       = x(39) ; % Imports of foreign goods
xi1H     = x(40) ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N     = x(41) ; % Parameter of non-traded capital utilization cost function
VL       = x(42) ; % Desutility labor
lambda   = x(43) ; % Marginal Utility of Wealth - Intertemporal Solvency Condition        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    STEADY STATE of the MODEL                    %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
% Aggregate Consumption -  C
g(1)= (C^(-sigma))*(VL^sigma) - (PC*lambda);

% Aggregate labor supply - L
g(2)= (C^(1-sigma))*sigma*gammaL*(L^(1/sigmaL))*(VL^(sigma-1)) - (lambda*W);

% MRPKH = RH - RH - 
g(3)= PH*ZH*(1-thetaH)*(LH^thetaH)*(KH^(-thetaH)) - RH; 

% MRPKN = RN - RN
g(4)= PN*ZN*(1-thetaN)*(LN^thetaN)*(KN^(-thetaN)) - RN; 

% MRPLH = WH - WH
g(5)= PH*ZH*thetaH*(LH^(thetaH-1))*(KH^(1-thetaH)) - WH;

% MRPLN = WN - WN
g(6)= PN*ZN*thetaN*(LN^(thetaN-1))*(KN^(1-thetaN)) - WN;

% Aggregate wage index - W
g(7)= W - ((vartheta*(WH)^(epsilon+1)) + ((1-vartheta)*(WN)^(epsilon+1)))^(1/(epsilon+1));

% Aggregate capital rental rate index - RK
g(8)= RK - ((varthetaK*(RH)^(epsilonK+1)) + ((1-varthetaK)*(RN)^(epsilonK+1)))^(1/(epsilonK+1));

% Return on capital is equal to capital cost dotQ=0 - PN 
g(9)= RK - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(10)= YN - CN - IN - GN;

% Homme good market clearing condition - PH
g(11)= YH - CH - IH - GH - XH;

% Traded good market clearing condition - B
g(12)= (r*B) + (PH*XH) - MF;

% Labor compensation share of tradables WH*LH/W*L - alphaL 
g(13)= alphaL - (vartheta*(WH)^(epsilon+1))/( vartheta*(WH)^(epsilon+1) + (1-vartheta)*(WN)^(epsilon+1) );  

% Capital compensation share of tradables RH*KH/RK*K- alphaK                                                                                                
g(14)= alphaK - (varthetaK*(RH)^(epsilonK+1))/( varthetaK*(RH)^(epsilonK+1) + (1-varthetaK)*(RN)^(epsilonK+1) );

% Consumption price index - PC=PC(PT,PN)
g(15)= PC - (varphi*(PT^(1-phi))+(1-varphi)*(PN^(1-phi)))^(1/(1-phi));

% Consumption price index for tradables - PT=PT(PH)
g(16)= PT - (varphiH*(PH^(1-rho))+(1-varphiH))^(1/(1-rho));

% Consumption in non tradables - CN
g(17)= CN - C*(1-varphi)*((PN/PC)^(-phi));

% Consumption in home goods - CH
g(18)= CH - C*varphi*((PT/PC)^(-phi))*varphiH*((PH/PT)^(-rho));

% Consumption in foreign goods - CF
g(19)= CF - C*varphi*((PT/PC)^(-phi))*(1-varphiH)*((1/PT)^(-rho));

% Tradable content of consumption expenditure - alphaC
g(20)= alphaC - varphi*(PT/PC)^(1-phi);

% Home goods content of consumption expenditure - alphaH
g(21)= alphaH - varphiH*(PH/PT)^(1-rho);

% Investment price index - PI=PI(PT,PN)
g(22)= PI - (iota*(PIT^(1-phiI))+(1-iota)*(PN^(1-phiI)))^(1/(1-phiI));

% Investment price index for tradables - PIT=PIT(PH)
g(23)= PIT - (iotaH*(PH^(1-rhoI))+(1-iotaH))^(1/(1-rhoI));

% Investment in non tradables - IN
g(24)= IN - (deltaK*K)*(1-iota)*((PN/PI)^(-phiI));

% Investment in home goods - IH
g(25)= IH - (deltaK*K)*iota*((PIT/PI)^(-phiI))*iotaH*((PH/PIT)^(-rhoI));

% Investment in foreign goods - IF
g(26)= IF - (deltaK*K)*iota*((PIT/PI)^(-phiI))*(1-iotaH)*((1/PIT)^(-rhoI));

% Tradable of investment expenditure - alphaI
g(27)= alphaI - iota*(PIT/PI)^(1-phiI);

% Home goods content of investment expenditure - alphaIH
g(28)= alphaIH - iotaH*(PH/PIT)^(1-rhoI);

% Hours worked in the traded sector - LH
g(29)= LH - L*(vartheta*(WH/W)^epsilon); 

% Hours worked in the non traded sector - LN
g(30)= LN - L*(1-vartheta)*(WN/W)^epsilon; 

% Capital stock in the traded sector - KH
g(31)= KH - K*varthetaK*(RH/RK)^epsilonK; 

% Capital stock in the non traded sector - KN
g(32)= KN - K*(1-varthetaK)*(RN/RK)^epsilonK; 

% Total government spending - G
g(33)= ((PH*GH) + GF + (PN*GN)) - omegaG*( (PH*YH) + (PN*YN) ); 

% Non tradable share of government spending  - GN
g(34)= (PN*GN) - omegaGN*( (PH*GH) + GF + (PN*GN) ); 

% Home goods content of government spending  - GH
g(35)= (PH*GH) - omegaGH*( (PH*GH) + GF ); 

% Traded value added - YH                       
g(36)= YH - ZH*(LH^thetaH)*(KH^(1-thetaH));     
                                                
% Non-traded value added - YN                   
g(37)= YN - ZN*(LN^thetaN)*(KN^(1-thetaN));     

% Export of home goods - XH
g(38)= XH - ex*(PH)^(-nuX);

% Import of foreign goods - MF
g(39)= MF - (CF+IF+GF);

% Capital utilzation rates parameters - xi1j 
g(40)= xi1H - (RH/PH); 
g(41)= xi1N - (RN/PN);

% Desutility from labor
g(42)= VL - ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) ); % Desutility labor
 
% Non Sep Preferences Shimer [2009]
% Solutions C=C(lambda,PN,PH,W); L=L(lambda,PN,PH,W)
a11 = -(sigma/C); 
a12 = (sigma/L)*((1+sigmaL)/sigmaL)*((VL-1)/VL);
a21 = (1-sigma)/C; 
a22 = (1/L)*( (1/sigmaL) + (sigma-1)*((1+sigmaL)/sigmaL)*((VL-1)/VL) );  

b11 = (1-alphaC)/PN; 
b12 = alphaC*alphaH/PH; 
b13 = 0;
b21 = 0;
b22 = 0; 
b23 = (1/W); 

A1 = [a11 a12; a21 a22];
B1 = [b11 b12 b13; b21 b22 b23];
JST1 = inv(A1);
MST1 = JST1*B1;
C_1PN = MST1(1,1); C_1PH = MST1(1,2); C_W = MST1(1,3); 
L_1PN = MST1(2,1); L_1PH = MST1(2,2); L_W = MST1(2,3);

% Partial derivatives of W=W(WN,WH)           
W_WH   = (W/WH)*alphaL; 
W_WN   = (W/WN)*(1-alphaL);                                                                                                                         
L_WH   = L_W*W_WH;                                                                    
L_WN   = L_W*W_WN;                                                                  
                                                                                        
% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH,WN,WH)                      
CN_1PN = -(CN/PN)*(alphaC*phi) + (CN/C)*C_1PN;                                         
CN_1PH = (CN/PH)*alphaC*alphaH*phi + (CN/C)*C_1PH;                                      
CN_WN  = (CN/C)*C_W*W_WN;                                                               
CN_WH  = (CN/C)*C_W*W_WH;                                                               
                                                                                        
CH_1PN = (CH/PN)*phi*(1-alphaC) + (CH/C)*C_1PN;                                         
CH_1PH = -(CH/PH)*( rho*(1-alphaH) + phi*alphaH*(1-alphaC) ) + (CH/C)*C_1PH;            
CH_WN  = (CH/C)*C_W*W_WN;                                                               
CH_WH  = (CH/C)*C_W*W_WH;                                                               
                                                                                        
CF_1PN = (CF/PN)*(1-alphaC)*phi + (CF/C)*C_1PN;                                         
CF_1PH = (CF/PH)*alphaH*(rho - phi*(1-alphaC) ) + (CF/C)*C_1PH;                         
CF_WN  = (CF/C)*C_W*W_WN;                                                               
CF_WH  = (CF/C)*C_W*W_WH;   

% Solutions LH=LH(lambda,WH,WN,PH,PN), LN=LN(lambda,WH,WN,PH,PN)
LH_WH  = (LH/WH)*epsilon*(1-alphaL) + (LH/L)*L_WH; 
LH_WN  = -(LH/WN)*epsilon*(1-alphaL) + (LH/L)*L_WN; 
LH_1PH = (LH/L)*L_1PH; 
LH_1PN = (LH/L)*L_1PN;

LN_WH  = -(LN/WH)*epsilon*alphaL + (LN/L)*L_WH; 
LN_WN  = (LN/WN)*epsilon*alphaL + (LN/L)*L_WN; 
LN_1PH = (LN/L)*L_1PH; 
LN_1PN = (LN/L)*L_1PN;  

% Solutions Kj=Kj(RH,RN,K), j=H,N            
KH_RH = (KH/RH)*epsilonK*(1-alphaK);         
KH_RN = -(KH/RN)*epsilonK*(1-alphaK);        
KH_1K  = (KH/K);                              
                                             
KN_RH = -(KN/RH)*epsilonK*alphaK;            
KN_RN = (KN/RN)*epsilonK*alphaK;             
KN_1K  = (KN/K);   

% Solutions for Wj,Rj(PN,PH,uKH,uKN,Zj,lambda),                                                                                                                                                      
d11 = - ( (1-thetaH)*(LH_WH/LH) + (1/WH) ); % WH                                               
d12 = - (1-thetaH)*(LH_WN/LH);  % WN                                                           
d13 = (1-thetaH)*(KH_RH/KH);  % RH                                                             
d14 = (1-thetaH)*(KH_RN/KH); % RN                                                              
                                                                                                     
d21 = - (1-thetaN)*(LN_WH/LN);  % WH                                                           
d22 = - ( (1-thetaN)*(LN_WN/LN) + (1/WN) ); % WN                                               
d23 = (1-thetaN)*(KN_RH/KN);  % RH                                                             
d24 = (1-thetaN)*(KN_RN/KN); % RN                                                              
                                                                                                     
d31 = thetaH*(LH_WH/LH); % WH                                                                  
d32 = thetaH*(LH_WN/LH); % WN                                                                  
d33 = - ( thetaH*(KH_RH/KH) + (1/RH) ); % RH                                                   
d34 = - thetaH*(KH_RN/KH); % RN                                                                 
                                                                                                     
d41 = thetaN*(LN_WH/LN); % WH                                                                  
d42 = thetaN*(LN_WN/LN); % WN                                                                  
d43 = - thetaN*(KN_RH/KN); % RH                                                                
d44 = - ( thetaN*(KN_RN/KN) + (1/RN) ); % RN                                                   
                                                                                                     
% PN, PH, K, uKH, uKN                                                                                
e11 = (1-thetaH)*(LH_1PN/LH); % PN                                                              
e12 = (1-thetaH)*(LH_1PH/LH) - (1/PH); % PH                                                     
e13 = - (1-thetaH)*(KH_1K/KH); % K                                                              
e14 = - (1-thetaH); % uKH                                                                      
e15 = 0; % uKN                                                                                       
                                                                                                     
e21 = (1-thetaN)*(LN_1PN/LN) - (1/PN); % PN                                                     
e22 = (1-thetaN)*(LN_1PH/LN);  % PH                                                             
e23 = - (1-thetaN)*(KN_1K/KN); % K                                                              
e24 = 0; % uKH                                                                                       
e25 = - (1-thetaN);  % uKN                                                                     
                                                                                                     
e31 = - thetaH*(LH_1PN/LH); % PN                                                                
e32 = - ( thetaH*(LH_1PH/LH) + (1/PH) ); % PH                                                   
e33 = thetaH*(KH_1K/KH); % K                                                                    
e34 = thetaH; % uKH                                                                            
e35 = 0;  % uKN                                                                                      
                                                                                                     
e41 = - ( thetaN*(LN_1PN/LN) + (1/PN) ); % PN                                                   
e42 = - thetaN*(LN_1PH/LN); % PH                                                                
e43 = thetaN*(KN_1K/KN); % K                                                                    
e44 = 0;  % uKH                                                                                      
e45 = thetaN; % uKN                                                                            
                                                                                                     
M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];                           
X2 = [e11 e12 e13 e14 e15; e21 e22 e23 e24 e25; e31 e32 e33 e34 e35; e41 e42 e43 e44 e45];           
JST2 = inv(M2);                                                                                      
MST2 = JST2*X2;                                                                                      
                                                                                                     
WH_1PN = MST2(1,1); WH_1PH = MST2(1,2); WH_1K = MST2(1,3); WH_uKH = MST2(1,4); WH_uKN = MST2(1,5);   
WN_1PN = MST2(2,1); WN_1PH = MST2(2,2); WN_1K = MST2(2,3); WN_uKH = MST2(2,4); WN_uKN = MST2(2,5);   
RH_1PN = MST2(3,1); RH_1PH = MST2(3,2); RH_1K = MST2(3,3); RH_uKH = MST2(3,4); RH_uKN = MST2(3,5);   
RN_1PN = MST2(4,1); RN_1PH = MST2(4,2); RN_1K = MST2(4,3); RN_uKH = MST2(4,4); RN_uKN = MST2(4,5);   

% Solving for sectoral labor and sectoral output - Lj,yj,Yj,Kj(PN,PH,K,uKj,uZj)
LH_2PN = LH_1PN + (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_2PH = LH_1PH + (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K  = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKH = (LH_WH*WH_uKH) + (LH_WN*WN_uKH);
LH_uKN = (LH_WH*WH_uKN) + (LH_WN*WN_uKN);

LN_2PN = LN_1PN + (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_2PH = LN_1PH + (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K  = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKH = (LN_WH*WH_uKH) + (LN_WN*WN_uKH);
LN_uKN = (LN_WH*WH_uKN) + (LN_WN*WN_uKN);                                                                    
                                                                                 
KH_1PN = (KH_RH*RH_1PN) + (KH_RN*RN_1PN);                                                     
KH_1PH = (KH_RH*RH_1PH) + (KH_RN*RN_1PH);                                                     
KH_2K  = KH_1K + (KH_RH*RH_1K)  + (KH_RN*RN_1K);                                                      
KH_uKH = (KH_RH*RH_uKH) + (KH_RN*RN_uKH);                                                     
KH_uKN = (KH_RH*RH_uKN) + (KH_RN*RN_uKN);                                                     
                                                                                              
KN_1PN = (KN_RH*RH_1PN) + (KN_RN*RN_1PN);                                                     
KN_1PH = (KN_RH*RH_1PH) + (KN_RN*RN_1PH);                                                     
KN_2K  = KN_1K + (KN_RH*RH_1K)  + (KN_RN*RN_1K);                                                      
KN_uKH = (KN_RH*RH_uKH) + (KN_RN*RN_uKH);                                                     
KN_uKN = (KN_RH*RH_uKN) + (KN_RN*RN_uKN);                                                                             
                                                                                 
YH_1PN = thetaH*YH*(LH_2PN/LH) + (1-thetaH)*YH*(KH_1PN/KH);                
YH_1PH = thetaH*YH*(LH_2PH/LH) + (1-thetaH)*YH*(KH_1PH/KH);                
YH_1K  = thetaH*YH*(LH_1K/LH) + (1-thetaH)*YH*(KH_2K/KH);                  
YH_uKH = thetaH*YH*(LH_uKH/LH) + (1-thetaH)*YH*( (KH_uKH/KH) + 1 );        
YH_uKN = thetaH*YH*(LH_uKN/LH) + (1-thetaH)*YH*(KH_uKN/KH);               
                                                                           
YN_1PN = thetaN*YN*(LN_2PN/LN) + (1-thetaN)*YN*(KN_1PN/KN);                
YN_1PH = thetaN*YN*(LN_2PH/LN) + (1-thetaN)*YN*(KN_1PH/KN);                
YN_1K  = thetaN*YN*(LN_1K/LN) + (1-thetaN)*YN*(KN_2K/KN);                  
YN_uKH = thetaN*YN*(LN_uKH/LN) + (1-thetaN)*YN*(KN_uKH/KN);                
YN_uKN = thetaN*YN*(LN_uKN/LN) + (1-thetaN)*YN*( (KN_uKN/KN) + 1);                                                                                                   
                                                                                 
% Intermediate solution for CN, CH, CF - Cj=Cj(PN,PH,K,uKj,uZj)               
CN_2PN     = CN_1PN + (CN_WH*WH_1PN) + (CN_WN*WN_1PN);                              
CN_2PH     = CN_1PH + (CN_WH*WH_1PH) + (CN_WN*WN_1PH);                              
CN_1K      = (CN_WH*WH_1K) + (CN_WN*WN_1K);                                         
CN_uKH     = (CN_WH*WH_uKH) + (CN_WN*WN_uKH);                                       
CN_uKN     = (CN_WH*WH_uKN) + (CN_WN*WN_uKN);                                       
                                                                                    
CH_2PN     = CH_1PN + (CH_WH*WH_1PN) + (CH_WN*WN_1PN);                              
CH_2PH     = CH_1PH + (CH_WH*WH_1PH) + (CH_WN*WN_1PH);                              
CH_1K      = (CH_WH*WH_1K) + (CH_WN*WN_1K);                                         
CH_uKH     = (CH_WH*WH_uKH) + (CH_WN*WN_uKH);                                       
CH_uKN     = (CH_WH*WH_uKN) + (CH_WN*WN_uKN);                                       
                                                                                    
CF_2PN     = CF_1PN + (CF_WH*WH_1PN) + (CF_WN*WN_1PN);                              
CF_2PH     = CF_1PH + (CF_WH*WH_1PH) + (CF_WN*WN_1PH);                              
CF_1K      = (CF_WH*WH_1K) + (CF_WN*WN_1K);                                         
CF_uKH     = (CF_WH*WH_uKH) + (CF_WN*WN_uKH);                                       
CF_uKN     = (CF_WH*WH_uKN) + (CF_WN*WN_uKN);     

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I     = deltaK*K; 
JN_PN = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K = (IN/I)*J_K; 
JN_1Q = (IN/I)*J_Q; 

JH_PN =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKH, uKN; uKj(PN,PH,K)                                 
f11 = ((xi2H/xi1H) + thetaH) - thetaH*(LH_uKH/LH) + thetaH*(KH_uKH/KH); % uKH                
f12 = - thetaH*(LH_uKN/LH) + thetaH*(KH_uKN/KH);  % uKN                                             
f21 = - thetaN*(LN_uKH/LN) + thetaN*(KN_uKH/KN); % uKH                                             
f22 = ((xi2N/xi1N) + thetaN) - thetaN*(LN_uKN/LN) + thetaN*(KN_uKN/KN); % uKN                
                                                                                                               
% PN, PH, K                                                                                                    
g11 = thetaH*(LH_2PN/LH) - thetaH*(KH_1PN/KH); % PN                                                
g12 = thetaH*(LH_2PH/LH) - thetaH*(KH_1PH/KH); % PH                                                
g13 = thetaH*(LH_1K/LH) - thetaH*(KH_2K/KH); % K                                                   
                                                                                                               
g21 = thetaN*(LN_2PN/LN) - thetaN*(KN_1PN/KN); % PN                                                
g22 = thetaN*(LN_2PH/LN) - thetaN*(KN_1PH/KN); % PH                                                
g23 = thetaN*(LN_1K/LN) - thetaN*(KN_2K/KN); % K                                                   
                                                                                                               
M3 = [f11 f12; f21 f22];                                                                                       
X3 = [g11 g12 g13; g21 g22 g23];                                                                               
JST3 = inv(M3);                                                                                                
MST3 = JST3*X3;                                                                                                
                                                                                                               
uKH_PN = MST3(1,1); uKH_PH = MST3(1,2); uKH_1K = MST3(1,3);                                                    
uKN_PN = MST3(2,1); uKN_PH = MST3(2,2); uKN_1K = MST3(2,3);                                                    

% Solving for sectoral labor and sectoral output - Lj,Kj,Wj,Rj,Yj(PN,PH,K)                                                                                                                 
LH_2K = LH_1K + (LH_uKH*uKH_1K) + (LH_uKN*uKN_1K);                                             
LH_PH = LH_2PH + (LH_uKH*uKH_PH) + (LH_uKN*uKN_PH);                                            
LH_PN = LH_2PN + (LH_uKH*uKH_PN) + (LH_uKN*uKN_PN);                                            
                                                                                               
LN_2K = LN_1K + (LN_uKH*uKH_1K) + (LN_uKN*uKN_1K);                                             
LN_PH = LN_2PH + (LN_uKH*uKH_PH) + (LN_uKN*uKN_PH);                                            
LN_PN = LN_2PN + (LN_uKH*uKH_PN) + (LN_uKN*uKN_PN);                                            
                                                                                               
KH_3K = KH_2K +  (KH_uKH*uKH_1K) + (KH_uKN*uKN_1K);                                            
KH_PH = KH_1PH + (KH_uKH*uKH_PH) + (KH_uKN*uKN_PH);                                            
KH_PN = KH_1PN + (KH_uKH*uKH_PN) + (KH_uKN*uKN_PN);                                            
                                                                                               
KN_3K = KN_2K +  (KN_uKH*uKH_1K) + (KN_uKN*uKN_1K);                                            
KN_PH = KN_1PH + (KN_uKH*uKH_PH) + (KN_uKN*uKN_PH);                                            
KN_PN = KN_1PN + (KN_uKH*uKH_PN) + (KN_uKN*uKN_PN);                                            
                                                                                                                                                                                                                                         
RH_2K = RH_1K + (RH_uKH*uKH_1K) + (RH_uKN*uKN_1K);                                             
RH_PH = RH_1PH + (RH_uKH*uKH_PH) + (RH_uKN*uKN_PH);                                            
RH_PN = RH_1PN + (RH_uKH*uKH_PN) + (RH_uKN*uKN_PN);                                            
                                                                                               
RN_2K = RN_1K + (RN_uKH*uKH_1K) + (RN_uKN*uKN_1K);                                             
RN_PH = RN_1PH + (RN_uKH*uKH_PH) + (RN_uKN*uKN_PH);                                            
RN_PN = RN_1PN + (RN_uKH*uKH_PN) + (RN_uKN*uKN_PN);                                            
                                                                                               
YH_2K = YH_1K + (YH_uKH*uKH_1K) + (YH_uKN*uKN_1K);                                             
YH_PH = YH_1PH + (YH_uKH*uKH_PH) + (YH_uKN*uKN_PH);                                            
YH_PN = YH_1PN + (YH_uKH*uKH_PN) + (YH_uKN*uKN_PN);                                            
                                                                                               
YN_2K = YN_1K + (YN_uKH*uKH_1K) + (YN_uKN*uKN_1K);                                             
YN_PH = YN_1PH + (YN_uKH*uKH_PH) + (YN_uKN*uKN_PH); 
YN_PN = YN_1PN + (YN_uKH*uKH_PN) + (YN_uKN*uKN_PN);

CN_2K = CN_1K + (CN_uKH*uKH_1K) + (CN_uKN*uKN_1K);   
CN_PH = CN_2PH + (CN_uKH*uKH_PH) + (CN_uKN*uKN_PH);  
CN_PN = CN_2PN + (CN_uKH*uKH_PN) + (CN_uKN*uKN_PN);  
                                                     
CH_2K = CH_1K + (CH_uKH*uKH_1K) + (CH_uKN*uKN_1K);   
CH_PH = CH_2PH + (CH_uKH*uKH_PH) + (CH_uKN*uKN_PH);  
CH_PN = CH_2PN + (CH_uKH*uKH_PN) + (CH_uKN*uKN_PN);  
                                                     
CF_2K = CF_1K + (CF_uKH*uKH_1K) + (CF_uKN*uKN_1K);   
CF_PH = CF_2PH + (CF_uKH*uKH_PH) + (CF_uKN*uKN_PH);  
CF_PN = CF_2PN + (CF_uKH*uKH_PN) + (CF_uKN*uKN_PN);  

% Solving for traded and non-traded prices: PH,PN(K,Q)     
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1N*uKN_PH);           
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1N*uKN_PN);           
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1H*uKH_PH);   
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1H*uKH_PN);           
                                                            
% K,Q                                                       
k11 = -(YN_2K - CN_2K - JN_1K - (KN*xi1N*uKN_1K));                  
k12 = JN_1Q;                                                
k21 = -(YH_2K - CH_2K - JH_1K - (KH*xi1H*uKH_1K));                  
k22 = JH_1Q;                                                
                                                            
M4 = [h11 h12; h21 h22];                                    
X4 = [k11 k12; k21 k22];                                    
JST4 = inv(M4);                                             
MST4 = JST4*X4;                                             
                                                            
PH_K = MST4(1,1); PH_Q = MST4(1,2);                         
PN_K = MST4(2,1); PN_Q = MST4(2,2);                         
                      
% Solving for Lj,Kj,Wj,Rj,Yj,uKj(K,Q) -                
LH_K = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K);               
LH_Q = (LH_PH*PH_Q) + (LH_PN*PN_Q);                       
LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);               
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);                       
                                                          
KH_K = KH_3K + (KH_PH*PH_K) + (KH_PN*PN_K);               
KH_Q = (KH_PH*PH_Q) + (KH_PN*PN_Q);                       
KN_K = KN_3K + (KN_PH*PH_K) + (KN_PN*PN_K);               
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);                       
                                                                                                                                       
RH_K = RH_2K + (RH_PH*PH_K) + (RH_PN*PN_K);               
RH_Q = (RH_PH*PH_Q) + (RH_PN*PN_Q);                       
RN_K = RN_2K + (RN_PH*PH_K) + (RN_PN*PN_K);               
RN_Q = (RN_PH*PH_Q) + (RN_PN*PN_Q);                       
                                                          
YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K);               
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q);                       
YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);               
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);                       
                                                          
uKH_K = uKH_1K + (uKH_PH*PH_K) + (uKH_PN*PN_K);           
uKH_Q = (uKH_PH*PH_Q) + (uKH_PN*PN_Q);                    
uKN_K = uKN_1K + (uKN_PH*PH_K) + (uKN_PN*PN_K);           
uKN_Q = (uKN_PH*PH_Q) + (uKN_PN*PN_Q);             
                                                   
% Solving for consumption Cj=Cj(lambda,K,Q,ZH,ZN), investment inputs 
% Jj=Jj(K,Q,ZH,ZN), imports MF=MF(lambda,K,Q,ZH,ZN), exports 
%XH=XH(lambda,K,Q,ZH,ZN)- Final Solutions
CN_K  = CN_2K + (CN_PH*PH_K) + (CN_PN*PN_K);            
CN_Q  = (CN_PH*PH_Q) + (CN_PN*PN_Q);                                                                                              
CH_K  = CH_2K + (CH_PH*PH_K) + (CH_PN*PN_K);            
CH_Q  = (CH_PH*PH_Q) + (CH_PN*PN_Q);                                     
CF_K  = CF_2K + (CF_PH*PH_K) + (CF_PN*PN_K);            
CF_Q  = (CF_PH*PH_Q) + (CF_PN*PN_Q);         

JH_K  = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q  = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q); 
JN_K  = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q  = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JF_K  = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q  = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 

XH_K = XH_PH*PH_K; 
XH_Q = XH_PH*PH_Q; 
MF_K = (CF_K + JF_K); 
MF_Q = (CF_Q + JF_Q); 

% Solving for investment function I/K = v(Q/PI)+delta_K - final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 

% Elements of the Jacobian Matrix                                                                                                                                           
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                  
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );                                                                           
Sigma_K   = -( -(RK/K)+(1/K)*( (RH*KH*uKH_K)+(RN*KN*uKN_K)+(RH*KH_K)+(RN*KN_K)+(RH_K*KH)+(RN_K*KN) )-(PH*KH/K)*xi1H*uKH_K-(PN*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) );   
Sigma_Q   = (r+deltaK)-( (1/K)*( (RH*KH*uKH_Q)+(RN*KN*uKN_Q)+(RH*KH_Q)+(RN*KN_Q)+(RH_Q*KH)+(RN_Q*KN) )-(PH*KH/K)*xi1H*uKH_Q-(PN*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) ); 
 
x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    
                                                                      
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
 
% Intertemporal solvency condition - lambda 
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega_21));
H1    = N1/(nu_1-r); 
g(43) = (B - B0) - H1*(K-K0);



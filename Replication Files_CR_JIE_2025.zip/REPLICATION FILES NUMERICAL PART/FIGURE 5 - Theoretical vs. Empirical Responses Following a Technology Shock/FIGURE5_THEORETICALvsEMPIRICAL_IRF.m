clc
clear


% Maximum duration for graphics
Tg = 10;

% Minimum duration for graphics
Tm = 0;

% unit for graph
Tu = 1;

IML_IMK_CAC_TOT_CES_NS_HNTC_NORMALIZED_SYMvsASYM;
IML_IMK_CAC_TOT_CES_NS_NORMALIZED_SYMvsASYM;

%%%%%%%%%%% Impulse Response Functions - FIGURE 2 Main Text %%%%%%%%%%

line_x   = zeros(1,11);

%%%%% IRF Utilization-Adjusted Aggregate TFP ZA %%%%%%%%%%%%%%%%%%%
[xdata1]=xlsread('LP_ZA_rescaled.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LZADJKA');  nbPVAR  = 1;

[obs nbvar1]=size(xdata1);
nptless  = 0;                                % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-0=11)
nptsvar  = obs-nptless;                      % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar1     = nbvar1/3;                        % number of variables included in VAR
irf1      = xdata1(1:obs,nvar1+1:2*nvar1);   % IRF
lowerb1   = xdata1(1:obs,1:nvar1);           % lower bound of IRF
upperb1   = xdata1(1:obs,2*nvar1+1:3*nvar1); % upper bound of IRF

figure(1)
%subplot(3,2,1)
hold on
axis on
axis([0 10 -0.05 1.4]);
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb1(1:11,1)',fliplr(lowerb1(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdZA_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathdZA_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf1(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');


%%%%% IRF Utilization-Adjusted Traded to Non-Traded TFP ZH/ZN %%%%%%%%%%%%%%%%%%%
[xdata37]=xlsread('LP_ZHZN_rescaled.xlsx');
namvar= char('IRF_LZRADJK');  nbPVAR  = 1;

[obs nbvar37]=size(xdata37);
nptless  = 0;
nptsvar  = obs-nptless;
nvar37     = nbvar37/3;
irf37      = xdata37(1:obs,nvar37+1:2*nvar37);
lowerb37   = xdata37(1:obs,1:nvar37);
upperb37   = xdata37(1:obs,2*nvar37+1:3*nvar37);

figure(2)
%subplot(3,2,1)
hold on
axis on
axis([0 10 -0.05 2.2]);
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb37(1:11,1)',fliplr(lowerb37(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdZR_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathdZR_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf37(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');


%%%%% IRF Aggregate Hours L %%%%%%%%%%%%%%%%%%%
[xdata3]=xlsread('LP_L_rescaled.xlsx');
namvar= char('IRF_LABH');  nbPVAR  = 1;

[obs nbvar3]=size(xdata3);
nptless  = 0;
nptsvar  = obs-nptless;
nvar3     = nbvar3/3;
irf3      = xdata3(1:obs,nvar3+1:2*nvar3);
lowerb3   = xdata3(1:obs,1:nvar3);
upperb3   = xdata3(1:obs,2*nvar3+1:3*nvar3);


figure(3)
%subplot(3,2,3)
hold on
axis on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb3(1:11,1)',fliplr(lowerb3(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdL_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathdL_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf3(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');


%%%%% IRF Non-Traded Hours LN %%%%%%%%%%%%%%%%%%%
[xdata12]=xlsread('LP_LN.xlsx');
namvar= char('IRF_LHN');  nbPVAR  = 1;

[obs nbvar12]=size(xdata12);
nptless  = 0;
nptsvar  = obs-nptless;
nvar12     = nbvar12/3;
irf12      = xdata12(1:obs,nvar12+1:2*nvar12);
lowerb12   = xdata12(1:obs,1:nvar12);
upperb12   = xdata12(1:obs,2*nvar12+1:3*nvar12);

figure(4)
hold on
axis on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb12(1:11,1)',fliplr(lowerb12(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdLN_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathdLN_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf12(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');

%%%%% IRF Traded Hours LH %%%%%%%%%%%%%%%%%%%

[xdata18]=xlsread('LP_LH.xlsx');
namvar= char('IRF_LHT');  nbPVAR  = 1;

[obs nbvar18]=size(xdata18);
nptless  = 0;
nptsvar  = obs-nptless;
nvar18     = nbvar18/3;
irf18      = xdata18(1:obs,nvar18+1:2*nvar18);
lowerb18   = xdata18(1:obs,1:nvar18);
upperb18   = xdata18(1:obs,2*nvar18+1:3*nvar18);

figure(5)
hold on
axis on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb18(1:11,1)',fliplr(lowerb18(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdLH_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathdLH_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf18(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');


%%%%% IRF Hours Worked Share of Tradables LH/L %%%%%%%%%%%%%%%%%%%
%[xdata21]=xlsread('LP_IRF_to_ZAadjK_LHTH_rescaled.xlsx');
[xdata21]=xlsread('LP_LHS.xlsx');
namvar= char('IRF_LHTH');  nbPVAR  = 1;

[obs nbvar21]=size(xdata21);
nptless  = 0;
nptsvar  = obs-nptless;
nvar21     = nbvar21/3;
irf21      = xdata21(1:obs,nvar21+1:2*nvar21);
lowerb21   = xdata21(1:obs,1:nvar21);
upperb21   = xdata21(1:obs,2*nvar21+1:3*nvar21);

figure(6)
hold on
axis on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb21(1:11,1)',fliplr(lowerb21(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdLHS_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathdLHS_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf21(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');

%%%%% IRF Non-Traded to Traded Wage WN/W %%%%%%%%%%%%%%%%%%%
[xdata16]=xlsread('LP_WNW.xlsx');
namvar= char('IRF_LRWNW');  nbPVAR  = 1;

[obs nbvar16]=size(xdata16);
nptless  = 0;
nptsvar  = obs-nptless;
nvar16     = nbvar16/3;
irf16      = xdata16(1:obs,nvar16+1:2*nvar16);
lowerb16   = xdata16(1:obs,1:nvar16);
upperb16   = xdata16(1:obs,2*nvar16+1:3*nvar16);


figure(7)
hold on
axis on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb16(1:11,1)',fliplr(lowerb16(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdWNW_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathdWNW_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf16(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');

%%%%% IRF Traded Labor Income Share sLH %%%%%%%%%%%%%%%%%%%
[xdata25]=xlsread('LP_LISH.xlsx');
namvar= char('IRF_LLST0');  nbPVAR  = 1;

[obs nbvar25]=size(xdata25);
nptless  = 0;
nptsvar  = obs-nptless;
nvar25     = nbvar25/3;
irf25      = xdata25(1:obs,nvar25+1:2*nvar25);
lowerb25   = xdata25(1:obs,1:nvar25);
upperb25   = xdata25(1:obs,2*nvar25+1:3*nvar25);

figure(8)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb25(1:11,1)',fliplr(lowerb25(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdLISH_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathdLISH_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf25(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');

%%%%% IRF Non-Traded Labor Income Share sLN %%%%%%%%%%%%%%%%%%%
[xdata23]=xlsread('LP_LISN.xlsx');
namvar= char('IRF_LLSN0');  nbPVAR  = 1;

[obs nbvar23]=size(xdata23);
nptless  = 0;
nptsvar  = obs-nptless;
nvar23     = nbvar23/3;
irf23      = xdata23(1:obs,nvar23+1:2*nvar23);
lowerb23   = xdata23(1:obs,1:nvar23);
upperb23   = xdata23(1:obs,2*nvar23+1:3*nvar23);

figure(9)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb23(1:11,1)',fliplr(lowerb23(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdLISN_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathdLISN_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf23(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');

%%%%% IRF Current Account CA % of GDP %%%%%%%%%%%%%%%%%%%
[xdata30]=xlsread('LP_CAY.xlsx');
namvar= char('IRF_CAY');  nbPVAR  = 1;

[obs nbvar30]=size(xdata30);
nptless  = 0;
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar30     = nbvar30/3;                       % number of variables included in VAR
irf30      = xdata30(1:obs,nvar30+1:2*nvar30);    % IRF of variables
lowerb30   = xdata30(1:obs,1:nvar30);           % lower bound of IRF
upperb30   = xdata30(1:obs,2*nvar30+1:3*nvar30);  % upper bound of IRF

figure(10)
hold on
axis on
axis([0 10 -0.06 0.06]);
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb30(1:11,1)',fliplr(lowerb30(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathCAY_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathCAY_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf30(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');

%%%%% IRF Relative Price of Non-Tradables PN/PH %%%%%%%%%%%%%%%%%%%
[xdata9]=xlsread('LP_PNPH.xlsx');
namvar= char('IRF_LRPNT');  nbPVAR  = 1;

[obs nbvar9]=size(xdata9);
nptless  = 0;
nptsvar  = obs-nptless;
nvar9     = nbvar9/3;
irf9      = xdata9(1:obs,nvar9+1:2*nvar9);
lowerb9   = xdata9(1:obs,1:nvar9);
upperb9   = xdata9(1:obs,2*nvar9+1:3*nvar9);


figure(11)
hold on
axis on
axis([0 10 -0.05 3]);
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb9(1:11,1)',fliplr(lowerb9(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdP_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathdP_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf9(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');

%%%%% IRF Terms of Trade PH %%%%%%%%%%%%%%%%%%%
[xdata33]=xlsread('LP_PHPHSTAR.xlsx');
namvar= char('IIRF_LRPHPHSTAR');  nbPVAR  = 1;

[obs nbvar33]=size(xdata33);
nptless  = 0;
nptsvar  = obs-nptless;
nvar33     = nbvar33/3;
irf33      = xdata33(1:obs,nvar33+1:2*nvar33);
lowerb33   = xdata33(1:obs,1:nvar33);
upperb33   = xdata33(1:obs,2*nvar33+1:3*nvar33);

figure(12)
hold on
axis on
axis([0 10 -3 0.05]);
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb33(1:11,1)',fliplr(lowerb33(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdPH_bias(2:12),'-ks','LineWidth',6);
plot(timeperm(2:12),pathdPH_hntc(2:12),'red','LineWidth',5,'LineStyle','--');
plot(timeperm(2:12),irf33(1:11,1)','blue','LineWidth',6);
plot(timeperm(2:12),line_x(1:11),'black','LineWidth',2);
hold off
box on;
legend('Baseline (FBTC)','Restricted (HNTC)','LP (data)');

clear
